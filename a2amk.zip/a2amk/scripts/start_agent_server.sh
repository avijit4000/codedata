#!/bin/sh
set -e

# Multi-agent startup helper
# Usage examples:
#   ./scripts/start_agent_server.sh
#   ./scripts/start_agent_server.sh --mcp-cert /path/to/standard_trusts.pem
#   ./scripts/start_agent_server.sh --agents "dynatrace,coder" --host 0.0.0.0 --port 8102

# Defaults
: "${MULTI_AGENT_CONFIG_NAMES:=servicenow,coder}"
# : "${MULTI_AGENT_CONFIG_NAMES:=dynatrace,coder,servicenow,release_compliance,azure,certificate}"
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-8102}

MCP_CERT=""
AZURE_VERIFY_UNSET=true

while [ $# -gt 0 ]; do
	case "$1" in
		--mcp-cert)
			MCP_CERT="$2"
			shift 2
			;;
		--azure-verify)
			export AZURE_OPENAI_HTTP_VERIFY="$2"
			AZURE_VERIFY_UNSET=false
			shift 2
			;;
		--agents)
			MULTI_AGENT_CONFIG_NAMES="$2"
			shift 2
			;;
		--host)
			HOST="$2"
			shift 2
			;;
		--port)
			PORT="$2"
			shift 2
			;;
		-h|--help)
			echo "Usage: $0 [--mcp-cert PATH] [--azure-verify PATH|truststore] [--agents NAMES] [--host HOST] [--port PORT]"
			exit 0
			;;
		*)
			echo "Unknown arg: $1"
			exit 1
			;;
	esac
done

export MULTI_AGENT_CONFIG_NAMES
export HOST
export PORT

if [ -n "$MCP_CERT" ]; then
	export MCP_HTTP_VERIFY="$MCP_CERT"
	echo "Using MCP cert: $MCP_HTTP_VERIFY"
fi

# If AZURE_OPENAI_HTTP_VERIFY was not explicitly set, unset it so the code
# will prefer the Certifi CA bundle for Azure traffic (recommended).
if [ "$AZURE_VERIFY_UNSET" = "true" ]; then
	unset AZURE_OPENAI_HTTP_VERIFY
	echo "AZURE_OPENAI_HTTP_VERIFY unset (Azure will use Certifi CA bundle)"
else
	echo "AZURE_OPENAI_HTTP_VERIFY set to: $AZURE_OPENAI_HTTP_VERIFY"
fi

echo "Starting agent server with MULTI_AGENT_CONFIG_NAMES=$MULTI_AGENT_CONFIG_NAMES on $HOST:$PORT"

# Python launcher: try to run agents.base_agent.main, else fall back to orchestrator
python - <<'PY'
import importlib, sys, os
try:
	m = importlib.import_module('agents.base_agent.main')
	print('Launching agents.base_agent.main')
	m.main(os.getenv('HOST','0.0.0.0'), int(os.getenv('PORT','8102')))
except Exception as e:
	print('agents.base_agent.main not available, falling back to agents.a2a_orchestrator.orch_main:', e)
	try:
		m2 = importlib.import_module('agents.a2a_orchestrator.orch_main')
		import asyncio
		asyncio.run(m2.main())
	except Exception as e2:
		print('Failed to start orchestrator:', e2)
		sys.exit(1)
PY

