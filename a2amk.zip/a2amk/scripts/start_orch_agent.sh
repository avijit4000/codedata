#!/bin/sh
# POSIX/sh-compatible start script for the orchestrator.
# Edit AGENTS_DEFAULT to enable/disable default agents.

# Default agents (space-separated)
AGENTS_DEFAULT="coder_agent release_compliance_agent servicenow_agent certificate_agent"
AGENTS_DEFAULT="coder_agent servicenow_agent"

# Mode: local or prod
MODE="${MODE:-local}"

# Virtualenv python path (override with PYTHON env if needed)
VENV_BIN="${PWD}/.venv/bin"
PYTHON="${PYTHON:-${VENV_BIN}/python}"

# FastAPI host/port defaults
FASTAPI_HOST="${FASTAPI_HOST:-127.0.0.1}"
FASTAPI_PORT="${FASTAPI_PORT:-8093}"

# Agents list: override with AGENTS_LIST (space-separated) or AGENTS_ON
AGENTS_LIST="${AGENTS_LIST:-$AGENTS_DEFAULT}"
if [ -n "$AGENTS_ON" ]; then
  AGENTS_LIST="$AGENTS_ON"
fi

# Base host per mode (override BASE_HOST if you want a custom URL)
if [ "$MODE" = "local" ]; then
  BASE_HOST="http://localhost:8102"
else
  BASE_HOST="${BASE_HOST:-https://agents.example.com}"
fi

# Build REMOTE_AGENT_URLS JSON (POSIX-safe)
REMOTE_AGENT_URLS='['
first=1
for agent in $AGENTS_LIST; do
  # Allow per-agent disable via ENABLE_<agent> environment variable (set to 0/false)
  ENABLE_VAR_NAME="ENABLE_${agent}"
  enabled_value=""
  # eval to read variable whose name is in ENABLE_VAR_NAME
  eval "enabled_value=\${$ENABLE_VAR_NAME}"
  if [ -n "$enabled_value" ]; then
    case "$enabled_value" in
      0|false|False) continue ;;
    esac
  fi

  # derive path by stripping trailing _agent if present
  path=`expr "$agent" : '\(.*\)_agent$'`
  if [ -z "$path" ]; then
    path="$agent"
  fi

  if [ "$first" -eq 1 ]; then
    first=0
  else
    REMOTE_AGENT_URLS="$REMOTE_AGENT_URLS,"
  fi

  REMOTE_AGENT_URLS="$REMOTE_AGENT_URLS{"`printf '%s' "\"name\":\"$agent\",\"url\":\"$BASE_HOST/agents/$path/\""`"}"
done
REMOTE_AGENT_URLS="$REMOTE_AGENT_URLS]"

export REMOTE_AGENT_URLS
export FASTAPI_HOST FASTAPI_PORT

# Fallback to system python if venv python not available
if [ ! -x "$PYTHON" ]; then
  PYTHON="`command -v python3 || command -v python || true`"
fi

exec "$PYTHON" -m agents.a2a_orchestrator.orch_main
