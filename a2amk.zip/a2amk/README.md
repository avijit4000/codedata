# a2a_poc
A2A Proof of Concept development

Deploy each agent separately

## Single-pod base agents (multi-agent mode)

If you want **one Kubernetes pod** to host **multiple base agents**, you can run the base agent server in *multi-agent mode*.

- Start command: `python -m agents.base_agent.main`
- Enable multi-agent mode by setting `MULTI_AGENT_CONFIG_NAMES` (comma-separated config names from `configs/`)

- To ensure Agent Cards advertise the externally reachable URL (e.g. through an ingress), set `A2A_AGENT_HOST`.
	Example:
	- `A2A_AGENT_HOST=https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/gpd-ops-a2a-api-agent`
	The server will publish agent cards with URLs like `.../agents/coder/`.

Example:

```bash
export MULTI_AGENT_CONFIG_NAMES="dynatrace,coder,certificate,servicenow"
export HOST=0.0.0.0
export PORT=8098
python -m agents.base_agent.main
```

Routing:

- Root listing: `GET /agents`
- Root health (aggregated MCP health): `GET /health`
- Per-agent mount path: `/<mount>` where `mount=/agents/<config>`
- Per-agent health: `GET /agents/<config>/health`

Orchestrator config:

- When all base agents share one service URL, set each remote agent URL to the mounted path, e.g.
	`https://<your-service>/agents/dynatrace` and `https://<your-service>/agents/certificate`.

### MCP dependency health + pod restart

By default the base agent server will return `503` on health when any dependent MCP is down, and it will exit after repeated failures so Kubernetes restarts the pod.

Environment variables:

- `MCP_HEALTHCHECK_ENABLED` (default `true`)
- `MCP_HEALTHCHECK_CRASH_ON_FAILURE` (default `true`)
- `MCP_HEALTHCHECK_INTERVAL_SECONDS` (default `15`)
- `MCP_HEALTHCHECK_FAILURE_THRESHOLD` (default `2`)
- `AGENT_EVALUATION_ENABLED` (default `false`) - enables optional evaluation metrics (may add heavy dependencies and latency)

## Why your current Deployment can't create "one pod per container"

In Kubernetes, a **Deployment** creates replicas of a **Pod template**. A Pod can contain multiple containers, but those containers are always co-scheduled together and scaled together.

That means:
- A single Deployment cannot dynamically create a variable number of Pods based on a container list.
- Environment variables inside a Pod also cannot cause Kubernetes to create *more* Pods.

To get **one Pod per agent** (coder/fetch/dynatrace/orchestrator), you need **one controller per agent** (e.g., 4 Deployments), or you need a templating/generation step (Helm, Kustomize+plugin, CI rendering, etc.).

## One list controls how many agent pods exist (Helm)

This repo includes a minimal Helm chart at `helm/gpd-ops-a2a-api` that renders **one Deployment + one Service per agent** from a single list:

- Edit `helm/gpd-ops-a2a-api/values.yaml` and add/remove items under `agents:`
- Each item creates a separate Deployment (so it becomes its own Pod(s))

### Render (no cluster changes)

Install Helm if needed:
- macOS (Homebrew): `brew install helm`

Render manifests:
- `helm template gpd-ops-a2a-api helm/gpd-ops-a2a-api --namespace default > rendered.yaml`

Apply:
- `kubectl apply -n default -f rendered.yaml`

### Configure as a single list

The single source of truth is the `agents:` list in `helm/gpd-ops-a2a-api/values.yaml`.

## Helm-free fallback: generate YAML with python3

If you can't use Helm, you can generate the same "one pod per agent" layout using:

- `python3 deploy/render_agents.py --namespace default --image centraluhg.jfrog.io/gpd-docker-vir/gpd-ops-a2a-api:YOUR_TAG > rendered.yaml`
- `kubectl apply -n default -f rendered.yaml`

## Coder Agent

To deploy the coder agent, run coder_main.py

## Fetch Agent

To deploy fetch agent, run main.py

## A2A Orchestrator

To deploy the orchestrator, run orch_main.py to have UI based chat interface.
Else, run orchestrator.py, to run it in terminal.

## TLS trust bundle for MCP HTTP

If your MCP endpoints use a private CA, set `MCP_HTTP_VERIFY` to the path of a PEM/CA bundle file (same idea as `httpx(verify=...)`).

- Example: `export MCP_HTTP_VERIFY=/path/to/standard_trusts.pem`

This is applied process-wide for outbound HTTP(S) clients via `SSL_CERT_FILE` / `REQUESTS_CA_BUNDLE` / `CURL_CA_BUNDLE`.

