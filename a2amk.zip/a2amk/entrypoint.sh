#!/bin/sh
set -e

# Determine which agent to run based on AGENT_TYPE environment variable
case "${AGENT_TYPE}" in
  orchestrator)
    echo "Starting Orchestrator Agent..."
    exec python -m agents.a2a_orchestrator.orch_main
    ;;
  base)
    echo "Starting Base Agent..."
    exec python -m agents.base_agent.main
    ;;
  coder)
    echo "Starting Coder Agent..."
    exec python -m agents.base_agent.main
    ;;
  latency)
    echo "Starting Latency Agent..."
    exec python -m agents.base_agent.main
    ;;
  fetch)
    echo "Starting Fetch Agent..."
    exec python -m agents.base_agent.main
    ;;
  dynatrace)
    echo "Starting Dynatrace Agent..."
    exec python -m agents.base_agent.main
    ;;
  azure)
    echo "Starting Azure Agent..."
    exec python -m agents.base_agent.main
    ;;
  servicenow)
    echo "Starting ServiceNow Agent..."
    exec python -m agents.base_agent.main
    ;;
  elasticsearch)
    echo "Starting Elasticsearch Agent..."
    exec python -m agents.base_agent.main
    ;;
  *)
    echo "Error: AGENT_TYPE environment variable must be set to one of:  orchestrator, coder, fetch, dynatrace, azure, servicenow, elasticsearch"
    echo "Example: docker run -e AGENT_TYPE=orchestrator autogen-agent: latest"
    exit 1
    ;;
esac