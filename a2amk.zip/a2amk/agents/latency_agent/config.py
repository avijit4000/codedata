import os
import json, asyncio
from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
from datetime import datetime

# Read from environment variables, default to localhost for local development
HOST = os.getenv('LATENCY_HOST', 'localhost')
PORT = int(os.getenv('LATENCY_AGENT_PORT', '8091'))

# Agent name defined in config.yaml file or kuberneters configMap yaml config to create model client and MCP Server connection.
agent_name_in_yaml_config = "latency_agent" 

agent_prompt = f"""You are a helpful assistant that fetches and analyze latency report and other data using the tools provided. 
                        Today's date is {datetime.today().strftime("%Y/%m/%d")}.
                        If the date or datetime provided is not in the correct datatype, convert it to the datatype accepted by the tool.
                        Infer the arguments required for the tool from the user request.
                        Strictly include all the function call/tool call responses in your final response to the user. Include all the IDs.

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        """


agent_name = "latency_agent"
agent_type = "latency_agent"

# Define MCP Parameters in the .env file using the below format for local development
FETCHER_MCP_SERVERS = [{"name": "latency_server","type": "http", "url": "http://127.0.0.1:8012/latency/mcp"}]
