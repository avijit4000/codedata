import asyncio
from dataclasses import dataclass
from pydantic import BaseModel
import json
from autogen_core import (DefaultTopicId, 
                          MessageContext, 
                          RoutedAgent, 
                          default_subscription, 
                          message_handler,
                          FunctionCall)
from autogen_core import AgentId, SingleThreadedAgentRuntime
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage, 
    UserMessage, 
    CreateResult, 
    AssistantMessage,
    LLMMessage,
    FunctionExecutionResult,
    FunctionExecutionResultMessage,
)
from dotenv import load_dotenv
from autogen_core.model_context import BufferedChatCompletionContext, ChatCompletionContext, UnboundedChatCompletionContext
from autogen_core.tools import FunctionTool, Tool, Workbench, ToolResult
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
from typing import Annotated, Any, AsyncGenerator, Callable, Coroutine, Dict, List, Optional, Sequence, Tuple, Literal

import os, json, importlib
script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
from agents_logger import logger
from agents.autogen_base_agent.config_loader import require_and_apply_selected_agent_config

load_dotenv()
require_and_apply_selected_agent_config()

config_module = importlib.import_module(f"agents.{script_folder}.config")
agent_base_config = config_module.agent_base_config

from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent, AgentInputMessage
from agents.autogen_base_agent.agent_invocation import agent_invocation
from agents.autogen_base_agent.utils import create_model_client

class ResponseFormat(BaseModel):
    status: Literal["completed", "input_required", "error"]
    agent_response: Annotated[str, "exact fetched data or the error message or the message asking for more information"]

llm_response_structure = {
    "type": "json_schema",
    "json_schema": {
       "name": f"{agent_base_config.agent_name}Response",
       "description": f"Response from the {agent_base_config.agent_display_name} Agent",
       # Use the schema directly without the wrapper to ensure consistent format
       "schema": {
           "type": "object",
           "properties": {
               "status": {
                   "type": "string",
                   "enum": ["completed", "input_required", "error"]
               },
               "agent_response": {
                   "type": "string",
                   "description": "fetched data or the error message or the message asking for more information"
               }
           },
           "required": ["status", "agent_response"],
           "additionalProperties": False
       },
       "strict": True
    }
}

# Create LLM Model Client
llm_model_client = create_model_client(agent_base_config.agent_name_in_yaml_config, 
                                        llm_response_structure = llm_response_structure,
                                        )


# Instance to create the dynatrace agent
# Instance used to create a agent factory and runtime for the agent,
# Instance used to nvoke the agent with user messages.  

agent_instance = agent_invocation(
    agent_name=agent_base_config.agent_name,
    agent_description=agent_base_config.agent_description,
    model_client=llm_model_client,
    agent_type=agent_base_config.agent_type,
    markdown_summary = agent_base_config.markdown_summary,
    system_message=[SystemMessage(content=agent_base_config.azure_agent_prompt)],
    model_context=BufferedChatCompletionContext(buffer_size=3, initial_messages=[]),
    agent_name_in_yaml_config=agent_base_config.agent_name_in_yaml_config,    # mcp_params=mcp_params
    )

tool_descriptions = asyncio.run(
    agent_instance.get_tool_descriptions(include_tool_schema=False, include_tool_params=True)
)

# The following is a more detailed dynamic description including tool capabilities.
# It is used by the orchestrator to understand what the agent can do.

if agent_instance.mcp_params:
    # If MCP servers are configured, append discovered tool descriptions to the
    # agent description so the orchestrator has accurate capabilities.
    if tool_descriptions and tool_descriptions.strip():
        agent_base_config.agent_description = (
            f"{agent_base_config.agent_description.rstrip()}\n\n"
            f"Available MCP tools:\n{tool_descriptions.strip()}\n"
        )
    else:
        agent_base_config.agent_description = (
            f"{agent_base_config.agent_description.rstrip()}\n\n"
            "MCP servers are configured, but no tools were discovered.\n"
        )

    # Keep the invocation instance in sync (this is what the runtime factory uses).
    agent_instance.agent_description = agent_base_config.agent_description

if __name__ == "__main__":
    import asyncio
    # runtime = asyncio.run(create_runtime()) 
    runtime = asyncio.run(agent_instance.create_runtime())
    while True:
        user_message = input("Enter your message: ")

        if not user_message == "quit":
            response = asyncio.run(agent_instance.invoke_agent(runtime, user_message))
            print("Agent response:", response)
        else:
            break
    
    
    