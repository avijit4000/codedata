import os
import sys
import traceback
import importlib
import json
from datetime import datetime

import click
import httpx
import uvicorn, asyncio
import contextlib
import time
import yaml

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import (
    BasePushNotificationSender,
    InMemoryPushNotificationConfigStore,
    InMemoryTaskStore,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import (
    InternalError,
)
from a2a.utils import new_agent_text_message, new_task
from a2a.utils.errors import ServerError
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TaskState,
)
from dotenv import load_dotenv
from starlette.applications import Starlette
from starlette.responses import JSONResponse

from agents.autogen_base_agent.config_loader import require_and_apply_selected_agent_config
from agents.autogen_base_agent.config_loader import load_agent_config
from agents.autogen_base_agent.utils import create_model_client, get_model_params
from agents.autogen_base_agent.agent_invocation import agent_invocation
from autogen_core.models import SystemMessage
from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent
from autogen_core.model_context import BufferedChatCompletionContext
from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
from agents_logger import logger

def _split_csv(value: str) -> list[str]:
    if not value:
        return []
    return [v.strip() for v in value.split(",") if v.strip()]


def _load_global_llm_models() -> dict:
    """Load global llm_models mapping from APP_CONFIG_YAML or config.yaml."""
    try:
        config_yaml_str = os.getenv("APP_CONFIG_YAML")
        if config_yaml_str:
            config = yaml.safe_load(config_yaml_str) or {}
            if isinstance(config, dict) and isinstance(config.get("llm_models"), dict):
                return config["llm_models"]
    except Exception as e:
        logger.warning(f"Error reading llm_models from APP_CONFIG_YAML: {e}")

    try:
        with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
            config = yaml.safe_load(file) or {}
            if isinstance(config, dict) and isinstance(config.get("llm_models"), dict):
                return config["llm_models"]
    except FileNotFoundError:
        logger.warning("config.yaml not found while loading llm_models")
    except Exception as e:
        logger.warning(f"Error reading llm_models from config.yaml: {e}")
    return {}


def _build_mcp_params_from_details(details: dict) -> list:
    mcp_servers = details.get("mcp_servers")
    if not mcp_servers:
        return []

    def _resolve_url(server_cfg: dict) -> str:
        if server_cfg.get("url"):
            return str(server_cfg["url"]).strip()
        host = server_cfg.get("mcp_host")
        path = server_cfg.get("mcp_path")
        if host and path:
            return f"{str(host).rstrip('/')}/{str(path).lstrip('/')}"
        raise KeyError("Missing MCP endpoint; expected 'url' or ('mcp_host' and 'mcp_path')")

    params = []
    if not isinstance(mcp_servers, list):
        raise ValueError("details.mcp_servers must be a list")

    for config in mcp_servers:
        server_type = str(config.get("type", "http")).lower()
        if server_type in ["http", "streamablehttp"]:
            kwargs = {"url": _resolve_url(config)}
            if config.get("headers") is not None:
                kwargs["headers"] = config["headers"]
            if config.get("timeout") is not None:
                kwargs["timeout"] = config["timeout"]
            if config.get("sse_read_timeout") is not None:
                kwargs["sse_read_timeout"] = config["sse_read_timeout"]
            if config.get("terminate_on_close") is not None:
                kwargs["terminate_on_close"] = config["terminate_on_close"]
            params.append(StreamableHttpServerParams(**kwargs))
        elif server_type == "sse":
            params.append(SseServerParams(url=_resolve_url(config)))
        elif server_type == "stdio":
            params.append(
                StdioServerParams(
                    command=config["command"],
                    args=config.get("args", []),
                    env=config.get("env", {}),
                )
            )
        else:
            raise ValueError(f"Unsupported MCP server type: {server_type}")

    return params


class _BoundAgentExecutor(AgentExecutor):
    """AgentExecutor that is bound to a specific agent_invocation instance."""

    def __init__(self, agent_instance: agent_invocation, agent_display_name: str):
        self._agent_instance = agent_instance
        self._agent_display_name = agent_display_name

    async def execute(self, request_context: RequestContext, event_queue: EventQueue) -> None:
        try:
            user_message = request_context.get_user_input()

            task = request_context.current_task
            if not task:
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)

            task_updater = TaskUpdater(event_queue, task.id, task.context_id)
            response = await self._agent_instance.invoke_agent(user_message)
            if isinstance(response, str):
                try:
                    response = json.loads(response)
                except Exception:
                    response = {"status": "completed", "agent_response": response}

            if isinstance(response, dict) and "properties" in response and "status" in response.get("properties", {}):
                response = response["properties"]

            response_str = ""
            if isinstance(response, dict):
                for k, v in response.items():
                    if k != "status":
                        response_str += f"{k}:\n {v}\n\n"
            else:
                response_str = str(response)

            status = response.get("status") if isinstance(response, dict) else None
            if status == "error":
                await task_updater.update_status(
                    TaskState.failed,
                    new_agent_text_message(
                        text=response_str,
                        context_id=task.context_id,
                        task_id=task.id,
                    ),
                    final=True,
                )
            elif status == "input_required":
                await task_updater.update_status(
                    TaskState.input_required,
                    new_agent_text_message(
                        text=response_str,
                        context_id=task.context_id,
                        task_id=task.id,
                    ),
                    final=False,
                )
            else:
                await task_updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(
                        text=response_str,
                        context_id=task.context_id,
                        task_id=task.id,
                    ),
                    final=True,
                )
        except Exception as e:
            logger.error(f"{self._agent_display_name} executor failed: {traceback.format_exc()}")
            raise ServerError(error=InternalError(message=f"{self._agent_display_name} executor failed: {str(e)}"))

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Handle cancellation of an in-flight task."""
        logger.info(f"{self._agent_display_name} received cancel request")
        task = context.current_task
        if task:
            task_updater = TaskUpdater(event_queue, task.id, task.context_id)
            await task_updater.update_status(
                TaskState.failed,
                new_agent_text_message(
                    text="Task cancelled by user.",
                    context_id=task.context_id,
                    task_id=task.id,
                ),
                final=True,
            )


def _run_single_agent(host: str | None, port: int | None) -> None:
    # Backward compatible single-agent mode.
    require_and_apply_selected_agent_config()
    script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
    A2AAgentExecutor = importlib.import_module(f"agents.{script_folder}.agent_executor").A2AAgentExecutor
    config_module = importlib.import_module(f"agents.{script_folder}.config")
    agent_module = importlib.import_module(f"agents.{script_folder}.agent")
    agent_base_config = config_module.agent_base_config

    host = host or agent_base_config.HOST
    port = port or agent_base_config.PORT

    capabilities = AgentCapabilities(streaming=False, push_notifications=False)
    skills = []
    for skill_config in agent_base_config.agent_skill_configs:
        skills.append(
            AgentSkill(
                id=skill_config.agent_skill_id,
                name=skill_config.agent_skill_name,
                description="agent_skill",
                tags=skill_config.agent_skill_tags,
                examples=skill_config.agent_skill_examples,
            )
        )
    agent_card = AgentCard(
        name=agent_base_config.agent_card_config.agent_name,
        description=agent_base_config.agent_description,
        url=agent_base_config.agent_card_config.agent_card_url,
        version=agent_base_config.agent_card_config.agent_version,
        default_input_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
        default_output_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
        capabilities=capabilities,
        skills=skills,
    )

    httpx_client = httpx.AsyncClient()
    push_config_store = InMemoryPushNotificationConfigStore()
    push_sender = BasePushNotificationSender(httpx_client=httpx_client, config_store=push_config_store)
    request_handler = DefaultRequestHandler(
        agent_executor=A2AAgentExecutor(),
        task_store=InMemoryTaskStore(),
        push_config_store=push_config_store,
        push_sender=push_sender,
    )
    server = A2AStarletteApplication(agent_card=agent_card, http_handler=request_handler)
    app = server.build()

    has_mcp_dependencies = bool(getattr(agent_module.agent_instance, "mcp_params", None))
    app.state.mcp_health = {
        "ok": True,
        "last_checked": None,
        "error": None,
        "consecutive_failures": 0,
    }

    async def _check_mcp_once() -> bool:
        if not has_mcp_dependencies:
            app.state.mcp_health.update(
                {"ok": True, "last_checked": time.time(), "error": None, "consecutive_failures": 0}
            )
            return True
        try:
            ok = await agent_module.agent_instance.check_mcp_health()
            app.state.mcp_health["ok"] = bool(ok)
            app.state.mcp_health["last_checked"] = time.time()
            if ok:
                app.state.mcp_health["error"] = None
                app.state.mcp_health["consecutive_failures"] = 0
            else:
                app.state.mcp_health["error"] = "MCP health check failed"
                app.state.mcp_health["consecutive_failures"] = int(app.state.mcp_health.get("consecutive_failures", 0)) + 1
            return bool(ok)
        except Exception as e:
            app.state.mcp_health["ok"] = False
            app.state.mcp_health["last_checked"] = time.time()
            app.state.mcp_health["error"] = f"MCP health check exception: {type(e).__name__}: {e}"
            app.state.mcp_health["consecutive_failures"] = int(app.state.mcp_health.get("consecutive_failures", 0)) + 1
            return False

    async def _health(request):
        state = getattr(app.state, "mcp_health", None) or {}
        if not has_mcp_dependencies:
            return JSONResponse({"status": "ok"})
        if state.get("ok"):
            return JSONResponse({"status": "ok", "mcp": "ok", "last_checked": state.get("last_checked")})
        return JSONResponse(
            {
                "status": "unhealthy",
                "mcp": "down",
                "error": state.get("error"),
                "last_checked": state.get("last_checked"),
                "consecutive_failures": state.get("consecutive_failures"),
            },
            status_code=503,
        )

    app.add_route("/health", _health, methods=["GET"])
    app.add_route("/health/live", _health, methods=["GET"])

    monitor_enabled = os.getenv("MCP_HEALTHCHECK_ENABLED", "true").lower() in {"1", "true", "yes"}
    if monitor_enabled:
        mcp_health = asyncio.run(_check_mcp_once())
        if not mcp_health:
            logger.error(
                f"MCP server health check failed at startup. Aborting {agent_base_config.agent_display_name} server startup."
            )
            sys.exit(1)
    crash_on_failure = os.getenv("MCP_HEALTHCHECK_CRASH_ON_FAILURE", "true").lower() in {"1", "true", "yes"}
    interval_seconds = float(os.getenv("MCP_HEALTHCHECK_INTERVAL_SECONDS", "15"))
    failure_threshold = int(os.getenv("MCP_HEALTHCHECK_FAILURE_THRESHOLD", "2"))

    async def _monitor_mcp_health() -> None:
        if not (monitor_enabled and has_mcp_dependencies):
            return
        logger.info(
            f"Starting MCP dependency monitor (interval={interval_seconds}s, threshold={failure_threshold}, crash={crash_on_failure})"
        )
        while True:
            ok = await _check_mcp_once()
            failures = int(app.state.mcp_health.get("consecutive_failures", 0))
            if (not ok) and crash_on_failure and failures >= failure_threshold:
                logger.error(f"MCP dependencies unhealthy for {failures} consecutive checks; exiting to trigger pod restart.")
                os._exit(1)
            await asyncio.sleep(interval_seconds)

    async def _on_startup() -> None:
        app.state._mcp_monitor_task = asyncio.create_task(_monitor_mcp_health())

    async def _on_shutdown() -> None:
        task = getattr(app.state, "_mcp_monitor_task", None)
        if task is not None:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    app.add_event_handler("startup", _on_startup)
    app.add_event_handler("shutdown", _on_shutdown)

    logger.info(f"Starting {agent_base_config.agent_display_name} server.")
    uvicorn.run(app, host=host, port=port)


def _run_multi_agent(host: str | None, port: int | None, config_names: list[str]) -> None:
    if not config_names:
        raise ValueError("MULTI_AGENT_CONFIG_NAMES is empty")

    host = host or os.getenv("HOST", "0.0.0.0")
    port = port or int(os.getenv("PORT", "8098"))

    llm_models = _load_global_llm_models()
    if not llm_models:
        logger.warning("No llm_models found in APP_CONFIG_YAML or config.yaml; model client creation may fail")

    # Public URL base used in agent cards.
    # Prefer an externally reachable https host (e.g. ingress) over bind host/port.
    #
    # Expected values:
    #   A2A_AGENT_HOST=https://<domain>/<optional-prefix>
    # Resulting per-agent card URL:
    #   {A2A_AGENT_HOST}/agents/<agent>/
    base_url = (
        os.getenv("A2A_MULTI_BASE_URL")
        or os.getenv("A2A_AGENT_HOST")
        or os.getenv("AGENT_URL_BASE")
    )
    if not base_url:
        base_url = f"http://{host}:{port}"
    base_url = base_url.rstrip("/")
    if base_url.startswith("http://0.0.0.0"):
        logger.warning(
            "Agent cards will advertise an unroutable URL (%s). Set A2A_AGENT_HOST (or A2A_MULTI_BASE_URL) to the external https host.",
            base_url,
        )

    # Shared HTTP infra for push sender
    httpx_client = httpx.AsyncClient()
    push_config_store = InMemoryPushNotificationConfigStore()
    push_sender = BasePushNotificationSender(httpx_client=httpx_client, config_store=push_config_store)

    root_app = Starlette()
    root_app.state.agents = {}
    root_app.state.mcp_health = {}

    def _agent_slug(config_name: str) -> str:
        return config_name.strip().lower().removesuffix("_agent").removesuffix(".yaml").removesuffix(".yml")

    for cfg_name in config_names:
        cfg = load_agent_config(cfg_name)
        details = cfg.get("details") or {}
        display_name = cfg.get("agent_display_name") or cfg.get("name") or cfg_name
        version = details.get("agent_version") or "1.0.0"
        cfg_llm_model = (details.get("llm_model") or cfg.get("llm_model") or os.getenv("LLM_MODEL"))
        if not cfg_llm_model:
            raise ValueError(f"Config '{cfg_name}' missing details.llm_model")

        model_params = llm_models.get(cfg_llm_model)
        if model_params is None:
            # Fallback to existing helper (reads APP_CONFIG_YAML/config.yaml)
            model_params = get_model_params(cfg_llm_model)
        if not model_params:
            raise ValueError(f"No model params found for llm_model '{cfg_llm_model}'")

        llm_response_structure = {
            "type": "json_schema",
            "json_schema": {
                "name": f"{(cfg.get('name') or _agent_slug(cfg_name) + '_agent')}Response",
                "description": f"Response from the {display_name} Agent",
                "schema": {
                    "type": "object",
                    "properties": {
                        "status": {"type": "string", "enum": ["completed", "input_required", "error"]},
                        "agent_response": {"type": "string", "description": "fetched data or the error message or the message asking for more information"},
                    },
                    "required": ["status", "agent_response"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
        }

        # Create Azure OpenAI client with the same TLS trust behavior as the single-agent code.
        from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
        from agents.mcp_trust import apply_mcp_http_trust_from_env
        from agents.autogen_base_agent.utils import create_azure_openai_http_client

        apply_mcp_http_trust_from_env()
        model_client = AzureOpenAIChatCompletionClient(
            model=model_params.get("model_name"),
            azure_endpoint=model_params.get("azure_endpoint"),
            azure_deployment=model_params.get("azure_deployment"),
            api_version=model_params.get("api_version"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            http_client=create_azure_openai_http_client(),
            response_format=llm_response_structure,
        )

        custom_prompt = details.get("agent_prompt") or os.getenv("BASE_AGENT_PROMPT") or ""
        system_prompt = (
            f"Today's date is {datetime.today().strftime('%Y/%m/%d')}.\n\n"
            f"{custom_prompt}\n\n"
            "Tool suggestions are provided in the input. It is not mandatory to use all the suggested tools. Identify and use the most relevant tool based on the user query.\n"
            "Infer the correct tool argument values from the given context.\n"
            "If there are multiple options to choose from, ask the user for clarification on which one to use.\n\n"
            "'Set response status to input_required if the user needs to provide more information to complete the request.'\n"
            "'Set response status to error if there is an error while processing the request.'\n"
            "'Set response status to completed if the request is complete.'\n"
        )

        mcp_params = _build_mcp_params_from_details(details)
        agent_slug = _agent_slug(cfg_name)
        mount_path = f"/agents/{agent_slug}"

        agent_name = (cfg.get("name") or f"{agent_slug}_agent")

        agent_desc = details.get("description") or cfg.get("description") or ""

        inv = agent_invocation(
            agent_name=agent_name,
            agent_description=agent_desc,
            model_client=model_client,
            markdown_summary=True,
            agent_type=agent_name,
            system_message=[SystemMessage(content=system_prompt)],
            model_context=BufferedChatCompletionContext(buffer_size=3, initial_messages=[]),
            mcp_params=mcp_params or None,
        )

        if mcp_params:
            try:
                tool_descriptions = asyncio.run(
                    inv.get_tool_descriptions(include_tool_schema=False, include_tool_params=True)
                )
                if tool_descriptions and tool_descriptions.strip():
                    agent_desc = (
                        f"{agent_desc.rstrip()}\n"
                        f"{tool_descriptions.strip()}"
                    )
                else:
                    agent_desc = (
                        f"{agent_desc.rstrip()}\n"
                        "MCP servers are configured, but no tools were discovered."
                    )
                inv.agent_description = agent_desc
            except Exception as e:
                logger.warning(
                    f"Failed to fetch MCP tool descriptions for agent '{display_name}': {type(e).__name__}: {e}"
                )

        agent_tags = details.get("agent_skill_tags") or []
        agent_examples = details.get("agent_skill_examples") or []

        # if inv.mcp_params:
        #     tool_descriptions = asyncio.run(inv.get_tool_descriptions(include_tool_schema=False, include_tool_params=True))
        #     tool_descriptions = f"The following are the agent capabilities and respective tools available to the agent:\n{tool_descriptions}"
        # else:
        #     tool_descriptions = ""
        # agent_desc_with_tools = f"{agent_desc}\n{tool_descriptions}"

        skill = AgentSkill(
            id=f"{agent_slug}_skill",
            name=f"{display_name} Skill",
            description="agent_skill",
            tags=agent_tags,
            examples=agent_examples,
        )
        agent_card = AgentCard(
            name=agent_name,
            description=agent_desc,
            url=f"{base_url}{mount_path}/",
            version=version,
            default_input_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
            default_output_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
            capabilities=AgentCapabilities(streaming=False, push_notifications=False),
            skills=[skill],
        )

        # Build per-agent A2A app and mount.
        request_handler = DefaultRequestHandler(
            agent_executor=_BoundAgentExecutor(inv, display_name),
            task_store=InMemoryTaskStore(),
            push_config_store=push_config_store,
            push_sender=push_sender,
        )
        server = A2AStarletteApplication(agent_card=agent_card, http_handler=request_handler)
        sub_app = server.build()

        has_mcp = bool(mcp_params)
        root_app.state.mcp_health[agent_slug] = {
            "ok": True,
            "last_checked": None,
            "error": None,
            "consecutive_failures": 0,
            "has_mcp": has_mcp,
        }

        async def _agent_health(request, slug=agent_slug):
            state = root_app.state.mcp_health.get(slug, {})
            if not state.get("has_mcp"):
                return JSONResponse({"status": "ok"})
            if state.get("ok"):
                return JSONResponse({"status": "ok", "mcp": "ok", "last_checked": state.get("last_checked")})
            return JSONResponse(
                {
                    "status": "unhealthy",
                    "mcp": "down",
                    "error": state.get("error"),
                    "last_checked": state.get("last_checked"),
                    "consecutive_failures": state.get("consecutive_failures"),
                },
                status_code=503,
            )

        sub_app.add_route("/health", _agent_health, methods=["GET"])
        sub_app.add_route("/health/live", _agent_health, methods=["GET"])

        root_app.mount(mount_path, sub_app)
        root_app.state.agents[agent_slug] = {
            "display_name": display_name,
            "config_name": cfg_name,
            "agent_card": agent_card,
            "invocation": inv,
        }
        logger.info(f"Mounted agent '{display_name}' at {mount_path} (mcp={has_mcp}, model={cfg_llm_model})")

    monitor_enabled = os.getenv("MCP_HEALTHCHECK_ENABLED", "true").lower() in {"1", "true", "yes"}
    crash_on_failure = os.getenv("MCP_HEALTHCHECK_CRASH_ON_FAILURE", "true").lower() in {"1", "true", "yes"}
    interval_seconds = float(os.getenv("MCP_HEALTHCHECK_INTERVAL_SECONDS", "15"))
    failure_threshold = int(os.getenv("MCP_HEALTHCHECK_FAILURE_THRESHOLD", "2"))

    async def _check_all_mcp_once() -> bool:
        agents = root_app.state.agents
        if not agents:
            return True

        async def _check_one(slug: str, inv: agent_invocation, has_mcp: bool) -> tuple[str, bool, str | None]:
            if not has_mcp:
                return slug, True, None
            try:
                ok = await inv.check_mcp_health()
                return slug, bool(ok), None if ok else "MCP health check failed"
            except Exception as e:
                return slug, False, f"MCP health check exception: {type(e).__name__}: {e}"

        tasks = []
        for slug, meta in agents.items():
            state = root_app.state.mcp_health.get(slug, {})
            tasks.append(_check_one(slug, meta["invocation"], bool(state.get("has_mcp"))))

        results = await asyncio.gather(*tasks)
        overall_ok = True
        now = time.time()
        for slug, ok, err in results:
            state = root_app.state.mcp_health.get(slug) or {}
            state["last_checked"] = now
            if ok:
                state["ok"] = True
                state["error"] = None
                state["consecutive_failures"] = 0
            else:
                overall_ok = False
                state["ok"] = False
                state["error"] = err or "MCP health check failed"
                state["consecutive_failures"] = int(state.get("consecutive_failures", 0)) + 1
            root_app.state.mcp_health[slug] = state
        return overall_ok

    async def _root_health(request):
        # Kubernetes can point readiness at this. Returns 503 if any MCP-backed agent is unhealthy.
        unhealthy = {}
        for slug, state in (root_app.state.mcp_health or {}).items():
            if state.get("has_mcp") and not state.get("ok"):
                unhealthy[slug] = {
                    "error": state.get("error"),
                    "last_checked": state.get("last_checked"),
                    "consecutive_failures": state.get("consecutive_failures"),
                }
        if not unhealthy:
            return JSONResponse({"status": "ok", "agents": list(root_app.state.agents.keys())})
        return JSONResponse({"status": "unhealthy", "unhealthy_agents": unhealthy}, status_code=503)

    async def _root_list(request):
        agents = {}
        for slug, meta in root_app.state.agents.items():
            agents[slug] = {
                "display_name": meta["display_name"],
                "path": f"/agents/{slug}",
                "url": meta["agent_card"].url,
            }
        return JSONResponse({"agents": agents})

    root_app.add_route("/health", _root_health, methods=["GET"])
    root_app.add_route("/health/live", _root_health, methods=["GET"])
    root_app.add_route("/agents", _root_list, methods=["GET"])

    # Fail fast at startup if any MCP-backed agent is unhealthy.
    if monitor_enabled:
        ok = asyncio.run(_check_all_mcp_once())
        if not ok:
            logger.error("One or more MCP dependencies are down at startup; aborting server startup")
            sys.exit(1)

    async def _monitor() -> None:
        if not monitor_enabled:
            return
        logger.info(
            f"Starting MCP dependency monitor (interval={interval_seconds}s, threshold={failure_threshold}, crash={crash_on_failure})"
        )
        while True:
            overall = await _check_all_mcp_once()
            if not overall and crash_on_failure:
                # If any MCP-backed agent crosses the threshold, exit.
                for slug, state in root_app.state.mcp_health.items():
                    if state.get("has_mcp") and not state.get("ok") and int(state.get("consecutive_failures", 0)) >= failure_threshold:
                        logger.error(f"Agent '{slug}' MCP unhealthy for {state.get('consecutive_failures')} checks; exiting")
                        os._exit(1)
            await asyncio.sleep(interval_seconds)

    async def _on_startup() -> None:
        root_app.state._mcp_monitor_task = asyncio.create_task(_monitor())

    async def _on_shutdown() -> None:
        task = getattr(root_app.state, "_mcp_monitor_task", None)
        if task is not None:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        await httpx_client.aclose()

    root_app.add_event_handler("startup", _on_startup)
    root_app.add_event_handler("shutdown", _on_shutdown)

    logger.info(f"Starting multi-agent server on {host}:{port} with agents={list(root_app.state.agents.keys())}")
    uvicorn.run(root_app, host=host, port=port)


def main(host: str | None = None, port: int | None = None) -> None:
    """Starts either a single base agent (legacy) or multiple base agents in one pod."""
    load_dotenv()
    try:
        multi_env = (
            os.getenv("MULTI_AGENT_CONFIG_NAMES")
            or os.getenv("MULTI_AGENT_CONFIGS")
            or os.getenv("BASE_AGENT_CONFIG_NAMES")
            or os.getenv("BASE_AGENT_CONFIGS")
        )
        if multi_env and multi_env.strip():
            config_names = _split_csv(multi_env)
            _run_multi_agent(host, port, config_names)
        else:
            _run_single_agent(host, port)
    except Exception:
        logger.error(f"An error occurred during server startup: {traceback.format_exc()}")
        sys.exit(1)


if __name__ == '__main__':
    main()