import os
import json
from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
from datetime import datetime

from agents.autogen_base_agent.config_modules import AgentCardConfig, AgentSkillConfig, AgentBaseConfig

# Read from environment variables, default to localhost for local development
HOST = os.getenv('HOST', 'localhost')
PORT = int(os.getenv('PORT', '8098'))

# Agent name defined in config.yaml file or kuberneters configMap yaml config to create model client and MCP Server connection.
agent_display_name = "ServiceNow Agent"
agent_display_name_env = os.getenv("BASE_AGENT_DISPLAY_NAME", agent_display_name)

# Name used for config lookups (model + MCP) in config.yaml / APP_CONFIG_YAML / configs/*.yaml
_default_agent_name_in_yaml_config = agent_display_name_env.lower().replace(" ", "_")
agent_name_in_yaml_config = os.getenv("AGENT_NAME_IN_YAML_CONFIG", _default_agent_name_in_yaml_config)

custom_agent_prompt = """
                        You are a helpful assistant that fetches and analyze data from servicenow using MCP tools provided. 
                        If the date or datetime provided is not in the correct datatype, convert it to the datatype accepted by the tool.
                        Infer the arguments required for the tool from the user request.
"""
custom_agent_prompt = os.getenv("BASE_AGENT_PROMPT", custom_agent_prompt)

azure_agent_prompt = f"""Today's date is {datetime.today().strftime("%Y/%m/%d")}.
                        {custom_agent_prompt}

                        Tool suggestions are provided in the input. It is not mandatory to use all the suggested tools. Identify and use the most relevant tool based on the user query.
                        Infer the correct tool argument values from the given context.
                        If there are multiple options to choose from, ask the user for clarification on which one to use. 

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        """


agent_name = agent_display_name_env.lower().replace(" ", "_")

agent_description = f"""
                    An agent that analyse the task query and fetches data/metrics from Servicenow using MCP tools.\n 
                    Provide insights on the fetched data.\n
                    The following are the agent capabilities and respective tools available to the agent:\n

                    """

agent_description = os.getenv("BASE_AGENT_DESCRIPTION", agent_description)

agent_skill_config = AgentSkillConfig(
    agent_name=agent_display_name_env,
    agent_skill_tags=os.getenv("BASE_AGENT_SKILL_TAGS", '["servicenow data", "servicenow metrics"]'),
    agent_skill_examples=os.getenv("BASE_AGENT_SKILL_EXAMPLES", '[]')
)
agent_card_config = AgentCardConfig(
    agent_card_url=os.getenv("AGENT_URL", f'http://{HOST}:{PORT}/'),
    agent_name=agent_display_name_env,
    agent_version=os.getenv("AGENT_VERSION", "1.0.0")
)

agent_base_config = AgentBaseConfig(
    agent_name=agent_display_name_env,
    host=HOST,
    port=PORT,
    agent_description=agent_description,
    markdown_summary = False,
    azure_agent_prompt=azure_agent_prompt,
    agent_skill_configs=[agent_skill_config],
    agent_card_config=agent_card_config,
    agent_name_in_yaml_config=agent_name_in_yaml_config,
)

agent_card = os.getenv("AGENT_URL", f'http://{HOST}:{PORT}/')