"""
A2A Task Planner Agent

This module contains the task planner agent responsible for analyzing user queries
and generating task execution plans using LLM.
"""

import uuid
from typing import Dict, List, Any, Tuple
from datetime import datetime
import os
import re

from autogen_core import MessageContext, RoutedAgent, message_handler
from autogen_core.models import SystemMessage

from agents.a2a_orchestrator.orchestrator_types import (
    UserQueryMessage,
    TaskExecutionMessage,
    TaskCompletionMessage,
    UserInputMessage,
    QueryCompletionMessage,
    ErrorAnalysisMessage,
    SummaryRequestMessage,
    TaskStatus,
    OrchestratorTask,
    RemoteAgent,
    USER_QUERY_TOPIC,
    TASK_EXECUTION_TOPIC,
    TASK_COMPLETION_TOPIC,
    USER_INPUT_TOPIC,
    QUERY_COMPLETION_TOPIC,
    ERROR_ANALYSIS_TOPIC,
    SUMMARY_TOPIC,
)
from agents.a2a_orchestrator.orch_config import logger, SUMMARY_USE_MARKDOWN


class A2ATaskPlannerAgent(RoutedAgent):
    """Agent responsible for analyzing user queries and generating task execution plans"""
    
    def __init__(self, remote_agents: Dict[str, RemoteAgent], model_client: Any, orchestrator_ref=None):
        super().__init__("A2ATaskPlanner")
        self.remote_agents = remote_agents
        self.model_client = model_client
        self.active_queries: Dict[str, List[OrchestratorTask]] = {}
        self.query_session_map: Dict[str, str] = {}  # Map query_id to session_id
        self.query_reference_context: Dict[str, List[Dict[str, str]]] = {}  # Map query_id to reference_context
        self.query_user_messages: Dict[str, str] = {}  # Map query_id to original user query
        self.orchestrator_ref = orchestrator_ref  # Reference to main orchestrator

    async def _emit_task_started_event(self, query_id: str, task_id: str, task_description: str, agent_name: str) -> None:
        """Emit a task-started event to the SSE stream (if active)."""
        if not self.orchestrator_ref:
            return
        queue = self.orchestrator_ref.streaming_queues.get(query_id)
        if not queue:
            return
        try:
            await queue.put(
                {
                    "type": "task_started",
                    "query_id": query_id,
                    "task_id": task_id,
                    "task_description": task_description,
                    "agent_name": agent_name,
                    "timestamp": datetime.now().isoformat(),
                }
            )
        except Exception as e:
            # Best-effort only; don't break orchestration if UI stream is gone.
            logger.debug(f"Failed to emit task_started event for {task_id}: {e}")

    def _is_capabilities_query(self, user_query: str) -> bool:
        """Return True if the user is asking what the orchestrator/agents/tools can do."""
        if not user_query:
            return False

        q = user_query.strip().lower()

        # Be intentionally strict: avoid misclassifying domain questions that happen
        # to contain words like "features" (e.g., "what features are non-compliant").
        patterns = [
            r"\bwhat can (you|this orchestrator) do\b",
            r"\bwhat do (you|this orchestrator) do\b",
            r"\b(your|this)\s+capabilit\w*\b",
            r"\bwhat\s+(agents|tools)\s+(do you have|are available)\b",
            r"\bavailable\s+(agents|tools)\b",
            r"\b(which|what)\s+agents\b",
            r"\b(which|what)\s+tools\b",
            r"\btool\s+list\b",
            r"\btools\s+can\s+you\s+access\b",
            r"\bwhat\s+(info|information)\s+can\s+you\s+provide\b",
        ]

        return any(re.search(p, q) for p in patterns)

    def _get_agents_summary_compact(self) -> str:
        """Compact summary for the LLM planner to reduce prompt size and latency."""
        summary_parts: List[str] = ["Available Remote Agents (compact):\n"]

        for agent in self.remote_agents.values():
            agent_name = agent.name or "(unnamed agent)"
            agent_url = agent.url or "(no url)"

            tool_names: set[str] = set(self._extract_tool_names(agent.description))
            for skill in (agent.skills or []):
                tool_names.update(self._extract_tool_names(skill.get("description", "")))
            tools_sorted = sorted(tool_names)

            skill_names = [s.get("name", "").strip() for s in (agent.skills or []) if s.get("name")]
            skills_text = ", ".join(skill_names) if skill_names else "(none listed)"

            summary_parts.append(f"\n{agent_name} ({agent_url}):")
            summary_parts.append(f"  Skills: {skills_text}")
            if tools_sorted:
                summary_parts.append(f"  Tools ({len(tools_sorted)}): {', '.join(tools_sorted)}")
            else:
                summary_parts.append("  Tools: (none discovered)")

        return "\n".join(summary_parts)

    def _extract_tool_names(self, text: str) -> List[str]:
        """Extract MCP tool names from an agent/skill description.

        Tool descriptions are typically emitted by `get_tool_descriptions()` as:
        `Tool Name: <name> - <desc>`
        """
        if not text:
            return []

        tool_names: set[str] = set()
        for line in text.splitlines():
            m = re.match(r"\s*Tool Name:\s*([^\-]+?)\s*-\s*", line)
            if m:
                tool_names.add(m.group(1).strip())

        return sorted(tool_names)

    def _format_capabilities_response(self) -> str:
        """Deterministic response listing connected agents + tools."""
        if not self.remote_agents:
            return (
                "I don't have any remote agents connected yet, so there are no tools to list. "
                "Once agents are registered, I can enumerate their skills and MCP tools here."
            )

        lines: List[str] = []
        lines.append("Here’s what I can access through this orchestrator (based on currently connected remote agents):\n")

        for agent in self.remote_agents.values():
            agent_name = agent.name or "(unnamed agent)"
            agent_url = agent.url or "(no url)"

            # Aggregate tool names from both the agent description and skill descriptions.
            tool_names: set[str] = set(self._extract_tool_names(agent.description))
            for skill in (agent.skills or []):
                tool_names.update(self._extract_tool_names(skill.get("description", "")))
            tool_list = sorted(tool_names)

            skill_names = [s.get("name", "").strip() for s in (agent.skills or []) if s.get("name")]
            skills_text = ", ".join(skill_names) if skill_names else "(none listed)"

            lines.append(f"- {agent_name} ({agent_url})")
            lines.append(f"  - Skills: {skills_text}")
            if tool_list:
                # Keep it readable; the full tool parameter schemas live in the agent description.
                lines.append(f"  - Tools ({len(tool_list)}): {', '.join(tool_list)}")
            else:
                lines.append("  - Tools: (no MCP tools were discovered / exposed in the agent description)")

        lines.append(
            "\nNotes: Tools are executed by the remote agents. This orchestrator itself only routes your request to the right agent/tool." 
        )
        return "\n".join(lines)
    
    @message_handler
    async def handle_user_query(self, message: UserQueryMessage, ctx: MessageContext) -> None:
        """Handle user queries and generate task execution plans"""
        logger.info(f"🎯 A2ATaskPlanner received query {message.query_id}: {message.user_query}")
        
        # Check if this query has been cancelled before processing
        if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(message.query_id):
            logger.info(f"🛑 Query {message.query_id} was cancelled, skipping planning")
            return
        
        # Log reference context if provided
        if message.reference_context:
            logger.info(f"📚 Reference context provided: {len(message.reference_context)} previous queries")
        
        try:
            # Plan tasks using LLM with reference context
            logger.info(f"🧠 Planning tasks using LLM for: {message.user_query}")
            is_task_query, tasks, direct_response = await self._plan_tasks(
                message.user_query, 
                message.query_id,
                reference_context=message.reference_context
            )
            
            if not is_task_query:
                # Send direct response
                logger.info(f"📤 Sending direct response for query {message.query_id}")
                
                # Check if streaming is active
                is_streaming = self.orchestrator_ref and message.query_id in self.orchestrator_ref.streaming_queues
                
                if is_streaming:
                    # Send via streaming queue
                    final_event = {
                        "type": "complete",
                        "query_id": message.query_id,
                        "summary": direct_response,
                        "timestamp": datetime.now().isoformat()
                    }
                    await self.orchestrator_ref.streaming_queues[message.query_id].put(final_event)
                    logger.info(f"✉️ Sent direct response via streaming for query {message.query_id}")
                    
                    # IMPORTANT: Also store result for /chat endpoint to detect completion
                    self.orchestrator_ref.query_results[message.query_id] = direct_response
                    
                    # Signal completion event for /chat endpoint waiting
                    if message.query_id in self.orchestrator_ref.query_completion_events:
                        self.orchestrator_ref.query_completion_events[message.query_id].set()
                    
                    # Update chat history
                    if message.session_id and self.orchestrator_ref:
                        self.orchestrator_ref.history_manager.update_response(
                            session_id=message.session_id,
                            query_id=message.query_id,
                            response_summary=direct_response,
                            status="completed"
                        )
                else:
                    # Use traditional QueryCompletionMessage
                    completion_msg = QueryCompletionMessage(
                        query_id=message.query_id,
                        summary=direct_response,
                        completed_tasks={},
                        session_id=message.session_id
                    )
                    logger.info(f"📨 Publishing completion message to topic: {QUERY_COMPLETION_TOPIC}")
                    await self.publish_message(completion_msg, topic_id=QUERY_COMPLETION_TOPIC)
                return
            
            if not tasks:
                # No tasks identified
                no_tasks_msg = "I understand your query, but I couldn't identify any specific tasks to execute. Could you please rephrase or provide more details?"
                
                # Check if streaming is active
                is_streaming = self.orchestrator_ref and message.query_id in self.orchestrator_ref.streaming_queues
                
                if is_streaming:
                    # Send via streaming queue
                    final_event = {
                        "type": "complete",
                        "query_id": message.query_id,
                        "summary": no_tasks_msg,
                        "timestamp": datetime.now().isoformat()
                    }
                    await self.orchestrator_ref.streaming_queues[message.query_id].put(final_event)
                    logger.info(f"✉️ Sent no-tasks response via streaming for query {message.query_id}")
                    
                    # IMPORTANT: Also store result for /chat endpoint to detect completion
                    self.orchestrator_ref.query_results[message.query_id] = no_tasks_msg
                    
                    # Signal completion event for /chat endpoint waiting
                    if message.query_id in self.orchestrator_ref.query_completion_events:
                        self.orchestrator_ref.query_completion_events[message.query_id].set()
                    
                    # Update chat history
                    if message.session_id and self.orchestrator_ref:
                        self.orchestrator_ref.history_manager.update_response(
                            session_id=message.session_id,
                            query_id=message.query_id,
                            response_summary=no_tasks_msg,
                            status="completed"
                        )
                else:
                    # Use traditional QueryCompletionMessage
                    completion_msg = QueryCompletionMessage(
                        query_id=message.query_id,
                        summary=no_tasks_msg,
                        completed_tasks={},
                        session_id=message.session_id
                    )
                    await self.publish_message(completion_msg, topic_id=QUERY_COMPLETION_TOPIC)
                return
            
            # Store tasks for this query
            self.active_queries[message.query_id] = tasks
            
            # Store session_id mapping
            if message.session_id:
                self.query_session_map[message.query_id] = message.session_id
            
            # Store original user query for the summary agent
            self.query_user_messages[message.query_id] = message.user_query
            
            # Store reference context for this query
            if message.reference_context:
                self.query_reference_context[message.query_id] = message.reference_context
            
            # Send initial tasks for execution (those with no dependencies)
            for task in tasks:
                if not task.dependencies:
                    logger.info(f"📤 Sending task {task.task_id} for execution (no dependencies)")
                    await self._emit_task_started_event(
                        query_id=message.query_id,
                        task_id=task.task_id,
                        task_description=task.description,
                        agent_name=task.agent_name,
                    )
                    task_msg = TaskExecutionMessage(
                        task_id=task.task_id,
                        query_id=message.query_id,
                        agent_url=task.agent_url,
                        agent_name=task.agent_name,
                        description=task.description,
                        query=task.query,
                        dependencies=task.dependencies,
                        dependency_results=task.dependency_results,
                        session_id=message.session_id,
                        reference_context=message.reference_context
                    )
                    await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
                else:
                    logger.info(f"⏳ Task {task.task_id} waiting for dependencies: {task.dependencies}")
                    
        except Exception as e:
            logger.error(f"Error planning tasks for query {message.query_id}: {e}")
            completion_msg = QueryCompletionMessage(
                query_id=message.query_id,
                summary=f"Error planning tasks: {str(e)}",
                completed_tasks={}
            )
            await self.publish_message(completion_msg, topic_id=QUERY_COMPLETION_TOPIC)
    
    @message_handler
    async def handle_task_completion(self, message: TaskCompletionMessage, ctx: MessageContext) -> None:
        """Handle task completion and trigger dependent tasks"""
        logger.info(f"📬 Task {message.task_id} completed with status: {message.status}")
        
        # Check if this query has been cancelled
        if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(message.query_id):
            logger.info(f"🛑 Query {message.query_id} was cancelled, ignoring task completion for {message.task_id}")
            # Clean up planner-local state for the cancelled query
            self.active_queries.pop(message.query_id, None)
            self.query_session_map.pop(message.query_id, None)
            self.query_reference_context.pop(message.query_id, None)
            self.query_user_messages.pop(message.query_id, None)
            return
        
        if message.query_id not in self.active_queries:
            logger.warning(f"⚠️ Received completion for unknown query {message.query_id}")
            return
            
        tasks = self.active_queries[message.query_id]
        
        # Update completed task
        completed_task = None
        for task in tasks:
            if task.task_id == message.task_id:
                task.status = TaskStatus(message.status)
                task.response = message.response
                task.error = message.error
                task.input_required_message = message.input_required_message
                task.remote_context_id = message.remote_context_id
                task.remote_task_id = message.remote_task_id
                completed_task = task
                logger.info(f"   Updated task {task.task_id} status to {task.status.value}")
                if task.error:
                    logger.error(f"   Task {task.task_id} error: {task.error[:200]}")
                break
        
        if not completed_task:
            logger.warning(f"Could not find task {message.task_id} in active queries")
            return
        
        # Handle task waiting for input
        if completed_task.status == TaskStatus.WAITING_FOR_INPUT:
            logger.info(f"Task {message.task_id} waiting for input")
            
            # Check if this is a coder agent task - skip auto-resolution for coder agent
            is_coder_agent = "coder" in completed_task.agent_name.lower()
            
            # Send the waiting_for_input task status to UI first (before attempting auto-resolution)
            if self.orchestrator_ref and message.query_id in self.orchestrator_ref.streaming_queues:
                auto_resolve_msg = "" if is_coder_agent else "\n Auto Resolving Input Requirement."
                task_update = {
                    "type": "task_complete",
                    "task_id": completed_task.task_id,
                    "task_description": completed_task.description,
                    "agent_name": completed_task.agent_name,
                    "task_status": TaskStatus.WAITING_FOR_INPUT.value,
                    "response": None,
                    "error": None,
                    "input_required": f"{completed_task.input_required_message}{auto_resolve_msg}",
                    "timestamp": datetime.now().isoformat()
                }
                await self.orchestrator_ref.streaming_queues[message.query_id].put(task_update)
                logger.info(f"✉️ Sent waiting_for_input status to UI for task {message.task_id}")
            
            # Try to automatically resolve input requirement (skip for coder agent)
            resolved = False
            if not is_coder_agent:
                resolved = await self._try_auto_resolve_input(completed_task, tasks, ctx)
            else:
                logger.info(f"⏭️ Skipping auto-resolution for coder_agent task {message.task_id}")
            
            if not resolved:
                # Store in orchestrator's waiting tasks (for the /chat endpoint to access)
                if self.orchestrator_ref:
                    logger.info(f"Task {message.task_id} added to waiting_for_input_tasks")
                    self.orchestrator_ref.waiting_for_input_tasks[message.task_id] = completed_task
                    
                    # Check if streaming is active
                    is_streaming = message.query_id in self.orchestrator_ref.streaming_queues
                    
                    if is_streaming:
                        # Send input-required event through streaming (keep stream alive)
                        input_event = {
                            "type": "input_required",
                            "query_id": message.query_id,
                            "task_id": message.task_id,
                            "message": completed_task.input_required_message,
                            "timestamp": datetime.now().isoformat()
                        }
                        await self.orchestrator_ref.streaming_queues[message.query_id].put(input_event)
                        logger.info(f"✉️ Sent input-required event via streaming for task {message.task_id}")
                    
                    # Also signal the orchestrator to check for input requirement (for non-streaming)
                    if message.query_id in self.orchestrator_ref.query_completion_events:
                        logger.info(f"Setting completion event for input-required query {message.query_id}")
                        self.orchestrator_ref.query_completion_events[message.query_id].set()

            if resolved and completed_task.is_resolution_task:
                completed_task.status = TaskStatus.SKIPPED
            return
        
        # Remove from waiting tasks if it was there
        if self.orchestrator_ref and message.task_id in self.orchestrator_ref.waiting_for_input_tasks:
            del self.orchestrator_ref.waiting_for_input_tasks[message.task_id]
        
        # Send incremental update to streaming queue if available
        if self.orchestrator_ref and message.query_id in self.orchestrator_ref.streaming_queues:
            task_update = {
                "type": "task_complete",
                "task_id": completed_task.task_id,
                "task_description": completed_task.description,
                "agent_name": completed_task.agent_name,
                "task_status": completed_task.status.value,
                "response": completed_task.response if completed_task.status == TaskStatus.COMPLETED else None,
                "error": completed_task.error if completed_task.error else None,
                "timestamp": datetime.now().isoformat()
            }
            await self.orchestrator_ref.streaming_queues[message.query_id].put(task_update)
            logger.info(f"✉️ Sent incremental task update for {message.task_id}")
        
        # If this is a resolution task, check if we should retry the parent task
        if completed_task.is_resolution_task:
            await self._check_and_retry_parent_task(completed_task, tasks, ctx)
            # Don't skip dependent tasks or check completion yet, let parent task complete first
            return
        
        # If task failed, try to automatically resolve the error
        if completed_task.status == TaskStatus.FAILED:
            # Check if this is a coder agent task - skip auto-resolution for coder agent
            is_coder_agent = "coder" in completed_task.agent_name.lower()
            
            if is_coder_agent:
                logger.warning(f"Task {message.task_id} from coder_agent failed. Skipping auto-resolution.")
                # Mark dependent tasks as SKIPPED
                self._skip_dependent_tasks(tasks, message.task_id, f"Dependency {message.task_id} failed")
            else:
                logger.warning(f"Task {message.task_id} failed. Attempting automatic error resolution.")
                
                # Try to automatically resolve the error
                resolved = await self._try_auto_resolve_error(completed_task, tasks, ctx)
                
                if not resolved:
                    # Could not resolve automatically, mark dependent tasks as SKIPPED
                    logger.warning(f"Could not auto-resolve error for task {message.task_id}. Marking dependent tasks as SKIPPED.")
                    self._skip_dependent_tasks(tasks, message.task_id, f"Dependency {message.task_id} failed")
        
        # Check if all tasks are complete (excluding resolution tasks in progress)
        # Original tasks (non-resolution) should be completed/failed/skipped or resolving_error
        all_completed = all(
            task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.SKIPPED] or
            (task.status == TaskStatus.RESOLVING_ERROR and all(
                next((t for t in tasks if t.task_id == res_id), OrchestratorTask(
                    task_id="", query_id="", agent_url="", agent_name="", description="", query="",
                    status=TaskStatus.COMPLETED
                )).status in [TaskStatus.COMPLETED, TaskStatus.FAILED]
                for res_id in task.resolution_tasks
            ))
            for task in tasks if not task.is_resolution_task
        )
        
        if all_completed:
            # Generate per-task summary list (will be passed to summary agent)
            summary = self._generate_summary(message.query_id, tasks)
            
            # Ensure summary is never None
            if summary is None:
                logger.warning(f"Summary is None for query {message.query_id}, using default message")
                summary = [{"error": "Task completed but no summary was generated"}]
            
            # Get session_id and original user query for the summary agent
            session_id = self.query_session_map.get(message.query_id, "")
            user_query = self.query_user_messages.get(message.query_id, "")
            
            # Dispatch to the summary agent — it will synthesise results,
            # emit its own task_started / task_complete SSE events, and publish
            # the final QueryCompletionMessage (or streaming "complete" event).
            summary_request = SummaryRequestMessage(
                query_id=message.query_id,
                user_query=user_query,
                task_results=summary,
                use_markdown=SUMMARY_USE_MARKDOWN,
                session_id=session_id,
            )
            await self.publish_message(summary_request, topic_id=SUMMARY_TOPIC)
            logger.info(f"📨 Dispatched SummaryRequestMessage for query {message.query_id}")
            
            # Clean up planner state (summary agent handles completion signaling)
            del self.active_queries[message.query_id]
            if message.query_id in self.query_session_map:
                del self.query_session_map[message.query_id]
            if message.query_id in self.query_reference_context:
                del self.query_reference_context[message.query_id]
            if message.query_id in self.query_user_messages:
                del self.query_user_messages[message.query_id]
        else:
            # Trigger dependent tasks if this task completed successfully
            if completed_task.status == TaskStatus.COMPLETED:
                await self._trigger_dependent_tasks(message.query_id, message.task_id, ctx)
    
    @message_handler
    async def handle_user_input(self, message: UserInputMessage, ctx: MessageContext) -> None:
        """Handle user input for tasks waiting for input"""
        logger.info(f"Received user input for task {message.task_id}")
        
        # Check if this query has been cancelled
        if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(message.query_id):
            logger.info(f"🛑 Query {message.query_id} was cancelled, ignoring user input for {message.task_id}")
            return
        
        if message.query_id not in self.active_queries:
            logger.warning(f"Received input for unknown query {message.query_id}")
            return
            
        tasks = self.active_queries[message.query_id]
        
        # Find the task waiting for input
        target_task = None
        for task in tasks:
            if task.task_id == message.task_id and task.status == TaskStatus.WAITING_FOR_INPUT:
                target_task = task
                break
        
        if not target_task:
            logger.warning(f"Could not find task {message.task_id} waiting for input")
            return
        
        # Get session_id for this query
        session_id = self.query_session_map.get(message.query_id, "")
        
        # Get reference_context for this query
        reference_context = self.query_reference_context.get(message.query_id, [])
        
        # Resume task with user input
        task_msg = TaskExecutionMessage(
            task_id=target_task.task_id,
            query_id=message.query_id,
            agent_url=target_task.agent_url,
            agent_name=target_task.agent_name,
            description=target_task.description,
            query=target_task.query,
            dependencies=target_task.dependencies,
            dependency_results=target_task.dependency_results,
            user_input=message.user_input,
            session_id=session_id,
            reference_context=reference_context
        )
        await self._emit_task_started_event(
            query_id=message.query_id,
            task_id=target_task.task_id,
            task_description=target_task.description,
            agent_name=target_task.agent_name,
        )
        await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
    
    def _skip_dependent_tasks(self, tasks: List[OrchestratorTask], failed_task_id: str, reason: str) -> None:
        """Recursively mark dependent tasks as SKIPPED when a dependency fails"""
        skipped_any = False
        for task in tasks:
            if task.status == TaskStatus.PENDING and failed_task_id in task.dependencies:
                task.status = TaskStatus.SKIPPED
                task.error = f"Skipped: {reason}"
                logger.info(f"Task {task.task_id} marked as SKIPPED due to failed dependency {failed_task_id}")
                skipped_any = True
                # Recursively skip tasks that depend on this task
                self._skip_dependent_tasks(tasks, task.task_id, f"dependency chain from {failed_task_id}")
        return skipped_any
    
    async def _trigger_dependent_tasks(self, query_id: str, completed_task_id: str, ctx: MessageContext) -> None:
        """Trigger tasks that depend on the completed task"""
        if query_id not in self.active_queries:
            return
            
        tasks = self.active_queries[query_id]
        completed_task = next((t for t in tasks if t.task_id == completed_task_id), None)
        
        if not completed_task:
            return
        
        # Find tasks that depend on this completed task
        for task in tasks:
            if (task.status == TaskStatus.PENDING and 
                completed_task_id in task.dependencies):
                
                # Check if all dependencies are satisfied
                deps_satisfied = all(
                    any(t.task_id == dep_id and t.status == TaskStatus.COMPLETED for t in tasks)
                    for dep_id in task.dependencies
                )
                
                if deps_satisfied:
                    # Collect dependency results with better formatting
                    for dep_id in task.dependencies:
                        dep_task = next((t for t in tasks if t.task_id == dep_id), None)
                        if dep_task and dep_task.response:
                            # Format dependency result with task description for context
                            formatted_result = f"Task '{dep_task.description}' ({dep_id}) result:\n{dep_task.response}"
                            task.dependency_results[dep_id] = formatted_result
                            logger.info(f"Added dependency result for {dep_id} to task {task.task_id}")
                    
                    # Get session_id for this query
                    session_id = self.query_session_map.get(query_id, "")
                    
                    # Get reference_context for this query
                    reference_context = self.query_reference_context.get(query_id, [])
                    
                    # Send task for execution
                    task_msg = TaskExecutionMessage(
                        task_id=task.task_id,
                        query_id=query_id,
                        agent_url=task.agent_url,
                        agent_name=task.agent_name,
                        description=task.description,
                        query=task.query,
                        dependencies=task.dependencies,
                        dependency_results=task.dependency_results,
                        session_id=session_id,
                        reference_context=reference_context
                    )
                    await self._emit_task_started_event(
                        query_id=query_id,
                        task_id=task.task_id,
                        task_description=task.description,
                        agent_name=task.agent_name,
                    )
                    await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
    
    def _get_agents_summary(self) -> str:
        """Get a summary of all available agents and their capabilities"""
        summary_parts = ["Available Remote Agents:\n"]
        
        for agent in self.remote_agents.values():
            summary_parts.append(f"\n{agent.name} ({agent.url}):")
            summary_parts.append(f"  Description: {agent.description}")
            summary_parts.append("  Skills:")
            for skill in agent.skills:
                summary_parts.append(f"    - {skill['name']}: {skill['description']}")
        
        return "\n".join(summary_parts)
    
    def _get_coder_agent_url(self) -> str:
        """Get the URL of the coder agent for visualization tasks"""
        for agent in self.remote_agents.values():
            # Look for coder agent by checking name or skills
            if "coder" in agent.name.lower():
                return agent.url
            # Also check if any skill mentions code writing/generation
            for skill in agent.skills:
                if "code" in skill['name'].lower() or "code" in skill['description'].lower():
                    return agent.url
        
        # If no coder agent found, return empty string (will be handled in prompt)
        logger.warning("No coder agent found in registered agents")
        return "CODER_AGENT_NOT_FOUND"
    
    async def _plan_tasks(self, user_query: str, query_id: str, reference_context: List[Dict[str, str]] = None) -> Tuple[bool, List[OrchestratorTask], str]:
        """Analyze user query and generate task execution plan using LLM"""
        if not self.model_client:
            raise ValueError("LLM model_client is required for task planning")

        # Capability/tool questions should be answered deterministically from
        # connected agent metadata to avoid LLM hallucinations.
        if self._is_capabilities_query(user_query):
            return False, [], self._format_capabilities_response()

        # Use a compact agent summary by default to reduce LLM prompt size and latency.
        agents_summary = self._get_agents_summary_compact()

        # Allow operators to override or augment the agent listing shown to the LLM.
        # - ORCHESTRATOR_AVAILABLE_AGENTS_TEXT: replaces the generated summary
        # - ORCHESTRATOR_OTHER_AGENTS_TEXT: appended as "other agents" guidance for out-of-scope requests
        agents_summary = os.getenv("ORCHESTRATOR_AVAILABLE_AGENTS_TEXT", agents_summary)
        other_agents_text = os.getenv("ORCHESTRATOR_OTHER_AGENTS_TEXT", "").strip()

        orchestrator_context_text = os.getenv(
            "ORCHESTRATOR_CONTEXT_TEXT",
            "You are the Task Planner for an orchestrator that can delegate work to the remote agents listed below.",
        ).strip()
        task_planner_prompt_prefix = os.getenv("TASK_PLANNER_PROMPT_PREFIX", "").strip()
        task_planner_prompt_suffix = os.getenv("TASK_PLANNER_PROMPT_SUFFIX", "").strip()
        
        # Build reference context section if available
        reference_section = ""
        if reference_context and len(reference_context) > 0:
            reference_section = "\n\nPrevious Conversation Context (for reference if the new query refers to it):\n"
            for i, ref in enumerate(reference_context, 1):
                reference_section += f"\nPrevious Query {i}:\n"
                reference_section += f"User asked: {ref['query']}\n"
                reference_section += f"Response: {ref['response_summary']}\n"
            reference_section += "\n**IMPORTANT**: If the new query uses phrases like 'this data', 'that', 'it', 'these results', 'the above', or similar references WITHOUT specifying what data, you MUST use the most recent response data from the context above. For example, if the user says 'Draw a line chart for this data', use the data from the most recent Previous Query response.\n"
        
        # Find coder agent for visualization tasks
        coder_agent_url = self._get_coder_agent_url()
        
        planning_prompt = f"""
    {orchestrator_context_text}

    {task_planner_prompt_prefix}

{agents_summary}
{reference_section}

    **SCOPE LIMITATION**: If the user asks any generic query apart from the capabilities and skills of the agents attached to the orchestrator, you should respond that you can help only with those agent topics.
    If the request seems out-of-scope, suggest which available agent(s) are relevant.
    {('\\n\\nOther available agents info (may be outside this orchestrator):\\n' + other_agents_text) if other_agents_text else ''}

Current User Query: {user_query}

Analyze the user query and determine:
1. Is this a query that requires task execution by the agents? (yes/no)
2. If the query references previous conversation context using words like "this", "that", "it", etc., use the context data. Also reference to the reference context if the user query is not clear or implicitly refers to the previous conversation.
3. If yes, break it down into specific tasks for the appropriate agents.
4. Complex queries should be inferred and properly broken down into multiple tasks. 
5. Identify any dependencies between tasks (e.g., Task B needs results from Task A)
6. Do not ask for large volume of data in a task while using from_time, to_time, from_date, to_date and resolution like parameters unless otherwise specified by the user.
7. Do not mention explicit use of tools in the task description or query. Describe the task/query in natural language. Add Tool Suggestions: [Tool names] at the end of the query for the agent to understand which tools to use.
8. Do not add Tool Suggestions for the coder agent.
9. Do not provide eloborative query. Make it concise and to the point. Also dont combine multiple steps into one task.
10. Do not give multiple tool suggestions. Identity the most apt tool and suggest that one.
11. **ALWAYS prefer making assumptions over asking the user for clarification.** If a parameter is missing, infer the most reasonable value and include it in the task's query so the agent knows what you assumed.
    - If the user has not specified a date, use today's date or the closest upcoming milestone/release date.
    - If the user has not specified a project/team name, use the one most aligned with the context of the conversation or previous queries.
    - If the user has not specified a release/milestone name, instruct the agent to use the closest upcoming one.
    - State assumptions explicitly inside the task query (e.g. "Use milestone closest to 2026-03-04 if exact name not found.").
    - Only respond with NOT_A_TASK asking for clarification when there is absolutely zero usable context — e.g. the user's message is a single ambiguous word with no prior conversation context and no matching agent can be inferred.

**CRITICAL RULES:**

1. **CODER AGENT USAGE RULE**:
     - Only create a task for the coder agent when the user explicitly asks for information to be represented in another way than a plain text response.
     - Examples that DO justify using the coder agent: generating code/scripts, producing HTML, creating charts/graphs/visualizations, producing structured output formats (JSON/YAML/CSV), generating diagrams (e.g., Mermaid), or transforming results into a specific template.
     - If the user only asks to fetch/analyze/summarize/explain data in text, do NOT add a coder agent task.

2. **CONTEXT-BASED REPRESENTATION RULE**:
     - If the user asks to visualize/chart/graph/draw/format "this data" / "the above results" / similar references,
         AND previous conversation context contains the relevant data,
         create a coder agent task that explicitly references the prior response data to transform/represent it.
     - The representation task should depend on ALL required upstream data-fetching tasks, or NONE if using only previous context.

3. **CAPABILITIES / FUNCTIONALITY QUESTIONS**:
     - If the user asks what functionality this orchestrator/agent has (e.g., "what can you do?", "what tools are available?", "what agents do you have?"),
         respond with NOT_A_TASK and provide a SINGLE markdown/text response listing all available agents, their skills, and any tool details included in their descriptions.
     - Do not create tasks for capability questions.

If this is NOT a task query (e.g., greeting, general question), respond with:
NOT_A_TASK: [your friendly response or follow-up question to get more details if user query is vague and cannot be turned into a task without more information]

If this IS a task query, respond in this format:
TASK_QUERY
TASK: [task_id] | [agent_url] | [task_description] | [specific_query] | DEPENDS_ON: [task_id1,task_id2] or NONE

IMPORTANT: 
- Task IDs must be in format: task_0, task_1, task_2, etc. (sequential starting from 0)
- List tasks in order (task_0 first, then task_1, etc.)
- Dependencies must reference task IDs of tasks listed earlier
- A task can only depend on tasks with lower numbers (e.g., task_2 can depend on task_0 or task_1)
- If the user query refers to previous context (e.g., "what about X?" or "Draw a chart for this data"), incorporate that understanding and reference the context data explicitly in the task query
- Only include a coder agent task when the user explicitly asks for non-plain-text representation (URL: {coder_agent_url})

Example with automatic visualization:
TASK_QUERY
TASK: task_0 | http://fetch-agent.com | Fetch latency data | Get latency data for 2025-11-12 | DEPENDS_ON: NONE
TASK: task_1 | {coder_agent_url} | Generate visualization | Generate interactive HTML code with a chart to visualize the latency data as a line graph or bar chart | DEPENDS_ON: task_0

Example with context-based visualization (when user says "draw a chart for this data" and previous query had data):
TASK_QUERY
TASK: task_0 | {coder_agent_url} | Generate visualization | Generate interactive HTML code with a line chart to visualize the latency comparison data from the previous query (dates 2025-11-15 and 2025-11-17) that includes UMS, AMP, and Overall latency metrics | DEPENDS_ON: NONE

Example without visualization (no data fetching):
TASK_QUERY
TASK: task_0 | http://agent.com | Send email | Send summary email to team@example.com | DEPENDS_ON: NONE

Generate the task plan.
{task_planner_prompt_suffix}
"""
# - Provide correct and accurate tool suggestions along with the task query to use for each task based on the agent tools.
# - Mention exact values for parameters or arguments. Dont mention to take from previous task. 
        
        try:
            response = await self.model_client.create(
                messages=[SystemMessage(content=planning_prompt)]
            )
            plan_text = response.content
            
            task_plans =  self._parse_task_plan(plan_text, query_id)
            # logger.info(f"Generated task plan:\n{task_plans[1]}")
            return task_plans
            
        except Exception as e:
            logger.error(f"Error in LLM task planning: {e}")
            raise
    
    def _parse_task_plan(self, plan_text: str, query_id: str) -> Tuple[bool, List[OrchestratorTask], str]:
        """Parse LLM-generated task plan"""
        lines = plan_text.strip().split('\n')
        
        # Check if not a task query
        if lines[0].startswith("NOT_A_TASK:"):
            # Extract the first line content
            first_line = lines[0].replace("NOT_A_TASK:", "").strip()
            
            # Collect all subsequent non-empty lines as part of the response (until we hit TASK_QUERY or TASK:)
            response_lines = [first_line]
            for line in lines[1:]:
                line = line.strip()
                if line and not line.startswith("TASK_QUERY") and not line.startswith("TASK:"):
                    response_lines.append(line)
                else:
                    break
            
            # Join all lines to form the complete response
            response = "\n".join(response_lines)
            
            # Remove template brackets if present (e.g., "[your friendly response]" -> "your friendly response")
            if response.startswith("[") and response.endswith("]"):
                response = response[1:-1].strip()
            
            logger.info("No tasks to parse.")
            return False, [], response
        
        # Parse tasks
        tasks = []
        # Use the query_id passed from the original user message
        # query_id is now passed as parameter instead of generating a new UUID
        
        for line in lines[1:]:  # Skip "TASK_QUERY" line
            line = line.strip()
            if line.startswith("TASK:"):
                parts = line.replace("TASK:", "").split("|")
                if len(parts) >= 5:
                    task_id = parts[0].strip()
                    agent_url = parts[1].strip()
                    description = parts[2].strip()
                    query = parts[3].strip()
                    depends_raw = parts[4].strip()
                    
                    # Parse dependencies
                    dependencies = []
                    if "DEPENDS_ON:" in depends_raw:
                        deps_str = depends_raw.replace("DEPENDS_ON:", "").strip()
                        if deps_str != "NONE":
                            dependencies = [d.strip() for d in deps_str.split(",")]
                    
                    # Find agent name
                    agent_name = "Unknown Agent"
                    for agent in self.remote_agents.values():
                        if agent.url == agent_url:
                            agent_name = agent.name
                            break
                    
                    task = OrchestratorTask(
                        task_id=task_id,
                        query_id=query_id,
                        agent_url=agent_url,
                        agent_name=agent_name,
                        description=description,
                        query=query,
                        dependencies=dependencies
                    )
                    tasks.append(task)

        logger.info(f"Parsed {len(tasks)} tasks from plan.") 
        return True, tasks, ""
    
    def _generate_summary(self, query_id: str, tasks: List[OrchestratorTask]) -> List[Dict[str, Any]]:
        """Generate final summary of all task executions as a list of dictionaries"""
        summary_parts = []
        
        # Individual task results
        for task in tasks:
            task_summary = {
                "task_id": task.task_id,
                "task_description": task.description,
                "agent_name": task.agent_name,
                "task_status": task.status.value,
                "response": task.response if task.status == TaskStatus.COMPLETED else None,
                "error": task.error if task.error else None,
                "input_required": task.input_required_message if task.status == TaskStatus.WAITING_FOR_INPUT else None
            }
            summary_parts.append(task_summary)
        
        return summary_parts
    
    
    def _serialize_task(self, task: OrchestratorTask) -> Dict[str, Any]:
        """Serialize a task object for message passing"""
        return {
            "task_id": task.task_id,
            "query_id": task.query_id,
            "agent_url": task.agent_url,
            "agent_name": task.agent_name,
            "description": task.description,
            "query": task.query,
            "dependencies": task.dependencies,
            "status": task.status.value,  # Convert enum to string
            "response": task.response,
            "error": task.error,
            "dependency_results": task.dependency_results,
            "remote_task_id": task.remote_task_id,
            "remote_context_id": task.remote_context_id,
            "input_required_message": task.input_required_message,
            "timestamp": task.timestamp,
            "resolution_tasks": task.resolution_tasks,
            "retry_count": task.retry_count,
            "is_resolution_task": task.is_resolution_task,
            "parent_task_id": task.parent_task_id
        }

    async def _try_auto_resolve_error(self, failed_task: OrchestratorTask, all_tasks: List[OrchestratorTask], ctx: MessageContext) -> bool:
        """
        Try to automatically resolve a task error by analyzing it and creating resolution tasks.
        
        Returns:
            True if error resolution was attempted, False otherwise
        """
        # Check if we've exceeded max retries
        if failed_task.retry_count >= failed_task.max_retries:
            logger.warning(f"Task {failed_task.task_id} has exceeded max retries ({failed_task.max_retries})")
            return False
        
        # Don't try to resolve resolution tasks (avoid infinite loops)
        if failed_task.is_resolution_task:
            logger.info(f"Task {failed_task.task_id} is a resolution task, not attempting further resolution")
            return False
        
        logger.info(f"🔍 Analyzing error for task {failed_task.task_id}: {failed_task.error[:200]}")
        
        # Use LLM to analyze the error and suggest resolution tasks
        try:
            agents_summary = self._get_agents_summary_compact()
            
            error_analysis_prompt = f"""
You are an error analysis assistant. A task has failed and you need to determine if it can be automatically resolved.

Task Details:
- Task ID: {failed_task.task_id}
- Description: {failed_task.description}
- Query: {failed_task.query}
- Agent: {failed_task.agent_name} ({failed_task.agent_url})
- Error: {failed_task.error}

Available Agents:
{agents_summary}

Analyze the error and determine:
1. Can this error be resolved automatically? (yes/no)
2. If yes, what specific tasks are needed to resolve it?

Common resolvable errors:
- Missing data/parameters that another agent can provide
- Authentication/credential issues that can be fixed
- Format/transformation issues
- Prerequisite tasks that should run first.
- Modifying the arguments values (e.g. adjusting time range, resolution, retrieval counts or other parameters) and retrying the same task.

Conditions:
- Do not mention explicit use of tools in the task description or query. Describe the task/query in natural language.
- Generate a single resolution task that should be accurate enough. 
- Dont combine multiple steps into one task query.

If the error can be resolved, respond with:
RESOLVABLE
RESOLUTION_TASK: [agent_url] | [task_description] | [specific_query_to_resolve_error]

If the error cannot be resolved automatically, respond with:
NOT_RESOLVABLE: [brief reason]

Generate the error analysis:
"""
    # (You can add multiple RESOLUTION_TASK lines if needed)
            
            response = await self.model_client.create(
                messages=[SystemMessage(content=error_analysis_prompt)]
            )
            analysis_text = response.content.strip()
            
            logger.info(f"📊 Error analysis result: {analysis_text}")
            
            # Parse the analysis
            if analysis_text.startswith("NOT_RESOLVABLE"):
                logger.info(f"Error for task {failed_task.task_id} is not automatically resolvable")
                return False
            
            if not analysis_text.startswith("RESOLVABLE"):
                logger.warning(f"Unexpected error analysis format: {analysis_text[:100]}")
                return False
            
            # Parse resolution tasks
            resolution_tasks = []
            lines = analysis_text.split('\n')
            
            for line in lines[1:]:  # Skip "RESOLVABLE" line
                line = line.strip()
                if line.startswith("RESOLUTION_TASK:"):
                    parts = line.replace("RESOLUTION_TASK:", "").split("|")
                    if len(parts) >= 3:
                        agent_url = parts[0].strip()
                        description = parts[1].strip()
                        query = parts[2].strip()
                        
                        # Find agent name
                        agent_name = "Unknown Agent"
                        for agent in self.remote_agents.values():
                            if agent.url == agent_url:
                                agent_name = agent.name
                                break
                        
                        resolution_tasks.append({
                            "agent_url": agent_url,
                            "agent_name": agent_name,
                            "description": description,
                            "query": query
                        })
            
            if not resolution_tasks:
                logger.warning(f"No resolution tasks generated for task {failed_task.task_id}")
                return False
            
            logger.info(f"✨ Generated {len(resolution_tasks)} resolution tasks for {failed_task.task_id}")
            
            # Create and execute resolution tasks
            failed_task.status = TaskStatus.RESOLVING_ERROR
            failed_task.retry_count += 1
            
            # Generate task IDs for resolution tasks
            existing_task_ids = [t.task_id for t in all_tasks]
            max_task_num = max([int(tid.split('_')[1]) for tid in existing_task_ids if '_' in tid], default=-1)
            
            created_resolution_task_ids = []
            
            for idx, res_task_info in enumerate(resolution_tasks):
                resolution_task_id = f"task_{max_task_num + 1 + idx}_resolution"
                
                resolution_task = OrchestratorTask(
                    task_id=resolution_task_id,
                    query_id=failed_task.query_id,
                    agent_url=res_task_info["agent_url"],
                    agent_name=res_task_info["agent_name"],
                    description=res_task_info["description"],
                    query=res_task_info["query"],
                    dependencies=[],  # Resolution tasks have no dependencies
                    is_resolution_task=True,
                    parent_task_id=failed_task.task_id
                )
                
                all_tasks.append(resolution_task)
                created_resolution_task_ids.append(resolution_task_id)
                
                # Send for execution immediately
                session_id = self.query_session_map.get(failed_task.query_id, "")
                reference_context = self.query_reference_context.get(failed_task.query_id, [])
                
                task_msg = TaskExecutionMessage(
                    task_id=resolution_task.task_id,
                    query_id=failed_task.query_id,
                    agent_url=resolution_task.agent_url,
                    agent_name=resolution_task.agent_name,
                    description=resolution_task.description,
                    query=resolution_task.query,
                    dependencies=resolution_task.dependencies,
                    dependency_results={},
                    session_id=session_id,
                    reference_context=reference_context
                )
                await self._emit_task_started_event(
                    query_id=failed_task.query_id,
                    task_id=resolution_task.task_id,
                    task_description=resolution_task.description,
                    agent_name=resolution_task.agent_name,
                )
                await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
                logger.info(f"📤 Sent resolution task {resolution_task_id} for execution")
            
            # Track resolution tasks in the failed task
            failed_task.resolution_tasks = created_resolution_task_ids
            
            # After resolution tasks complete, retry the original task
            # This will be handled by monitoring resolution task completions
            
            return True
            
        except Exception as e:
            logger.error(f"Error during error analysis for task {failed_task.task_id}: {e}")
            return False

    async def _try_auto_resolve_input(self, input_task: OrchestratorTask, all_tasks: List[OrchestratorTask], ctx: MessageContext) -> bool:
        """
        Try to automatically resolve an input requirement by identifying agents that can provide the input.
        
        Returns:
            True if input resolution was attempted, False otherwise
        """
        logger.info(f"🔍 Analyzing input requirement for task {input_task.task_id}")
        logger.info(f"   Input required message: {input_task.input_required_message[:200]}")
        
        try:
            agents_summary = self._get_agents_summary_compact()

            input_analysis_prompt = f"""
                You are an input analysis assistant. A task requires additional information and you must decide how to resolve it.

                Task Details:
                - Task ID: {input_task.task_id}
                - Description: {input_task.description}
                - Query: {input_task.query}
                - Agent: {input_task.agent_name} ({input_task.agent_url})
                - Input Required: {input_task.input_required_message}
                - Is Resolution Task: {input_task.is_resolution_task}
                {f"- Parent Task Query: {parent_query}\n- Parent Task Input Required Message: {parent_input_required_message}" if parent_query and parent_input_required_message else ""}

                Available Agents:
                {agents_summary}

                YOUR GOAL: Resolve this automatically wherever possible. Do NOT escalate to the user unless it is impossible to proceed even with a reasonable assumption.

                Rules:
                - If the agent is asking the user to choose between multiple options (e.g. "which milestone?", "which project?"), treat this as AUTO_RESOLVABLE. Generate an INPUT_TASK that asks the same agent to use the most likely/closest available option and explicitly state the assumption in the query (e.g. "use the closest upcoming milestone to 2026-03-04").
                - If a lookup agent can fetch the required value, use it.
                - If a reasonable default can be inferred from the original query context, state it directly in the INPUT_TASK query.
                - Only respond USER_INPUT_REQUIRED when the missing information is a personal decision, credential, or something no agent or reasonable default can supply.

                Conditions for the INPUT_TASK:
                - Single task only.
                - Concise query — no elaboration.
                - Include any inferred/assumed values directly in the query text.
                - Do not mention tool names explicitly.

                If the input can be resolved automatically, respond with:
                AUTO_RESOLVABLE
                INPUT_TASK: [agent_url] | [task_description] | [specific_query_with_assumed_values]

                If it is truly impossible to resolve automatically, respond with:
                USER_INPUT_REQUIRED: [brief reason]

                Generate the input analysis:
                """
            
            response = await self.model_client.create(
                messages=[SystemMessage(content=input_analysis_prompt)]
            )
            analysis_text = response.content.strip()
            
            logger.info(f"📊 Input analysis result: {analysis_text}")
            
            # Parse the analysis
            if analysis_text.startswith("USER_INPUT_REQUIRED"):
                logger.info(f"Input for task {input_task.task_id} requires user intervention")
                return False
            
            if not analysis_text.startswith("AUTO_RESOLVABLE"):
                logger.warning(f"Unexpected input analysis format: {analysis_text[:100]}")
                return False
            
            # Parse input collection tasks
            lines = analysis_text.split('\n')
            input_task_info = None
            
            for line in lines[1:]:  # Skip "AUTO_RESOLVABLE" line
                line = line.strip()
                if line.startswith("INPUT_TASK:"):
                    parts = line.replace("INPUT_TASK:", "").split("|")
                    if len(parts) >= 3:
                        agent_url = parts[0].strip()
                        description = parts[1].strip()
                        query = parts[2].strip()
                        
                        # Find agent name
                        agent_name = "Unknown Agent"
                        for agent in self.remote_agents.values():
                            if agent.url == agent_url:
                                agent_name = agent.name
                                break
                        
                        input_task_info = {
                            "agent_url": agent_url,
                            "agent_name": agent_name,
                            "description": description,
                            "query": query
                        }
                        break
            
            if not input_task_info:
                logger.warning(f"No input collection task generated for task {input_task.task_id}")
                return False
            
            logger.info(f"✨ Generated input collection task for {input_task.task_id}")
            
            # Create input collection task
            existing_task_ids = [t.task_id for t in all_tasks]
            max_task_num = max([int(tid.split('_')[1]) for tid in existing_task_ids if '_' in tid], default=-1)
            
            input_collection_task_id = f"task_{max_task_num + 1}_input_collection"
            
            # If the input_task is itself a resolution task, inherit its parent_task_id
            # Otherwise, use the input_task as the parent
            parent_id = input_task.parent_task_id if input_task.is_resolution_task else input_task.task_id
            
            input_collection_task = OrchestratorTask(
                task_id=input_collection_task_id,
                query_id=input_task.query_id,
                agent_url=input_task_info["agent_url"],
                agent_name=input_task_info["agent_name"],
                description=input_task_info["description"],
                query=input_task_info["query"],
                dependencies=[],
                is_resolution_task=True,
                parent_task_id=parent_id
            )
            
            all_tasks.append(input_collection_task)
            
            # Track this as a resolution task for the input-waiting task
            if parent_task:
                parent_task.resolution_tasks.append(input_collection_task_id)
            else:
                input_task.resolution_tasks = [input_collection_task_id]
            
            # Send for execution
            session_id = self.query_session_map.get(input_task.query_id, "")
            reference_context = self.query_reference_context.get(input_task.query_id, [])
            
            task_msg = TaskExecutionMessage(
                task_id=input_collection_task.task_id,
                query_id=input_task.query_id,
                agent_url=input_collection_task.agent_url,
                agent_name=input_collection_task.agent_name,
                description=input_collection_task.description,
                query=input_collection_task.query,
                dependencies=input_collection_task.dependencies,
                dependency_results={},
                session_id=session_id,
                reference_context=reference_context
            )
            await self._emit_task_started_event(
                query_id=input_task.query_id,
                task_id=input_collection_task.task_id,
                task_description=input_collection_task.description,
                agent_name=input_collection_task.agent_name,
            )
            await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
            logger.info(f"📤 Sent input collection task {input_collection_task_id} for execution")
            
            return True
            
        except Exception as e:
            logger.error(f"Error during input analysis for task {input_task.task_id}: {e}")
            return False

    async def _check_and_retry_parent_task(self, resolution_task: OrchestratorTask, all_tasks: List[OrchestratorTask], ctx: MessageContext) -> None:
        """
        Check if all resolution tasks for a parent task have completed, and retry the parent task if so.
        """
        if not resolution_task.parent_task_id:
            return
        
        # Find the parent task
        parent_task = None
        for task in all_tasks:
            if task.task_id == resolution_task.parent_task_id:
                parent_task = task
                break
        
        if not parent_task:
            logger.warning(f"Could not find parent task {resolution_task.parent_task_id}")
            return
        
        # Check if all resolution tasks are complete
        all_resolution_complete = True
        resolution_results = {}
        
        for res_task_id in parent_task.resolution_tasks:
            res_task = next((t for t in all_tasks if t.task_id == res_task_id), None)
            if not res_task:
                logger.warning(f"Could not find resolution task {res_task_id}")
                continue
            
            if res_task.status not in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.SKIPPED]:
                all_resolution_complete = False
                break
            
            if res_task.status == TaskStatus.COMPLETED:
                resolution_results[res_task_id] = res_task.response
        
        if not all_resolution_complete:
            logger.info(f"Not all resolution tasks complete for parent {parent_task.task_id}")
            return
        
        # Check if any resolution task failed
        any_resolution_failed = any(
            next((t for t in all_tasks if t.task_id == res_id), OrchestratorTask(
                task_id="", query_id="", agent_url="", agent_name="", description="", query="", status=TaskStatus.FAILED
            )).status == TaskStatus.FAILED
            for res_id in parent_task.resolution_tasks
        )
        
        if any_resolution_failed:
            logger.warning(f"Some resolution tasks failed for parent {parent_task.task_id}, not retrying")
            parent_task.status = TaskStatus.FAILED
            return
        
        logger.info(f"✅ All resolution tasks complete for {parent_task.task_id}, retrying original task")
        
        # Retry the parent task with resolution results
        parent_task.status = TaskStatus.PENDING
        
        # Add resolution results to dependency results
        for res_id, res_result in resolution_results.items():
            parent_task.dependency_results[f"resolution_{res_id}"] = res_result
        
        # For input-waiting tasks, use the resolution result as user input
        if parent_task.input_required_message:
            # Combine all resolution results as input
            combined_input = "\\n\\n".join([f"From {res_id}:\\n{result}" for res_id, result in resolution_results.items()])
            
            session_id = self.query_session_map.get(parent_task.query_id, "")
            reference_context = self.query_reference_context.get(parent_task.query_id, [])
            
            # Resume task with collected input
            task_msg = TaskExecutionMessage(
                task_id=parent_task.task_id,
                query_id=parent_task.query_id,
                agent_url=parent_task.agent_url,
                agent_name=parent_task.agent_name,
                description=parent_task.description,
                query=parent_task.query,
                dependencies=parent_task.dependencies,
                dependency_results=parent_task.dependency_results,
                user_input=combined_input,
                session_id=session_id,
                reference_context=reference_context
            )
            await self._emit_task_started_event(
                query_id=parent_task.query_id,
                task_id=parent_task.task_id,
                task_description=parent_task.description,
                agent_name=parent_task.agent_name,
            )
            await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
            logger.info(f"📤 Resumed parent task {parent_task.task_id} with collected input")
        else:
            # For failed tasks, retry with resolution context
            enhanced_query = f"""{parent_task.query}
                Additional context from error resolution:
                {chr(10).join([f"- {res_id}: {result[:200]}" for res_id, result in resolution_results.items()])}
                """
            
            session_id = self.query_session_map.get(parent_task.query_id, "")
            reference_context = self.query_reference_context.get(parent_task.query_id, [])
            
            task_msg = TaskExecutionMessage(
                task_id=parent_task.task_id,
                query_id=parent_task.query_id,
                agent_url=parent_task.agent_url,
                agent_name=parent_task.agent_name,
                description=parent_task.description,
                query=enhanced_query,
                dependencies=parent_task.dependencies,
                dependency_results=parent_task.dependency_results,
                session_id=session_id,
                reference_context=reference_context
            )
            await self._emit_task_started_event(
                query_id=parent_task.query_id,
                task_id=parent_task.task_id,
                task_description=parent_task.description,
                agent_name=parent_task.agent_name,
            )
            await self.publish_message(task_msg, topic_id=TASK_EXECUTION_TOPIC)
            logger.info(f"📤 Retrying parent task {parent_task.task_id} with resolution context")
