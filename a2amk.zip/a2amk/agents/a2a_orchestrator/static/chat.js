let currentQueryId = null;
let currentTaskId = null;
let isWaitingForInput = false;
let isProcessing = false;
let currentSessionId = null;
let currentEventSource = null;  // Track SSE connection
let streamingTasks = [];  // Track tasks as they complete
let processedQueryCompletions = new Set();  // Track completed queries to prevent duplicates

// Determine BASE_PATH for API/static URLs. Priority:
// 1. window.BASE_PATH (if set by server-side template)
// 2. Derive from this script's `src` (useful when script is served from /<base>/static/chat.js)
(function() {
    function normalize(p) {
        if (!p) return '';
        // ensure leading slash and no trailing slash
        return p === '/' ? '' : ('/' + p.replace(/^\//, '').replace(/\/$/, ''));
    }

    function detectFromScript() {
        try {
            var script = document.currentScript;
            if (!script) {
                var scripts = document.getElementsByTagName('script');
                script = scripts[scripts.length - 1];
            }
            if (script && script.src) {
                var src = new URL(script.src, location.href);
                var m = src.pathname.match(/(.*)\/static\/chat(?:\.min)?\.js$/);
                if (m) return normalize(m[1]);
            }
        } catch (e) {
            // ignore
        }
        return '';
    }

    var bp = '';
    if (typeof window.BASE_PATH === 'string') {
        bp = normalize(window.BASE_PATH);
    }
    if (!bp) bp = detectFromScript();
    // expose for debugging and other scripts
    window.__A2A_BASE_PATH = bp;
})();

function apiUrl(path) {
    var base = window.__A2A_BASE_PATH || '';
    if (!path) return base || '/';
    if (/^https?:\/\//.test(path) || /^\/\//.test(path)) return path;
    if (path.startsWith('/')) return (base || '') + path;
    return (base || '') + '/' + path;
}

function generateSessionId() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return 'session_' + Date.now() + '_' + array[0].toString(36);
}

function startNewSession() {
    currentSessionId = generateSessionId();
    document.getElementById('current-session').textContent = currentSessionId.substr(-12);
    document.getElementById('chat-container').innerHTML = '';
    addMessage('New session started: ' + currentSessionId.substr(-12), 'system');
    updateStatus('Ready for new query in new session', 'ready');
}

async function showSessionHistory() {
    if (!currentSessionId) {
        alert('No active session. Please start a new session first.');
        return;
    }
    
    try {
        const response = await fetch(apiUrl(`/history/session/${currentSessionId}`));
        const data = await response.json();
        
        if (Object.keys(data).length === 0) {
            addMessage('No history found for this session.', 'system');
            return;
        }
        
        const historyElement = createHistoryElement(data);
        addMessage(historyElement, 'system');
    } catch (error) {
        addMessage('Error loading history: ' + error.message, 'system');
    }
}

async function listSessions() {
    try {
        const response = await fetch(apiUrl('/history/sessions'));
        const sessions = await response.json();
        
        if (sessions.length === 0) {
            addMessage('No sessions found.', 'system');
            return;
        }
        
        const sessionsElement = createSessionsElement(sessions);
        addMessage(sessionsElement, 'system');
    } catch (error) {
        addMessage('Error loading sessions: ' + error.message, 'system');
    }
}

async function loadSession(sessionId) {
    currentSessionId = sessionId;
    document.getElementById('current-session').textContent = sessionId.substr(-12);
    document.getElementById('chat-container').innerHTML = '';
    addMessage('Loaded session: ' + sessionId.substr(-12), 'system');
    await showSessionHistory();
}

async function clearAllHistory() {
    if (!confirm('Are you sure you want to clear ALL session history? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch(apiUrl('/history/clear'), {
            method: 'DELETE'
        });
        
        if (response.ok) {
            document.getElementById('chat-container').innerHTML = '';
            currentSessionId = null;
            document.getElementById('current-session').textContent = 'None';
            addMessage('✅ All session history has been cleared successfully.', 'system');
            updateStatus('Ready for new query', 'ready');
        } else {
            const error = await response.json();
            addMessage('❌ Error clearing history: ' + error.detail, 'system');
        }
    } catch (error) {
        addMessage('❌ Error clearing history: ' + error.message, 'system');
    }
}

function generateQueryId() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return 'query_' + Date.now() + '_' + array[0].toString(36);
}

function updateStatus(message, type = 'ready') {
    const statusBar = document.getElementById('query-status');
    const indicator = type === 'completed' ? '🟢' : 
                    type === 'processing' ? '🟡' : 
                    type === 'input-required' ? '🔴' : '⚪';
    statusBar.textContent = `${indicator} ${message}`;
    if (currentQueryId) {
        statusBar.textContent += ` (Query: ${currentQueryId.substr(-8)})`;
    }
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function isMarkdownTable(text) {
    // Check if text contains markdown table syntax
    // Look for lines with | characters that form table structure
    const lines = text.split('\n');
    let tableLineCount = 0;
    
    for (const line of lines) {
        const trimmed = line.trim();
        // Count lines that look like table rows (contain | and have content)
        if (trimmed.includes('|') && trimmed.length > 3) {
            // Skip lines that are just separators
            if (!/^[\|\-\s:=]+$/.test(trimmed)) {
                tableLineCount++;
            }
        }
    }
    
    // Consider it a table if we have at least 2 lines that look like table rows
    return tableLineCount >= 2;
}

function convertMarkdownTableToHtml(markdownText) {
    try {
        const lines = markdownText.split('\n');
        let result = '';
        let currentSection = '';
        let inTable = false;
        let tableLines = [];
        let consecutiveTableLines = 0;
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmedLine = line.trim();
            
            // Check if this is a separator line (all dashes, pipes, spaces, colons, equals)
            const isSeparatorLine = /^[\|\-\s:=]+$/.test(trimmedLine) && trimmedLine.includes('|');
            
            // Check if this is a table content line
            const isTableLine = trimmedLine.includes('|') && !isSeparatorLine && trimmedLine.length > 3;
            
            // Check if this looks like a header (Problem 1, Problem 2, etc.)
            const isHeader = /^(Problem \d+|###|####|##|#)/.test(trimmedLine) || 
                           /^[A-Z][a-zA-Z\s]*\d*\s*$/.test(trimmedLine);
            
            if (isTableLine) {
                consecutiveTableLines++;
                
                if (!inTable && consecutiveTableLines >= 1) {
                    // Starting a new table - process any accumulated non-table content
                    if (currentSection.trim()) {
                        result += processNonTableContent(currentSection);
                        currentSection = '';
                    }
                    inTable = true;
                    tableLines = [];
                }
                
                if (inTable) {
                    tableLines.push(line);
                }
            } else {
                // Not a table line
                if (inTable && tableLines.length > 0) {
                    // End of table - process the accumulated table lines
                    result += createHtmlTable(tableLines);
                    tableLines = [];
                    inTable = false;
                }
                
                consecutiveTableLines = 0;
                
                // Add the current non-table line to current section (skip separator lines)
                if (!isSeparatorLine) {
                    currentSection += line + '\n';
                }
            }
        }
        
        // Handle any remaining table
        if (inTable && tableLines.length > 0) {
            result += createHtmlTable(tableLines);
        }
        
        // Handle any remaining non-table content
        if (currentSection.trim()) {
            result += processNonTableContent(currentSection);
        }
        
        return result || escapeHtml(markdownText);
        
    } catch (error) {
        console.error('Error converting markdown table:', error);
        return escapeHtml(markdownText);
    }
}

function processNonTableContent(content) {
    const lines = content.trim().split('\n');
    let html = '';
    
    for (const line of lines) {
        const trimmedLine = line.trim();
        if (trimmedLine === '') continue;
        
        // Check for headers (###, ##, #)
        if (trimmedLine.startsWith('####')) {
            html += `<h4 style="margin: 15px 0 10px 0; color: #333; font-weight: bold;">${escapeHtml(trimmedLine.substring(4).trim())}</h4>`;
        } else if (trimmedLine.startsWith('###')) {
            html += `<h3 style="margin: 20px 0 15px 0; color: #333; font-weight: bold; border-bottom: 2px solid #4caf50; padding-bottom: 5px;">${escapeHtml(trimmedLine.substring(3).trim())}</h3>`;
        } else if (trimmedLine.startsWith('##')) {
            html += `<h2 style="margin: 25px 0 15px 0; color: #333; font-weight: bold;">${escapeHtml(trimmedLine.substring(2).trim())}</h2>`;
        } else if (trimmedLine.startsWith('#')) {
            html += `<h1 style="margin: 30px 0 20px 0; color: #333; font-weight: bold;">${escapeHtml(trimmedLine.substring(1).trim())}</h1>`;
        } else if (trimmedLine.startsWith('-')) {
            // List item
            html += `<div style="margin: 5px 0; padding-left: 20px;">${escapeHtml(trimmedLine)}</div>`;
        } else {
            // Regular paragraph
            html += `<div style="margin: 10px 0; line-height: 1.6;">${escapeHtml(trimmedLine)}</div>`;
        }
    }
    
    return html;
}

function createHtmlTable(tableLines) {
    if (tableLines.length === 0) return '';
    
    let html = '<table style="border-collapse: collapse; table-layout: fixed; width: 100%; margin: 15px 0; border: 1px solid #ddd; background: white;">';
    
    // Check if first line looks like a header (Key, Value pattern)
    let hasHeader = false;
    if (tableLines.length > 0) {
        const firstLine = tableLines[0].trim();
        const cells = firstLine.split('|').map(cell => cell.trim()).filter(cell => cell !== '');
        if (cells.length >= 2 && (
            cells[0].toLowerCase().includes('key') || 
            cells[0].toLowerCase().includes('field') ||
            cells[0].toLowerCase().includes('property')
        )) {
            hasHeader = true;
        }
    }
    
    let processedFirstRow = false;
    
    for (const line of tableLines) {
        const trimmedLine = line.trim();
        if (!trimmedLine.includes('|')) continue;
        
        // Split by | and clean up cells
        const cells = trimmedLine.split('|')
            .map(cell => cell.trim())
            .filter(cell => cell !== '');
        
        if (cells.length === 0) continue;
        
        if (hasHeader && !processedFirstRow) {
            // Header row
            html += '<thead style="background-color: #f8f9fa;"><tr>';
            cells.forEach((cell, index) => {
                // Use same width for all columns - first column gets fixed width, others share remaining space
                const thStyle = index === 0
                    ? "border: 1px solid #ddd; padding: 12px; text-align: left; font-weight: bold; color: #333; background-color: #f8f9fa; width: 200px; box-sizing: border-box;"
                    : "border: 1px solid #ddd; padding: 12px; text-align: left; font-weight: bold; color: #333; background-color: #f8f9fa; box-sizing: border-box;";
                html += `<th style="${thStyle}">${escapeHtml(cell)}</th>`;
            });
            html += '</tr></thead><tbody>';
            processedFirstRow = true;
        } else {
            // Data row or first row without header
            if (!processedFirstRow) {
                // No header detected, start tbody directly
                html += '<tbody>';
                processedFirstRow = true;
            }
            
            html += '<tr style="border-bottom: 1px solid #eee;">';
            cells.forEach((cell, index) => {
                // First column (Key column) should be bold with same width as header
                const cellStyle = index === 0 
                    ? "border: 1px solid #ddd; padding: 12px; font-weight: bold; background-color: #fafafa; width: 200px; word-wrap: break-word; box-sizing: border-box;"
                    : "border: 1px solid #ddd; padding: 12px; word-wrap: break-word; box-sizing: border-box;";
                html += `<td style="${cellStyle}">${escapeHtml(cell)}</td>`;
            });
            html += '</tr>';
        }
    }
    
    html += '</tbody></table>';
    return html;
}

function extractEvaluationScores(response) {
    // Extract evaluation scores from response text
    console.log('Attempting to extract scores from response:', response.substring(0, 200) + '...');
    
    const scores = {};
    const scorePatterns = {
        'tool_selection_score': /tool_selection_score:\s*([0-9\.]+)/i,
        'argument_correctness_score': /argument_correctness_score:\s*([0-9\.]+)/i,
        'faithfulness_score': /faithfulness_score:\s*([0-9\.]+)/i,
        'answer_relevancy_score': /answer_relevancy_score:\s*([0-9\.]+)/i
    };
    
    for (const [scoreName, pattern] of Object.entries(scorePatterns)) {
        const match = response.match(pattern);
        if (match) {
            scores[scoreName] = parseFloat(match[1]);
            console.log(`Found ${scoreName}: ${scores[scoreName]}`);
        } else {
            console.log(`No match found for ${scoreName}`);
        }
    }
    
    console.log('Extracted scores:', scores);
    
    const hasScores = Object.keys(scores).length > 0;
    console.log('Has scores:', hasScores);
    
    return hasScores ? scores : null;
}

function removeScoreTextFromResponse(response) {
    // Remove the score text lines from response when we're going to display them as graphics
    let cleanedResponse = response;
    
    const scorePatterns = [
        /tool_selection_score:\s*[0-9\.]+\s*/gi,
        /argument_correctness_score:\s*[0-9\.]+\s*/gi,
        /faithfulness_score:\s*[0-9\.]+\s*/gi,
        /answer_relevancy_score:\s*[0-9\.]+\s*/gi
    ];
    
    scorePatterns.forEach(pattern => {
        cleanedResponse = cleanedResponse.replace(pattern, '');
    });
    
    // Clean up extra whitespace and newlines
    cleanedResponse = cleanedResponse.replace(/\n\s*\n\s*\n/g, '\n\n').trim();
    
    return cleanedResponse;
}

function getScoreColorClass(score) {
    if (score < 0.5) return 'red';
    if (score < 0.7) return 'orange';
    return 'green';
}

function createScoreVisualization(scores) {
    let html = '<div class="evaluation-scores" style="margin-top: 15px; padding: 15px; background: #f8f9fa !important; border-radius: 8px; border-left: 4px solid #2196F3; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">';
    html += '<div style="font-weight: bold; margin-bottom: 12px; color: #1976D2; font-size: 1.1em;">📊 Evaluation Metrics</div>';
    
    const scoreLabels = {
        'tool_selection_score': 'Tool Selection',
        'argument_correctness_score': 'Argument Correctness',
        'faithfulness_score': 'Faithfulness',
        'answer_relevancy_score': 'Answer Relevancy'
    };
    
    const getScoreColor = (score) => {
        if (score < 0.5) return '#d32f2f';
        if (score < 0.7) return '#f57c00';
        return '#388e3c';
    };
    
    for (const [scoreKey, label] of Object.entries(scoreLabels)) {
        if (scores.hasOwnProperty(scoreKey)) {
            const score = scores[scoreKey];
            const color = getScoreColor(score);
            
            html += '<div style="display: flex; align-items: center; margin-bottom: 8px;">';
            
            // Colored dot indicator
            html += `<div style="width: 12px; height: 12px; background-color: ${color}; border-radius: 50%; margin-right: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);"></div>`;
            
            // Score label and value
            html += `<span style="font-size: 0.9em; font-weight: 500; color: #333; margin-right: 10px;">${label}:</span>`;
            html += `<span style="font-weight: bold; font-size: 0.9em; color: ${color};">${score.toFixed(3)}</span>`;
            
            html += '</div>';
        }
    }
    
    html += '</div>';
    
    console.log('Score visualization rendered with scores:', scores);
    
    return html;
}

function formatTaskSummary(tasks) {
    // Handle null, undefined, or non-array values
    if (tasks === null || tasks === undefined) {
        return 'No summary available.';
    }
    
    if (!Array.isArray(tasks)) {
        // If it's a string or other type, display it directly
        // Handle case where string might be JSON-stringified
        let displayText = tasks;
        if (typeof tasks === 'string') {
            // Try to parse if it looks like JSON
            try {
                const parsed = JSON.parse(tasks);
                if (Array.isArray(parsed)) {
                    // Recursively handle if it was a stringified array
                    return formatTaskSummary(parsed);
                } else if (typeof parsed === 'string') {
                    displayText = parsed;
                }
            } catch (e) {
                // Not JSON, use as-is
                displayText = tasks;
            }
        }
        return displayText;
    }
    
    if (tasks.length === 0) {
        return 'No tasks to display.';
    }
    
    let html = '<div class="summary-container">';
    html += '<div class="summary-header">✨ Task Execution Results</div>';
    
    tasks.forEach((task, index) => {
        html += '<div class="task-result">';
        
        // Task header with status badge
        html += `<div class="task-result-header">`;
        html += `📋 ${task.task_id}: ${task.task_description}`;
        
        // Status badge
        const statusClass = task.task_status === 'completed' ? 'task-status-completed' : 
                          task.task_status === 'failed' ? 'task-status-failed' : 
                          'task-status-badge';
        html += `<span class="${statusClass} task-status-badge">${task.task_status.toUpperCase()}</span>`;
        html += `</div>`;
        
        // Agent name
        html += `<div style="margin-top: 5px; color: #666; font-size: 0.9em;">`;
        html += `🤖 Agent: <strong>${task.agent_name}</strong>`;
        html += `</div>`;
        
        // Response (if available)
        if (task.response) {
            // Check if response contains HTML code (from coder agent)
            const isHtmlCode = task.response.includes('<!DOCTYPE html>') || 
                               (task.response.includes('<html') && task.response.includes('</html>'));
            
            if (isHtmlCode && (task.agent_name.toLowerCase().includes('coder') || 
                               task.task_description.toLowerCase().includes('visualization') ||
                               task.task_description.toLowerCase().includes('chart') ||
                               task.task_description.toLowerCase().includes('graph'))) {
                // Render HTML visualization in an iframe
                html += `<div class="task-response">`;
                html += `<strong>📊 Interactive Visualization:</strong><br>`;
                html += `<div style="margin-top: 10px; border: 1px solid #ddd; border-radius: 5px; overflow: hidden;">`;
                
                // Create a sandboxed iframe to render the HTML
                const iframeId = 'viz-' + task.task_id + '-' + Date.now();
                html += `<iframe id="${iframeId}" style="width: 100%; min-height: 400px; border: none;" sandbox="allow-scripts allow-same-origin"></iframe>`;
                
                // Inject HTML content into iframe after a short delay to ensure DOM is ready
                setTimeout(() => {
                    const iframe = document.getElementById(iframeId);
                    if (iframe) {
                        const doc = iframe.contentDocument || iframe.contentWindow.document;
                        doc.open();
                        doc.write(task.response);
                        doc.close();
                    }
                }, 100);
                html += `</div>`;
                html += `</div>`;
            } else {
                // Check if response contains markdown table
                html += `<div class="task-response">`;
                html += `<strong>Response:</strong><br>`;
                
                // Extract evaluation scores from response
                const evaluationScores = extractEvaluationScores(task.response);
                
                // Clean the response text if scores are found
                let responseToDisplay = task.response;
                if (evaluationScores) {
                    responseToDisplay = removeScoreTextFromResponse(task.response);
                }
                
                if (isMarkdownTable(responseToDisplay)) {
                    // Debug logging
                    console.log('Markdown table detected, converting...');
                    console.log('Original response:', responseToDisplay.substring(0, 200) + '...');
                    
                    // Convert markdown table to HTML table
                    const convertedHtml = convertMarkdownTableToHtml(responseToDisplay);
                    console.log('Converted HTML preview:', convertedHtml.substring(0, 200) + '...');
                    html += convertedHtml;
                } else {
                    console.log('No markdown table detected, using plain text');
                    console.log('Response preview:', responseToDisplay.substring(0, 200) + '...');
                    // Regular text response (only display if there's content after cleaning)
                    if (responseToDisplay.trim()) {
                        html += escapeHtml(responseToDisplay);
                    }
                }
                
                // Add evaluation scores visualization if scores are found
                if (evaluationScores) {
                    html += createScoreVisualization(evaluationScores);
                }
                
                html += `</div>`;
            }
        }
        
        // Error (if available)
        if (task.error) {
            // Extract evaluation scores from error
            const errorEvaluationScores = extractEvaluationScores(task.error);
            
            // Clean the error text if scores are found
            let errorToDisplay = task.error;
            if (errorEvaluationScores) {
                errorToDisplay = removeScoreTextFromResponse(task.error);
            }
            
            html += `<div class="task-response" style="color: #d32f2f;">`;
            html += `<strong>❌ Error:</strong><br>${convertMarkdownTableToHtml(errorToDisplay)}`;
            html += `</div>`;
            
            // Add evaluation scores visualization if scores are found
            if (errorEvaluationScores) {
                html += createScoreVisualization(errorEvaluationScores);
            }
        }
        
        // Input required (if available)
        if (task.input_required) {
            html += `<div class="task-response" style="color: #f57c00;">`;
            html += `<strong>⏸️ Input Required:</strong><br>${task.input_required}`;
            html += `</div>`;
        }
        
        html += '</div>';
        
        // Add separator between tasks (except last one)
        if (index < tasks.length - 1) {
            html += '<div class="task-separator"></div>';
        }
    });
    
    html += '</div>';
    return html;
}

// Helper function to safely set HTML content that has been properly escaped
// This wraps escaped HTML in a DOM element to avoid direct innerHTML assignment
function createElementFromEscapedHTML(htmlString) {
    const wrapper = document.createElement('div');
    // Use DOMParser for safer HTML parsing
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    // Move all children from parsed document to wrapper
    while (doc.body.firstChild) {
        wrapper.appendChild(doc.body.firstChild);
    }
    return wrapper;
}

// Helper function to safely escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Helper function to create a DOM element from structured data
function createHistoryElement(data) {
    const container = document.createElement('div');
    container.className = 'summary-container';
    
    const header = document.createElement('div');
    header.className = 'summary-header';
    header.textContent = '📜 Session History';
    container.appendChild(header);
    
    for (const [queryId, queryData] of Object.entries(data)) {
        const taskResult = document.createElement('div');
        taskResult.className = 'task-result';
        
        const taskHeader = document.createElement('div');
        taskHeader.className = 'task-result-header';
        taskHeader.textContent = `Query: ${queryData.user_query}`;
        taskResult.appendChild(taskHeader);
        
        const timeDiv = document.createElement('div');
        timeDiv.style.fontSize = '0.85em';
        timeDiv.style.color = '#666';
        timeDiv.textContent = `Time: ${queryData.timestamp}`;
        taskResult.appendChild(timeDiv);
        
        const statusDiv = document.createElement('div');
        statusDiv.style.fontSize = '0.85em';
        statusDiv.style.color = '#666';
        statusDiv.textContent = `Status: ${queryData.status}`;
        taskResult.appendChild(statusDiv);
        
        if (queryData.response_summary) {
            const responseDiv = document.createElement('div');
            responseDiv.className = 'task-response';
            responseDiv.style.marginTop = '10px';
            
            // Parse and format the response properly
            let formattedResponse;
            if (typeof queryData.response_summary === 'string') {
                try {
                    // Try to parse if it's a JSON string
                    const parsed = JSON.parse(queryData.response_summary);
                    formattedResponse = formatTaskSummary(parsed);
                } catch (e) {
                    // Not JSON, use as-is
                    formattedResponse = queryData.response_summary;
                }
            } else if (Array.isArray(queryData.response_summary)) {
                // It's already an array of tasks
                formattedResponse = formatTaskSummary(queryData.response_summary);
            } else {
                formattedResponse = String(queryData.response_summary);
            }
            
            // Add the formatted response
            if (typeof formattedResponse === 'string' && !formattedResponse.includes('<')) {
                // Plain text
                responseDiv.textContent = formattedResponse;
            } else {
                // HTML formatted content
                const contentElement = createElementFromEscapedHTML(formattedResponse);
                responseDiv.appendChild(contentElement);
            }
            
            taskResult.appendChild(responseDiv);
        }
        
        container.appendChild(taskResult);
        
        const separator = document.createElement('div');
        separator.className = 'task-separator';
        container.appendChild(separator);
    }
    
    return container;
}

// Helper function to create sessions list element
function createSessionsElement(sessions) {
    const container = document.createElement('div');
    container.className = 'summary-container';
    
    const header = document.createElement('div');
    header.className = 'summary-header';
    header.textContent = '📚 All Sessions';
    container.appendChild(header);
    
    sessions.forEach(session => {
        const taskResult = document.createElement('div');
        taskResult.className = 'task-result';
        
        const taskHeader = document.createElement('div');
        taskHeader.className = 'task-result-header';
        taskHeader.textContent = `Session: ${session.session_id.substr(-12)}`;
        taskResult.appendChild(taskHeader);
        
        const queriesDiv = document.createElement('div');
        queriesDiv.style.fontSize = '0.85em';
        queriesDiv.style.color = '#666';
        queriesDiv.textContent = `Queries: ${session.query_count}`;
        taskResult.appendChild(queriesDiv);
        
        const lastQueryTimeDiv = document.createElement('div');
        lastQueryTimeDiv.style.fontSize = '0.85em';
        lastQueryTimeDiv.style.color = '#666';
        lastQueryTimeDiv.textContent = `Last Query: ${session.last_query_time}`;
        taskResult.appendChild(lastQueryTimeDiv);
        
        if (session.last_query) {
            const lastQueryDiv = document.createElement('div');
            lastQueryDiv.style.fontSize = '0.85em';
            lastQueryDiv.textContent = `Last: ${session.last_query}`;
            taskResult.appendChild(lastQueryDiv);
        }
        
        const button = document.createElement('button');
        button.textContent = 'Load Session';
        button.style.marginTop = '5px';
        button.style.padding = '5px 10px';
        button.onclick = () => loadSession(session.session_id);
        taskResult.appendChild(button);
        
        container.appendChild(taskResult);
        
        const separator = document.createElement('div');
        separator.className = 'task-separator';
        container.appendChild(separator);
    });
    
    return container;
}

function addMessage(content, type, taskInfo = null) {
    const container = document.getElementById('chat-container');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + type + '-message';
    
    if (currentQueryId && type !== 'user') {
        const queryInfoDiv = document.createElement('div');
        queryInfoDiv.className = 'query-info';
        queryInfoDiv.textContent = `Query: ${currentQueryId.substr(-8)}`;
        messageDiv.appendChild(queryInfoDiv);
    }
    
    const contentDiv = document.createElement('div');
    // Handle both string content and DOM elements
    if (typeof content === 'string') {
        contentDiv.textContent = content;
    } else if (content instanceof HTMLElement) {
        contentDiv.appendChild(content);
    }
    messageDiv.appendChild(contentDiv);
    
    if (taskInfo) {
        const infoDiv = document.createElement('div');
        infoDiv.className = 'task-info';
        infoDiv.textContent = taskInfo;
        messageDiv.appendChild(infoDiv);
    }
    
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
}

function handleKeyPress(event) {
    if (event.key === 'Enter' && !isProcessing) {
        sendMessage();
    }
}


function connectToStream(queryId) {
    // Close existing connection if any
    if (currentEventSource) {
        currentEventSource.close();
    }
    
    // Reset streaming tasks
    streamingTasks = [];
    
    // Create new EventSource for Server-Sent Events
    currentEventSource = new EventSource(`/stream/${queryId}`);
    
    currentEventSource.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            console.log('Received SSE event:', data);
            
            if (data.type === 'cancelled') {
                // Query was cancelled by the server / another tab
                console.log('Query cancelled via SSE:', data.query_id);
                addMessage(data.message || 'Query cancelled.', 'system');
                updateStatus('Query cancelled', 'ready');

                // Close connection
                currentEventSource.close();
                currentEventSource = null;

                // Reset state
                currentQueryId = null;
                currentTaskId = null;
                isWaitingForInput = false;
                streamingTasks = [];
                isProcessing = false;
                _setCancelBtnVisible(false);
                return;
            }

            if (data.type === 'input_required') {
                // Task needs user input - display message but keep stream alive
                console.log('Task requires input:', data.task_id);
                addMessage(data.message, 'input-required', 
                    `Task ${data.task_id} needs your input`);
                updateStatus('Waiting for your input...', 'input-required');
                
                // Set state for input handling
                currentQueryId = data.query_id;
                currentTaskId = data.task_id;
                isWaitingForInput = true;
                // Keep currentEventSource open - don't close it!
                
            } else if (data.type === 'task_complete') {
                // Task completed - add to streaming tasks array
                const taskInfo = {
                    task_id: data.task_id,
                    task_description: data.task_description,
                    agent_name: data.agent_name,
                    task_status: data.task_status,
                    response: data.response,
                    error: data.error
                };
                streamingTasks.push(taskInfo);
                
                // Display incremental update
                const formattedMessage = formatTaskSummary(streamingTasks);
                
                // Always update the last system message (which is our placeholder or previous update)
                const container = document.getElementById('chat-container');
                const existingMessages = container.querySelectorAll('.system-message');
                
                if (existingMessages.length > 0) {
                    // Update the last system message
                    const lastMessage = existingMessages[existingMessages.length - 1];
                    // Find the content div more precisely
                    const children = Array.from(lastMessage.children);
                    const contentDiv = children.find(child => 
                        !child.classList.contains('query-info') && 
                        !child.classList.contains('task-info')
                    );
                    if (contentDiv) {
                        // Clear existing content
                        contentDiv.textContent = '';
                        // Add new content safely
                        const newContent = createElementFromEscapedHTML(formattedMessage);
                        contentDiv.appendChild(newContent);
                    }
                    // Scroll to bottom to show latest content
                    container.scrollTop = container.scrollHeight;
                } else {
                    // Fallback: add new message if somehow placeholder is missing
                    const messageElement = createElementFromEscapedHTML(formattedMessage);
                    addMessage(messageElement, 'system');
                }
                
                updateStatus(`Task ${data.task_id} completed (${streamingTasks.length} task(s) done)`, 'processing');
                
            } else if (data.type === 'complete') {
                // All tasks completed (or direct response)
                console.log('Query completed via SSE:', data.query_id);
                console.log('Summary data:', data.summary);
                console.log('Summary type:', typeof data.summary);
                console.log('Is array:', Array.isArray(data.summary));
                
                // Check if we already processed this completion
                if (processedQueryCompletions.has(data.query_id)) {
                    console.log('DUPLICATE: Already processed completion for query', data.query_id, '- skipping');
                    return;
                }
                
                // Mark this query as processed
                processedQueryCompletions.add(data.query_id);
                console.log('Processing completion for query:', data.query_id);
                
                // For direct responses, summary is a string; for tasks, it's an array
                const formattedMessage = formatTaskSummary(data.summary);
                
                // Update or add final message
                const container = document.getElementById('chat-container');
                const existingMessages = container.querySelectorAll('.system-message');
                
                // Check if we have accumulated tasks (task-based query) or it's a direct response
                if (streamingTasks.length > 0) {
                    // Task-based query - tasks already displayed incrementally
                    // Don't show summary again, just update status
                    console.log('Tasks already displayed, skipping final summary');
                } else {
                    // Direct response (no tasks) - update the placeholder or add new message
                    console.log('Direct response handling - existing messages:', existingMessages.length);
                    if (existingMessages.length > 0) {
                        const lastMessage = existingMessages[existingMessages.length - 1];
                        console.log('Last message element:', lastMessage);
                        console.log('Last message ID:', lastMessage.id);
                        // Find the content div more precisely
                        const children = Array.from(lastMessage.children);
                        const contentDiv = children.find(child => 
                            !child.classList.contains('query-info') && 
                            !child.classList.contains('task-info')
                        );
                        console.log('Content div found:', contentDiv !== undefined);
                        if (contentDiv) {
                            // Clear existing content (removes "Processing...")
                            contentDiv.textContent = '';
                            // Check if it's plain text or HTML
                            if (typeof formattedMessage === 'string' && !formattedMessage.includes('<')) {
                                // Plain text response - set directly
                                contentDiv.textContent = formattedMessage;
                            } else {
                                // HTML response - parse and add safely
                                const messageElement = createElementFromEscapedHTML(formattedMessage);
                                contentDiv.appendChild(messageElement);
                            }
                            // Scroll to bottom after update
                            container.scrollTop = container.scrollHeight    ;
                        }
                    } else {
                        console.log('No existing messages found, adding new message via addMessage()');
                        // No existing message, add new one
                        // Check if it's plain text or HTML
                        if (typeof formattedMessage === 'string' && !formattedMessage.includes('<')) {
                            // Plain text response - add directly
                            addMessage(formattedMessage, 'system');
                        } else {
                            // HTML response - parse and add safely
                            const messageElement = createElementFromEscapedHTML(formattedMessage);
                            addMessage(messageElement, 'system');
                        }
                    }
                }
                
                updateStatus('Query completed', 'completed');
                
                // Close connection
                currentEventSource.close();
                currentEventSource = null;
                
                // Reset state for new query
                currentQueryId = null;
                currentTaskId = null;
                isWaitingForInput = false;
                streamingTasks = [];
                isProcessing = false;  // IMPORTANT: Reset processing flag
                _setCancelBtnVisible(false);
                
                // Clean up old processed queries (keep last 10)
                if (processedQueryCompletions.size > 10) {
                    const queries = Array.from(processedQueryCompletions);
                    processedQueryCompletions = new Set(queries.slice(-10));
                }
                
                setTimeout(() => {
                    updateStatus('Ready for new query', 'ready');
                }, 2000);
            }
        } catch (error) {
            console.error('Error parsing SSE data:', error);
            // Reset processing flag on parse error
            isProcessing = false;
        }
    };
    
    currentEventSource.onerror = function(error) {
        console.error('SSE connection error:', error);
        // Do NOT close the EventSource here; the browser will auto-reconnect.
        // Closing it turns transient network/proxy issues into permanent stream loss.
        if (currentEventSource && currentEventSource.readyState === EventSource.CLOSED) {
            currentEventSource = null;
            isProcessing = false;
            _setCancelBtnVisible(false);
            updateStatus('Stream closed - Ready for new query', 'ready');
        } else {
            updateStatus('Stream interrupted - retrying...', 'processing');
        }
    };
}

async function sendMessage() {
    const input = document.getElementById('user-input');
    const message = input.value.trim();
    
    if (!message || isProcessing) return;
    
    // Initialize session if not exists
    if (!currentSessionId) {
        startNewSession();
    }
    
    addMessage(message, 'user');
    input.value = '';
    isProcessing = true;
    _setCancelBtnVisible(true);
    
    try {
        let requestData;
        
        if (isWaitingForInput && currentTaskId && currentQueryId) {
            // Sending user input for existing task
            console.log('Sending user input for task:', currentTaskId, 'query:', currentQueryId);
            updateStatus('Processing user input...', 'processing');
            requestData = {
                query_id: currentQueryId,
                message: message,
                task_id: currentTaskId,
                session_id: currentSessionId
            };
            // Clear waiting state temporarily while processing
            isWaitingForInput = false;
            currentTaskId = null;
        } else {
            // Sending new query
            currentQueryId = generateQueryId();
            currentTaskId = null;
            isWaitingForInput = false;
            console.log('Sending new query with ID:', currentQueryId);
            updateStatus('Processing new query...', 'processing');
            requestData = {
                query_id: currentQueryId,
                message: message,
                session_id: currentSessionId
            };
            
            // Start streaming connection for new query
            connectToStream(currentQueryId);
            
            // Add placeholder system message immediately to maintain order
            const placeholderDiv = document.createElement('div');
            placeholderDiv.className = 'message system-message streaming-placeholder';
            placeholderDiv.id = `placeholder-${currentQueryId}`;
            
            // Add query info
            const queryInfoDiv = document.createElement('div');
            queryInfoDiv.className = 'query-info';
            queryInfoDiv.textContent = `Query: ${currentQueryId.substr(-8)}`;
            placeholderDiv.appendChild(queryInfoDiv);
            
            // Add loading content
            const contentDiv = document.createElement('div');
            contentDiv.textContent = '⏳ Processing...';
            placeholderDiv.appendChild(contentDiv);
            
            const container = document.getElementById('chat-container');
            container.appendChild(placeholderDiv);
            container.scrollTop = container.scrollHeight;
        }
        
        const response = await fetch(apiUrl('/chat'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        
        const data = await response.json();
        console.log('Received response:', data);
        
        if (response.ok) {
            // Check if streaming is active
            if (data.streaming) {
                // Streaming mode - all updates will come via SSE
                console.log('Streaming mode active, waiting for SSE updates...');
                // Don't display anything here, SSE will handle all updates
                
            } else if (data.is_query_completed && !requestData.task_id) {
                // Direct response without tasks (e.g., greeting)
                // Only show if we didn't start streaming for THIS query
                // Check both currentEventSource AND if we have a placeholder for this query
                const hasStreamingConnection = currentEventSource !== null;
                const placeholderElement = document.getElementById(`placeholder-${currentQueryId}`);
                const hasPlaceholder = placeholderElement !== null;
                
                console.log('POST /chat response - is_query_completed:', data.is_query_completed);
                console.log('  hasStreamingConnection:', hasStreamingConnection);
                console.log('  hasPlaceholder:', hasPlaceholder);
                console.log('  placeholder element:', placeholderElement);
                console.log('  currentQueryId:', currentQueryId);
                console.log('  Already processed?:', processedQueryCompletions.has(data.query_id));
                
                // Don't add message if we already processed this via SSE OR if placeholder exists
                if (processedQueryCompletions.has(data.query_id)) {
                    console.log('SKIPPING: Query already completed via SSE');
                } else if (hasPlaceholder) {
                    console.log('SKIPPING: Placeholder exists, SSE will/did handle it');
                } else if (!hasStreamingConnection && !hasPlaceholder) {
                    console.log('ADDING: No streaming/placeholder, adding message via /chat response');
                    const formattedMessage = formatTaskSummary(data.message);
                    const messageElement = createElementFromEscapedHTML(formattedMessage);
                    addMessage(messageElement, 'system');
                    updateStatus('Query completed', 'completed');
                    
                    // Reset state for new query
                    currentQueryId = null;
                    currentTaskId = null;
                    isWaitingForInput = false;
                    
                    setTimeout(() => {
                        updateStatus('Ready for new query', 'ready');
                    }, 2000);
                } else {
                    console.log('SKIPPING: Streaming is handling it (hasConnection:', hasStreamingConnection, ')');
                }
                
            } else if (data.user_input_required) {
                // Task needs user input - keep streaming open for continuation
                // Don't close the EventSource - it will continue after user provides input
                logger.info('User input required - keeping stream alive');
                
                console.log('User input required for task:', data.task_id);
                addMessage(data.message, 'input-required', 
                    `Task ${data.task_id} needs your input`);
                updateStatus('Waiting for your input...', 'input-required');
                
                // Restore query ID and set task ID
                currentQueryId = data.query_id;
                currentTaskId = data.task_id;
                isWaitingForInput = true;
                
            } else if (!currentEventSource && !data.is_query_completed) {
                // Still processing but no streaming (fallback)
                console.log('Processing without streaming...');
                addMessage(data.message || 'Processing...', 'processing');
                updateStatus('Processing...', 'processing');
            }
        } else {
            console.error('Error response:', data.detail);
            addMessage('Error: ' + data.detail, 'system');
            updateStatus('Error occurred', 'ready');
            
            // Close streaming on error
            if (currentEventSource) {
                currentEventSource.close();
                currentEventSource = null;
            }
            
            // Reset state on error
            currentQueryId = null;
            currentTaskId = null;
            isWaitingForInput = false;
            _setCancelBtnVisible(false);
        }
    } catch (error) {
        console.error('Network error:', error);
        addMessage('Network error: ' + error.message, 'system');
        updateStatus('Network error', 'ready');
        
        // Close streaming on error
        if (currentEventSource) {
            currentEventSource.close();
            currentEventSource = null;
        }
        
        // Reset state on error
        currentQueryId = null;
        currentTaskId = null;
        isWaitingForInput = false;
    } finally {
        isProcessing = false;
        // Only hide cancel button if there is no active stream still running
        if (!currentEventSource) {
            _setCancelBtnVisible(false);
        }
    }
}

// Initialize
updateStatus('Ready for new query', 'ready');

async function cancelQuery() {
    if (!currentQueryId) {
        console.log('No active query to cancel');
        return;
    }

    const queryIdToCancel = currentQueryId;
    console.log('Cancelling query:', queryIdToCancel);

    try {
        const response = await fetch(apiUrl(`/cancel/${queryIdToCancel}`), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            console.log('Cancel request sent successfully');
        } else {
            console.error('Cancel request failed:', response.status);
        }
    } catch (error) {
        console.error('Error sending cancel request:', error);
    }

    // Close the SSE stream for this query immediately
    if (currentEventSource) {
        currentEventSource.close();
        currentEventSource = null;
    }

    addMessage('Query cancelled by user.', 'system');
    updateStatus('Query cancelled', 'ready');

    // Reset all state
    currentQueryId = null;
    currentTaskId = null;
    isWaitingForInput = false;
    streamingTasks = [];
    isProcessing = false;
    _setCancelBtnVisible(false);
}

function _setCancelBtnVisible(visible) {
    var btn = document.getElementById('cancel-btn');
    if (btn) btn.style.display = visible ? 'inline-block' : 'none';
}
