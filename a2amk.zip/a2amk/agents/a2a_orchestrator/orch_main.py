"""
A2A Orchestrator Main Entry Point

This module provides the main entry point for running the A2A Orchestrator with FastAPI.
The core orchestrator logic is in orchestrator_core.py and the FastAPI wrapper is in
orchestrator_fastapi.py.
"""

import asyncio
import logging
import os
import sys
import traceback

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from dotenv import load_dotenv
load_dotenv()

# Import from the new modular files
from agents.a2a_orchestrator.orchestrator_core import A2AOrchestrator
from agents.a2a_orchestrator.orchestrator_fastapi import OrchestratorFastAPIApp
from agents.a2a_orchestrator.utils import create_llm_client



async def main():
    """Main function to run the A2A Orchestrator with FastAPI"""

    # Import configuration with fallback
    try:
        from agents.a2a_orchestrator.orch_config import (
        REMOTE_AGENT_URLS,
        FASTAPI_HOST,
        FASTAPI_PORT,
        LOG_LEVEL,
        LOG_FORMAT, 
        logger,
        orch_name_in_config
        )
    except ImportError as e:
        raise ImportError("Failed to import orch_config. Please ensure the config file exists.")
    
    # Add startup delay to allow agent containers to start first
    startup_delay = int(os.getenv('ORCHESTRATOR_STARTUP_DELAY', '0'))
    if startup_delay > 0:
        logger.info(f"Waiting {startup_delay} seconds for agent containers to start...")
        await asyncio.sleep(startup_delay)
        logger.info("Startup delay complete. Initializing orchestrator...")
    
    
    
    logger.info("=" * 80)
    logger.info("A2A ORCHESTRATOR WITH AUTOGEN TOPICS AND FASTAPI")
    logger.info("=" * 80)
    
    # Create Azure OpenAI client for task planning
    try:
        gpt_model_client = await create_llm_client(orch_name_in_config)
        logger.info("✓ Azure OpenAI client initialized")
    except Exception as e:
        logger.error(f"✗ Failed to initialize Azure OpenAI client: {e}")
        logger.error("Please check your environment variables and config.py")
        return
    
    # Create orchestrator
    try:
        orchestrator = A2AOrchestrator(
            remote_agent_urls=REMOTE_AGENT_URLS,
            model_client=gpt_model_client,
        )
        
        logger.info(f"✓ Orchestrator created with {len(REMOTE_AGENT_URLS)} configured remote agents")
        
        # Initialize the orchestrator
        logger.info("Initializing orchestrator and connecting to remote agents...")
        await orchestrator.initialize()
        
        # Create FastAPI app wrapper
        fastapi_app = OrchestratorFastAPIApp(orchestrator)
        
        logger.info("=" * 80)
        logger.info("🚀 ORCHESTRATOR READY!")
        logger.info(f"📱 Web Interface: http://{FASTAPI_HOST}:{FASTAPI_PORT}")
        logger.info(f"🔗 Health Check: http://{FASTAPI_HOST}:{FASTAPI_PORT}/health")
        logger.info(f"⚡ Remote Agents: {len(orchestrator.remote_agents)} connected")
        logger.info("=" * 80)
        logger.info("Press Ctrl+C to stop the server")
        
        # Start the FastAPI server
        await fastapi_app.run_server(host=FASTAPI_HOST, port=FASTAPI_PORT)
        
    except KeyboardInterrupt:
        logger.info("\n🛑 Shutting down gracefully...")
    except Exception as e:
        logger.error(f"✗ Error running orchestrator: {e}")
        traceback.print_exc()
        raise
    finally:
        if 'orchestrator' in locals():
            logger.info("🧹 Cleaning up resources...")
            await orchestrator.close()
            logger.info("✓ Cleanup complete")



if __name__ == "__main__":
    asyncio.run(main())
