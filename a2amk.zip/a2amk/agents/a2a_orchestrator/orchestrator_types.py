"""
Orchestrator Types and Constants

This module contains all shared data types, message classes, enums, and topic IDs
used across the orchestrator components.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

from autogen_core import TopicId

from a2a.types import AgentCard
from a2a.client import Client


# Message types for Autogen topics
@dataclass
class UserQueryMessage:
    """Message type for user queries"""
    query_id: str
    user_query: str
    timestamp: str  # Changed from datetime to string for serialization
    session_id: str = ""  # Session identifier for chat history
    reference_context: List[Dict[str, str]] = field(default_factory=list)  # Previous query context


@dataclass
class TaskExecutionMessage:
    """Message type for task execution requests"""
    task_id: str
    query_id: str
    agent_url: str
    agent_name: str
    description: str
    query: str
    dependencies: List[str]
    dependency_results: Dict[str, str]
    user_input: str = ""
    session_id: str = ""  # Session identifier for chat history
    reference_context: List[Dict[str, str]] = field(default_factory=list)  # Previous query context from chat history


@dataclass
class TaskCompletionMessage:
    """Message type for task completion notifications"""
    task_id: str
    query_id: str
    status: str
    response: str = ""
    error: str = ""
    input_required_message: str = ""
    remote_context_id: str = ""
    remote_task_id: str = ""


@dataclass
class UserInputMessage:
    """Message type for user input responses"""
    task_id: str
    query_id: str
    user_input: str
    timestamp: str  # Changed from datetime to string for serialization


@dataclass
class QueryCompletionMessage:
    """Message type for query completion notifications"""
    query_id: str
    summary: List[Dict[str, Any]]
    completed_tasks: Dict[str, Any]
    session_id: str = ""  # Session identifier for chat history


@dataclass
class ErrorAnalysisMessage:
    """Message type for error analysis and resolution"""
    task_id: str
    query_id: str
    error_details: str
    original_task: Dict[str, Any]  # Serialized original task
    timestamp: str


class TaskStatus(Enum):
    """Status of orchestrator tasks"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WAITING_FOR_INPUT = "waiting_for_input"
    ANALYZING_ERROR = "analyzing_error"  # Task failed and error is being analyzed
    RESOLVING_ERROR = "resolving_error"  # Resolution tasks are being executed


@dataclass
class OrchestratorTask:
    """Represents a task to be executed by a remote agent"""
    task_id: str
    query_id: str
    agent_url: str
    agent_name: str
    description: str
    query: str
    dependencies: List[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    response: str = ""
    error: str = ""
    dependency_results: Dict[str, str] = field(default_factory=dict)
    # A2A remote task context
    remote_task_id: str = ""
    remote_context_id: str = ""
    input_required_message: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    # Error resolution tracking
    resolution_tasks: List[str] = field(default_factory=list)  # IDs of tasks created to resolve errors
    retry_count: int = 0  # Number of retry attempts
    max_retries: int = 3  # Maximum retry attempts
    is_resolution_task: bool = False  # Whether this task is created to resolve another task's error
    parent_task_id: str = ""  # If this is a resolution task, ID of the parent task


@dataclass
class RemoteAgent:
    """Information about a remote A2A agent"""
    url: str
    name: str
    description: str
    skills: List[Dict[str, Any]]
    agent_card: Optional[AgentCard] = None
    client: Optional[Client] = None


@dataclass
class SummaryRequestMessage:
    """Message type for requesting an LLM-generated summary of all task results"""
    query_id: str
    user_query: str
    task_results: List[Dict[str, Any]]
    use_markdown: bool = True
    session_id: str = ""


# Topic IDs for different message types
USER_QUERY_TOPIC = TopicId("user_query", source="default")
TASK_EXECUTION_TOPIC = TopicId("task_execution", source="default") 
TASK_COMPLETION_TOPIC = TopicId("task_completion", source="default")
USER_INPUT_TOPIC = TopicId("user_input", source="default")
QUERY_COMPLETION_TOPIC = TopicId("query_completion", source="default")
ERROR_ANALYSIS_TOPIC = TopicId("error_analysis", source="default")
SUMMARY_TOPIC = TopicId("summary_request", source="default")
