from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import (
    ChatCompletionClient, )
import yaml
import os
from dotenv import load_dotenv
load_dotenv()
from agents.a2a_orchestrator.orch_config import logger


async def create_llm_client(orch_name_in_config:str,
                        ) -> ChatCompletionClient:
    model_params = None
    try:
        config_yaml_str = os.getenv("APP_CONFIG_YAML")
        config = yaml.safe_load(config_yaml_str)
        model_name = config.get(orch_name_in_config, {}).get("llm_model")
        model_params = config.get("llm_models", {}).get(model_name)
    except Exception as e:
        logger.error(f"Error reading model configuration for {orch_name_in_config} from k8s environment variable: {e}")

    if not model_params:
        logger.info(f"Falling back to config.yaml.")
        try:
            with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
                config = yaml.safe_load(file)
                model_name = config.get(orch_name_in_config, {}).get("llm_model")
                model_params = config.get("llm_models", {}).get(model_name)
        except FileNotFoundError:
            logger.error("config.yaml file not found.")
            raise 
        except Exception as e:
            logger.error(f"Error reading config.yaml: {e}")

    if not model_params:
        logger.error(f"No llm model configuration found for {orch_name_in_config}. Please check your k8s environment variables or config.yaml.")
        raise ValueError(f"No configuration found for {orch_name_in_config}.")

    llm_model_client = AzureOpenAIChatCompletionClient(model = model_params.get("model_name"), 
                                        azure_endpoint = model_params.get("azure_endpoint"),
                                        azure_deployment = model_params.get("azure_deployment"),
                                        api_version = model_params.get("api_version"),
                                        api_key = os.getenv("AZURE_OPENAI_API_KEY"),
                                        )
    return llm_model_client