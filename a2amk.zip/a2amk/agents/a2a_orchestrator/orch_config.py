"""
Configuration file for A2A Orchestrator with FastAPI user input handling.

This file contains settings for the orchestrator including remote agent URLs,
server configuration, and other parameters.
"""
import os
import json
import logging
from dotenv import load_dotenv
load_dotenv()
orch_name_in_config = "orchestrator" # Necessary to create llm model client

#Create logger
logger = logging.getLogger(__name__)

# Logging configuration
LOG_LEVEL = "INFO"
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# Configure logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format=LOG_FORMAT
    )

# Suppress verbose INFO messages from autogen_core
logging.getLogger("autogen_core").setLevel(logging.WARNING)

# Remote A2A agent URLs
# This will be read from kubernetes configMap
# For local development, set in .env file as below
# REMOTE_AGENT_URLS = [{"name": "coder_agent","url": "http://localhost:8095"},{"name": "latency_agent","url": "http://localhost:8091"},{"name": "dynatrace_agent","url": "http://localhost:8096"}]
_default_remote_agent_urls = ['http://localhost:8091', 'http://localhost:8095', 'http://localhost:8096']
remote_agent_urls = os.getenv('REMOTE_AGENT_URLS')
if remote_agent_urls and remote_agent_urls.strip():
    try:
        if not isinstance(remote_agent_urls, list):
            remote_agent_urls = json.loads(remote_agent_urls)
        
        if isinstance(remote_agent_urls, list) and len(remote_agent_urls) > 0:
            # Extract URLs from JSON array format: [{"name":"coder_agent","url":"http://..."}]
            REMOTE_AGENT_URLS = [agent['url'].strip() for agent in remote_agent_urls]
        else:
            # Treat as one or more URLs separated by commas or newlines
            parts = [p.strip() for p in str(remote_agent_urls).replace('\n', ',').split(',')]
            REMOTE_AGENT_URLS = [p for p in parts if p]

        if not REMOTE_AGENT_URLS:
            logger.warning("REMOTE_AGENT_URLS was set but parsed to an empty list; falling back to defaults")
            REMOTE_AGENT_URLS = _default_remote_agent_urls
    except (json.JSONDecodeError, KeyError, TypeError):
        logger.exception("Failed to parse REMOTE_AGENT_URLS environment variable: %r", remote_agent_urls)
        REMOTE_AGENT_URLS = _default_remote_agent_urls
else:
    # Default values if environment variable is not set
    REMOTE_AGENT_URLS = _default_remote_agent_urls

# Log the configured URLs for debugging
logger.info(f"Configured REMOTE_AGENT_URLS: {REMOTE_AGENT_URLS}")

# Summary agent: whether to use markdown in the final summary (default True)
SUMMARY_USE_MARKDOWN = os.getenv("SUMMARY_USE_MARKDOWN", "true").strip().lower() in ("true", "1", "yes")

# FastAPI server configuration
# Read from environment variables, default to localhost for local development
FASTAPI_HOST = os.getenv('FASTAPI_HOST', 'localhost')
FASTAPI_PORT = int(os.getenv('FASTAPI_PORT', '8093'))

# Timeout settings (in seconds)

def _parse_timeout_seconds(env_var: str, default_value: float) -> float | None:
    """Parse timeout seconds from an environment variable.

    Supported values:
    - unset/empty: uses default
    - positive number: timeout in seconds
    - 0 or negative: disables timeout (returns None)
    - 'none'/'disabled'/'off': disables timeout (returns None)
    """
    raw = os.getenv(env_var)
    if raw is None:
        return default_value
    raw = str(raw).strip()
    if not raw:
        return default_value

    lowered = raw.lower()
    if lowered in {"none", "null", "disable", "disabled", "off"}:
        return None

    try:
        value = float(raw)
    except ValueError:
        logger.warning("Invalid %s=%r; using default %s", env_var, raw, default_value)
        return default_value

    if value <= 0:
        return None
    return value


QUERY_TIMEOUT = _parse_timeout_seconds("A2A_QUERY_TIMEOUT_SECONDS", 180.0)  # 2 minutes
AGENT_TIMEOUT = _parse_timeout_seconds("A2A_AGENT_TIMEOUT_SECONDS", 180.0)  # 3 minutes
AGENT_CONNECT_TIMEOUT = _parse_timeout_seconds("A2A_AGENT_CONNECT_TIMEOUT_SECONDS", 10.0)
AGENT_HEALTHCHECK_TIMEOUT = _parse_timeout_seconds("A2A_AGENT_HEALTHCHECK_TIMEOUT_SECONDS", 5.0)
