"""
A2A Summary Agent

After all planned tasks complete, this agent synthesises the collected results
into a single, cohesive answer that directly addresses the user's original query.
It appears as its own task in the SSE event stream (task_started → task_complete)
so the UI can display it alongside the other agent tasks.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, List

from autogen_core import MessageContext, RoutedAgent, message_handler
from autogen_core.models import SystemMessage, UserMessage

from agents.a2a_orchestrator.orchestrator_types import (
    SummaryRequestMessage,
    QueryCompletionMessage,
    QUERY_COMPLETION_TOPIC,
)
from agents.a2a_orchestrator.orch_config import logger


# ── System prompts ──────────────────────────────────────────────────────────

SUMMARY_SYSTEM_PROMPT_MARKDOWN = """\
You are a senior operations analyst.
You will receive the user's original question together with the results gathered
from one or more specialised agents.

Your job is to produce a single, clear, actionable answer that directly addresses
what the user asked.

Guidelines:
- Lead with a direct answer to the user's question.
- Use Markdown formatting: headings, bullet points, tables, bold / emphasis
  where they aid clarity.
- If some tasks failed or returned errors, mention them briefly but focus on the
  data that was successfully collected.
- If the collected data is insufficient to fully answer the question, state what
  is known and what is missing.
- Be concise but thorough.  Do not repeat raw data verbatim — summarise and
  highlight key findings.
- If the user asked for metrics or numbers, present them clearly (tables are
  encouraged).
- End with recommended next steps if applicable.
"""

SUMMARY_SYSTEM_PROMPT_PLAIN = """\
You are a senior operations analyst.
You will receive the user's original question together with the results gathered
from one or more specialised agents.

Your job is to produce a single, clear, actionable answer that directly addresses
what the user asked.

Guidelines:
- Lead with a direct answer to the user's question.
- Use plain text only.  No Markdown formatting, no '#' headings, no '*' bullets.
  Use simple line breaks and indentation for structure.
- If some tasks failed or returned errors, mention them briefly but focus on the
  data that was successfully collected.
- If the collected data is insufficient to fully answer the question, state what
  is known and what is missing.
- Be concise but thorough.  Do not repeat raw data verbatim — summarise and
  highlight key findings.
- End with recommended next steps if applicable.
"""


# ── Agent ────────────────────────────────────────────────────────────────────

class A2ASummaryAgent(RoutedAgent):
    """Synthesises all completed task results into one final answer."""

    def __init__(self, model_client: Any, orchestrator_ref=None):
        super().__init__("A2ASummaryAgent")
        self.model_client = model_client
        self.orchestrator_ref = orchestrator_ref

    # ── handler ──────────────────────────────────────────────────────────

    @message_handler
    async def handle_summary_request(
        self, message: SummaryRequestMessage, ctx: MessageContext
    ) -> None:
        """Generate a summary and publish the final query-completion event."""
        query_id = message.query_id
        task_id = f"summary_{uuid.uuid4().hex[:8]}"
        agent_name = "summary_agent"
        description = "Summarise all task results and answer the original query"

        # Check if the query was cancelled before doing expensive LLM work.
        if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(query_id):
            logger.info(f"🛑 Summary agent skipping cancelled query {query_id}")
            return

        logger.info(f"📝 Summary agent processing query {query_id}")

        # ── task_started SSE event ───────────────────────────────────────
        await self._emit_sse(query_id, {
            "type": "task_started",
            "query_id": query_id,
            "task_id": task_id,
            "task_description": description,
            "agent_name": agent_name,
            "timestamp": datetime.now().isoformat(),
        })

        summary_text: str | None = None
        try:
            system_prompt = (
                SUMMARY_SYSTEM_PROMPT_MARKDOWN
                if message.use_markdown
                else SUMMARY_SYSTEM_PROMPT_PLAIN
            )

            results_text = self._format_task_results(message.task_results)
            user_prompt = (
                f"Original user question:\n{message.user_query}\n\n"
                f"Results from agents:\n{results_text}"
            )

            response = await self.model_client.create(
                messages=[
                    SystemMessage(content=system_prompt),
                    UserMessage(content=user_prompt, source="user"),
                ]
            )
            summary_text = response.content if hasattr(response, "content") else str(response)

            logger.info(f"✅ Summary agent completed for query {query_id}")

            # ── task_complete SSE event ──────────────────────────────────
            await self._emit_sse(query_id, {
                "type": "task_complete",
                "task_id": task_id,
                "task_description": description,
                "agent_name": agent_name,
                "task_status": "completed",
                "response": summary_text,
                "error": None,
                "timestamp": datetime.now().isoformat(),
            })

        except Exception as e:
            logger.error(f"❌ Summary agent failed for query {query_id}: {e}")
            await self._emit_sse(query_id, {
                "type": "task_complete",
                "task_id": task_id,
                "task_description": description,
                "agent_name": agent_name,
                "task_status": "failed",
                "response": None,
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
            })

        # ── build final summary payload ──────────────────────────────────
        final_summary: List[Dict[str, Any]] = list(message.task_results)
        final_summary.append({
            "task_id": task_id,
            "task_description": description,
            "agent_name": agent_name,
            "task_status": "completed" if summary_text else "failed",
            "response": summary_text,
            "error": None if summary_text else "Summary generation failed",
            "input_required": None,
        })

        # ── publish completion (streaming or traditional) ────────────────
        is_streaming = (
            self.orchestrator_ref
            and query_id in self.orchestrator_ref.streaming_queues
        )

        if is_streaming:
            final_event = {
                "type": "complete",
                "query_id": query_id,
                "summary": None,   # tasks already streamed incrementally
                "timestamp": datetime.now().isoformat(),
            }
            await self.orchestrator_ref.streaming_queues[query_id].put(final_event)

            # Store result so /chat endpoint can detect completion.
            self.orchestrator_ref.query_results[query_id] = final_summary

            if query_id in self.orchestrator_ref.query_completion_events:
                self.orchestrator_ref.query_completion_events[query_id].set()

            # Update chat history
            if message.session_id and self.orchestrator_ref:
                self.orchestrator_ref.history_manager.update_response(
                    session_id=message.session_id,
                    query_id=query_id,
                    response_summary=final_summary,
                    status="completed",
                )
        else:
            completion_msg = QueryCompletionMessage(
                query_id=query_id,
                summary=final_summary,
                completed_tasks={},
                session_id=message.session_id,
            )
            await self.publish_message(completion_msg, topic_id=QUERY_COMPLETION_TOPIC)

        logger.info(f"📨 Summary agent published completion for query {query_id}")

    # ── helpers ───────────────────────────────────────────────────────────

    def _format_task_results(self, task_results: List[Dict[str, Any]]) -> str:
        """Render task results into a readable text block for the LLM."""
        parts: List[str] = []
        for i, task in enumerate(task_results, 1):
            status = task.get("task_status", "unknown")
            desc = task.get("task_description", "")
            agent = task.get("agent_name", "")
            response = task.get("response") or ""
            error = task.get("error") or ""

            parts.append(
                f"--- Task {i}: {desc} (agent: {agent}, status: {status}) ---"
            )
            if response:
                parts.append(response)
            if error:
                parts.append(f"[Error]: {error}")
            parts.append("")
        return "\n".join(parts)

    async def _emit_sse(self, query_id: str, event: dict) -> None:
        """Best-effort emit to the SSE streaming queue."""
        if not self.orchestrator_ref:
            return
        queue = self.orchestrator_ref.streaming_queues.get(query_id)
        if not queue:
            return
        try:
            await queue.put(event)
        except Exception as e:
            logger.debug(f"Failed to emit SSE event for summary: {e}")
