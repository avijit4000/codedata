"""
A2A Orchestrator Agent Package

A sophisticated orchestrator for coordinating tasks across multiple A2A remote agents.

This package is now modular with separate files for:
- orchestrator_types: Shared types, messages, and constants
- task_planner_agent: Task planning agent (uses LLM)
- task_executor_agent: Task execution agent (executes on remote agents)
- orchestrator_core: Main orchestrator and query completion agent
- orchestrator_fastapi: FastAPI web wrapper
- orch or orch_new: Main entry point
"""

# Import shared types
from a2a_orchestrator.orchestrator_types import (
    UserQueryMessage,
    TaskExecutionMessage,
    TaskCompletionMessage,
    UserInputMessage,
    QueryCompletionMessage,
    TaskStatus,
    OrchestratorTask,
    RemoteAgent,
    USER_QUERY_TOPIC,
    TASK_EXECUTION_TOPIC,
    TASK_COMPLETION_TOPIC,
    USER_INPUT_TOPIC,
    QUERY_COMPLETION_TOPIC,
)

# Import agent classes
from a2a_orchestrator.task_planner_agent import A2ATaskPlannerAgent
from a2a_orchestrator.task_executor_agent import A2ATaskExecutorAgent

# Import from orchestrator core
from a2a_orchestrator.orchestrator_core import (
    A2AOrchestrator,
    A2AQueryCompletionAgent,
)

# Import FastAPI wrapper
from .orchestrator_fastapi import (
    OrchestratorFastAPIApp,
)

__version__ = "2.1.0"
__all__ = [
    # Core orchestrator
    "A2AOrchestrator",
    # Agent classes
    "A2ATaskPlannerAgent",
    "A2ATaskExecutorAgent",
    "A2AQueryCompletionAgent",
    # FastAPI wrapper
    "OrchestratorFastAPIApp",
    # Data structures
    "OrchestratorTask",
    "RemoteAgent",
    "TaskStatus",
    # Message types
    "UserQueryMessage",
    "TaskExecutionMessage",
    "TaskCompletionMessage",
    "UserInputMessage",
    "QueryCompletionMessage",
    # Topic IDs
    "USER_QUERY_TOPIC",
    "TASK_EXECUTION_TOPIC",
    "TASK_COMPLETION_TOPIC",
    "USER_INPUT_TOPIC",
    "QUERY_COMPLETION_TOPIC",
]
