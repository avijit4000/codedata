"""
A2A Task Executor Agent

This module contains the task executor agent responsible for executing individual
tasks on remote A2A agents.
"""

import traceback
import uuid
import re
from typing import Dict

from a2a.client.errors import A2AClientJSONRPCError

import httpx
from autogen_core import MessageContext, RoutedAgent, message_handler

from a2a.client import ClientFactory, ClientConfig
from a2a.types import Message, Task, TaskState, TextPart, Role

from agents.a2a_orchestrator.orchestrator_types import (
    TaskExecutionMessage,
    TaskCompletionMessage,
    TaskStatus,
    RemoteAgent,
    TASK_COMPLETION_TOPIC,
)
from agents.a2a_orchestrator.orch_config import AGENT_TIMEOUT, AGENT_CONNECT_TIMEOUT, logger


def _build_httpx_timeout(total_seconds: float | None, connect_seconds: float | None) -> httpx.Timeout | None:
    if total_seconds is None and connect_seconds is None:
        return None
    if total_seconds is None:
        return httpx.Timeout(None, connect=connect_seconds)
    if connect_seconds is None:
        return httpx.Timeout(total_seconds)
    return httpx.Timeout(total_seconds, connect=connect_seconds)



class A2ATaskExecutorAgent(RoutedAgent):
    """Agent responsible for executing individual tasks on remote A2A agents"""
    
    def __init__(self, remote_agents: Dict[str, RemoteAgent], httpx_client: httpx.AsyncClient | None = None, orchestrator_ref=None):
        super().__init__("A2ATaskExecutor")
        self.remote_agents = remote_agents
        self.orchestrator_ref = orchestrator_ref  # Reference to orchestrator for cancellation checks
        # Allow injection of a shared httpx client from the orchestrator. If
        # none provided, create a local client (less optimal for connection reuse).
        if httpx_client is None:
            self.httpx_client = httpx.AsyncClient(
                timeout=_build_httpx_timeout(AGENT_TIMEOUT, AGENT_CONNECT_TIMEOUT),
                verify="standard_trusts.pem",
            )
            self._owns_httpx_client = True
        else:
            self.httpx_client = httpx_client
            self._owns_httpx_client = False

        self.client_config = ClientConfig(
            streaming=False,
            polling=False,
            httpx_client=self.httpx_client
        )
    
    @message_handler
    async def handle_task_execution(self, message: TaskExecutionMessage, ctx: MessageContext) -> None:
        """Execute a task on the appropriate remote agent"""
        logger.info(f"🚀 Executing task {message.task_id}: {message.description}")
        logger.info(f"   Agent: {message.agent_name} at {message.agent_url}")
        logger.info(f"   Query: {message.query}")
        
        # Check if this query has been cancelled before executing
        if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(message.query_id):
            logger.info(f"🛑 Query {message.query_id} was cancelled, skipping task {message.task_id}")
            return
        
        # Get the remote agent
        agent = self.remote_agents.get(message.agent_url)
        if not agent or not agent.client:
            completion_msg = TaskCompletionMessage(
                task_id=message.task_id,
                query_id=message.query_id,
                status=TaskStatus.FAILED.value,
                error=f"Agent not found or not initialized: {message.agent_url}"
            )
            await self.publish_message(completion_msg, topic_id=TASK_COMPLETION_TOPIC)
            return
        
        try:
            # Prepare query with dependency results if any
            if message.user_input:
                # Resuming with user input
                query_text = message.user_input
            else:
                # Initial execution
                query_text = message.query
                
                # Add reference context if available (previous conversation history)
                if message.reference_context and len(message.reference_context) > 0:
                    context_info = "\n\n**Previous Conversation Context:**\n"
                    for i, ref in enumerate(message.reference_context, 1):
                        context_info += f"\nPrevious Query {i}:\n"
                        context_info += f"User asked: {ref['query']}\n"
                        context_info += f"Response: {ref['response_summary']}\n"
                    query_text = query_text + context_info
                
                # Add dependency results from current query tasks
                if message.dependency_results:
                    deps_info = "\n\n**Context from previous tasks in this query:**\n"
                    deps_info += "The following tasks have been completed and their results are provided below:\n\n"
                    for dep_id, result in message.dependency_results.items():
                        deps_info += f"Task ID {dep_id} Result:\n"
                        deps_info += f"{result}\n\n"
                        deps_info += "---\n\n"
                    query_text = query_text + deps_info
            
            # Create message with unique message_id
            # Sanitize query text to remove verbose tool-suggestion postfixes that can
            # lead to overly long resource names on some remote agents.
            sanitized_query = re.sub(r"Add Tool Suggestions:\s*\[.*?\]", "", query_text, flags=re.IGNORECASE)
            sanitized_query = re.sub(r"Tool Suggestions:\s*\[.*?\]", "", sanitized_query, flags=re.IGNORECASE)
            # Collapse multiple whitespace/newlines
            sanitized_query = re.sub(r"\s+", " ", sanitized_query).strip()

            a2a_message = Message(
                message_id=str(uuid.uuid4()),
                role=Role.user,
                parts=[TextPart(text=sanitized_query)]
            )
            
            # If resuming task, add context from previous execution
            if hasattr(message, 'remote_context_id') and message.remote_context_id:
                a2a_message.context_id = message.remote_context_id
            if hasattr(message, 'remote_task_id') and message.remote_task_id:
                a2a_message.task_id = message.remote_task_id
            
            # Send message to agent (non-streaming)
            response_parts = []
            final_task_state = None
            remote_context_id = None
            remote_task_id = None
            
            async def _send_and_collect(msg):
                parts = []
                state = None
                r_context_id = None
                r_task_id = None
                try:
                    async for ev in agent.client.send_message(msg):
                        if isinstance(ev, Message):
                            for part in ev.parts:
                                if hasattr(part, 'root'):
                                    parts.append(part.root.text)
                                elif hasattr(part, 'content'):
                                    parts.append(str(part.content))
                        elif isinstance(ev, tuple) and len(ev) == 2:
                            task_obj, update_event = ev
                            if isinstance(task_obj, Task):
                                if task_obj.context_id:
                                    r_context_id = task_obj.context_id
                                if task_obj.id:
                                    r_task_id = task_obj.id
                                if task_obj.status:
                                    state = task_obj.status.state
                                    if task_obj.status.message and hasattr(task_obj.status.message, 'parts'):
                                        for part in task_obj.status.message.parts:
                                            if hasattr(part, 'root'):
                                                parts.append(part.root.text)
                            if update_event is not None and hasattr(update_event, 'status'):
                                state = update_event.status.state
                except A2AClientJSONRPCError:
                    # Propagate the JSON-RPC error to the caller to allow higher-level retry logic.
                    raise
                except Exception:
                    # On unexpected errors during streaming, raise to outer handler
                    raise
                return parts, state, r_context_id, r_task_id

            async def _send_with_retry(msg):
                # First attempt
                try:
                    return await _send_and_collect(msg)
                except A2AClientJSONRPCError as rpc_err:
                    err_text = str(rpc_err)
                    if 'Name must be less' in err_text or 'Invalid name' in err_text:
                        # Extract offending name if present
                        m = re.search(r"Invalid name:\s*([^\.\s]+)", err_text)
                        long_name = m.group(1) if m else None
                        if long_name:
                            # sanitize and shorten
                            safe = re.sub(r"[^A-Za-z0-9_\-]", "_", long_name)
                            short_hint = (safe[:32] + '_' + uuid.uuid4().hex[:6]) if len(safe) > 38 else safe
                        else:
                            short_hint = (message.task_id[:32] + '_' + uuid.uuid4().hex[:6])

                        retry_query_text = f"[AUTO-RETRY: prefer short resource name '{short_hint}']\n\n" + query_text
                        a2a_message_retry = Message(
                            message_id=str(uuid.uuid4()),
                            role=Role.user,
                            parts=[TextPart(text=retry_query_text)]
                        )
                        # preserve context/task ids if present
                        if hasattr(a2a_message, 'context_id') and a2a_message.context_id:
                            a2a_message_retry.context_id = a2a_message.context_id
                        if hasattr(a2a_message, 'task_id') and a2a_message.task_id:
                            a2a_message_retry.task_id = a2a_message.task_id

                        try:
                            return await _send_and_collect(a2a_message_retry)
                        except Exception:
                            # If retry fails, re-raise original rpc error
                            raise rpc_err
                    else:
                        raise

            # perform send with retry logic
            response_parts, final_task_state, remote_context_id, remote_task_id = await _send_with_retry(a2a_message)
            
            # Check cancellation again after receiving the response
            if self.orchestrator_ref and self.orchestrator_ref.is_query_cancelled(message.query_id):
                logger.info(f"🛑 Query {message.query_id} was cancelled after task {message.task_id} response received, discarding result")
                return
            
            # Combine response data
            raw_response = "\n".join(response_parts) if response_parts else ""
            logger.info(f"📥 Task {message.task_id} - Raw Response length: {len(raw_response)}")
            logger.info(f"📊 Task {message.task_id} - Final state: {final_task_state}")
            
            # Process based on task state from events
            if final_task_state == TaskState.failed:
                logger.error(f"❌ Task {message.task_id} FAILED: {raw_response[:200]}")
                completion_msg = TaskCompletionMessage(
                    task_id=message.task_id,
                    query_id=message.query_id,
                    status=TaskStatus.FAILED.value,
                    error=raw_response or "Task failed"
                )
                
            elif final_task_state == TaskState.input_required:
                completion_msg = TaskCompletionMessage(
                    task_id=message.task_id,
                    query_id=message.query_id,
                    status=TaskStatus.WAITING_FOR_INPUT.value,
                    input_required_message=raw_response,
                    remote_context_id=remote_context_id,
                    remote_task_id=remote_task_id
                )
                
            elif final_task_state == TaskState.completed:
                logger.info(f"✅ Task {message.task_id} COMPLETED successfully")
                completion_msg = TaskCompletionMessage(
                    task_id=message.task_id,
                    query_id=message.query_id,
                    status=TaskStatus.COMPLETED.value,
                    response=raw_response or "Task completed successfully"
                )
                
            else:
                # No explicit state or unknown state - default to completed
                logger.warning(f"⚠️ Task {message.task_id} - No explicit state, defaulting to COMPLETED")
                completion_msg = TaskCompletionMessage(
                    task_id=message.task_id,
                    query_id=message.query_id,
                    status=TaskStatus.COMPLETED.value,
                    response=raw_response or "Task completed successfully"
                )
            
            await self.publish_message(completion_msg, topic_id=TASK_COMPLETION_TOPIC)
            
        except Exception as e:
            logger.error(f"Task {message.task_id} failed: {traceback.format_exc()}")
            completion_msg = TaskCompletionMessage(
                task_id=message.task_id,
                query_id=message.query_id,
                status=TaskStatus.FAILED.value,
                error=str(e)
            )
            await self.publish_message(completion_msg, topic_id=TASK_COMPLETION_TOPIC)
    
    async def close(self):
        """Clean up resources"""
        # Only close the HTTP client if this agent created/owns it.
        if getattr(self, "_owns_httpx_client", False) and self.httpx_client:
            try:
                await self.httpx_client.aclose()
                logger.info("Task executor HTTP client closed")
            except Exception as e:
                logger.error(f"Error closing task executor HTTP client: {e}")
