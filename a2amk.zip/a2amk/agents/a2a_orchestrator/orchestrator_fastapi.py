"""
A2A Orchestrator FastAPI Application

This module provides a FastAPI wrapper for the A2AOrchestrator, handling HTTP requests
and serving a web-based chat interface for user interaction.

Features:
- RESTful API endpoints for chat interaction
- Web-based chat interface with state management
- Health check endpoint
- CORS support for cross-origin requests
"""

import asyncio
from typing import Dict, Any
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import json
import os

from agents.a2a_orchestrator.orchestrator_core import A2AOrchestrator
from agents.a2a_orchestrator.orch_config import logger

class OrchestratorFastAPIApp:
    """FastAPI application wrapper for A2AOrchestrator"""
    
    def __init__(self, orchestrator: A2AOrchestrator):
        self.orchestrator = orchestrator
        # Respect an optional BASE_PATH environment variable so the app
        # can be served under a path prefix (e.g. /gpd-ops-a2a-api).
        # BASE_PATH may be set with or without a leading slash.
        import os
        raw_base = os.getenv("BASE_PATH", "").strip()
        logger.info(f"Setting BASE_PATH to '{raw_base}'")
        if raw_base and not raw_base.startswith("/"):
            raw_base = "/" + raw_base
        self.base_path = raw_base.rstrip("/") if raw_base else ""

        self.app = FastAPI(title="A2A Orchestrator with User Input")

        # Get the directory where this file is located
        self.current_dir = Path(__file__).parent

        # Mount static files. Mount at both the root `/static` and also
        # under the configured `BASE_PATH` (if any) so assets are reachable
        # whether requests arrive with or without the prefix.
        static_dir = self.current_dir / "static"
        static_dir.mkdir(exist_ok=True)
        # Always mount at root /static for local dev and ingress-rewrite setups
        self.app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
        logger.info(f"Mounted static files at /static from {self.base_path}/static")
        if self.base_path:
            mount_path = f"{self.base_path}/static"
            # use a different name to avoid mount name collision
            self.app.mount(mount_path, StaticFiles(directory=str(static_dir)), name="static_prefixed")

        # Register lifecycle events
        self.app.add_event_handler("shutdown", self._shutdown)
        
        self._setup_routes()
    
    async def _shutdown(self):
        """Cleanup resources on shutdown"""
        logger.info("Shutting down orchestrator...")
        try:
            await self.orchestrator.close()
            logger.info("Orchestrator cleanup complete")
        except Exception as e:
            logger.error(f"Error during shutdown: {e}")
    
    def _setup_routes(self):
        """Setup FastAPI routes"""
        
        # Enable CORS for web interface
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        @self.app.get("/", response_class=HTMLResponse)
        async def get_chat_interface():
            """Serve the chat interface HTML"""
            try:
                html_file = self.current_dir / "chat_interface.html"
                with open(html_file, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                # Replace template placeholder with the configured BASE_PATH
                # so client requests reference the correct prefixed URL.
                base = self.base_path or ""
                html_content = html_content.replace("{{BASE_PATH}}", base)
                return html_content
            except FileNotFoundError:
                return """
                <html>
                <body>
                    <h1>Chat Interface Not Found</h1>
                    <p>The chat interface template file is missing. Please check the installation.</p>
                </body>
                </html>
                """
        
        @self.app.post("/chat")
        async def handle_chat(request: dict):
            """Handle both new queries and user input responses"""
            try:
                query_id = request.get("query_id", "").strip()
                message = request.get("message", "").strip()
                task_id = request.get("task_id", "")  # Only present for user input
                session_id = request.get("session_id", "")  # Session identifier
                
                # Delegate to orchestrator's chat handler logic
                response = await self.orchestrator.handle_chat_request(
                    query_id=query_id,
                    message=message,
                    task_id=task_id if task_id else None,
                    session_id=session_id if session_id else None
                )
                return response
                
            except ValueError as e:
                logger.error(f"Validation error: {e}")
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                logger.error(f"Error handling chat: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/stream/{query_id}")
        async def stream_task_updates(query_id: str):
            """Stream task completion updates via Server-Sent Events"""
            async def event_generator():
                # Create/reuse a queue for this specific query.
                # Reuse helps when the UI reconnects or when `/chat` and `/stream` race.
                queue = self.orchestrator.streaming_queues.get(query_id)
                if queue is None:
                    queue = asyncio.Queue()
                    self.orchestrator.streaming_queues[query_id] = queue

                # Send periodic keep-alive comments so intermediaries (ingress, proxies)
                # don't terminate the connection during long-running tasks.
                heartbeat_seconds = float(os.getenv("A2A_SSE_HEARTBEAT_SECONDS", "15"))
                if heartbeat_seconds <= 0:
                    heartbeat_seconds = 15.0
                
                try:
                    while True:
                        # Wait for task updates, but wake up periodically to emit a heartbeat.
                        try:
                            event_data = await asyncio.wait_for(queue.get(), timeout=heartbeat_seconds)
                        except asyncio.TimeoutError:
                            # SSE comment line (ignored by EventSource) as heartbeat
                            yield ": keep-alive\n\n"
                            continue
                        
                        # Check if this is a cancellation event
                        if event_data.get("type") == "cancelled":
                            yield f"data: {json.dumps(event_data)}\n\n"
                            break
                        
                        # Check if this is the final event
                        if event_data.get("type") == "complete":
                            yield f"data: {json.dumps(event_data)}\n\n"
                            break
                        
                        # Send task completion event
                        yield f"data: {json.dumps(event_data)}\n\n"
                        
                except asyncio.CancelledError:
                    safe_query_id = query_id.replace('\r', '').replace('\n', '')
                    logger.info(f"Stream cancelled for query {safe_query_id}")
                finally:
                    # Cleanup
                    # Only remove if we're still the active queue for this query
                    if self.orchestrator.streaming_queues.get(query_id) is queue:
                        del self.orchestrator.streaming_queues[query_id]
            
            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no"
                }
            )
        
        @self.app.get("/history/session/{session_id}")
        async def get_session_history(session_id: str):
            """Get chat history for a specific session"""
            try:
                history = self.orchestrator.history_manager.get_session_history(session_id)
                return history
            except Exception as e:
                logger.error(f"Error getting session history: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/history/sessions")
        async def list_all_sessions():
            """List all sessions with summary information"""
            try:
                sessions = self.orchestrator.history_manager.list_sessions()
                return sessions
            except Exception as e:
                logger.error(f"Error listing sessions: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.delete("/history/session/{session_id}")
        async def delete_session_history(session_id: str):
            """Delete a specific session's history"""
            try:
                deleted = self.orchestrator.history_manager.delete_session(session_id)
                if deleted:
                    return {"message": f"Session {session_id} deleted successfully"}
                else:
                    raise HTTPException(status_code=404, detail="Session not found")
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Error deleting session: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.delete("/history/clear")
        async def clear_all_history():
            """Clear all session history"""
            try:
                self.orchestrator.history_manager.clear_all_history()
                return {"message": "All history cleared successfully"}
            except Exception as e:
                logger.error(f"Error clearing all history: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/health")
        async def health_check():
            """Health check endpoint"""
            return {
                "status": "healthy", 
                "active_queries": len(self.orchestrator.active_queries)
            }
        
        @self.app.post("/cancel/{query_id}")
        async def cancel_query(query_id: str):
            """Cancel an active query and its event stream.
            
            This cancels only the specified query's flow. It does not
            shut down the server or affect other active streams.
            """
            try:
                result = await self.orchestrator.cancel_query(query_id)
                return result
            except Exception as e:
                logger.error(f"Error cancelling query {query_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))
    
    async def run_server(self, host: str = "localhost", port: int = 8090):
        """Run the FastAPI server"""
        config = uvicorn.Config(
            app=self.app,
            host=host,
            port=port,
            log_level="info",
            access_log=True
        )
        server = uvicorn.Server(config)
        await server.serve()