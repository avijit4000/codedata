"""
Chat History Manager

This module manages chat history and sessions for the A2A Orchestrator.
Each user can have multiple sessions, and chat history is maintained per session.

Schema:
{
    session_id1: {
        query_id1: {
            "user_query": "...",
            "response_summary": "...",
            "timestamp": "...",
            "status": "completed|processing|failed"
        },
        query_id2: {...}
    },
    session_id2: {...}
}
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
import json, os
from pathlib import Path
import asyncio
from threading import Lock
import tiktoken
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from agents.a2a_orchestrator.utils import create_llm_client
from agents.a2a_orchestrator.orch_config import orch_name_in_config, logger
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage, 
    UserMessage, )

class ChatHistoryManager:
    """Manages chat history and sessions"""
    
    def __init__(self, persistence_file: Optional[str] = None):
        """
        Initialize the chat history manager.
        
        Args:
            persistence_file: Optional path to file for persisting history
        """
        self.history: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self.persistence_file = persistence_file
        self.lock = Lock()
        self.model_client = None
        
        # Load existing history if persistence file exists
        if self.persistence_file:
            self._load_history()
    
    def _load_history(self):
        """Load history from persistence file"""
        try:
            if Path(self.persistence_file).exists():
                with open(self.persistence_file, 'r') as f:
                    self.history = json.load(f)
                logger.info(f"Loaded chat history from {self.persistence_file}")
        except Exception as e:
            logger.error(f"Error loading history from {self.persistence_file}: {e}")
            self.history = {}
    
    def _save_history(self):
        """Save history to persistence file"""
        if not self.persistence_file:
            return
        
        try:
            # Ensure directory exists
            Path(self.persistence_file).parent.mkdir(parents=True, exist_ok=True)
            
            with open(self.persistence_file, 'w') as f:
                json.dump(self.history, f, indent=2)
            logger.debug(f"Saved chat history to {self.persistence_file}")
        except Exception as e:
            logger.error(f"Error saving history to {self.persistence_file}: {e}")
    
    def add_query(
        self, 
        session_id: str, 
        query_id: str, 
        user_query: str,
        timestamp: Optional[str] = None
    ):
        """
        Add a new query to the history.
        
        Args:
            session_id: Session identifier
            query_id: Query identifier
            user_query: The user's query text
            timestamp: Optional timestamp (will be auto-generated if not provided)
        """
        with self.lock:
            # Initialize session if it doesn't exist
            if session_id not in self.history:
                self.history[session_id] = {}
            
            # Add query entry with user_inputs array
            self.history[session_id][query_id] = {
                "user_query": user_query,
                "user_inputs": [
                    {
                        "input": user_query,
                        "timestamp": timestamp or datetime.now().isoformat(),
                        "type": "initial_query"
                    }
                ],
                "response_summary": "",
                "timestamp": timestamp or datetime.now().isoformat(),
                "status": "processing"
            }
            
            self._save_history()
            logger.info(f"Added query {query_id} to session {session_id}")
    
    def update_response(
        self, 
        session_id: str, 
        query_id: str, 
        response_summary: Any,
        status: str = "completed"
    ):
        """
        Update the response for a query.
        
        Args:
            session_id: Session identifier
            query_id: Query identifier
            response_summary: The response/summary (can be string or list)
            status: Status of the query (completed, failed, etc.)
        """
        with self.lock:
            if session_id not in self.history:
                logger.warning(f"Session {session_id} not found")
                return
            
            if query_id not in self.history[session_id]:
                logger.warning(f"Query {query_id} not found in session {session_id}")
                return
            
            # Update response
            self.history[session_id][query_id]["response_summary"] = response_summary
            self.history[session_id][query_id]["status"] = status
            self.history[session_id][query_id]["updated_at"] = datetime.now().isoformat()
            
            self._save_history()
            logger.info(f"Updated response for query {query_id} in session {session_id}")
    
    def add_user_input(
        self,
        session_id: str,
        query_id: str,
        user_input: str,
        input_type: str = "follow_up",
        task_id: Optional[str] = None,
        timestamp: Optional[str] = None
    ):
        """
        Add a user input to an existing query's history.
        
        Args:
            session_id: Session identifier
            query_id: Query identifier
            user_input: The user's input text
            input_type: Type of input (follow_up, task_response, etc.)
            task_id: Optional task ID if this is a response to a specific task
            timestamp: Optional timestamp (will be auto-generated if not provided)
        """
        with self.lock:
            if session_id not in self.history:
                logger.warning(f"Session {session_id} not found")
                return
            
            if query_id not in self.history[session_id]:
                logger.warning(f"Query {query_id} not found in session {session_id}")
                return
            
            # Create input entry
            input_entry = {
                "input": user_input,
                "timestamp": timestamp or datetime.now().isoformat(),
                "type": input_type
            }
            
            if task_id:
                input_entry["task_id"] = task_id
            
            # Add to user_inputs array
            if "user_inputs" not in self.history[session_id][query_id]:
                # For backward compatibility with old entries
                self.history[session_id][query_id]["user_inputs"] = []
            
            self.history[session_id][query_id]["user_inputs"].append(input_entry)
            
            self._save_history()
            logger.info(f"Added user input to query {query_id} in session {session_id}")
    
    def get_session_history(self, session_id: str) -> Dict[str, Dict[str, Any]]:
        """
        Get all chat history for a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Dictionary of query_id -> query data
        """
        with self.lock:
            return self.history.get(session_id, {}).copy()
    
    def get_query(self, session_id: str, query_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific query from history.
        
        Args:
            session_id: Session identifier
            query_id: Query identifier
            
        Returns:
            Query data or None if not found
        """
        with self.lock:
            session = self.history.get(session_id)
            if not session:
                return None
            return session.get(query_id)
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        """
        List all sessions with summary information.
        
        Returns:
            List of session summaries
        """
        with self.lock:
            sessions = []
            for session_id, queries in self.history.items():
                if not queries:
                    continue
                
                # Get first and last timestamps
                sorted_queries = sorted(
                    queries.values(),
                    key=lambda x: x.get("timestamp", "")
                )
                
                first_timestamp = sorted_queries[0].get("timestamp", "") if sorted_queries else ""
                last_timestamp = sorted_queries[-1].get("updated_at") or sorted_queries[-1].get("timestamp", "") if sorted_queries else ""
                
                sessions.append({
                    "session_id": session_id,
                    "query_count": len(queries),
                    "first_query_time": first_timestamp,
                    "last_query_time": last_timestamp,
                    "last_query": sorted_queries[-1].get("user_query", "")[:100] if sorted_queries else ""
                })
            
            # Sort by last query time (most recent first)
            sessions.sort(key=lambda x: x["last_query_time"], reverse=True)
            return sessions
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session and all its history.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session was deleted, False if not found
        """
        with self.lock:
            if session_id in self.history:
                del self.history[session_id]
                self._save_history()
                logger.info(f"Deleted session {session_id}")
                return True
            return False
    
    def clear_all_history(self):
        """Clear all history (use with caution!)"""
        with self.lock:
            self.history = {}
            self._save_history()
            logger.warning("Cleared all chat history")
    
    def get_session_context(self, session_id: str, max_queries: int = 5) -> str:
        """
        Get recent chat context for a session (useful for LLM context).
        
        Args:
            session_id: Session identifier
            max_queries: Maximum number of recent queries to include
            
        Returns:
            Formatted string with recent chat history
        """
        with self.lock:
            session = self.history.get(session_id, {})
            if not session:
                return ""
            
            # Get recent queries
            sorted_queries = sorted(
                session.items(),
                key=lambda x: x[1].get("timestamp", ""),
                reverse=True
            )[:max_queries]
            
            # Reverse to chronological order
            sorted_queries.reverse()
            
            context_parts = []
            for query_id, query_data in sorted_queries:
                user_query = query_data.get("user_query", "")
                response = query_data.get("response_summary", "")
                
                # Format response if it's a list (task results)
                if isinstance(response, list):
                    response_str = f"{len(response)} tasks completed"
                else:
                    response_str = str(response)[:200]
                
                context_parts.append(f"User: {user_query}\nAssistant: {response_str}")
            
            return "\n\n".join(context_parts)
    
    async def get_reference_context(self, session_id: str, max_queries: int = 3, exclude_query_id: Optional[str] = None) -> List[Dict[str, str]]:
        """
        Get reference context from previous queries in the session.
        Returns the last N completed queries with their initial query and response summary.
        
        Args:
            session_id: Session identifier
            max_queries: Maximum number of recent queries to include (default: 3)
            exclude_query_id: Query ID to exclude (e.g., current query)
            
        Returns:
            List of dictionaries with query and response_summary for reference
            Example: [
                {
                    "query": "What is the weather?",
                    "response_summary": "It's sunny and 75°F"
                },
                ...
            ]
        """
        with self.lock:
            session = self.history.get(session_id, {})
            if not session:
                return []
            
            # Get queries sorted by timestamp (most recent first)
            sorted_queries = sorted(
                session.items(),
                key=lambda x: x[1].get("timestamp", ""),
                reverse=True
            )
            
            reference_context = []
            for query_id, query_data in sorted_queries:
                # Skip the current query if specified
                if exclude_query_id and query_id == exclude_query_id:
                    continue
                
                # Only include completed queries
                if query_data.get("status") != "completed":
                    continue
                
                # Only include queries with a response
                response_summary = query_data.get("response_summary", "")
                if not response_summary:
                    continue
                
                # Format response if it's a list (task results)
                if isinstance(response_summary, list):
                    # Extract key information from task results
                    response_text = await self._format_task_summary(response_summary)
                else:
                    response_text = str(response_summary)
                
                reference_context.append({
                    "query": query_data.get("user_query", ""),
                    "response_summary": response_text
                })
                
                # Stop when we have enough
                if len(reference_context) >= max_queries:
                    break
            
            # Reverse to chronological order (oldest first)
            reference_context.reverse()
            
            return reference_context
    
    async def _format_task_summary(self, task_results: List[Dict[str, Any]], max_token_count = 2048) -> str:
        """
        Format task results into a readable summary.
        
        Args:
            task_results: List of task result dictionaries
            
        Returns:
            Formatted string summary
        """
        if not task_results:
            return "No tasks completed"
        
        summary_parts = []
        for task in task_results:
            if task["agent_name"] == "coder_agent":
                continue
            task_desc = task.get("task_description", "Unknown task")
            if task["response"] != None:
                response = task["response"]
            elif task["error"] != None:
                response = task['error']
            elif task["input_required"] != None:
                response = task['input_required']
            else:
                response = "No response"
            
            # Truncate long responses
            # if len(response) > 200:
            #     response = response[:200] + "..."
            
            if response:
                summary_parts.append(f"Task:\n {task_desc}\nTask Response:\n {response}\n")
            else:
                summary_parts.append(f"Task:\n {task_desc}\nTask Response:\n Completed\n")
        
        query_response = " | ".join(summary_parts)
        enc = tiktoken.get_encoding("o200k_base")
        token_count = len(enc.encode(query_response))
        if token_count < max_token_count:
            return query_response
        else:
            if self.model_client is None:
                self.model_client = await create_llm_client(orch_name_in_config)
            logger.info(f"Token count {token_count} exceeds max {max_token_count}, summarizing task results.")
            system_message = SystemMessage(content="Summarize the text under each Task Response: heading. Return in the same format.")
            user_message = UserMessage(content=query_response, source = "chat_history_manager")
            response = await self.model_client.create(
                messages = [system_message, user_message],
                extra_create_args = {"max_completion_tokens":max_token_count},
            )
            return response.content