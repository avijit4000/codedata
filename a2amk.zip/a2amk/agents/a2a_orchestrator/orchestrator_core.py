"""
A2A Orchestrator Core Module

This module contains the main A2AOrchestrator class and the A2AQueryCompletionAgent
for managing task execution across multiple remote A2A agents.

Features:
- Autogen runtime management
- Remote agent registration
- Chat request handling
- Query completion handling
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime

from autogen_core import (
    MessageContext, TypeSubscription,
    AgentRuntime, RoutedAgent,
    SingleThreadedAgentRuntime, message_handler
)

import httpx
import sys
import os
import time

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from a2a.client import ClientFactory, ClientConfig
from a2a.types import AgentCard
from a2a.client.card_resolver import A2ACardResolver

# Import shared types
from agents.a2a_orchestrator.orchestrator_types import (
    UserQueryMessage,
    UserInputMessage,
    QueryCompletionMessage,
    OrchestratorTask,
    RemoteAgent,
    USER_QUERY_TOPIC,
    USER_INPUT_TOPIC,
    QUERY_COMPLETION_TOPIC,
)

# Import agent classes
from agents.a2a_orchestrator.task_planner_agent import A2ATaskPlannerAgent
from agents.a2a_orchestrator.task_executor_agent import A2ATaskExecutorAgent
from agents.a2a_orchestrator.summary_agent import A2ASummaryAgent
from agents.a2a_orchestrator.chat_history_manager import ChatHistoryManager
from agents.a2a_orchestrator.orch_config import (
    QUERY_TIMEOUT,
    AGENT_TIMEOUT,
    AGENT_CONNECT_TIMEOUT,
    AGENT_HEALTHCHECK_TIMEOUT,
    logger,
)


def _build_httpx_timeout(total_seconds: float | None, connect_seconds: float | None) -> httpx.Timeout | None:
    if total_seconds is None and connect_seconds is None:
        return None
    if total_seconds is None:
        return httpx.Timeout(None, connect=connect_seconds)
    if connect_seconds is None:
        return httpx.Timeout(total_seconds)
    return httpx.Timeout(total_seconds, connect=connect_seconds)


class A2AQueryCompletionAgent(RoutedAgent):
    """Agent responsible for handling query completion events"""

    def __init__(self, orchestrator_ref):
        super().__init__("A2AQueryCompletion")
        self.orchestrator_ref = orchestrator_ref  # Reference to main orchestrator
    
    @message_handler
    async def handle_query_completion(self, message: QueryCompletionMessage, ctx: MessageContext) -> None:
        """Handle query completion events"""
        # Check if this query was cancelled before persisting results
        if self.orchestrator_ref.is_query_cancelled(message.query_id):
            logger.info(f"🛑 Query {message.query_id} was cancelled, ignoring completion")
            return

        logger.info(f"🎯 Query {message.query_id} completed")
        # Log summary info - it's now a list of dicts
        summary_info = f"{len(message.summary)} tasks" if isinstance(message.summary, list) else str(message.summary)[:100]
        logger.info(f"📄 Summary: {summary_info}")
        
        # Store result
        self.orchestrator_ref.query_results[message.query_id] = message.summary
        logger.info(f"💾 Stored result for query {message.query_id}")
        
        # Update chat history if session_id is provided
        if message.session_id:
            self.orchestrator_ref.history_manager.update_response(
                session_id=message.session_id,
                query_id=message.query_id,
                response_summary=message.summary,
                status="completed"
            )
        
        # Signal completion
        if message.query_id in self.orchestrator_ref.query_completion_events:
            logger.info(f"🚨 Setting completion event for query {message.query_id}")
            self.orchestrator_ref.query_completion_events[message.query_id].set()
        else:
            logger.error(f"❌ No completion event found for query {message.query_id}")
            logger.error(f"🔍 Available events: {list(self.orchestrator_ref.query_completion_events.keys())}")


class A2AOrchestrator:
    """Main orchestrator class for managing Autogen runtime and task execution"""
    
    def __init__(self, remote_agent_urls: List[str], model_client: Any, history_persistence_file: Optional[str] = "chat_history.json"):
        self.remote_agent_urls = remote_agent_urls
        self.model_client = model_client
        self.remote_agents: Dict[str, RemoteAgent] = {}
        self.httpx_client = httpx.AsyncClient(
            timeout=_build_httpx_timeout(AGENT_TIMEOUT, AGENT_CONNECT_TIMEOUT),
            verify="standard_trusts.pem",
        )
    
        # Autogen runtime and agents
        self.runtime: Optional[AgentRuntime] = None
        self.planner_agent: Optional[A2ATaskPlannerAgent] = None
        self.executor_agent: Optional[A2ATaskExecutorAgent] = None
        self.completion_agent: Optional[A2AQueryCompletionAgent] = None
        self.summary_agent: Optional[A2ASummaryAgent] = None
        
        # State management
        self.active_queries: Dict[str, Dict] = {}  # query_id -> query info
        self.waiting_for_input_tasks: Dict[str, OrchestratorTask] = {}  # task_id -> task
        self.query_results: Dict[str, str] = {}  # query_id -> final summary
        
        # Thread-safe event for query completion
        self.query_completion_events: Dict[str, asyncio.Event] = {}
        
        # Streaming support - queues for sending task updates to UI
        self.streaming_queues: Dict[str, asyncio.Queue] = {}  # query_id -> queue for SSE
        
        # Cancellation support - tracks query IDs that have been cancelled
        self.cancelled_queries: set = set()
        
        # Chat history manager
        self.history_manager = ChatHistoryManager(persistence_file=history_persistence_file)
    
    async def handle_chat_request(self, query_id: str, message: str, task_id: Optional[str] = None, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Handle chat requests - both new queries and user input responses.
        This method contains the core orchestrator logic.
        
        Args:
            query_id: Unique identifier for the query
            message: The user's message/query
            task_id: Optional task ID (present only for user input responses)
            session_id: Optional session ID for chat history tracking
            
        Returns:
            Dictionary with response data including completion status and message
        """
        if not message:
            raise ValueError("Message is required")
        
        # Determine if this is a new query or user input
        is_user_input = bool(task_id and query_id)
        
        if is_user_input:
            # Handle user input for existing task
            logger.info(f"Handling user input for task {task_id}, query {query_id}")
            
            if query_id not in self.active_queries:
                raise ValueError("Invalid query_id or query has expired")
            
            # Track user input in history if session_id is available
            query_info = self.active_queries.get(query_id, {})
            stored_session_id = session_id or query_info.get("session_id", "")
            
            if stored_session_id:
                self.history_manager.add_user_input(
                    session_id=stored_session_id,
                    query_id=query_id,
                    user_input=message,
                    input_type="task_response",
                    task_id=task_id,
                    timestamp=datetime.now().isoformat()
                )
            
            # Send user input to planner agent
            input_message = UserInputMessage(
                task_id=task_id,
                query_id=query_id,
                user_input=message,
                timestamp=datetime.now().isoformat()
            )
            
            await self.runtime.publish_message(input_message, topic_id=USER_INPUT_TOPIC)
            
            # Reset the event for the next wait
            self.query_completion_events[query_id].clear()

            # If the UI has an active SSE stream for this query, do not block this request.
            # The browser will receive progress/completion via `/stream/{query_id}`.
            # This prevents QUERY_TIMEOUT from firing mid-conversation when work is ongoing.
            if query_id not in self.streaming_queues:
                # Handle a brief reconnect/race where `/chat` arrives before `/stream/{query_id}`.
                # Keep this short so the POST stays fast under typical gateways.
                attach_wait = float(os.getenv("A2A_STREAM_ATTACH_WAIT_SECONDS", "1.0"))
                if attach_wait > 0:
                    deadline = time.monotonic() + attach_wait
                    while query_id not in self.streaming_queues and time.monotonic() < deadline:
                        await asyncio.sleep(0.05)

            if query_id in self.streaming_queues:
                logger.info(f"Streaming active for query {query_id} (user input), returning immediately")
                return {
                    "is_query_completed": False,
                    "streaming": True,
                    "message": "Processing with streaming updates...",
                    "query_id": query_id
                }
            
            # Wait for query completion or next input requirement
            try:
                if QUERY_TIMEOUT is None:
                    await self.query_completion_events[query_id].wait()
                else:
                    await asyncio.wait_for(self.query_completion_events[query_id].wait(), timeout=QUERY_TIMEOUT)
                
                # Check if query is completed or needs more input
                if query_id in self.query_results:
                    # Query completed
                    final_summary = self.query_results[query_id]
                    
                    # Handle None summary
                    if final_summary is None:
                        final_summary = "Query completed but no summary was provided."
                        logger.warning(f"Query {query_id} completed with None summary")
                    
                    # Cleanup
                    del self.active_queries[query_id]
                    del self.query_completion_events[query_id]
                    del self.query_results[query_id]
                    
                    return {
                        "is_query_completed": True,
                        "message": final_summary,
                        "query_id": query_id
                    }
                else:
                    # Check if there's a task waiting for input
                    waiting_task = None
                    for tid, task in self.waiting_for_input_tasks.items():
                        if task.query_id == query_id:
                            waiting_task = task
                            break
                    
                    if waiting_task:
                        return {
                            "is_query_completed": False,
                            "user_input_required": True,
                            "message": waiting_task.input_required_message,
                            "task_id": waiting_task.task_id,
                            "query_id": query_id
                        }
                    else:
                        # Query still processing
                        return {
                            "is_query_completed": False,
                            "user_input_required": False,
                            "message": "Processing...",
                            "query_id": query_id
                        }
            except asyncio.TimeoutError:
                # Check if streaming is active for this query
                if query_id in self.streaming_queues:
                    logger.info(f"Query {query_id} (user input) timed out but streaming is active")
                    # Check if query actually completed via streaming
                    if query_id in self.query_results:
                        # Query completed via streaming, return the result
                        final_summary = self.query_results[query_id]
                        if final_summary is None:
                            final_summary = "Query completed but no summary was provided."
                        # Cleanup
                        if query_id in self.active_queries:
                            del self.active_queries[query_id]
                        if query_id in self.query_completion_events:
                            del self.query_completion_events[query_id]
                        del self.query_results[query_id]
                        return {
                            "is_query_completed": True,
                            "message": final_summary,
                            "query_id": query_id
                        }
                    return {
                        "is_query_completed": False,
                        "streaming": True,
                        "message": "Query is being processed via streaming",
                        "query_id": query_id
                    }
                return {
                    "is_query_completed": False,
                    "user_input_required": False,
                    "message": "Query is still being processed",
                    "query_id": query_id
                }
                
        else:
            # Handle new query
            if not query_id:
                raise ValueError("query_id is required for new queries")
                
            logger.info(f"Processing new query {query_id}: {message}")
            
            # Get reference context from previous queries if session_id provided
            reference_context = []
            if session_id:
                # Get last 3 completed queries from this session for context
                reference_context = await self.history_manager.get_reference_context(
                    session_id=session_id,
                    max_queries=3,
                    exclude_query_id=query_id
                )
                logger.info(f"Retrieved {len(reference_context)} reference queries for context")
            
            # Add query to chat history if session_id provided
            if session_id:
                self.history_manager.add_query(
                    session_id=session_id,
                    query_id=query_id,
                    user_query=message,
                    timestamp=datetime.now().isoformat()
                )
            
            # Store query info
            self.active_queries[query_id] = {
                "query": message,
                "timestamp": datetime.now().isoformat(),
                "status": "processing",
                "session_id": session_id or ""
            }
            
            # Create completion event for this query
            self.query_completion_events[query_id] = asyncio.Event()
            
            # Send query to planner agent with reference context
            query_message = UserQueryMessage(
                query_id=query_id,
                user_query=message,
                timestamp=str(datetime.now().isoformat()),
                session_id=session_id or "",
                reference_context=reference_context
            )

            logger.info(f"Publishing UserQueryMessage for query {query_id} with {len(reference_context)} reference queries")
            
            await self.runtime.publish_message(query_message, topic_id=USER_QUERY_TOPIC)

            logger.info(f"Message published for query {query_id}")
            
            # Check if streaming is enabled for this query.
            # The UI opens the SSE stream first, but in practice requests can race.
            if query_id not in self.streaming_queues:
                attach_wait = float(os.getenv("A2A_STREAM_ATTACH_WAIT_SECONDS", "1.0"))
                if attach_wait > 0:
                    deadline = time.monotonic() + attach_wait
                    while query_id not in self.streaming_queues and time.monotonic() < deadline:
                        await asyncio.sleep(0.05)

            if query_id in self.streaming_queues:
                # Streaming is active - return immediately without waiting
                # The UI will receive updates via SSE
                logger.info(f"Streaming active for query {query_id}, returning immediately")
                return {
                    "is_query_completed": False,
                    "streaming": True,
                    "message": "Processing with streaming updates...",
                    "query_id": query_id
                }
            
            # Wait for initial response (completion or input requirement)
            # This path is for non-streaming queries (direct responses, etc.)
            # Use query timeout for consistency
            try:
                if QUERY_TIMEOUT is None:
                    await self.query_completion_events[query_id].wait()
                else:
                    await asyncio.wait_for(self.query_completion_events[query_id].wait(), timeout=QUERY_TIMEOUT)
                
                # Check if query completed immediately or needs input
                if query_id in self.query_results:
                    # Query completed
                    final_summary = self.query_results[query_id]
                    
                    # Handle None summary
                    if final_summary is None:
                        final_summary = "Query completed but no summary was provided."
                        logger.warning(f"Query {query_id} completed with None summary")
                    
                    # Cleanup
                    del self.active_queries[query_id]
                    del self.query_completion_events[query_id]
                    del self.query_results[query_id]
                    
                    return {
                        "is_query_completed": True,
                        "message": final_summary,
                        "query_id": query_id
                    }
                else:
                    # Check if there's a task waiting for input
                    logger.info("Checking for waiting tasks after event")
                    # print(self.waiting_for_input_tasks)
                    waiting_task = None
                    for tid, task in self.waiting_for_input_tasks.items():
                        if task.query_id == query_id:
                            waiting_task = task
                            break
                    
                    if waiting_task:
                        return {
                            "is_query_completed": False,
                            "user_input_required": True,
                            "message": waiting_task.input_required_message,
                            "task_id": waiting_task.task_id,
                            "query_id": query_id
                        }
                    else:
                        # Query still processing
                        return {
                            "is_query_completed": False,
                            "user_input_required": False,
                            "message": "Processing...",
                            "query_id": query_id
                        }
            except asyncio.TimeoutError:
                # Check if streaming is active for this query
                if query_id in self.streaming_queues:
                    logger.info(f"Query {query_id} (new query) timed out but streaming is active")
                    # Check if query actually completed via streaming
                    if query_id in self.query_results:
                        # Query completed via streaming, return the result
                        final_summary = self.query_results[query_id]
                        if final_summary is None:
                            final_summary = "Query completed but no summary was provided."
                        # Cleanup
                        if query_id in self.active_queries:
                            del self.active_queries[query_id]
                        if query_id in self.query_completion_events:
                            del self.query_completion_events[query_id]
                        del self.query_results[query_id]
                        return {
                            "is_query_completed": True,
                            "message": final_summary,
                            "query_id": query_id
                        }
                    return {
                        "is_query_completed": False,
                        "streaming": True,
                        "message": "Query is being processed via streaming",
                        "query_id": query_id
                    }
                return {
                    "is_query_completed": False,
                    "user_input_required": False,
                    "message": "Query is still being processed",
                    "query_id": query_id
                }
    
    async def cancel_query(self, query_id: str) -> Dict[str, Any]:
        """Cancel an active query flow.

        This stops the active event stream for *only* the given query_id,
        cleans up all internal state associated with it, and prevents any
        further tasks from being dispatched or processed for that query.

        It does **not** shut down the server, the autogen runtime, or any
        other concurrent event streams.
        """
        safe_qid = query_id.replace('\r', '').replace('\n', '')
        logger.info(f"🛑 Cancelling query {safe_qid}")

        # 1. Mark the query as cancelled so planner/executor skip future work.
        self.cancelled_queries.add(query_id)

        # 2. Send a "cancelled" event through the SSE stream (if active).
        queue = self.streaming_queues.get(query_id)
        if queue is not None:
            try:
                await queue.put({
                    "type": "cancelled",
                    "query_id": query_id,
                    "message": "Query cancelled by user.",
                })
            except Exception as e:
                logger.warning(f"Failed to push cancel event to stream: {e}")

        # 3. Set the completion event so any awaiting coroutine unblocks.
        event = self.query_completion_events.get(query_id)
        if event is not None:
            event.set()

        # 4. Clean up orchestrator-level state for this query.
        self.active_queries.pop(query_id, None)
        self.query_completion_events.pop(query_id, None)
        self.query_results.pop(query_id, None)

        # Remove any tasks waiting for user input that belong to this query.
        waiting_to_remove = [
            tid for tid, task in self.waiting_for_input_tasks.items()
            if task.query_id == query_id
        ]
        for tid in waiting_to_remove:
            del self.waiting_for_input_tasks[tid]

        # 5. Clean up planner state (active_queries, session maps, etc.).
        if hasattr(self, 'runtime') and self.runtime:
            # The planner agent keeps its own dict of active queries.
            # We mark them so the planner's next handler invocation can discard them.
            # The planner checks self.orchestrator_ref.cancelled_queries directly.
            pass

        logger.info(f"✅ Query {safe_qid} cancelled and cleaned up")

        # Schedule lazy cleanup of the cancelled_queries set so it doesn't
        # grow unboundedly.  After 60s a late-arriving message for this
        # query_id would no longer be blocked, but by then all downstream
        # handlers have already dropped it.
        async def _delayed_discard():
            await asyncio.sleep(60)
            self.cancelled_queries.discard(query_id)
        asyncio.ensure_future(_delayed_discard())

        return {"status": "cancelled", "query_id": query_id}

    def is_query_cancelled(self, query_id: str) -> bool:
        """Check whether a query has been cancelled."""
        return query_id in self.cancelled_queries

    async def initialize(self):
        """Initialize the orchestrator by setting up agents and runtime"""
        logger.info("Initializing A2A Orchestrator with FastAPI...")
        
        # Register remote agents
        for agent_url in self.remote_agent_urls:
            try:
                await self._register_remote_agent(agent_url)
            except Exception as e:
                logger.error(f"Failed to register agent at {agent_url}: {e}")
        
        # Initialize Autogen runtime
        self.runtime = SingleThreadedAgentRuntime()
        
        # Create and register agents
        await A2ATaskPlannerAgent.register(self.runtime, "A2ATaskPlanner", lambda: A2ATaskPlannerAgent(self.remote_agents, self.model_client, self))
        await A2ATaskExecutorAgent.register(self.runtime, "A2ATaskExecutor", lambda: A2ATaskExecutorAgent(self.remote_agents, httpx_client=self.httpx_client, orchestrator_ref=self))
        await A2AQueryCompletionAgent.register(self.runtime, "A2AQueryCompletion", lambda: A2AQueryCompletionAgent(self))
        await A2ASummaryAgent.register(self.runtime, "A2ASummaryAgent", lambda: A2ASummaryAgent(self.model_client, self))
        
        # Subscribe agents to topics
        await self.runtime.add_subscription(TypeSubscription(topic_type="user_query", agent_type="A2ATaskPlanner"))
        await self.runtime.add_subscription(TypeSubscription(topic_type="task_completion", agent_type="A2ATaskPlanner"))
        await self.runtime.add_subscription(TypeSubscription(topic_type="user_input", agent_type="A2ATaskPlanner"))
        await self.runtime.add_subscription(TypeSubscription(topic_type="task_execution", agent_type="A2ATaskExecutor"))
        await self.runtime.add_subscription(TypeSubscription(topic_type="query_completion", agent_type="A2AQueryCompletion"))
        await self.runtime.add_subscription(TypeSubscription(topic_type="summary_request", agent_type="A2ASummaryAgent"))
        
        # Start runtime
        self.runtime.start()
        
        logger.info(f"Orchestrator initialized with {len(self.remote_agents)} remote agents")
    
    async def _register_remote_agent(self, agent_url: str):
        """Register a remote A2A agent"""
        try:
            # Check agent connectivity using shared client to reuse keep-alive/TLS.
            logger.info(f"Checking connectivity to {agent_url}")
            try:
                response = await self.httpx_client.get(f"{agent_url}/health", timeout=_build_httpx_timeout(AGENT_HEALTHCHECK_TIMEOUT, AGENT_CONNECT_TIMEOUT))
                if response.status_code != 200:
                    logger.warning(f"Health check failed for {agent_url}, status: {response.status_code}")
            except Exception as e:
                logger.warning(f"Health check error for {agent_url}: {e}")
            
            # Create card resolver
            card_resolver = A2ACardResolver(
                httpx_client=self.httpx_client,
                base_url=agent_url
            )
            
            # Fetch agent card
            agent_card = await card_resolver.get_agent_card()

            # IMPORTANT: In real deployments the agent card's `url` field is often
            # misconfigured (e.g., defaults to http://0.0.0.0:PORT or misses an ingress
            # path prefix). The orchestrator is already configured with the reachable
            # agent base URL, so prefer it when there is a mismatch.
            expected_agent_url = agent_url.rstrip("/") + "/"
            resolved_card_url = (agent_card.url or "").rstrip("/") + "/"
            if resolved_card_url != expected_agent_url:
                logger.warning(
                    "Agent card URL mismatch for %s: card.url=%s expected=%s; overriding card.url",
                    agent_url,
                    agent_card.url,
                    expected_agent_url,
                )
                agent_card = agent_card.model_copy(update={"url": expected_agent_url})
            
            # Create client for this agent
            client_config = ClientConfig(
                streaming=False,
                polling=False,
                httpx_client=self.httpx_client
            )
            client = await ClientFactory.connect(agent=agent_card, client_config=client_config)
            
            # Extract skills
            skills = []
            if agent_card.skills:
                skills = [
                    {
                        "id": skill.id,
                        "name": skill.name,
                        "description": skill.description,
                        "examples": skill.examples or []
                    }
                    for skill in agent_card.skills
                ]
            
            # Register agent
            remote_agent = RemoteAgent(
                url=agent_url,
                name=agent_card.name,
                description=agent_card.description or "",
                skills=skills,
                agent_card=agent_card,
                client=client
            )
            
            self.remote_agents[agent_url] = remote_agent
            logger.info(f"Registered agent: {agent_card.name} at {agent_url}")
            
        except Exception as e:
            logger.error(f"Error registering agent at {agent_url}: {e}")
            raise
    
    async def close(self):
        """Clean up resources"""
        logger.info("Closing orchestrator resources...")

        if self.executor_agent:
            try:
                await self.executor_agent.close()
            except Exception as e:
                logger.error(f"Error closing executor agent: {e}")

        if self.runtime:
            try:
                await self.runtime.stop()
            except RuntimeError as e:
                # autogen_core raises if stop() is called before start(); treat as benign during shutdown
                if "Runtime is not started" not in str(e):
                    raise

        for agent in self.remote_agents.values():
            if agent.client:
                try:
                    await agent.client.close()
                except Exception as e:
                    logger.error(f"Error closing client for {agent.name}: {e}")

        if self.httpx_client:
            try:
                await self.httpx_client.aclose()
            except Exception as e:
                logger.error(f"Error closing orchestrator HTTP client: {e}")

        logger.info("Orchestrator resources closed")
