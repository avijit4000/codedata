"""LLM client factory helpers.

This module exists to avoid import cycles between the orchestrator entrypoint
(`orch_main.py`) and modules used by the orchestrator core.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

import yaml
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient


def create_llm_client(config_section_name: str, *, config_path: Optional[str] = None) -> AzureOpenAIChatCompletionClient:
    """Create an Azure OpenAI chat completion client from `config.yaml`.

    Args:
        config_section_name: Top-level section in config.yaml (e.g. orchestrator/agent name)
            that contains a `llm_model` key.
        config_path: Optional explicit path to the YAML config file. Defaults to
            `<cwd>/config.yaml`.

    Returns:
        Configured AzureOpenAIChatCompletionClient.

    Raises:
        FileNotFoundError: if config file is missing.
        ValueError: if required model configuration is missing.
    """

    logger = logging.getLogger(__name__)
    resolved_config_path = config_path or os.path.join(os.getcwd(), "config.yaml")

    model_name: Optional[str] = None
    model_params: Optional[Dict[str, Any]] = None

    try:
        with open(resolved_config_path, "r") as file:
            config = yaml.safe_load(file) or {}
            model_name = (config.get(config_section_name) or {}).get("llm_model")
            if model_name:
                model_params = (config.get("llm_models") or {}).get(model_name)
    except FileNotFoundError:
        logger.warning("config.yaml file not found at %s", resolved_config_path)
        raise
    except Exception as exc:
        logger.error("Error reading config.yaml at %s: %s", resolved_config_path, exc)
        raise

    if not model_name:
        raise ValueError(f"No `llm_model` configured under section '{config_section_name}' in {resolved_config_path}.")

    if not model_params:
        raise ValueError(f"No configuration found for model '{model_name}'. Please check llm_models in {resolved_config_path}.")

    return AzureOpenAIChatCompletionClient(
        model=model_params.get("model_name"),
        azure_endpoint=model_params.get("azure_endpoint"),
        azure_deployment=model_params.get("azure_deployment"),
        api_version=model_params.get("api_version"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    )
