import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

from agents_logger import logger


DEFAULT_CONFIG_ENV_VARS = (
    "AGENT_CONFIG_NAME",
    "AGENT_CONFIG",
)


def _workspace_root() -> Path:
    # Repo code typically assumes cwd is workspace root.
    return Path(os.getcwd())


def _configs_dir() -> Path:
    return _workspace_root() / "configs"


def _normalize_config_name(name: str) -> str:
    return name.strip().removesuffix(".yaml").removesuffix(".yml")


def find_agent_config_file(config_name: str, configs_dir: Optional[Path] = None) -> Path:
    """Find a config yaml file in configs/ matching the provided name.

    Matching rules:
    - If `config_name` is a path to an existing file, use it.
    - Else try configs/<name>.yaml and configs/<name>.yml.
    - Else scan all yaml files and match `name` field to config_name or f"{config_name}_agent".
    """
    if not config_name or not config_name.strip():
        raise ValueError("config_name is empty")

    configs_dir = configs_dir or _configs_dir()
    candidate = Path(config_name)
    if candidate.exists() and candidate.is_file():
        return candidate

    stem = _normalize_config_name(config_name)

    direct_yaml = configs_dir / f"{stem}.yaml"
    if direct_yaml.exists():
        return direct_yaml
    direct_yml = configs_dir / f"{stem}.yml"
    if direct_yml.exists():
        return direct_yml

    if not configs_dir.exists():
        raise FileNotFoundError(f"configs directory not found: {configs_dir}")

    yaml_files = sorted(list(configs_dir.glob("*.yaml")) + list(configs_dir.glob("*.yml")))
    for p in yaml_files:
        try:
            data = yaml.safe_load(p.read_text()) or {}
            name_field = (data.get("name") or "").strip()
            if name_field == stem or name_field == f"{stem}_agent":
                return p
        except Exception:
            continue

    available = ", ".join([p.name for p in yaml_files]) if yaml_files else "(none)"
    raise FileNotFoundError(
        f"No config yaml found for '{stem}' under {configs_dir}. Available: {available}"
    )


def load_agent_config(config_name: str) -> Dict[str, Any]:
    config_path = find_agent_config_file(config_name)
    try:
        data = yaml.safe_load(config_path.read_text())
        if not isinstance(data, dict):
            raise ValueError(f"Config file must be a mapping, got {type(data).__name__}")
        return data
    except FileNotFoundError:
        raise
    except Exception as e:
        logger.error(f"Error reading agent config file {config_path}: {e}")
        raise


def get_selected_config_name() -> Optional[str]:
    for env_var in DEFAULT_CONFIG_ENV_VARS:
        value = os.getenv(env_var)
        if value and value.strip():
            return value.strip()
    return None


def _set_env_if_present(env_name: str, value: Any) -> None:
    if value is None:
        return
    # Convert lists/dicts into JSON strings for downstream env parsing.
    if isinstance(value, (list, dict)):
        os.environ[env_name] = json.dumps(value)
    else:
        os.environ[env_name] = str(value)


def apply_agent_config_to_base_agent_env(agent_config: Dict[str, Any]) -> None:
    """Map configs/<name>.yaml content into env vars expected by agents/base_agent/config.py."""
    details = agent_config.get("details") or {}

    # Core identity
    _set_env_if_present("BASE_AGENT_DISPLAY_NAME", agent_config.get("agent_display_name"))
    _set_env_if_present("AGENT_NAME_IN_YAML_CONFIG", agent_config.get("name"))

    # Host/port
    _set_env_if_present("HOST", details.get("HOST"))
    _set_env_if_present("PORT", details.get("PORT"))

    # Description/prompt
    _set_env_if_present("BASE_AGENT_DESCRIPTION", details.get("description"))
    _set_env_if_present("BASE_AGENT_PROMPT", details.get("agent_prompt"))

    # Skills
    _set_env_if_present("BASE_AGENT_SKILL_TAGS", details.get("agent_skill_tags"))
    _set_env_if_present("BASE_AGENT_SKILL_EXAMPLES", details.get("agent_skill_examples"))

    # Version
    _set_env_if_present("AGENT_VERSION", details.get("agent_version"))

    # The model selection is used by create_model_client.
    _set_env_if_present("LLM_MODEL", details.get("llm_model"))


def require_and_apply_selected_agent_config() -> Dict[str, Any]:
    """If AGENT_CONFIG_NAME/AGENT_CONFIG is set, load configs/<name>.yaml and apply to env.

    Raises FileNotFoundError if the selected config doesn't exist.
    """
    config_name = get_selected_config_name()
    if not config_name:
        return {}

    agent_cfg = load_agent_config(config_name)
    apply_agent_config_to_base_agent_env(agent_cfg)
    logger.info(f"Loaded agent config from configs for '{config_name}'")
    return agent_cfg
