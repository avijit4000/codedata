import asyncio
from dataclasses import dataclass
from pydantic import BaseModel
import json
import time
from autogen_core import (DefaultTopicId, 
                          MessageContext, 
                          RoutedAgent, 
                          default_subscription, 
                          message_handler,
                          FunctionCall)
from autogen_core import AgentId, SingleThreadedAgentRuntime
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage, 
    UserMessage, 
    CreateResult, 
    AssistantMessage,
    LLMMessage,
    FunctionExecutionResult,
    FunctionExecutionResultMessage,
)
from dotenv import load_dotenv
from autogen_core.model_context import BufferedChatCompletionContext, ChatCompletionContext, UnboundedChatCompletionContext
from autogen_core.tools import FunctionTool, Tool, Workbench, ToolResult
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
from typing import Annotated, Any, AsyncGenerator, Callable, Coroutine, Dict, List, Optional, Sequence, Tuple, Literal
import typing
import os, json
from agents_logger import logger
from agents.mcp_trust import apply_mcp_http_trust_from_env
load_dotenv()

func_call_summary_prompt = """
                        Restructure the function calls response into markdown format if it contains data. Else restructure as plain text.
                        The function calls responses are a list of dictionaries with keys and values.
                        Read and understand the response and its structure thoroughly.
                        You should create a table for each dictionary within the list in the markdown format.
                        Strictly include all the keys and values available in the function call responses.
                        If there are timestamps, convert it into human readable format.

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        """
func_call_summary_prompt2 =  """
                        Summarize the entire function calls response.
                        The function calls responses are a list of dictionaries with keys and values.
                        Read and understand the response and its structure thoroughly.
                        If there are timestamps, convert it into human readable format.

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        """                      


class AgentInputMessage(BaseModel):
    request: str
    source: str
    task_id: Optional[str] = None
    context_id: Optional[str] = None

# An Autogen Agent implementation
class AutogenCoreAgent(RoutedAgent):
    SUPPORTED_CONTENT_TYPES = ['text', 'text/plain', 'application/json']
    def __init__(self, agent_name: str,
                 agent_description: str,
                 model_client: ChatCompletionClient, 
                 system_message: Optional[List[SystemMessage]] = None,
                 model_context: ChatCompletionContext | None = None,
                 tools: Optional[Sequence[Tool]] = None,
                 mcp_server_params: Optional[StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]] = None,
                 markdown_summary = True,
                #  workbench: Optional[Sequence[Workbench]] = None,

                 ) -> None:
        super().__init__(description = agent_description)
        self._system_message = system_message
        self._model_client = model_client
        self._model_context = model_context
        self._tools = tools
        self._agent_name  = agent_name
        # self._agent_description = agent_description
        self._workbench = None
        self._persistent_workbench = False
        self._mcp_server_params = mcp_server_params
        self._markdown_summary = markdown_summary



    @message_handler
    async def handle_text_message(self, message: AgentInputMessage, context: MessageContext)-> str | Dict:

        # if self._tools and self._workbench:
        #     raise ValueError("Cannot have both tools and workbench defined at the same time.")
        
        # CRITICAL: Reset model context for each request to prevent message accumulation across requests.
        # When using a shared runtime, agent instances can be reused; we must ensure clean state.
        if self._model_context is not None:
            try:
                context_type = type(self._model_context)
                if context_type == BufferedChatCompletionContext:
                    self._model_context = BufferedChatCompletionContext(buffer_size=5, initial_messages=[])
                    logger.debug(f"Reset model context for agent {self._agent_name}")
            except Exception as e:
                logger.warning(f"Failed to reset model context: {e}")
        
        if self._mcp_server_params is not None:
            try:
                # Create workbench once and reuse across requests to avoid per-request
                # start/stop costs (TCP/TLS handshakes and process startup latency).
                if self._workbench is None:
                    self._workbench = await self.create_mcp_workbench(self._mcp_server_params)
                    # Mark persistent to avoid closing between requests
                    self._persistent_workbench = True
            except Exception as e:
                logger.error(f"Error creating MCP workbench: {e}")
        else:
            self._workbench = None
        


        tools = []
        if self._workbench is not None:
            # _fetch_workbench_tools will ensure the workbench is started if needed.
            wb_tools = await self._fetch_workbench_tools(self._workbench)
            tools.extend(wb_tools)
            # logger.info(f"Tools from workbenches: {wb_tools}")
        if self._tools is not None:
            tools.extend(self._tools)
        
        user_message = UserMessage(content=message.request, source=message.source)

        if self._model_context is not None:
            await self._model_context.add_message(user_message)
            # logger.info(await self._model_context.get_messages())

        func_calls = None
        logger.info("Sending request to model...")
        model_response = await self._model_client.create(
            messages=self._system_message + (await self._model_context.get_messages() if self._model_context else user_message),
            tools=tools, 
            cancellation_token=context.cancellation_token,
            )     

        

        if isinstance(model_response, CreateResult) and isinstance(model_response.content, str):
            await self._model_context.add_message(AssistantMessage(content=model_response.content, source=self.id.type))
            await self.close_wb()
            return json.dumps(model_response.content)
        elif isinstance(model_response, str):
            await self._model_context.add_message(AssistantMessage(content=model_response, source=self.id.type))
            await self.close_wb()
            return model_response
        elif isinstance(model_response, CreateResult) and isinstance(model_response.content, list):
            func_calls = model_response.content
            if self._model_context is not None:
                # Create assistant message with tool calls
                assistant_message = AssistantMessage(
                    content=func_calls, 
                    source=self.id.type
                )
                await self._model_context.add_message(assistant_message)
        else:
            logger.info("None")
            await self.close_wb()
            raise RuntimeError(f"Invalid LLM response type: {type(model_response)}")


        if func_calls is not None:
            logger.info(f"Function calls to execute: {func_calls}")
    
            tool_results: List[Tuple[FunctionCall, FunctionExecutionResult]] = await asyncio.gather(
                        *[
                            self._execute_tool_call(
                                workbenches = self._workbench,
                                func_call=call,
                                cancellation_token=context.cancellation_token,
                            )
                            for call in func_calls
                        ]
                    )

            # Verify all tool calls have results
            logger.info(f"Tool results count: {len(tool_results)}, Tool calls count: {len(func_calls)}")

            # IMPORTANT: OpenAI/Azure OpenAI requires that each assistant tool_call (tool_call_id)
            # is followed by a corresponding tool message for that exact tool_call_id.
            # When the assistant returns multiple tool_calls in a single message, we must add
            # one FunctionExecutionResultMessage per tool_call_id.
            # Always build tool result messages explicitly to avoid buffered-context
            # truncation breaking tool-call ↔ tool-result ordering.
            func_exec_res_msg = [FunctionExecutionResultMessage(content=[result]) for _, result in tool_results]

            if self._markdown_summary:
                summary_prompt = func_call_summary_prompt
            else:
                summary_prompt = func_call_summary_prompt2

            # CRITICAL: Do not rely on BufferedChatCompletionContext here.
            # If the agent makes many tool calls, the buffer can drop the assistant tool_calls
            # message (or some tool results), and Azure OpenAI will reject the request.
            # Build a valid message chain explicitly:
            #   system(summary prompt) -> user -> assistant(tool_calls) -> tool(results...)
            summary_messages: List[LLMMessage] = [
                SystemMessage(content=summary_prompt),
                user_message,
                AssistantMessage(content=func_calls, source=self.id.type),
            ]
            summary_messages.extend(func_exec_res_msg)

            tool_call_summary = await self._model_client.create(messages=summary_messages)
        
            # logger.info(f"Function Call Summary: {tool_call_summary}")
            
            await self.close_wb()

            evaluation_scores = await self.run_metrics_evaluation(
                user_message=user_message,
                tool_call_summary=tool_call_summary,
                func_calls=func_calls,
                available_tools=tools,
                tool_results=tool_results
            )

            call_summary = tool_call_summary.content

            if isinstance(call_summary, dict):
                call_summary.update(evaluation_scores)
            else:
                call_summary = json.loads(call_summary)
                call_summary.update(evaluation_scores)
            

            # call_summary = json.loads(tool_call_summary.content)
            # if call_summary["status"] == "completed":
            #     func_call_result = [result.content for _, result in tool_results]
            #     return json.dumps({"status": "completed", "agent_response":json.dumps(func_call_result)})
        

            return json.dumps(call_summary)
        
    async def close_wb(self):
        # Only close workbench resources if they are not marked persistent.
        if self._workbench is not None and not getattr(self, "_persistent_workbench", False):
            for wb in self._workbench:
                # Prefer explicit stop() if supported by the workbench implementation.
                # Calling __aexit__ without a matching __aenter__ can leave some implementations
                # in a bad state.
                try:
                    if hasattr(wb, "stop"):
                        await wb.stop()
                    else:
                        await wb.__aexit__(None, None, None)
                except Exception as e:
                    logger.warning(f"Error closing MCP workbench: {e}")
    
    async def run_metrics_evaluation(self, user_message: UserMessage,
                                     tool_call_summary: CreateResult,
                                     func_calls: Sequence[FunctionCall],
                                     available_tools: Dict | str,
                                     tool_results: List[Tuple[FunctionCall, FunctionExecutionResult]]) -> Dict[str, float]:
        # Evaluation metrics can be expensive and pull in heavy dependencies.
        # Keep them optional to reduce startup time and response latency.
        enabled = os.getenv("AGENT_EVALUATION_ENABLED", "false").lower() in {"1", "true", "yes"}
        if not enabled:
            return {}

        try:
            from agents.autogen_base_agent.agent_evaluation import evaluation_metrics
        except Exception as e:
            logger.warning(f"Evaluation metrics disabled (import failed): {type(e).__name__}: {e}")
            return {}

        try:
            evaluation_scores = await evaluation_metrics.custom_tool_correctness(
                query=user_message.content if isinstance(user_message, UserMessage) else str(user_message),
                llm_response=tool_call_summary.content if isinstance(tool_call_summary.content, str) else str(tool_call_summary.content),
                tools_called=func_calls,
                available_tools=available_tools,
            )
        except Exception as e:
            logger.warning(f"Evaluation metrics failed: {type(e).__name__}: {e}")
            return {}
        # # Get the Faithfullness Score
        # faithfulness_score = await evaluation_metrics.ragas_faithfulness(
        #     query=user_message.content if isinstance(user_message, UserMessage) else str(user_message),
        #     llm_response= tool_call_summary.content if isinstance(tool_call_summary.content, str) else str(tool_call_summary.content),
        #     retrieved_context= [result.content for _, result in tool_results]
        # )

        # evaluation_scores.update(faithfulness_score)

        # # Get the Answer Relevancy Score
        # answer_relevancy_score = await evaluation_metrics.ragas_answer_relevancy(
        #     query=user_message.content if isinstance(user_message, UserMessage) else str(user_message),
        #     llm_response= tool_call_summary.content if isinstance(tool_call_summary.content, str) else str(tool_call_summary.content)
        # )

        # evaluation_scores.update(answer_relevancy_score)

        logger.info(f"Task Evaluation Scores: {evaluation_scores}")
        return evaluation_scores

        
    async def create_mcp_workbench(self, mcp_params: StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
                     ) -> Sequence[McpWorkbench]:
        apply_mcp_http_trust_from_env()
        workbenches = []
        if isinstance(mcp_params, Sequence):
            for params in  mcp_params:
                workbench = McpWorkbench(params)
                workbenches.append(workbench)
            return workbenches
        
        workbench = McpWorkbench(mcp_params)
        workbenches.append(workbench)
        return workbenches


    async def _fetch_workbench_tools(self, workbench: Sequence[Workbench]) -> List[Tool]:

        try:
            if isinstance(workbench, Sequence):
                tools = []
                for bench in workbench:
                    try:
                        # Start explicitly so MCP init failures propagate with useful details.
                        if hasattr(bench, "start"):
                            await bench.start()
                        wb_tools = await bench.list_tools()
                        tools.extend(wb_tools)
                    except Exception as e:
                        logger.error(f"Error fetching tools from workbench {bench}: {e}")
                        import traceback
                        traceback.print_exc()
                        continue
                return tools

            return []
        except Exception as e:
            logger.error(f"Error fetching workbench tools: {e}")
            return []
        
    async def _execute_tool_call(self, workbenches: Sequence[Workbench],
                                 func_call: FunctionCall,
                                 cancellation_token
                                 ) -> Tuple[FunctionCall, FunctionExecutionResult]:

        try:
            arguments = json.loads(func_call.arguments)
        except json.JSONDecodeError as e:
            return (
                func_call,
                FunctionExecutionResult(
                    content=f"Error: {e}",
                    call_id=func_call.id,
                    is_error=True,
                    name=func_call.name,
                ),
            )

        # Run through workbenches to find the tool and execute the tool call
        if workbenches:
            for workbench in workbenches:
                # Ensure workbench is started (some environments can race or reconnect).
                try:
                    if hasattr(workbench, "start"):
                        await workbench.start()
                except Exception:
                    # If start fails, list_tools/call_tool will return a more specific error.
                    pass

                # List tools with timing
                try:
                    logger.info(f"MCP: listing tools on workbench {workbench} for call {func_call.name} (call_id={func_call.id})")
                    list_start = time.monotonic()
                    wb_tools = await workbench.list_tools()
                    list_dur = time.monotonic() - list_start
                    logger.info(f"MCP: list_tools completed in {list_dur:.3f}s, found {len(wb_tools)} tools")
                except RuntimeError as e:
                    if "not started" in str(e).lower() or "call start() first" in str(e).lower():
                        if hasattr(workbench, "start"):
                            await workbench.start()
                        logger.info(f"MCP: retrying list_tools after start() for workbench {workbench}")
                        list_start = time.monotonic()
                        wb_tools = await workbench.list_tools()
                        list_dur = time.monotonic() - list_start
                        logger.info(f"MCP: list_tools retry completed in {list_dur:.3f}s, found {len(wb_tools)} tools")
                    else:
                        raise

                # If the tool is present, call it
                if any(t["name"] == func_call.name for t in wb_tools):
                    try:
                        logger.info(f"MCP: calling tool '{func_call.name}' (call_id={func_call.id}) with args={arguments}")
                        call_start = time.monotonic()
                        func_call_result = await workbench.call_tool(
                            name=func_call.name,
                            arguments=arguments,
                            cancellation_token=cancellation_token,
                            call_id=func_call.id,
                        )
                        call_dur = time.monotonic() - call_start
                    except RuntimeError as e:
                        if "not started" in str(e).lower() or "call start() first" in str(e).lower():
                            if hasattr(workbench, "start"):
                                await workbench.start()
                            logger.info(f"MCP: retrying call_tool after start() for tool {func_call.name} (call_id={func_call.id})")
                            call_start = time.monotonic()
                            func_call_result = await workbench.call_tool(
                                name=func_call.name,
                                arguments=arguments,
                                cancellation_token=cancellation_token,
                                call_id=func_call.id,
                            )
                            call_dur = time.monotonic() - call_start
                        else:
                            raise

                    # Try to log response size/text safely
                    try:
                        resp_text = func_call_result.to_text()
                        resp_len = len(resp_text) if resp_text is not None else 0
                    except Exception:
                        resp_text = None
                        resp_len = None

                    logger.info(f"MCP: tool '{func_call.name}' (call_id={func_call.id}) completed in {call_dur:.3f}s; response_length={resp_len}")
                    if resp_text and resp_len and resp_len < 2000:
                        logger.debug(f"MCP: tool response (call_id={func_call.id}): {resp_text}")

                    return (
                        func_call,
                        FunctionExecutionResult(
                            content=func_call_result.to_text(),
                            call_id=func_call.id,
                            is_error=func_call_result.is_error,
                            name=func_call.name,
                        ),
                    )
        # if Tools not found in workbenches, check in self._tools and execute
        if self._tools is not None:
            for tool in self._tools:
                tool_schema = tool.schema if hasattr(tool, "schema") else {}
                if tool_schema.get("name") == func_call.name and isinstance(tool, Tool):
                    tool_result = await tool.run_json(arguments, cancellation_token)
                    tool_result_str = tool.return_value_as_string(tool_result)
                    return (
                        func_call,
                        FunctionExecutionResult(
                            content=tool_result_str,
                            call_id=func_call.id,
                            is_error=False,
                            name=func_call.name,
                        ),
                    )

        return (
            func_call,
            FunctionExecutionResult(
                content=f"Error: tool '{func_call.name}' not found in any workbench",
                call_id=func_call.id,
                is_error=True,
                name=func_call.name,
            ),
        )
