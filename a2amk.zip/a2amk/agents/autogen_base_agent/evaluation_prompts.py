

evaluation_prompt = """
You are an expert evaluator tasked with assessing two metrics for a Large Language Model (LLM):
1. Tool Selection Accuracy 
2. ArgumentCorrectnessMetric

## Evaluation Context:

**Original Query:** 
{}

**LLM Response:** 
{}
The LLM Response can be in a markdown format.

**Tools Called by LLM:** 
{}

**Available Tools:** 
{}

## Evaluation Instructions:

### METRIC 1: Tool Selection Accuracy
1. **Analyze Query Requirements**: Determine what tools would be most appropriate for the request.
2. **Assess Tool Appropriateness**: For each tool called, evaluate if it was necessary and contextually appropriate.
3. **Calculate Tool Selection Score**: 
   - Count correctly/appropriately called tools
   - Formula: Tool_Selection_Score = (Correct Tool Calls) / (Total Tool Calls)
   - If no tools called but needed: score = 0.0
   - If no tools called and none needed: score = 1.0

### METRIC 2: ArgumentCorrectnessMetric  
1. **Analyze Parameter Correctness**: For each tool call, check if ALL input parameters are correct.
2. **Assess Each Parameter Set**: Evaluate if:
   - All required parameters are present
   - Parameters have correct data types and formats
   - Parameter values are contextually appropriate
3. **Calculate Argument Correctness Score**:
   - Count tool calls with completely correct parameter sets
   - Formula: Argument_Correctness_Score = (Tool Calls with Correct Parameters) / (Total Tool Calls)
   - If no tools called: score = 1.0

## Output Format:

You must output EXACTLY a JSON object with two float values, representing:
"tool_selection_score": <float_value>,
"argument_correctness_score": <float_value>

**Examples:**
- "tool_selection_score": 1.0, "argument_correctness_score": 1.0 (perfect tool selection and perfect parameters)
- "tool_selection_score": 0.75, "argument_correctness_score": 1.0 (3/4 tools correct, all parameters correct)
- "tool_selection_score": 1.0, "argument_correctness_score": 0.5 (all tools correct, half had correct parameters)
- "tool_selection_score": 0.0, "argument_correctness_score": 0.0 (no correct tools, no correct parameters)

**Important:** Output ONLY the JSON object with the two scores. No explanation, text, or additional formatting.

Do not include ```json or any other markdown formatting in your final output.
Begin your evaluation now.
"""