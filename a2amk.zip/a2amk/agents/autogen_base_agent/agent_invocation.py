import os, asyncio
import traceback
import httpcore
from httpx import HTTPStatusError
from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent, AgentInputMessage
from typing import Optional, List, Sequence, Dict
from pydantic import BaseModel
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage,)
from autogen_core.model_context import ChatCompletionContext, BufferedChatCompletionContext
from autogen_core.tools import FunctionTool, Tool
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
from autogen_core import AgentRuntime, AgentId
import json
from agents_logger import logger
from agents.mcp_trust import apply_mcp_http_trust_from_env
from dotenv import load_dotenv
load_dotenv()
import yaml
from agents.autogen_base_agent.config_loader import get_selected_config_name, load_agent_config

class agent_invocation:
    def __init__(self, 
                 agent_name:str,
                 agent_description:str,
                 model_client: ChatCompletionClient,
                #  runtime: AgentRuntime,
                 agent_type: str,
                 markdown_summary: bool,
                 system_message: Optional[List[SystemMessage]] = None,
                 model_context: Optional[ChatCompletionContext] = None,
                 tools: Optional[List[Tool]] = None,
                 # Use this parameter to directly provide MCP server parameters.
                 mcp_params: Optional[StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]] = None,
                 # Use this parameter to read MCP server parameters from kubernetes manifest file environment variable for each agent.
                 # This is the name of the environment variable name that contains the MCP server configuration in JSON format.
                 agent_name_in_yaml_config: Optional[str] = None,
                 ):

        # If provided, apply a custom CA/trust bundle for all outbound HTTP(S) clients.
        # This supports MCP HTTP connections where autogen-ext does not currently expose `verify=`.
        apply_mcp_http_trust_from_env()
        
        self.agent_name = agent_name
        self.agent_description = agent_description
        self.model_client = model_client
        self.system_message = system_message
        self.model_context = model_context
        self.tools = tools
        # self.runtime = runtime
        self.agent_type = agent_type
        self.agent_name_in_yaml_config = agent_name_in_yaml_config        
        # Runtime pooling: Reuse runtime instead of creating fresh ones
        self._shared_runtime: Optional[AgentRuntime] = None
        self._runtime_lock = asyncio.Lock()
        self._runtime_started = False
        self._markdown_summary = markdown_summary
        
        if mcp_params and agent_name_in_yaml_config:
            raise ValueError("Provide either mcp_params or agent_name_in_yaml_config, not both.")
        if mcp_params:
            self.mcp_params = mcp_params
        elif self.agent_name_in_yaml_config:
            self.mcp_params = self.get_mcp_params()
        else:
            self.mcp_params = None

    def get_mcp_params(self):
        """
        Read MCP server parameters from config.yaml file.
        If not set, reads from kubernetes configMap environment variable.
        Falls back to default localhost configuration if not set
        """
        mcp_servers = None

        # Optional: prefer configs/<name>.yaml if selected via AGENT_CONFIG_NAME/AGENT_CONFIG.
        selected_cfg_name = get_selected_config_name()
        if selected_cfg_name:
            try:
                agent_cfg = load_agent_config(selected_cfg_name)
                details = agent_cfg.get("details") or {}
                mcp_servers = details.get("mcp_servers")
            except FileNotFoundError as e:
                logger.error(str(e))
                raise
            except Exception as e:
                logger.error(f"Error reading MCP server configuration from configs/{selected_cfg_name}.yaml: {e}")
                raise

        if not mcp_servers:
            try:
                config_yaml_str = os.getenv("APP_CONFIG_YAML")
                config = yaml.safe_load(config_yaml_str)
                mcp_servers = config.get("agents", {}).get(self.agent_name_in_yaml_config)["mcp_servers"]
            except Exception as e:
                logger.error(f"Error reading MCP server configuration for {self.agent_name_in_yaml_config} from k8s environment variable: {e}")
        
        if not mcp_servers:
            try:
                with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
                    config = yaml.safe_load(file)
                    mcp_servers = config.get("agents", {}).get(self.agent_name_in_yaml_config)["mcp_servers"]
            except FileNotFoundError:
                logger.error("config.yaml file not found.")
            except Exception as e:
                logger.error(f"Error reading config.yaml: {e}")
        
        if mcp_servers:
            try:
                def _resolve_url(server_cfg: dict) -> str:
                    # Support both legacy `url` and new `mcp_host` + `mcp_path`.
                    if server_cfg.get("url"):
                        return str(server_cfg["url"]).strip()
                    host = server_cfg.get("mcp_host")
                    path = server_cfg.get("mcp_path")
                    if host and path:
                        return f"{str(host).rstrip('/')}/{str(path).lstrip('/')}"
                    raise KeyError("Missing MCP endpoint; expected 'url' or ('mcp_host' and 'mcp_path')")

                # Parse JSON configuration from environment
                if not isinstance(mcp_servers, list):
                    mcp_servers = json.loads(mcp_servers)
                
                mcp_list = []
                
                for config in mcp_servers:
                    server_type = config.get('type', 'http').lower()
                    
                    if server_type in ['http', 'streamablehttp']:
                        # Only pass recognized, non-None kwargs to avoid creating
                        # StreamableHttpServerParams with explicit None values.
                        kwargs = {'url': _resolve_url(config)}
                        if config.get('headers') is not None:
                            kwargs['headers'] = config['headers']
                        if config.get('timeout') is not None:
                            kwargs['timeout'] = config['timeout']
                        if config.get('sse_read_timeout') is not None:
                            kwargs['sse_read_timeout'] = config['sse_read_timeout']
                        if config.get('terminate_on_close') is not None:
                            kwargs['terminate_on_close'] = config['terminate_on_close']
                        mcp_list.append(StreamableHttpServerParams(**kwargs))
                    elif server_type == 'sse':
                        mcp_list.append(SseServerParams(url=_resolve_url(config)))
                    elif server_type == 'stdio':
                        mcp_list.append(StdioServerParams(
                            command=config['command'],
                            args=config.get('args', []),
                            env=config.get('env', {})
                        ))
                logger.info(f"Created MCP Server Params list for agent {self.agent_name}")
                return mcp_list if mcp_list else None
            except (json.JSONDecodeError, KeyError) as e:
                logger.error(f"Error parsing MCP_SERVERS environment variable: {e}")
                return None
        logger.error(f"No MCP server configuration found for {self.agent_name_in_yaml_config}. Please check your k8s environment variables or config.yaml.")
        return None

    async def check_mcp_health(self):
        if self.mcp_params is None:
            logger.warning(f"No MCP server parameters configured for agent {self.agent_name}. Skipping health check.")
            return True
        
        def _flatten_exceptions(exc: BaseException):
            # Python 3.11+: ExceptionGroup can nest; flatten for readable logging.
            if isinstance(exc, ExceptionGroup):
                for sub in exc.exceptions:
                    yield from _flatten_exceptions(sub)
            else:
                yield exc

        for mcp_param in self.mcp_params:
            # Prefer probing via McpWorkbench(list_tools) instead of mcp_server_tools().
            # Some autogen-ext versions validate server params differently in mcp_server_tools,
            # which can raise errors like: "Unsupported or missing type `None` in union".
            workbench = McpWorkbench(mcp_param)
            try:
                if hasattr(workbench, "start"):
                    await workbench.start()
                tools = await workbench.list_tools()
                if isinstance(tools, list) and len(tools) > 0:
                    logger.info(f"MCP server {mcp_param} is healthy for agent {self.agent_name} (tools={len(tools)}).")
                else:
                    logger.error(f"MCP server {mcp_param} is NOT healthy for agent {self.agent_name} (no tools returned).")
                    return False
            except ExceptionGroup as e:
                # Catch ExceptionGroup (Python 3.11+) - common for anyio/asyncio task groups
                # Handle all exceptions within the group
                for exc in _flatten_exceptions(e):
                    if isinstance(exc, HTTPStatusError):
                        status_code = exc.response.status_code
                        logger.error(f"MCP server {mcp_param} returned HTTP {status_code} for agent {self.agent_name}.")
                        if status_code == 503:
                            logger.error(f"503 Service Unavailable: The service may be down, restarting, or under maintenance.")
                        elif status_code == 502:
                            logger.error(f"502 Bad Gateway: Check if the upstream server is accessible.")
                        elif status_code == 504:
                            logger.error(f"504 Gateway Timeout: The upstream server is too slow to respond.")
                        elif status_code == 401:
                            logger.error(f"401 Unauthorized: Check authentication credentials.")
                        elif status_code == 403:
                            logger.error(f"403 Forbidden: Check authorization permissions.")
                        elif status_code == 500:
                            logger.error(f"500 Internal Server Error: The server encountered an error.")
                        elif status_code == 404:
                            logger.error(f"404 Not Found: The MCP endpoint does not exist.")
                        elif status_code == 429:
                            logger.error(f"429 Too Many Requests: Rate limit exceeded.")
                    elif isinstance(exc, TimeoutError):
                        logger.error(f"Timeout error for MCP server {mcp_param} for agent {self.agent_name}: {exc}")
                        logger.error(f"Consider increasing the timeout value or checking server responsiveness.")
                    elif isinstance(exc, ConnectionError):
                        logger.error(f"Connection error to MCP server {mcp_param} for agent {self.agent_name}: {exc}")
                        logger.error(f"Please verify: 1) Network connectivity, 2) Server is running, 3) Firewall rules, 4) DNS resolution")
                    elif isinstance(exc, OSError):
                        error_msg = str(exc)
                        if "timeout" in error_msg.lower():
                            logger.error(f"Connection timeout to MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                        elif "refused" in error_msg.lower():
                            logger.error(f"Connection refused by MCP server {mcp_param} for agent {self.agent_name}. Is the server running?")
                        elif "name resolution" in error_msg.lower() or "getaddrinfo" in error_msg.lower():
                            logger.error(f"DNS resolution failed for MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                        else:
                            logger.error(f"OS error connecting to MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                    else:
                        # Handle any other exception type
                        logger.error(f"Exception in MCP health check for agent {self.agent_name}: {type(exc).__name__}: {exc}")
                
                # After logging all exceptions, return False to indicate health check failed
                logger.error(f"MCP server health check failed for {mcp_param} due to exceptions listed above.")
                return False
            except ConnectionError as e:
                # Network connection errors
                logger.error(f"Network connection error to MCP server {mcp_param} for agent {self.agent_name}: {str(e)}")
                logger.error(f"Please verify: 1) Network connectivity, 2) Server is running, 3) Firewall rules, 4) DNS resolution")
                return False
            except OSError as e:
                # OS-level errors (socket errors, DNS failures, etc.)
                error_msg = str(e)
                if "timeout" in error_msg.lower():
                    logger.error(f"Connection timeout to MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                elif "refused" in error_msg.lower():
                    logger.error(f"Connection refused by MCP server {mcp_param} for agent {self.agent_name}. Is the server running?")
                elif "name resolution" in error_msg.lower() or "getaddrinfo" in error_msg.lower():
                    logger.error(f"DNS resolution failed for MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                else:
                    logger.error(f"OS error connecting to MCP server {mcp_param} for agent {self.agent_name}: {error_msg}")
                return False
            except TimeoutError as e:
                # Explicit timeout errors
                logger.error(f"Timeout connecting to MCP server {mcp_param} for agent {self.agent_name}: {str(e)}")
                logger.error(f"Consider increasing the timeout value or checking server responsiveness")
                return False
            except Exception as e:
                # Catch-all for any other unexpected errors
                logger.error(f"Unexpected error checking MCP server {mcp_param} for agent {self.agent_name}: {type(e).__name__}: {str(e)}")
                logger.debug(f"Full traceback: {traceback.format_exc()}")
                return False
            finally:
                try:
                    if hasattr(workbench, "stop"):
                        await workbench.stop()
                    else:
                        await workbench.__aexit__(None, None, None)
                except Exception:
                    pass
        return True

    async def simple_agent_factory(self):

        logger.info(f"Creating AutogenCoreAgent instance for agent {self.agent_name}")
        
        # Create a fresh model context for each agent instance to prevent state pollution
        # If the original context was provided, create a new instance of the same type
        fresh_model_context = None
        if self.model_context is not None:
            # Create a new instance of the same context type
            context_type = type(self.model_context)
            if context_type == BufferedChatCompletionContext:
                fresh_model_context = BufferedChatCompletionContext(buffer_size=5, initial_messages=[])
            else:
                fresh_model_context = context_type()
            logger.info(f"Created fresh {context_type.__name__} for agent instance")
        
        return AutogenCoreAgent(
                agent_name=self.agent_name,
                agent_description = self.agent_description,
                system_message=self.system_message,
                model_client=self.model_client,
                model_context=fresh_model_context,
                mcp_server_params=self.mcp_params,
                tools=self.tools,
                markdown_summary=self._markdown_summary
            )

    async def get_or_create_runtime(self) -> AgentRuntime:
        """
        Get or create a shared runtime instance (runtime pooling).
        This method implements a singleton pattern to reuse the same runtime
        across multiple requests, significantly reducing initialization overhead.
        
        Returns:
            AgentRuntime: Shared runtime instance
        """
        if self._shared_runtime is None:
            async with self._runtime_lock:
                # Double-check pattern to prevent race conditions
                if self._shared_runtime is None:
                    logger.info(f"Creating shared runtime for agent {self.agent_name}")
                    from autogen_core import SingleThreadedAgentRuntime
                    self._shared_runtime = SingleThreadedAgentRuntime()
                    
                    # Register the agent in the runtime
                    await AutogenCoreAgent.register(
                        self._shared_runtime, 
                        self.agent_type, 
                        self.simple_agent_factory
                    )
                    
                    # Start the runtime
                    self._shared_runtime.start()
                    self._runtime_started = True
                    logger.info(f"Shared runtime started for agent {self.agent_name}")
        
        return self._shared_runtime

    async def create_runtime(self) -> AgentRuntime:
        """
        Legacy method: Creates a fresh runtime for each request.
        
        DEPRECATED: Use get_or_create_runtime() instead for better performance.
        This method is kept for backward compatibility but creates unnecessary overhead.
        
        Returns:
            AgentRuntime: Fresh runtime instance
        """
        logger.warning(f"Using deprecated create_runtime() for agent {self.agent_name}. Consider using get_or_create_runtime() instead.")
        logger.info(f"Creating runtime for agent {self.agent_name}")
        # Create a fresh runtime instance for each request to avoid agent type conflicts
        from autogen_core import SingleThreadedAgentRuntime
        fresh_runtime = SingleThreadedAgentRuntime()
        
        # Register the agent in this new runtime
        await AutogenCoreAgent.register(fresh_runtime, self.agent_type, self.simple_agent_factory)
        return fresh_runtime

    async def invoke_agent(self, user_message: str,
                                ag_runtime: Optional[AgentRuntime] = None,
                                source: str = "user",
                                context_id: Optional[str] = None,
                                task_id: Optional[str] = None,
                                ) -> BaseModel|str|Dict:
        """
        Invoke the agent with a user message.
        
        Args:
            ag_runtime: Optional runtime to use. If None, uses shared runtime (recommended).
            user_message: Message to send to the agent.
            source: Source of the message.
            context_id: Optional context identifier.
            task_id: Optional task identifier.
            
        Returns:
            Agent response (parsed JSON or string)
            
        Usage:
            # Recommended: Use shared runtime (automatic)
            response = await agent.invoke_agent(user_message="Hello")
            
            # Legacy: Use custom runtime
            runtime = await agent.create_runtime()
            response = await agent.invoke_agent(ag_runtime=runtime, user_message="Hello")
        """
        try:
            # Determine which runtime to use
            if ag_runtime is None:
                # Use shared runtime pool (recommended for performance)
                logger.debug(f"Using shared runtime for agent {self.agent_name}")
                runtime_to_use = await self.get_or_create_runtime()
            else:
                # Use provided runtime (for backward compatibility or custom scenarios)
                logger.debug(f"Using provided runtime for agent {self.agent_name}")
                runtime_to_use = ag_runtime
            
            # Start the runtime if not already started
            # The runtime can handle multiple concurrent messages
            try:
                runtime_to_use.start()
            except RuntimeError as e:
                # Runtime is already started, which is fine for concurrent requests
                if "already started" not in str(e):
                    raise
            
            agent_id = AgentId(self.agent_type, "default")
            logger.info(f"Sending message to agent {self.agent_name}...")
            final_response = await runtime_to_use.send_message(
                AgentInputMessage(request = user_message, source = source, context_id = context_id, task_id = task_id), 
                recipient = agent_id
                )
            
            # DO NOT stop the runtime here - it needs to stay running for concurrent requests
            # The runtime will be stopped when the server/executor is shut down
            # await runtime_to_use.stop_when_idle()

            final_response  = json.loads(final_response)

            # logger.info("Final Response from the agent:")
            # logger.info(final_response)

            return final_response
        except Exception as e:
            logger.error(f"Error invoking agent {self.agent_name}: {traceback.format_exc()}")
            raise e
    
    async def shutdown(self, ag_runtime: AgentRuntime = None):
        """
        Gracefully shutdown the agent runtime.
        Should be called when the agent executor is being shut down.
        
        Args:
            ag_runtime: Optional runtime to shutdown. If None, shuts down the shared runtime.
        """
        try:
            runtime_to_shutdown = ag_runtime or self._shared_runtime
            if runtime_to_shutdown is None:
                logger.warning(f"No runtime to shutdown for agent {self.agent_name}")
                return
            
            logger.info(f"Shutting down runtime for agent {self.agent_name}")
            await runtime_to_shutdown.stop_when_idle()
            
            # Clear shared runtime if it was shutdown
            if runtime_to_shutdown is self._shared_runtime:
                async with self._runtime_lock:
                    self._shared_runtime = None
                    self._runtime_started = False
            
            logger.info(f"Runtime stopped successfully for agent {self.agent_name}")
        except Exception as e:
            logger.error(f"Error shutting down runtime for agent {self.agent_name}: {e}")

    async def get_tool_descriptions(self, include_tool_schema = False, include_tool_params = True):
        """
        Get descriptions of all tools available to the agent.
        """
        try:
            tool_descriptions = """"""
            if self.tools:
                logger.info(f"Agent {self.agent_name} has {len(self.tools)} predefined tools.")
                for tool in self.tools:
                    description = tool.get('description', '')
                    description = description.replace("\n\n","")
                    # if description != '' and "Args:" in description:
                    #     desc, args_returns = description.split("Args:")  # Remove Args section for brevity
                    # elif description != '' and "Args:" not in description:
                    #     desc = description.strip()
                    #     args_returns = None

                    # tool_descriptions += f"{desc.replace('\n', ' ').replace("  ","")}\n"
                    tool_descriptions += f"Tool Name: {tool.get('name', 'N/A')}\n Tool Details:\n{description}\n"
                    if include_tool_schema:
                        tool.pop("description")
                        tool_descriptions += f"Tool Schema:\n{tool}\n"
                        if args_returns:
                            tool_descriptions += f"Args:{args_returns.replace('  ', '').replace("\n\n","\n")}\n\n"
                        else:
                            tool_descriptions += "\n"
            
            
            workbenches = []
            if self.mcp_params is None:
                logger.info(f"No MCP server parameters configured for agent {self.agent_name}. Skipping MCP tool description fetch.")
                return tool_descriptions

            if isinstance(self.mcp_params, Sequence):
                for params in self.mcp_params:
                    workbench = McpWorkbench(params)
                    workbenches.append(workbench)
            else:
                workbench = McpWorkbench(self.mcp_params)
                workbenches.append(workbench)
            
            if isinstance(workbenches, Sequence):
                tools = []
                for bench in workbenches:
                    try:
                        # Start immediately; calling list_tools right away ensures
                        # session initialization failures propagate with useful error details.
                        await bench.start()
                        wb_tools = await bench.list_tools()
                        tools.extend(wb_tools)
                    except RuntimeError as e:
                        # If the MCP actor crashed during initialization, autogen-ext can leave
                        # a workbench with an inactive actor attached. Reset and retry once.
                        if "MCP Actor not running" in str(e):
                            try:
                                await bench.stop()
                            except Exception:
                                pass
                            try:
                                await bench.start()
                                wb_tools = await bench.list_tools()
                                tools.extend(wb_tools)
                                continue
                            except Exception as retry_exc:
                                logger.error(f"Error fetching tools from workbench {bench} after retry: {retry_exc}")
                                logger.error(traceback.format_exc())
                                continue
                        logger.error(f"Error fetching tools from workbench {bench}: {e}")
                        logger.error(traceback.format_exc())
                        continue
                    except Exception as e:
                        logger.error(f"Error fetching tools from workbench {bench}: {e}")
                        logger.error(traceback.format_exc())
                        continue
            logger.info(f"Fetched {len(tools)} tools from MCP workbenches for agent {self.agent_name}")
            if tools:
                for tool in tools:
                    description = tool.get('description', '')
                    description = description.replace("\n\n","\n").replace("\t","")
                    # if description != '' and "Args" in description:
                    #     desc, args_returns = description.split("Args:")  # Remove Args section for brevity 
                    # elif description != '' and "Args" not in description:
                    #     desc = description.strip()
                    #     args_returns = None

                    # tool_descriptions += f"Tool Name: {tool.get('name', 'N/A')} - {desc.replace("\n", "").replace("  ","")}\n"
                    tool_descriptions += f"Tool Name: {tool.get('name', 'N/A')}\nTool Details:\n{description}"

                    if include_tool_params:
                        if tool["parameters"]:
                            params = list(tool["parameters"]["properties"].keys()) if "properties" in tool["parameters"] else []
                            tool_descriptions += f"Tool Parameters:\n {params}\n\n"

                    if include_tool_schema:
                        tool.pop("description")
                        tool_descriptions += f"Tool Schema:\n{tool}\n"
                        if args_returns:
                            tool_descriptions += f"Args:{args_returns.replace('  ', '').replace("\n\n","\n")}\n\n"
                        else:
                            tool_descriptions += "\n"
                    
            return tool_descriptions
        except Exception as e:
            logger.error(f"Error getting tool descriptions for agent {self.agent_name}: {traceback.format_exc()}")
            raise e 
    
    

