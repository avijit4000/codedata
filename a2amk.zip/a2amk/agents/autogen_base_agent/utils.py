from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import ChatCompletionClient
import httpx
import yaml
import os
import ssl
from dotenv import load_dotenv
load_dotenv()
from agents_logger import logger
from agents.autogen_base_agent.config_loader import (
    get_selected_config_name,
    load_agent_config,
)

from agents.mcp_trust import apply_mcp_http_trust_from_env


AZURE_OPENAI_HTTP_VERIFY_ENV_VAR = "AZURE_OPENAI_HTTP_VERIFY"
AZURE_OPENAI_HTTP_DEBUG_ENV_VAR = "AZURE_OPENAI_HTTP_DEBUG"


def create_azure_openai_http_client() -> httpx.AsyncClient | None:
    """Create an httpx client for Azure OpenAI with explicit TLS verification.

    We intentionally do NOT use MCP_HTTP_VERIFY for Azure OpenAI.
    MCP_HTTP_VERIFY is meant for private MCP endpoints and may contain a narrow
    CA bundle that should not be applied to public Azure endpoints.

    Behavior:
    - If AZURE_OPENAI_HTTP_VERIFY is set to "truststore"/"system"/"os", use the
      OS trust store via truststore.
    - If AZURE_OPENAI_HTTP_VERIFY is set to a PEM path, use that bundle (opt-in).
    - If unset, use a clean default trust context based on Certifi (when available)
      to avoid inheriting any process-wide SSL_CERT_FILE overrides.
    """

    verify_path = os.getenv(AZURE_OPENAI_HTTP_VERIFY_ENV_VAR)
    debug_enabled = os.getenv(AZURE_OPENAI_HTTP_DEBUG_ENV_VAR, "false").lower() in {"1", "true", "yes"}

    async def _log_request(request: httpx.Request) -> None:
        logger.info("Azure OpenAI request: %s %s", request.method, request.url)

    async def _log_response(response: httpx.Response) -> None:
        logger.info("Azure OpenAI response: %s %s", response.status_code, response.request.url)

    event_hooks = None
    if debug_enabled:
        event_hooks = {"request": [_log_request], "response": [_log_response]}

    # Special option: use OS trust store.
    if verify_path and verify_path.strip().lower() in {"truststore", "system", "os"}:
        try:
            import truststore  # type: ignore

            ssl_context = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            logger.info("Azure OpenAI TLS verify: OS trust store via truststore")
            return httpx.AsyncClient(verify=ssl_context, event_hooks=event_hooks)
        except Exception as e:
            logger.error(
                "AZURE_OPENAI_HTTP_VERIFY is set to '%s' but truststore is not available (%s). "
                "Install 'truststore' or set AZURE_OPENAI_HTTP_VERIFY to a PEM bundle path.",
                verify_path,
                e,
            )
            return None

    # Default behavior: clean, public roots only (Certifi), ignoring any SSL_CERT_FILE overrides.
    if not verify_path:
        try:
            import certifi  # type: ignore

            cafile = certifi.where()
            ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ssl_context.load_verify_locations(cafile=cafile)
            logger.info("Azure OpenAI TLS verify: certifi CA bundle")
            return httpx.AsyncClient(verify=ssl_context, event_hooks=event_hooks)
        except Exception as e:
            logger.warning(
                "Azure OpenAI TLS verify: falling back to httpx defaults (certifi unavailable: %s)",
                e,
            )
            return httpx.AsyncClient(event_hooks=event_hooks)

    # Opt-in behavior: explicit PEM bundle path.
    resolved_path = os.path.expanduser(verify_path)
    if not os.path.isabs(resolved_path):
        resolved_path = os.path.abspath(resolved_path)

    if not os.path.exists(resolved_path):
        logger.error(
            f"{AZURE_OPENAI_HTTP_VERIFY_ENV_VAR} is set to '{verify_path}', but file does not exist at '{resolved_path}'. "
            "Proceeding without an explicit http_client override."
        )
        return None

    logger.info("Azure OpenAI TLS verify bundle (explicit): %s", resolved_path)
    return httpx.AsyncClient(verify=resolved_path, event_hooks=event_hooks)


def create_model_client(agent_name_in_yaml_config:str,
                        llm_response_structure = None,
                        ) -> ChatCompletionClient:
    model_params = None
    model_name = None

    # Optional: allow selecting an agent config from configs/<name>.yaml
    # by setting AGENT_CONFIG_NAME (or AGENT_CONFIG). If set, this becomes
    # the primary source of the model selection for the agent.
    selected_cfg_name = get_selected_config_name()
    if selected_cfg_name:
        try:
            agent_cfg = load_agent_config(selected_cfg_name)
            model_name = (
                (agent_cfg.get("details") or {}).get("llm_model")
                or agent_cfg.get("llm_model")
                or os.getenv("LLM_MODEL")
            )
            if not model_name:
                raise ValueError(
                    f"Config '{selected_cfg_name}' is missing details.llm_model"
                )
        except FileNotFoundError as e:
            # Required behavior: if a config name is provided but file is missing,
            # log and stop loading.
            logger.error(str(e))
            raise
        except Exception as e:
            logger.error(f"Error reading model selection from configs/{selected_cfg_name}.yaml: {e}")
            raise

    try:
        config_yaml_str = os.getenv("APP_CONFIG_YAML")
        config = yaml.safe_load(config_yaml_str)
        if not model_name:
            model_name = config.get("agents", {}).get(agent_name_in_yaml_config, {}).get("llm_model")
            model_params = config.get("llm_model", {}).get(model_name)
        if model_name:
            model_params = config.get("llm_models", {}).get(model_name)
    except Exception as e:
        logger.error(f"Error reading model configuration for {agent_name_in_yaml_config} from k8s environment variable: {e}")

    if not model_params:
        logger.info(f"Falling back to config.yaml.")
        try:
            with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
                config = yaml.safe_load(file)
                if not model_name:
                    model_name = config.get("agents", {}).get(agent_name_in_yaml_config, {}).get("llm_model")
                    model_params = config.get("llm_model", {}).get(model_name)
                if model_name:
                    model_params = config.get("llm_models", {}).get(model_name)
        except FileNotFoundError:
            logger.error("config.yaml file not found.")
            raise 
        except Exception as e:
            logger.error(f"Error reading config.yaml: {e}")

    if not model_params:
        logger.error(
            f"No llm model configuration found for agent '{agent_name_in_yaml_config}' (model='{model_name}'). "
            "Please check your configs/<name>.yaml selection, APP_CONFIG_YAML, or config.yaml."
        )
        raise ValueError(f"No configuration found for {agent_name_in_yaml_config}.")

    # Apply TLS trust bundle BEFORE creating any outbound HTTP clients.
    # Note: many agents create the model client at import time, so this must happen here.
    apply_mcp_http_trust_from_env()
    azure_http_client = create_azure_openai_http_client()

    llm_model_client = AzureOpenAIChatCompletionClient(
        model=model_params.get("model_name"),
        azure_endpoint=model_params.get("azure_endpoint"),
        azure_deployment=model_params.get("azure_deployment"),
        api_version=model_params.get("api_version"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        http_client=azure_http_client,
        response_format=llm_response_structure,
    )
    return llm_model_client

def get_model_params(model_name:str):
    model_params = None

    # Optional: allow configs/<name>.yaml to define llm_models directly.
    selected_cfg_name = get_selected_config_name()
    if selected_cfg_name:
        try:
            agent_cfg = load_agent_config(selected_cfg_name)
            cfg_llm_models = agent_cfg.get("llm_models") or (agent_cfg.get("details") or {}).get("llm_model")
            if isinstance(cfg_llm_models, dict):
                model_params = cfg_llm_models.get(model_name)
                if model_params:
                    return model_params
        except FileNotFoundError as e:
            logger.error(str(e))
            raise
        except Exception as e:
            logger.error(f"Error reading llm_models from configs/{selected_cfg_name}.yaml: {e}")
            raise

    try:
        config_yaml_str = os.getenv("APP_CONFIG_YAML")
        config = yaml.safe_load(config_yaml_str)
        model_params = config.get("llm_models", {}).get(model_name)
        return model_params
    except Exception as e:
        logger.error(f"Error reading model parameters from environment variable: {e}")
    
    if not model_params:
        logger.info(f"No configuration found for model {model_name} in environment variable. Falling back to config.yaml.")
        try:
            with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
                config = yaml.safe_load(file)
                model_params = config.get("llm_models").get(model_name)
                return model_params
        except FileNotFoundError:
            logger.warning("config.yaml file not found.")
            raise
        except Exception as e:
            logger.error(f"Error reading config.yaml: {e}")
            raise

def get_config_data(agent_name_in_yaml_config):

    agent_config_data = None
    try:
        config_yaml_str = os.getenv("APP_CONFIG_YAML")
        config = yaml.safe_load(config_yaml_str)
        config_keys = config.keys()
        agent_config_data = config.get("agents", {}).get(agent_name_in_yaml_config)
        for data in agent_config_data:
            if data in config_keys:
                agent_config_data[data] = config.get(data).get(agent_config_data[data])
            elif data == "embedding_model":
                agent_config_data[data] = config.get("llm_model", {}).get(agent_config_data[data])
                
        return agent_config_data
    except Exception as e:
        logger.error(f"Error reading agent configuration for {agent_name_in_yaml_config} from k8s environment variable: {e}")
    
    if not agent_config_data:
        logger.info(f"Falling back to config.yaml.")
        try:
            with open(os.path.join(os.getcwd(), "config.yaml"), "r") as file:
                config = yaml.safe_load(file)
                config_keys = config.keys()
                agent_config_data = config.get("agents", {}).get(agent_name_in_yaml_config)
                for data in agent_config_data:
                    if data in config_keys:
                        agent_config_data[data] = config.get(data).get(agent_config_data[data])
                    elif data == "embedding_model":
                        agent_config_data[data] = config.get("llm_models", {}).get(agent_config_data[data])
                    
                return agent_config_data
        except FileNotFoundError:
            logger.error("config.yaml file not found.")
            raise 
        except Exception as e:
            logger.error(f"Error reading config.yaml: {e}")


