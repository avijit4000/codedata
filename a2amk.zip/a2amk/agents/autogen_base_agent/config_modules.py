import os
import json

def get_agent_name_base(AGENT_NAME):
    agent_name = AGENT_NAME.lower().replace(" ", "_")
    return agent_name if '_agent' not in agent_name else agent_name.replace('_agent', '')

class AgentSkillConfig:
    def __init__(self, agent_name: str, agent_skill_id: str|None=None, agent_skill_name: str|None=None, agent_skill_tags: list|None=None, agent_skill_examples: list|None=None):
        self.agent_name = get_agent_name_base(agent_name)
        self.agent_skill_id = agent_skill_id if agent_skill_id else f"{self.agent_name}_skill"
        self.agent_skill_name = agent_skill_name if agent_skill_name else f"{self.agent_name.capitalize()} Skill"

        def _coerce_list(value):
            if value is None:
                return []
            if isinstance(value, list):
                return value
            if isinstance(value, str):
                raw = value.strip()
                if raw == "":
                    return []
                # Common case: env var contains JSON list string.
                if raw.startswith("[") and raw.endswith("]"):
                    try:
                        parsed = json.loads(raw)
                        return parsed if isinstance(parsed, list) else []
                    except Exception:
                        return []
                # Fallback: treat as a single tag/example.
                return [raw]
            return []

        self.agent_skill_tags = _coerce_list(agent_skill_tags)
        self.agent_skill_examples = _coerce_list(agent_skill_examples)

class AgentCardConfig:
    def __init__(self, agent_name: str, agent_card_url: str|None=None, agent_type: str|None=None, agent_version: str="1.0.0"):
        if os.getenv("AGENT_URL", agent_card_url) and not agent_card_url:
            print(f"Warning: AGENT_URL environment variable is set to {os.getenv('AGENT_URL')}, which will override the agent_card_url parameter passed to AgentCardConfig. If this is not intended, please unset the AGENT_URL environment variable.")
        elif not os.getenv("AGENT_URL", agent_card_url):
            print("Warning: AGENT_URL environment variable is not set and no agent_card_url parameter was passed to AgentCardConfig. The agent URL will default to http://{HOST}:{PORT}/ based on the HOST and PORT environment variables or their defaults.")

        self.agent_card_url = os.getenv("AGENT_URL", agent_card_url)
        self.agent_name = get_agent_name_base(agent_name) + "_agent"
        self.agent_type = agent_type if agent_type else self.agent_name
        self.agent_version = agent_version

class AgentBaseConfig:
    def __init__(self, agent_name: str, host: str, port: int, agent_description: str, azure_agent_prompt: str, agent_skill_configs: list[AgentSkillConfig], agent_card_config: AgentCardConfig, agent_type: str|None=None, agent_name_in_yaml_config: str|None=None):
        self.agent_display_name = agent_name
        self.agent_name = get_agent_name_base(agent_name) + "_agent"
        self.agent_type = agent_type if agent_type else self.agent_name
        self.HOST = host
        self.PORT = port
        self.agent_description = agent_description
        self.agent_name_in_yaml_config = agent_name_in_yaml_config if agent_name_in_yaml_config else self.agent_name
        self.azure_agent_prompt = azure_agent_prompt

        self.agent_skill_configs = agent_skill_configs
        self.agent_card_config = agent_card_config
