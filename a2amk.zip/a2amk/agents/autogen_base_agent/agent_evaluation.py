# from deepeval import evaluate
# from deepeval.test_case import LLMTestCase, ToolCall
# from deepeval.metrics import ToolCorrectnessMetric, AnswerRelevancyMetric, FaithfulnessMetric
from agents.autogen_base_agent.evaluation_prompts import *
from typing import Dict, List
import dotenv
import os, json, yaml
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import SystemMessage, UserMessage
import litellm
from ragas.llms import llm_factory
from ragas.embeddings.base import embedding_factory
from ragas.metrics.collections import AnswerRelevancy, Faithfulness
from agents_logger import logger
from agents.autogen_base_agent.utils import create_model_client, get_model_params
dotenv.load_dotenv()


        
class EvaluationMetrics:

    def __init__(self):
        self.llm_model_client = create_model_client("agent_evaluation")
        model_params = get_model_params("gpt41_mini")
        embed_model_params = get_model_params("embedding")

        litellm.api_base = model_params.get("azure_endpoint")
        litellm.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        litellm.api_version = model_params.get("api_version")
        litellm.drop_params=True

        self.azure_llm = llm_factory(f"azure/{model_params.get("azure_deployment")}",
                                provider="litellm",
                                client=litellm.acompletion)
        
        self.azure_embeddings  = embedding_factory(
            "litellm",
            model=f"azure/{embed_model_params.get("azure_deployment")}",
            api_base= embed_model_params.get("azure_endpoint"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=embed_model_params.get("api_version")
        )

    # async def deepeval_tool_correctness(self, query: str,
    #                      llm_response: str, 
    #                      expected_tool_calls: list[ToolCall],
    #                      tools_called: list[ToolCall],
    #                      available_tools: list[ToolCall]
    #                      ) -> float:
    #     """
    #     Evaluate whether the LLM called the appropriate tool for the query.

    #     Args:
    #         query (str): The input query to the LLM.
    #         llm_response (str): The response from the LLM.
    #         expected_tool_calls (list[ToolCall]): The expected tool calls.
    #         tools_called (list[ToolCall]): The actual tool calls made by the LLM.
    #         available_tools (list[ToolCall]): The list of available tools.
    #     Returns:
    #         float: The tool correctness score.
    #     """
    #     test_case = LLMTestCase(
    #         input=query,
    #         actual_output=llm_response,
    #         tools_called=tools_called,
    #         expected_tools=expected_tool_calls,
    #         available_tools=available_tools
    #         )
    #     metric = ToolCorrectnessMetric()
    #     score = evaluate(test_cases=[test_case], metrics=[metric])
    #     return score
    
    async def custom_tool_correctness(self, 
                                query: str,
                                llm_response: str,
                                tools_called: List[dict],
                                available_tools: List[dict]
                                ) -> Dict[str, float]:
        """
        Evaluates Tool Selection Accuracy and Argument Correctness Metric.
        Args:
        query (str): The original user query/request
        llm_response (str): The LLM's response to the query
        tools_called (list): List of tools that the LLM actually called with their parameters
        available_tools (list): List of tools available to the LLM.
        
        Returns:
        Dict[str, float]: {"tool_selection_score": float, "argument_correctness_score": float}
        """        
        # Format the evaluation prompt
        formatted_prompt = evaluation_prompt.format(
            query, llm_response, tools_called, available_tools)
        
        # Set response format on the client for this evaluation

        response_format = {
            "type": "json_schema",
            "json_schema": {
            "name": "EvaluationResponse",
            "description": "Tool Selection Accuracy and Argument Correctness Metric",
            # Use the schema directly without the wrapper to ensure consistent format
            "schema": {
                "type": "object",
                "properties": {
                    "tool_selection_score": {
                        "type": "float",
                        "description": "float value between 0.0 and 1.0 representing tool selection accuracy"
                    },
                    "argument_correctness_score": {
                        "type": "float",
                        "description": "float value between 0.0 and 1.0 representing argument correctness"
                    }
                },
                "required": ["tool_selection_score", "argument_correctness_score"],
                "additionalProperties": False
            },
            "strict": True
            }
        }
        
        self.llm_model_client.response_format = response_format
        self.llm_model_client.max_tokens = 75  
        
        # Create messages for the LLM
        messages = [
            SystemMessage(content = "You are an expert LLM evaluation system."),
            UserMessage(content = formatted_prompt, source = "custom_tool_correctness")
        ]
        
        try:
            # Call the LLM (response_format set on client above)
            response = await self.llm_model_client.create(
                messages=messages,
            )
                        
            
            try:
                # Expected JSON format: {"tool_selection_score": 0.75, "argument_correctness_score": 1.0}
                if type(response.content) == str:
                    scores_dict = json.loads(response.content)
                else:
                    scores_dict = response.content
                tool_selection_score = float(scores_dict.get("tool_selection_score", 0.0))
                argument_correctness_score = float(scores_dict.get("argument_correctness_score", 0.0))
            except json.JSONDecodeError:
                # Fallback: try parsing comma-separated format
                response_text = response.content.strip()
                scores = response_text.split(',')
                if len(scores) == 2:
                    tool_selection_score = float(scores[0].strip())
                    argument_correctness_score = float(scores[1].strip())
                else:
                    raise ValueError(f"Invalid response format: {response_text}")
            
            # Validate scores are in valid range
            if not (0.0 <= tool_selection_score <= 1.0):
                raise ValueError(f"Tool selection score out of range: {tool_selection_score}")
            if not (0.0 <= argument_correctness_score <= 1.0):
                raise ValueError(f"Argument correctness score out of range: {argument_correctness_score}")
            
            return {
                "tool_selection_score": tool_selection_score,
                "argument_correctness_score": argument_correctness_score
            }
            
        except Exception as e:
            print(f"Error in custom_tool_correctness evaluation: {e}")
            # Return default scores on error
            return {"tool_selection_score": -1, "argument_correctness_score": -1}
    
    # async def answer_relevancy_score(self, query: str,
    #                      llm_response: str
    #                      ) -> Dict[str, float]:
    #     """
    #     Evaluate the relevancy of the LLM's answer to the query.
    #     Args:
    #         query (str): The input query to the LLM.
    #         llm_response (str): The response from the LLM.
            
    #     Returns: Dict[str, float]: {"answer_relevancy_score": float}
    #     """

    #     try:

    #         metric = AnswerRelevancyMetric(threshold=0.7,
    #                                     model="gpt-4o",
    #                                     include_reason=False
    #                                     )
    #         test_case = LLMTestCase(input=query,
    #                                 actual_output=llm_response)

    #         # To run metric as a standalone
    #         relevancy_score = metric.measure(test_case)
    #         return {"answer_relevancy_score": relevancy_score.score}

    #     except Exception as e:
    #         print(f"Error in answer_relevancy_score evaluation: {e}")
    #         return {"answer_relevancy_score": -1}
    
    # async def faithfullness_score(self, query: str,
    #                      llm_response: str,
    #                      retrieved_context: str
    #                      ) -> Dict[str, float]:
    #     """
    #     Evaluate whether the llm_response factually aligns with the contents of your retrieved_context.
    #     Args:
    #         query (str): The input query to the LLM.
    #         llm_response (str): The response from the LLM.
    #         retrieved_context (str): The context provided to the LLM.
            
    #     Returns: Dict[str, float]: {"faithfulness_score": float}
    #     """

    #     try:

    #         metric = FaithfulnessMetric(threshold=0.7,
    #                                     model="gpt-4o",
    #                                     include_reason=False
    #                                     )
    #         test_case = LLMTestCase(input=query,
    #                                 actual_output=llm_response,
    #                                 retrieval_context=retrieved_context)

    #         # To run metric as a standalone
    #         faithfulness_score = metric.measure(test_case)
    #         return {"faithfulness_score": faithfulness_score.score}

    #     except Exception as e:
    #         print(f"Error in faithfulness_score evaluation: {e}")
    #         return {"faithfulness_score": -1}
    
    async def ragas_answer_relevancy(self,query: str,
                                     llm_response: str,
                                     ) -> Dict[str, float]:
        """
        Evaluate the relevancy of the LLM's answer to the query.
        Args:
            query (str): The input query to the LLM.
            llm_response (str): The response from the LLM.
            
        Returns: Dict[str, float]: {"answer_relevancy_score": float}
        """

        try:
            metric = AnswerRelevancy(llm=self.azure_llm, 
                                     embeddings=self.azure_embeddings
                                     )
            
            result = await metric.ascore(user_input=query,
                                         response=llm_response
                                         )
            return {"answer_relevancy_score": result.value}
            

        except Exception as e:
            logger.error(f"Error in ragas_answer_relevancy evaluation: {e}")
            return {"answer_relevancy_score": -1}


    async def ragas_faithfulness(self, query: str,
                                 llm_response: str,
                                 retrieved_context: list
                                 ) -> Dict[str, float]:
        """
        Evaluate whether the llm_response factually aligns with the contents of the retrieved_context.
        Args:
            query (str): The input query to the LLM.
            llm_response (str): The response from the LLM.
            retrieved_context (str): The context provided to the LLM.
            
        Returns: Dict[str, float]: {"faithfulness_score": float}
        """

        try:
            metric = Faithfulness(llm=self.azure_llm, 
                                  embeddings=self.azure_embeddings
                                  )
            
            result = await metric.ascore(user_input=query,
                                         response=llm_response,
                                         retrieved_contexts=retrieved_context
                                         )
            return {"faithfulness_score": result.value}
            

        except Exception as e:
            logger.error(f"Error in ragas_faithfulness evaluation: {e}")
            return {"faithfulness_score": -1}

evaluation_metrics = EvaluationMetrics()