"""
Simple gRPC Host Manager for Distributed Agent Runtime

This module provides a simple interface to start and manage a gRPC host service
that facilitates communication between distributed agent workers.

The host service acts as a message router and does NOT run any agents itself.
Workers connect to the host and register their agents.

Usage:
    from agents.autogen_base_agent.grpc_host_manager import GrpcHostManager
    
    # Start a host service
    host_manager = GrpcHostManager(address="localhost:50051")
    host_manager.start()
    
    # Keep it running...
    
    # When done
    host_manager.stop()
"""

from autogen_ext.runtimes.grpc import GrpcWorkerAgentRuntimeHost
from agents_logger import logger
from typing import Optional


class GrpcHostManager:
    """
    Manager for gRPC host service that routes messages between agent workers.
    
    The host service does NOT run agents - it only facilitates communication
    between worker runtimes that host the actual agents.
    """
    
    def __init__(self, address: str = "localhost:50051"):
        """
        Initialize the host manager.
        
        Args:
            address: Address to bind the host service to (host:port)
        """
        self.address = address
        self.host: Optional[GrpcWorkerAgentRuntimeHost] = None
        self._is_running = False
    
    def start(self):
        """Start the gRPC host service in the background."""
        if self._is_running:
            logger.warning(f"Host service already running at {self.address}")
            return
        
        logger.info(f"Starting gRPC host service at {self.address}")
        self.host = GrpcWorkerAgentRuntimeHost(address=self.address)
        self.host.start()
        self._is_running = True
        logger.info(f"Host service started and listening at {self.address}")
    
    def stop(self):
        """Stop the gRPC host service."""
        if not self._is_running or self.host is None:
            logger.warning("Host service is not running")
            return
        
        logger.info(f"Stopping gRPC host service at {self.address}")
        self.host.stop()
        self._is_running = False
        logger.info("Host service stopped")
    
    @property
    def is_running(self) -> bool:
        """Check if the host service is currently running."""
        return self._is_running
    
    def __enter__(self):
        """Context manager entry - start the host."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - stop the host."""
        self.stop()
