"""
Distributed Agent Invocation using AutoGen's gRPC-based Distributed Runtime

This module implements agent invocation using AutoGen's distributed agent runtime,
which allows agents to run across process boundaries with a host service
facilitating communication between worker runtimes.

Reference: https://microsoft.github.io/autogen/stable/user-guide/core-user-guide/framework/distributed-agent-runtime.html

Key Components:
- GrpcWorkerAgentRuntimeHost: Maintains connections to worker runtimes and facilitates message delivery
- GrpcWorkerAgentRuntime: Processes application code (agents) and connects to host service
- Distributed message passing using publish/subscribe patterns

Requirements:
    pip install "autogen-ext[grpc]"
"""

import os
import json
import asyncio
import traceback
from typing import Optional, List, Sequence
from pydantic import BaseModel

from autogen_core import (
    DefaultTopicId,
    MessageContext,
    RoutedAgent,
    default_subscription,
    message_handler,
    AgentId
)
from autogen_core.models import (
    ChatCompletionClient,
    SystemMessage,
)
from autogen_core.model_context import ChatCompletionContext
from autogen_core.tools import FunctionTool, Tool
from autogen_ext.tools.mcp import (
    McpWorkbench,
    SseServerParams,
    StdioServerParams,
    StreamableHttpServerParams,
    mcp_server_tools
)

from autogen_ext.runtimes.grpc import (
        GrpcWorkerAgentRuntimeHost,
        GrpcWorkerAgentRuntime
    )

from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent, AgentInputMessage
from agents_logger import logger
from agents.mcp_trust import apply_mcp_http_trust_from_env


class DistributedAgentInvocation:
    """
    Distributed agent invocation using gRPC-based runtime.
    
    This class creates worker runtimes that connect to a gRPC host service.
    The host service must be started separately (see GrpcHostManager).
    
    Each instance represents one agent running as a worker that connects to the host.
    Multiple workers can connect to the same host for horizontal scaling.
    """
    
    def __init__(
        self,
        agent_name: str,
        agent_description: str,
        model_client: ChatCompletionClient,
        agent_type: str,
        host_address: str = "localhost:50051",
        system_message: Optional[List[SystemMessage]] = None,
        model_context: Optional[ChatCompletionContext] = None,
        tools: Optional[List[FunctionTool]] = None,
        mcp_params: Optional[
            StdioServerParams | SseServerParams | StreamableHttpServerParams |
            Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
        ] = None,
        agent_mcp_env_name: Optional[str] = None,
    ):
        """
        Initialize distributed agent worker.
        
        Note: The gRPC host service must be running before starting workers.
        
        Args:
            agent_name: Name of the agent
            agent_description: Description of agent capabilities
            model_client: LLM client for agent
            agent_type: Type identifier for the agent
            host_address: Address of the gRPC host service (host:port)
            system_message: System messages for the agent
            model_context: Chat completion context
            tools: Function tools available to the agent
            mcp_params: MCP server parameters
            agent_mcp_env_name: Environment variable name for MCP config
        """

        # If provided, apply a custom CA/trust bundle for all outbound HTTP(S) clients.
        apply_mcp_http_trust_from_env()
        
        self.agent_name = agent_name
        self.agent_description = agent_description
        self.model_client = model_client
        self.system_message = system_message
        self.model_context = model_context
        self.tools = tools
        self.agent_type = agent_type
        self.host_address = host_address
        self.agent_mcp_env_name = agent_mcp_env_name
        
        # Runtime instance (worker only)
        self.worker: Optional[GrpcWorkerAgentRuntime] = None
        
        # Validate MCP parameters
        if mcp_params and agent_mcp_env_name:
            raise ValueError("Provide either mcp_params or agent_mcp_env_name, not both.")
        
        if mcp_params:
            self.mcp_params = mcp_params
        elif self.agent_mcp_env_name:
            self.mcp_params = self.get_mcp_params()
        else:
            self.mcp_params = None
    
    def get_mcp_params(self):
        """
        Read MCP server parameters from environment variable.
        Falls back to None if not configured.
        """
        mcp_servers_json = os.getenv(self.agent_mcp_env_name)
        
        if mcp_servers_json:
            try:
                servers_config = json.loads(mcp_servers_json)
                mcp_list = []

                def _resolve_url(server_cfg: dict) -> str:
                    if server_cfg.get("url"):
                        return str(server_cfg["url"]).strip()
                    host = server_cfg.get("mcp_host")
                    path = server_cfg.get("mcp_path")
                    if host and path:
                        return f"{str(host).rstrip('/')}/{str(path).lstrip('/')}"
                    raise KeyError("Missing MCP endpoint; expected 'url' or ('mcp_host' and 'mcp_path')")
                
                for config in servers_config:
                    server_type = config.get('type', 'http').lower()
                    
                    if server_type in ['http', 'streamablehttp']:
                        # Only pass recognized, non-None kwargs to avoid constructing
                        # StreamableHttpServerParams with explicit None values.
                        kwargs = {'url': _resolve_url(config)}
                        if config.get('headers') is not None:
                            kwargs['headers'] = config['headers']
                        if config.get('timeout') is not None:
                            kwargs['timeout'] = config['timeout']
                        if config.get('sse_read_timeout') is not None:
                            kwargs['sse_read_timeout'] = config['sse_read_timeout']
                        if config.get('terminate_on_close') is not None:
                            kwargs['terminate_on_close'] = config['terminate_on_close']
                        mcp_list.append(StreamableHttpServerParams(**kwargs))
                    elif server_type == 'sse':
                        mcp_list.append(SseServerParams(url=_resolve_url(config)))
                    elif server_type == 'stdio':
                        mcp_list.append(StdioServerParams(
                            command=config['command'],
                            args=config.get('args', []),
                            env=config.get('env', {})
                        ))
                
                logger.info(f"Created MCP Server Params list for agent {self.agent_name}")
                return mcp_list if mcp_list else None
            except (json.JSONDecodeError, KeyError) as e:
                logger.error(f"Error parsing MCP servers environment variable: {e}")
                return None
        return None
    
    async def check_mcp_health(self) -> bool:
        """Check health of configured MCP servers"""
        if self.mcp_params is None:
            logger.warning(
                f"No MCP server parameters configured for agent {self.agent_name}. "
                "Skipping health check."
            )
            return True
        
        for mcp_param in self.mcp_params:
            workbench = McpWorkbench(mcp_param)
            try:
                if hasattr(workbench, "start"):
                    await workbench.start()
                tools = await workbench.list_tools()
                if isinstance(tools, list) and len(tools) > 0:
                    logger.info(
                        f"MCP server {mcp_param} is healthy for agent {self.agent_name} (tools={len(tools)})."
                    )
                else:
                    logger.error(
                        f"MCP server {mcp_param} is NOT healthy for agent {self.agent_name} (no tools returned)."
                    )
                    return False
            except Exception as e:
                logger.error(
                    f"Error checking MCP server {mcp_param} for agent {self.agent_name}: {e}"
                )
                return False
            finally:
                try:
                    if hasattr(workbench, "stop"):
                        await workbench.stop()
                    else:
                        await workbench.__aexit__(None, None, None)
                except Exception:
                    pass
        return True
    
    async def agent_factory(self):
        """Factory function to create agent instances"""
        logger.info(f"Creating AutogenCoreAgent instance for agent {self.agent_name}")
        return AutogenCoreAgent(
            agent_name=self.agent_name,
            agent_description=self.agent_description,
            system_message=self.system_message,
            model_client=self.model_client,
            model_context=self.model_context,
            mcp_server_params=self.mcp_params,
            tools=self.tools
        )
    
    async def start_worker_runtime(self):
        """
        Start the worker runtime and register the agent.
        The worker connects to the host service.
        
        Note: The host service must be running before calling this method.
        """
        logger.info(f"Starting worker runtime for agent {self.agent_name}")
        
        # Create worker runtime
        self.worker = GrpcWorkerAgentRuntime(host_address=self.host_address)
        await self.worker.start()
        
        # Register agent with the worker
        await AutogenCoreAgent.register(
            self.worker,
            self.agent_type,
            self.agent_factory
        )
        
        logger.info(
            f"Worker runtime started and agent {self.agent_name} registered "
            f"with type {self.agent_type}"
        )
    
    async def publish_message(
        self,
        message: str,
        source: str = "user",
        context_id: Optional[str] = None,
        task_id: Optional[str] = None,
        topic_id=None
    ) -> None:
        """
        Publish a message to a topic (broadcast to all subscribed agents).
        
        Args:
            message: Message content
            source: Source of the message
            context_id: Optional context identifier
            task_id: Optional task identifier
            topic_id: Topic to publish to (defaults to DefaultTopicId)
        """
        if not self.worker:
            raise RuntimeError("Worker runtime not started. Call start_worker_runtime() first.")
        
        topic = topic_id or DefaultTopicId()
        
        agent_message = AgentInputMessage(
            request=message,
            source=source,
            context_id=context_id,
            task_id=task_id
        )
        
        logger.info(f"Publishing message to topic from {self.agent_name}")
        await self.worker.publish_message(agent_message, topic)
    
    async def send_message(
        self,
        message: str,
        recipient_type: str,
        recipient_key: str = "default",
        source: str = "user",
        context_id: Optional[str] = None,
        task_id: Optional[str] = None
    ) -> BaseModel | str:
        """
        Send a direct message to a specific agent (RPC-style).
        
        Args:
            message: Message content
            recipient_type: Type of the recipient agent
            recipient_key: Key identifier for the agent instance
            source: Source of the message
            context_id: Optional context identifier
            task_id: Optional task identifier
        
        Returns:
            Response from the agent
        """
        if not self.worker:
            raise RuntimeError("Worker runtime not started. Call start_worker_runtime() first.")
        
        agent_id = AgentId(recipient_type, recipient_key)
        
        agent_input = AgentInputMessage(
            request=message,
            source=source,
            context_id=context_id,
            task_id=task_id
        )
        
        logger.info(
            f"Sending message to agent {recipient_type}/{recipient_key} "
            f"from {self.agent_name}"
        )
        
        try:
            response = await self.worker.send_message(agent_input, recipient=agent_id)
            
            # Try to parse response as JSON
            try:
                response = json.loads(response)
            except (json.JSONDecodeError, TypeError):
                pass  # Return as-is if not JSON
            
            logger.info(f"Received response from agent {recipient_type}")
            return response
        except Exception as e:
            logger.error(f"Error sending message to agent: {traceback.format_exc()}")
            raise e
    
    async def stop_worker(self):
        """Stop the worker runtime gracefully"""
        if self.worker:
            logger.info(f"Stopping worker runtime for agent {self.agent_name}")
            await self.worker.stop()
            logger.info(f"Worker runtime stopped for agent {self.agent_name}")
    
    async def stop_when_signal(self):
        """
        Keep the worker running until a termination signal is received.
        Useful for long-running worker processes.
        """
        if self.worker:
            logger.info(f"Worker {self.agent_name} running. Waiting for termination signal...")
            await self.worker.stop_when_signal()


# Helper function to create multiple workers

async def create_distributed_agent_workers(
    agents_config: List[dict],
    host_address: str = "localhost:50051"
) -> List[DistributedAgentInvocation]:
    """
    Create multiple worker agents that connect to an existing host service.
    
    Note: The host service must be started separately before calling this function.
    Use GrpcHostManager to start the host service.
    
    Args:
        agents_config: List of agent configuration dictionaries
        host_address: Address of the running gRPC host service
    
    Returns:
        List of worker agent instances
    
    Example:
        # First, start the host service
        from agents.autogen_base_agent.grpc_host_manager import GrpcHostManager
        
        host_manager = GrpcHostManager(address="localhost:50051")
        host_manager.start()
        
        # Then create workers
        agents_config = [
            {
                'agent_name': 'Worker1',
                'agent_description': 'First worker agent',
                'agent_type': 'worker1',
                'model_client': client,
            },
            {
                'agent_name': 'Worker2',
                'agent_description': 'Second worker agent',
                'agent_type': 'worker2',
                'model_client': client,
            }
        ]
        
        workers = await create_distributed_agent_workers(agents_config, "localhost:50051")
    """
    worker_agents = []
    
    for config in agents_config:
        agent = DistributedAgentInvocation(
            agent_name=config['agent_name'],
            agent_description=config['agent_description'],
            model_client=config['model_client'],
            agent_type=config['agent_type'],
            host_address=host_address,
            system_message=config.get('system_message'),
            model_context=config.get('model_context'),
            tools=config.get('tools'),
            mcp_params=config.get('mcp_params'),
            agent_mcp_env_name=config.get('agent_mcp_env_name'),
        )
        
        # Start worker runtime
        await agent.start_worker_runtime()
        worker_agents.append(agent)
    
    logger.info(f"Created {len(worker_agents)} distributed agent workers")
    return worker_agents


async def shutdown_distributed_workers(
    worker_agents: List[DistributedAgentInvocation]
):
    """
    Gracefully shutdown distributed agent workers.
    
    Args:
        worker_agents: List of worker agent instances
    """
    logger.info("Shutting down distributed agent workers...")
    
    # Stop all workers
    for worker in worker_agents:
        await worker.stop_worker()
    
    logger.info("All distributed agent workers shutdown complete")
