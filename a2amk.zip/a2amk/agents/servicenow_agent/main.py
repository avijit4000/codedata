import os
import sys
import traceback
import importlib

import click
import httpx
import uvicorn, asyncio

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import (
    BasePushNotificationSender,
    InMemoryPushNotificationConfigStore,
    InMemoryTaskStore,
)
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
)
from dotenv import load_dotenv
from starlette.responses import JSONResponse

script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
A2AAgentExecutor = importlib.import_module(f"agents.{script_folder}.agent_executor").A2AAgentExecutor
config_module = importlib.import_module(f"agents.{script_folder}.config")
agent_module = importlib.import_module(f"agents.{script_folder}.agent")
agent_name, agent_type, HOST, PORT = (config_module.agent_name, config_module.agent_type, config_module.HOST, config_module.PORT)
agent_instance, agent_description = (agent_module.agent_instance, agent_module.agent_description)

from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent
from agents_logger import logger


def main(host, port):
    """Starts the Service Now Agent server."""
    try:

        capabilities = AgentCapabilities(streaming=False, push_notifications=False)
        skill = AgentSkill(
            id='servicenow_agent_skill',
            name='ServiceNow Data Fetching/Analysis',
            description=agent_description,
            tags=["servicenow datas", "servicenow metrics"],
            examples=[],
        )
        agent_card = AgentCard(
            name=agent_name,
            description=agent_description,
            url=os.getenv("AGENT_URL", f'http://{host}:{port}/'),
            version='1.0.0',
            default_input_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
            default_output_modes=AutogenCoreAgent.SUPPORTED_CONTENT_TYPES,
            capabilities=capabilities,
            skills=[skill],
        )


        # --8<-- [start:DefaultRequestHandler]
        httpx_client = httpx.AsyncClient()
        push_config_store = InMemoryPushNotificationConfigStore()
        push_sender = BasePushNotificationSender(httpx_client=httpx_client,
                        config_store=push_config_store)
        
        request_handler = DefaultRequestHandler(
            agent_executor=A2AAgentExecutor(),
            task_store=InMemoryTaskStore(),
            push_config_store=push_config_store,
            push_sender= push_sender
        )
        server = A2AStarletteApplication(
            agent_card=agent_card, http_handler=request_handler
        )
        app = server.build()

        async def _health(request):
            return JSONResponse({"status": "ok"})

        async def stop_task(request):
            task_id = request.path_params.get("task_id")
            logger.info(f"Received request to stop task {task_id}.")

        app.add_route("/health", _health, methods=["GET"])
        app.add_route("/health/live", _health, methods=["GET"])

        mcp_health = asyncio.run(agent_instance.check_mcp_health())
        
        if mcp_health:
            logger.info(f"MCP server health check passed. Starting {agent_name} server.")
            uvicorn.run(app, host=host, port=port)
        else:
            logger.error(f"MCP server health check failed. Aborting {agent_name} server startup.")
            sys.exit(1)

    except Exception as e:
        logger.error(f'An error occurred during server startup: {traceback.format_exc()}')
        sys.exit(1)


if __name__ == '__main__':
    main(HOST, PORT)