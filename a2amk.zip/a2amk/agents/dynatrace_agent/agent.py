import asyncio, importlib
from dataclasses import dataclass
from pydantic import BaseModel
import json
from autogen_core import (DefaultTopicId, 
                          MessageContext, 
                          RoutedAgent, 
                          default_subscription, 
                          message_handler,
                          FunctionCall)
from autogen_core import AgentId, SingleThreadedAgentRuntime
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage, 
    UserMessage, 
    CreateResult, 
    AssistantMessage,
    LLMMessage,
    FunctionExecutionResult,
    FunctionExecutionResultMessage,
)
from dotenv import load_dotenv
from autogen_core.model_context import BufferedChatCompletionContext, ChatCompletionContext, UnboundedChatCompletionContext
from autogen_core.tools import FunctionTool, Tool, Workbench, ToolResult
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
from typing import Annotated, Any, AsyncGenerator, Callable, Coroutine, Dict, List, Optional, Sequence, Tuple, Literal

import os, json
script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
config_module = importlib.import_module(f"agents.{script_folder}.config")
globals().update({k: v for k, v in vars(config_module).items() if not k.startswith('_')})

from agents_logger import logger
load_dotenv()
from agents.autogen_base_agent.autogen_agent import AutogenCoreAgent, AgentInputMessage
from agents.autogen_base_agent.agent_invocation import agent_invocation
from agents.autogen_base_agent.utils import create_model_client

class ResponseFormat(BaseModel):
    status: Literal["completed", "input_required", "error"]
    agent_response: Annotated[str, "exact fetched data or the error message or the message asking for more information"]

llm_response_structure = {
    "type": "json_schema",
    "json_schema": {
       "name": "DynatraceAgentResponse",
       "description": "Response from the Dynatrace Agent",
       # Use the schema directly without the wrapper to ensure consistent format
       "schema": {
           "type": "object",
           "properties": {
               "status": {
                   "type": "string",
                   "enum": ["completed", "input_required", "error"]
               },
               "agent_response": {
                   "type": "string",
                   "description": "fetched data or the error message or the message asking for more information"
               }
           },
           "required": ["status", "agent_response"],
           "additionalProperties": False
       },
       "strict": True
    }
}

# Create LLM Model Client
llm_model_client = create_model_client(agent_name_in_yaml_config, 
                                        llm_response_structure = llm_response_structure,
                                        )

# Instance to create the dynatrace agent
# Instance used to create a agent factory and runtime for the agent,
# Instance used to nvoke the agent with user messages.  

agent_instance = agent_invocation(
    agent_name=agent_name,
    agent_description=" An agent that retrieves and analyses Dynatrace data using MCP tools.",
    model_client=llm_model_client,
    # runtime=SingleThreadedAgentRuntime(),
    agent_type=agent_type,
    markdown_summary = False,
    system_message=[SystemMessage(content=agent_prompt)],
    model_context=BufferedChatCompletionContext(buffer_size=3, initial_messages=[]),
    agent_name_in_yaml_config=agent_name_in_yaml_config,
    # mcp_params=mcp_params
    )

tool_descriptions = asyncio.run(agent_instance.get_tool_descriptions(include_tool_schema = False, 
                                                                    include_tool_params = True
                                                                    ))
print(tool_descriptions)
# The following is a more detailed dynamic description including tool capabilities.
# It is used by the orchestrator to understand what the agent can do.
agent_description = f"""
                    An agent that analyse the task query and fetches data from dynatrace using MCP tools.\n 
                    Provide insights on the fetched data.\n
                    The following are the agent capabilities and respective tools available to the agent:\n
                    {tool_descriptions}\n
                    """

if __name__ == "__main__":
    import asyncio
    
    # runtime = asyncio.run(create_runtime()) 
    runtime = asyncio.run(agent_instance.create_runtime())
    while True:
        user_message = input("Enter your message: ")

        if not user_message == "quit":
            # response = asyncio.run(invoke_fetch_agent(runtime, user_message))
            response = asyncio.run(dynatrace_agent.invoke_agent(runtime, user_message))
            print("Agent response:", response)
        else:
            break
    
    
    