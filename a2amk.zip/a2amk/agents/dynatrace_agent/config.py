import os
import json
from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
from datetime import datetime

# Read from environment variables, default to localhost for local development
HOST = os.getenv('DYNATRACE_HOST', os.getenv('HOST', 'localhost'))
PORT = int(os.getenv('DYNATRACE_AGENT_PORT', os.getenv('PORT', '8096')))

# Agent name defined in config.yaml file or kuberneters configMap yaml config to create model client and MCP Server connection.
agent_name_in_yaml_config = "dynatrace_agent" 


agent_prompt = f"""You are a helpful assistant that fetches and analyze data from dynatrace using MCP tools provided. 
                        Today's date is {datetime.today().strftime("%Y/%m/%d")}.
                        If the date or datetime provided is not in the correct datatype, convert it to the datatype accepted by the tool.
                        Infer the arguments required for the tool from the user request.
                        Use supporting tools provided in the MCP tools to fetch the object IDs and other relevant information required to query tools that provide the right data. This can come as needing to pull related named entities before a metric query and evaluating through LLM.
                        Tool suggestions are provided in the input. It is not mandatory to use all the suggested tools. Identify and use the most relevant tool based on the user query.
                        Infer the correct tool argument values from the given context.
                        If there are multiple options to choose from, ask the user for clarification on which one to use. 

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'
                        """


agent_name = "dynatrace_agent"
agent_type = "dynatrace_agent"