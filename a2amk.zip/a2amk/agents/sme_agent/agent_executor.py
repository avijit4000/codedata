import traceback
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import (
    InternalError,
    InvalidParamsError,
    Part,
    TaskState,
    TextPart,
    UnsupportedOperationError,
    TaskStatusUpdateEvent
)
from a2a.utils import (
    new_agent_text_message,
    new_task,
)
from a2a.utils.errors import ServerError

import json, asyncio, os, importlib

script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
agent_module = importlib.import_module(f"agents.{script_folder}.agent")
agent_instance = agent_module.agent_instance
config_module = importlib.import_module(f"agents.{script_folder}.config")
globals().update({k: v for k, v in vars(config_module).items() if not k.startswith('_')})
from agents_logger import logger

class A2AAgentExecutor(AgentExecutor):
    f"An executor for the {agent_name.rsplit('_', maxsplit = 1)[0].replace('_',' ').capitalize()} Agent."
    def __init__(self):
        # Don't create a shared runtime - we'll create one per request
        # This prevents state pollution and ensures clean context for each request
        pass

    async def execute(
        self,
        request_context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        
        # Create a fresh runtime for this request
        # This ensures complete isolation between concurrent requests
        # ag_runtime = None
        
        try:
            user_message = request_context.get_user_input()
            
            task = request_context.current_task

            if not task:
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)

            task_updater = TaskUpdater(event_queue, task.id, task.context_id)

            # Create a new runtime for this request
            # logger.info("Creating new runtime for this request...")
            # ag_runtime = await latency_agent.create_runtime()
            
            response = await agent_instance.invoke_agent(user_message)

            # Log raw response before parsing
            # logger.info(f"Raw response from agent (type: {type(response)}): {response}")
            
            if isinstance(response, str):
                response = json.loads(response)

            # logger.info("Parsed response received in the executor:")
            # logger.info(str(response))

            # Handle wrapped response format (with "properties" key from JSON schema)
            if "properties" in response and "status" in response["properties"]:
                logger.info("Unwrapping response from JSON schema format")
                response = response["properties"]
            
            # Convert the dict to string for message
            response_str = ""
            for k, v in response.items():
                if k != "status":
                    response_str += f"{k}:\n {v}\n\n"
            

            if response.get("status") == "error":
                await task_updater.update_status(
                    TaskState.failed,
                    new_agent_text_message(
                            text=response_str, #str(response.get("fetched_data")),
                            context_id=task.context_id,
                            task_id=task.id,
                        ),
                        final=True,
                )

            elif response.get("status") == "input_required":
                await task_updater.update_status(
                    TaskState.input_required,
                    new_agent_text_message(
                            text=response_str, #str(response.get("fetched_data")),
                            context_id=task.context_id,
                            task_id=task.id,
                        ),
                        final=False,
                )
            elif response.get("status") == "completed":
                await task_updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(
                            text=response_str,
                            context_id=task.context_id,
                            task_id=task.id,
                        ),
                        final=True,
                ) 
            
            else:
                await task_updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(
                        text=response_str, #str(response.get("fetched_data")),
                        context_id=task.context_id,
                        task_id=task.id,
                    ),
                    final=True,
                )
        except Exception as e:
            logger.error(f"{agent_name.rsplit('_', maxsplit = 1)[0].replace('_',' ').capitalize()} Agent Executor failed: {traceback.format_exc()}")
            raise ServerError(error=InternalError(message=f"{agent_name.rsplit('_', maxsplit = 1)[0].replace('_',' ').capitalize()} Agent Executor failed: {str(e)}"))
        # finally:
        #     # Cleanup: Stop the runtime after request completes
        #     if ag_runtime is not None:
        #         try:
        #             logger.info("Stopping runtime after request completion...")
        #             await ag_runtime.stop_when_idle()
        #             logger.info("Runtime stopped successfully")
        #         except Exception as cleanup_error:
        #             logger.warning(f"Error stopping runtime: {cleanup_error}")
        
    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        raise ServerError(error=UnsupportedOperationError())

