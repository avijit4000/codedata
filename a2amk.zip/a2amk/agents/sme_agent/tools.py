from autogen_ext.tools.azure import AzureAISearchTool
from azure.core.credentials import AzureKeyCredential
import os, importlib
script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
config_module = importlib.import_module(f"agents.{script_folder}.config")
globals().update({k: v for k, v in vars(config_module).items() if not k.startswith('_')})
from agents.autogen_base_agent.utils import get_config_data
from dotenv import load_dotenv
load_dotenv()


yaml_config_data = get_config_data(agent_name_in_yaml_config)
print(yaml_config_data)


azure_search_tool = AzureAISearchTool.create_hybrid_search(
    name="semantic-hybrid-search",
    endpoint= yaml_config_data["azure_search"]["azure_search_endpoint"],
    index_name= yaml_config_data["azure_search"]["index_name"],
    credential=AzureKeyCredential(os.getenv("AZURE_KEY")),
    vector_fields=["text_vector"],
    search_fields=["chunk", "title"],
    query_type="semantic",  # Enable semantic ranking
    semantic_config_name=yaml_config_data["azure_search"]["semantic_config_name"],  # Your semantic config name
    embedding_provider="azure_openai",  # Use Azure OpenAI for embeddings
    embedding_model= yaml_config_data["embedding_model"]["azure_deployment"],  # Embedding model to use
    openai_endpoint=yaml_config_data["embedding_model"]["azure_endpoint"],  # Your Azure OpenAI endpoint
    openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),  # Your Azure OpenAI key
    openai_api_version=yaml_config_data["embedding_model"]["api_version"],  # Azure OpenAI API version
    select_fields=["chunk", "title"],  # Fields to return in results
    top=5,
)