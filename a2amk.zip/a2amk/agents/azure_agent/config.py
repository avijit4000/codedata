import os
import json
from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
from datetime import datetime

# Read from environment variables, default to localhost for local development
HOST = os.getenv('AZURE_HOST', os.getenv('HOST', 'localhost'))
PORT = int(os.getenv('AZURE_AGENT_PORT', os.getenv('PORT', '8097')))

# Agent name defined in config.yaml file or kuberneters configMap yaml config to create model client and MCP Server connection.
agent_name_in_yaml_config = "azure_agent" 

agent_prompt = f"""You are a helpful assistant that fetches and analyze data from dynatrace using MCP tools provided. 
                        Today's date is {datetime.today().strftime("%Y/%m/%d")}.
                        If the date or datetime provided is not in the correct datatype, convert it to the datatype accepted by the tool.
                        Infer the arguments required for the tool from the user request.

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        """


agent_name = "azure_agent"
agent_type = "azure_agent"