import asyncio
from dataclasses import dataclass
from pydantic import BaseModel
import json
from autogen_core import (DefaultTopicId, 
                          MessageContext, 
                          RoutedAgent, 
                          default_subscription, 
                          message_handler,
                          FunctionCall)
from autogen_core import AgentId, SingleThreadedAgentRuntime
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.models import (
    ChatCompletionClient, 
    SystemMessage, 
    UserMessage, 
    CreateResult, 
    AssistantMessage,
    LLMMessage,
    FunctionExecutionResult,
    FunctionExecutionResultMessage,
)
from dotenv import load_dotenv
from autogen_core.model_context import BufferedChatCompletionContext, ChatCompletionContext, UnboundedChatCompletionContext
from autogen_core.tools import FunctionTool, Tool, Workbench, ToolResult
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
from typing import Any, AsyncGenerator, Callable, Coroutine, Dict, List, Optional, Sequence, Tuple, Literal, Annotated

import os, json, importlib
script_folder = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
config_module = importlib.import_module(f"agents.{script_folder}.config")
globals().update({k: v for k, v in vars(config_module).items() if not k.startswith('_')})
from agents_logger import logger

load_dotenv()
from agents.autogen_base_agent.agent_invocation import agent_invocation
from agents.autogen_base_agent.utils import create_model_client

class CoderInput(BaseModel):
    request: str
    source: str
    task_id: Optional[str] = None
    context_id: Optional[str] = None

class ResponseFormat(BaseModel):
    status: Literal["completed", "input_required", "error"]
    response: Annotated[str, "Generated code or error message or message"] # or input request message

llm_response_structure = {
    "type": "json_schema",
    "json_schema": {
       "name": "CoderAgentResponse",
       "description": "Response from the Coder Agent",
       "schema": ResponseFormat.model_json_schema(),
        }
}

# Create LLM Model Client
llm_model_client = create_model_client(agent_name_in_yaml_config, 
                                        llm_response_structure = llm_response_structure,
                                        )


agent_instance = agent_invocation(
    agent_name=agent_name,
    agent_description= "An agent that generates code",
    model_client=llm_model_client,
    # runtime=SingleThreadedAgentRuntime(),
    agent_type=agent_type,
    markdown_summary = False,
    system_message=[SystemMessage(content=agent_prompt)],
    model_context=BufferedChatCompletionContext(buffer_size=2, initial_messages=[]),
)

agent_description = """An agent that writes efficient code in various programming languages as per the request.
                    It can write code for specific tasks or projects. Specializes in creating interactive HTML/JavaScript 
                    visualizations and charts for data display. Can generate code, debug issues, and create data visualization 
                    solutions using popular charting libraries."""



if __name__ == "__main__":
    import asyncio
    runtime = asyncio.run(agent_instance.create_runtime())
    while True:
        user_message = input("Enter your message: ")

        if not user_message == "quit":
            response = asyncio.run(agent_instance.invoke_agent(runtime, user_message))
            print("Agent response:", response)
            print(type(response))
        else:
            break