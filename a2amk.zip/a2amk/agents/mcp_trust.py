import os
import tempfile
from pathlib import Path

from agents_logger import logger


# Env var containing a PEM file or CA bundle path for TLS verification.
# When set, we propagate it to common TLS-related env vars used by Python/OpenSSL tooling.
MCP_HTTP_VERIFY_ENV_VAR = "MCP_HTTP_VERIFY"


def apply_mcp_http_trust_from_env() -> str | None:
    """Apply a custom CA/trust bundle for outbound HTTP(S) clients.

    autogen-ext's MCP HTTP param types currently do not expose a `verify=` argument.
    The most reliable way to influence the underlying httpx/ssl verification is to
    set process environment variables before connections are created.

    IMPORTANT: Do not *replace* the platform trust roots with a narrow bundle.
    Instead, we merge the platform/Certifi trust roots with the custom bundle
    to avoid breaking calls to public endpoints (e.g., Azure OpenAI) whose
    issuing roots may not exist in the custom bundle.

    Returns:
        The resolved trust bundle path if applied, else None.
    """

    verify_path = os.getenv(MCP_HTTP_VERIFY_ENV_VAR)
    if not verify_path:
        return None

    resolved_path = os.path.expanduser(verify_path)
    if not os.path.isabs(resolved_path):
        resolved_path = os.path.abspath(resolved_path)

    if not os.path.exists(resolved_path):
        logger.error(
            f"{MCP_HTTP_VERIFY_ENV_VAR} is set to '{verify_path}', but file does not exist at '{resolved_path}'. "
            "Skipping custom trust bundle configuration."
        )
        return None

    # Determine a base trust store to merge with.
    # Prefer the current SSL_CERT_FILE if present (before we override it), else Certifi,
    # else the common Debian/Ubuntu path.
    base_ca_path: str | None = None
    existing_ssl_cert_file = os.getenv("SSL_CERT_FILE")
    if existing_ssl_cert_file and os.path.exists(existing_ssl_cert_file):
        base_ca_path = existing_ssl_cert_file
    else:
        try:
            import certifi  # type: ignore

            certifi_path = certifi.where()
            if certifi_path and os.path.exists(certifi_path):
                base_ca_path = certifi_path
        except Exception:
            base_ca_path = None

    if not base_ca_path and os.path.exists("/etc/ssl/certs/ca-certificates.crt"):
        base_ca_path = "/etc/ssl/certs/ca-certificates.crt"

    # If we cannot find a base store, fall back to the legacy behavior.
    if not base_ca_path:
        for env_var in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
            existing = os.getenv(env_var)
            if existing and existing != resolved_path:
                logger.info(
                    f"Overriding {env_var} from '{existing}' to '{resolved_path}' "
                    f"because {MCP_HTTP_VERIFY_ENV_VAR} is set."
                )
            os.environ[env_var] = resolved_path

        logger.info(f"Using custom TLS trust bundle for HTTP clients: {resolved_path}")
        return resolved_path

    # Create a merged CA bundle.
    combined_path = os.getenv(
        "MCP_HTTP_VERIFY_COMBINED_PATH",
        os.path.join(tempfile.gettempdir(), "mcp_http_verify_combined.pem"),
    )
    combined_path = os.path.expanduser(combined_path)
    if not os.path.isabs(combined_path):
        combined_path = os.path.abspath(combined_path)

    try:
        Path(combined_path).parent.mkdir(parents=True, exist_ok=True)
        with open(combined_path, "wb") as out:
            for path in (base_ca_path, resolved_path):
                with open(path, "rb") as f:
                    content = f.read()
                    out.write(content)
                    if content and not content.endswith(b"\n"):
                        out.write(b"\n")
        effective_path = combined_path
        logger.info(
            "Using merged TLS trust bundle for HTTP clients: %s (base=%s, extra=%s)",
            effective_path,
            base_ca_path,
            resolved_path,
        )
    except Exception as e:
        # If merging fails for any reason, fall back to using the custom bundle.
        effective_path = resolved_path
        logger.error(
            "Failed to create merged trust bundle (%s). Falling back to custom bundle only: %s",
            e,
            effective_path,
        )

    for env_var in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
        existing = os.getenv(env_var)
        if existing and existing != effective_path:
            logger.info(
                f"Overriding {env_var} from '{existing}' to '{effective_path}' "
                f"because {MCP_HTTP_VERIFY_ENV_VAR} is set."
            )
        os.environ[env_var] = effective_path

    return effective_path
