import logging

logging.basicConfig(level=logging.INFO)
logging.getLogger("autogen_core").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)
