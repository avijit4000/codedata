from autogen_agentchat.agents import AssistantAgent, UserProxyAgent
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from dotenv import load_dotenv
import os
from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
import asyncio
from typing import Annotated, Sequence
from autogen_agentchat.messages import ToolCallSummaryMessage
from autogen_agentchat.teams import MagenticOneGroupChat
from autogen_agentchat.ui import Console



load_dotenv()
from config import *

gpt4_model_client = AzureOpenAIChatCompletionClient(model = GPT4_MODEL_NAME, 
                                      azure_endpoint = GPT4_AZURE_ENDPOINT,
                                      azure_deployment = GPT4_AZURE_DEPLOYMENT,
                                      api_version = GPT4_API_VERSION,
                                      api_key = os.getenv("GPT4_AZURE_API_KEY"))

sse_mcp_server_params = SseServerParams(
    url="http://localhost:8080/sse",
    
)

std_mcp_params = StdioServerParams(
    command = "python",
    args = ["-m", "mcps.pull_metric_api"],
    
)

async def get_work_bench(server_params: StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
                     ) -> McpWorkbench | Sequence[McpWorkbench]:
    if isinstance(server_params, Sequence):
        workbenches = []
        for params in server_params:
            async with McpWorkbench(server_params = params) as workbench:
                pass
            workbenches.append(workbench)
        return workbenches
    
    async with McpWorkbench(server_params = server_params) as workbench:
        pass
    return workbench

async def get_mcp_tools(server_params: StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
                     ):
    if isinstance(server_params, Sequence):
        mcp_tools = None
        for idx, params in enumerate(server_params):
                if idx == 0:
                    mcp_tools = await mcp_server_tools(params)
                else:
                    mcp_tools += await mcp_server_tools(params)
        return mcp_tools
       
    
    mcp_tools = await mcp_server_tools(server_params)
    return mcp_tools

work_bench = asyncio.run(get_work_bench(std_mcp_params))
mcp_tools = asyncio.run(get_mcp_tools(std_mcp_params))


async def create_multi_mcp_agent(server_params: StdioServerParams | SseServerParams | StreamableHttpServerParams | 
                     Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams],
                     agent_name: str,
                     system_message: Annotated[str | Sequence[str], "System message for the agent"]):
    workbenches = []
    if isinstance(server_params, Sequence):
        for params in server_params:
            workbench = McpWorkbench(params)
            await workbench.__aenter__()
            workbenches.append(workbench)

    workbench = McpWorkbench(server_params)
    await workbench.__aenter__()
    workbenches.append(workbench)

    agent = AssistantAgent(
        name=agent_name,
        model_client=gpt4_model_client,
        workbench=workbenches,
        system_message=system_message,
    )
    return agent, workbenches



summary_agent = AssistantAgent(
        name="summary_agent",
        model_client=gpt4_model_client,
        workbench=None,
        tools = None,
        system_message="You are a helpful assistant that summarizes the information provided.",
    )

user_agent = UserProxyAgent(
        name="user_agent",
        description="You are a human user",
    )


coder_agent = AssistantAgent(
        name="coder_agent",
        model_client=gpt4_model_client,
        workbench=None,
        tools = None,
        system_message="You are a helpful coding assistant that writes code.",
    )



async def main(user_message):

    fetcher_agent, workbenches = await create_multi_mcp_agent(
        server_params=std_mcp_params,
        agent_name="fetcher_agent",
        system_message="You are a helpful assistant that fetches information for the user using the tools/workbench provided.",
    )

    orchestrator = MagenticOneGroupChat(
    name="orchestrator",
    participants=[user_agent, fetcher_agent, summary_agent, coder_agent],
    model_client=gpt4_model_client,
    )

    await Console(orchestrator.run_stream(task=user_message))

    for workbench in workbenches:
        await workbench.__aexit__(None, None, None)



if __name__ == "__main__":

    while True:
        user_message = input("Enter your message: ")

        if not user_message == "quit":
            asyncio.run(main(user_message))
        else:
            break
    # Get the latency report for 2025/11/13
    # Perform latency analysis for the dates 2025/11/13 and 2025/11/12
    # fetch the latency report from 2025/11/12 to 2025/11/14 and provide a python code to plot the fetched result