from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import (
    InternalError,
    InvalidParamsError,
    Part,
    TaskState,
    TextPart,
    UnsupportedOperationError,
)
from a2a.utils import (
    new_agent_text_message,
    new_task,
)
from a2a.utils.errors import ServerError

import json

from agents.fetch_agent.fetch_agent import invoke_fetch_agent, create_fetch_agent_runtime

class FetchAgentExecutor(AgentExecutor):
    "An executor for the Fetch Agent."

    def __init__(self):
        self._ag_runtime = create_fetch_agent_runtime()

    async def execute(
        self,
        request_context: RequestContext,
        event_queue: EventQueue,
        task_updater: TaskUpdater,
    ) -> None:
        error = self._validate_request(request_context)

        if error:
            raise ServerError(error=InvalidParamsError())
        
        try:
            user_message = request_context.get_user_input()
            
            task = request_context.current_task

            if not task:
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)

            updater = TaskUpdater(event_queue, task.id, task.context_id)

            response = await invoke_fetch_agent(self._ag_runtime, user_message)

            if response.get("status") == "error":
                await task_updater.update_status(
                    TaskState.FAILED,
                    new_agent_text_message(
                            response.get("fetched_data"),
                            task.context_id,
                            task.id,
                        ),
                        final=True,
                )
            elif response.get("status") == "input_required":
                await task_updater.update_status(
                    TaskState.INPUT_REQUIRED,
                    new_agent_text_message(
                            response.get("fetched_data"),
                            task.context_id,
                            task.id,
                        ),
                        final=False,
                )
            elif response.get("status") == "completed":
                await task_updater.update_status(
                    TaskState.COMPLETED,
                    new_agent_text_message(
                            response.get("fetched_data"),
                            task.context_id,
                            task.id,
                        ),
                        final=True,
                ) 
            
            response_part = TextPart(content=response)
            await task_updater.update_task(
                state=TaskState.COMPLETED,
                output={"response": response_part},
            )
        except Exception as e:
            raise InternalError(f"FetchAgentExecutor failed: {str(e)}") from e
        
    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        raise ServerError(error=UnsupportedOperationError())

