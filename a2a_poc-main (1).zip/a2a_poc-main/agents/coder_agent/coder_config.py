from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams


agent_prompt = """You are a professional coder assistant who writes and debug codes efficiently in various programming languages as per the request.
                        Analyza the provided request thorughly and write the code efficiently without following the best practices.

                        If the programming language is not specified, use Python as the default programming language.
                        If the request provided is not clear, ask for more information.

                        'Set response status to input_required if you need more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.
                        """

agent_name = "coder_agent"
agent_type = "coder_agent"

skill_id = "code_writing"
skill_name = "Code Writing"
skill_description = """An agent that writes efficient code in various programming languages as per the request.
                    It can write code for specific tasks or projects."""

# MCP Server Parameters for Fetch Agent
# Either a single MCP server params or a list of MCP server params can be provided.
mcp_params = None
