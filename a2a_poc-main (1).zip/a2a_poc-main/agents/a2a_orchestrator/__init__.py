"""
A2A Orchestrator Agent Package

A sophisticated orchestrator for coordinating tasks across multiple A2A remote agents.
"""

from .orchestrator import (
    A2AOrchestratorAgent,
    OrchestratorTask,
    RemoteAgent,
    TaskStatus,
)

__version__ = "1.0.0"
__all__ = [
    "A2AOrchestratorAgent",
    "OrchestratorTask",
    "RemoteAgent",
    "TaskStatus",
]
