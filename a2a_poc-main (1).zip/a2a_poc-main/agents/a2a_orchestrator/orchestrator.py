"""
A2A Orchestrator Agent

This orchestrator agent manages task execution across multiple remote A2A agents.
It performs the following actions:
1. Analyzes user query and generates a list of tasks based on available remote agents
2. Handles non-task queries with appropriate responses
3. Executes tasks sequentially or in dependency order
4. Manages task dependencies (Task B waits for Task A completion)
5. Returns individual task responses and final summary

Compatible with a2a-sdk Python package.
"""

import asyncio
import logging,sys
from config import *
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import uuid
from openai import AsyncAzureOpenAI, APITimeoutError, APIConnectionError

from a2a.client import ClientFactory, ClientConfig, Client
from a2a.types import (
    AgentCard,
    Message,
    Task,
    TaskState,
    TextPart,
    Role,
)
from a2a.client.card_resolver import A2ACardResolver
import httpx

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Status of orchestrator tasks"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WAITING_FOR_INPUT = "waiting_for_input"


@dataclass
class OrchestratorTask:
    """Represents a task to be executed by a remote agent"""
    task_id: str
    agent_url: str
    agent_name: str
    description: str
    query: str
    dependencies: List[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    response: Optional[str] = None
    error: Optional[str] = None
    dependency_results: Dict[str, str] = field(default_factory=dict)
    # A2A remote task context
    remote_task_id: Optional[str] = None
    remote_context_id: Optional[str] = None
    input_required_message: Optional[str] = None


@dataclass
class RemoteAgent:
    """Information about a remote A2A agent"""
    url: str
    name: str
    description: str
    skills: List[Dict[str, Any]]
    agent_card: Optional[AgentCard] = None
    client: Optional[Client] = None


class A2AOrchestratorAgent:
    """
    Orchestrator agent that coordinates task execution across multiple remote A2A agents.
    
    The orchestrator:
    - Fetches agent capabilities from remote agents
    - Analyzes user queries and generates task lists
    - Manages task dependencies
    - Executes tasks on appropriate remote agents
    - Aggregates and returns results
    """
    
    def __init__(
        self,
        remote_agent_urls: List[str],
        model_client: Any = None,
        httpx_client: Optional[httpx.AsyncClient] = None
    ):
        """
        Initialize the orchestrator agent.
        
        Args:
            remote_agent_urls: List of URLs for remote A2A agents
            model_client: LLM client for task planning (e.g., Azure OpenAI client)
            httpx_client: Optional HTTPX client for network requests
        """
        self.remote_agent_urls = remote_agent_urls
        self.model_client = model_client
        self.httpx_client = httpx_client or httpx.AsyncClient(
            timeout=httpx.Timeout(60.0, connect=10.0)  # 60s total, 10s connect timeout
        )
        self.remote_agents: Dict[str, RemoteAgent] = {}
        self.client_config = ClientConfig(
            streaming=False,  # Remote agents don't stream
            polling=False,
            httpx_client=self.httpx_client
        )
        
    async def initialize(self):
        """Initialize the orchestrator by fetching agent cards from all remote agents"""
        logger.info("Initializing orchestrator agent...")
        
        for agent_url in self.remote_agent_urls:
            try:
                await self._register_remote_agent(agent_url)
            except Exception as e:
                logger.error(f"Failed to register agent at {agent_url}: {e}")
                
        logger.info(f"Orchestrator initialized with {len(self.remote_agents)} remote agents")
    
    async def _register_remote_agent(self, agent_url: str):
        """
        Fetch agent card and register a remote agent.
        
        Args:
            agent_url: URL of the remote agent
        """
        try:
            # First check if agent is reachable
            logger.info(f"Checking connectivity to {agent_url}")
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as test_client:
                    response = await test_client.get(f"{agent_url}/health", timeout=5.0)
                    if response.status_code != 200:
                        logger.warning(f"Health check failed for {agent_url}, status: {response.status_code}")
            except Exception as connectivity_error:
                logger.error(f"Cannot connect to agent at {agent_url}: {connectivity_error}")
                raise Exception(f"Agent unreachable: {connectivity_error}")
            
            # Create card resolver with timeout
            card_resolver = A2ACardResolver(
                httpx_client=self.httpx_client,
                base_url=agent_url
            )
            
            # Fetch agent card with retry logic
            max_retries = 2
            agent_card = None
            for attempt in range(max_retries):
                try:
                    agent_card = await card_resolver.get_agent_card()
                    break
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    logger.warning(f"Retry {attempt + 1} for agent card from {agent_url}: {e}")
                    await asyncio.sleep(1)
            
            # Create client for this agent
            client = await ClientFactory.connect(
                agent=agent_card,
                client_config=self.client_config
            )
            
            # Extract skills
            skills = []
            if agent_card.skills:
                skills = [
                    {
                        "id": skill.id,
                        "name": skill.name,
                        "description": skill.description,
                        "examples": skill.examples or []
                    }
                    for skill in agent_card.skills
                ]
            
            # Register agent
            remote_agent = RemoteAgent(
                url=agent_url,
                name=agent_card.name,
                description=agent_card.description or "",
                skills=skills,
                agent_card=agent_card,
                client=client
            )
            
            self.remote_agents[agent_url] = remote_agent
            logger.info(f"Registered agent: {agent_card.name} at {agent_url}")
            
        except Exception as e:
            logger.error(f"Error registering agent at {agent_url}: {e}")
            raise
    
    def _get_agents_summary(self) -> str:
        """
        Get a summary of all available agents and their capabilities.
        
        Returns:
            Formatted string describing available agents
        """
        summary_parts = ["Available Remote Agents:\n"]
        
        for agent in self.remote_agents.values():
            summary_parts.append(f"\n{agent.name} ({agent.url}):")
            summary_parts.append(f"  Description: {agent.description}")
            summary_parts.append("  Skills:")
            for skill in agent.skills:
                summary_parts.append(f"    - {skill['name']}: {skill['description']}")
        
        return "\n".join(summary_parts)
    
    async def _plan_tasks(self, user_query: str) -> Tuple[bool, List[OrchestratorTask], str]:
        """
        Analyze user query and generate task execution plan using LLM.
        
        Args:
            user_query: User's input query
            
        Returns:
            Tuple of (is_task_query, tasks_list, response_message)
            - is_task_query: Whether the query requires task execution
            - tasks_list: List of tasks to execute
            - response_message: Direct response if not a task query
        """
        if not self.model_client:
            raise ValueError(
                "LLM model_client is required for task planning. "
                "Please provide a model_client when initializing the orchestrator."
            )
        
        # Use LLM for intelligent task planning
        agents_summary = self._get_agents_summary()
        
        planning_prompt = f"""
You are a task planning assistant for an orchestrator that manages multiple specialized agents.

{agents_summary}

User Query: {user_query}

Analyze the user query and determine:
1. Is this a query that requires task execution by the agents? (yes/no)
2. If yes, break it down into specific tasks for the appropriate agents
3. Identify any dependencies between tasks (e.g., Task B needs results from Task A)

If this is NOT a task query (e.g., greeting, general question), respond with:
NOT_A_TASK: [your friendly response]

If this IS a task query, respond in this format:
TASK_QUERY
TASK: [task_id] | [agent_url] | [task_description] | [specific_query] | DEPENDS_ON: [task_id1,task_id2] or NONE

IMPORTANT: 
- Task IDs must be in format: task_0, task_1, task_2, etc. (sequential starting from 0)
- List tasks in order (task_0 first, then task_1, etc.)
- Dependencies must reference task IDs of tasks listed earlier
- A task can only depend on tasks with lower numbers (e.g., task_2 can depend on task_0 or task_1)

Example:
TASK_QUERY
TASK: task_0 | http://agent1.com | Fetch weather data | Get weather for New York | DEPENDS_ON: NONE
TASK: task_1 | http://agent2.com | Analyze weather | Analyze the weather data | DEPENDS_ON: task_0

Generate the task plan:
""".format(agents_summary=agents_summary, user_query=user_query)
        
        try:
            # Call Azure OpenAI using chat completions API
            response = await self.model_client.chat.completions.create(
                model=GPT4_AZURE_DEPLOYMENT,
                messages=[{"role": "user", "content": planning_prompt}],
                temperature=0.7,
                max_tokens=2000
            )
            plan_text = response.choices[0].message.content
            # print(plan_text)
            
            return self._parse_task_plan(plan_text)
            
        except Exception as e:
            logger.error(f"Error in LLM task planning: {e}")
            raise
    

    def _parse_task_plan(self, plan_text: str) -> Tuple[bool, List[OrchestratorTask], str]:
        """
        Parse LLM-generated task plan.
        
        Args:
            plan_text: Raw text output from LLM
            
        Returns:
            Tuple of (is_task_query, tasks_list, response_message)
        """
        lines = plan_text.strip().split('\n')
        
        # Check if not a task query
        if lines[0].startswith("NOT_A_TASK:"):
            response = lines[0].replace("NOT_A_TASK:", "").strip()
            logger.info("No tasks to parse.")
            return False, [], response
        
        # Parse tasks
        tasks = []
        
        for line in lines[1:]:  # Skip "TASK_QUERY" line
            line = line.strip()
            if line.startswith("TASK:"):
                parts = line.replace("TASK:", "").split("|")
                if len(parts) >= 5:
                    task_id = parts[0].strip()
                    agent_url = parts[1].strip()
                    description = parts[2].strip()
                    query = parts[3].strip()
                    depends_raw = parts[4].strip()
                    
                    # Parse dependencies
                    dependencies = []
                    if "DEPENDS_ON:" in depends_raw:
                        deps_str = depends_raw.replace("DEPENDS_ON:", "").strip()
                        if deps_str != "NONE":
                            dependencies = [d.strip() for d in deps_str.split(",")]
                    
                    # Find agent name
                    agent_name = "Unknown Agent"
                    for agent in self.remote_agents.values():
                        if agent.url == agent_url:
                            agent_name = agent.name
                            break
                    
                    task = OrchestratorTask(
                        task_id=task_id,
                        agent_url=agent_url,
                        agent_name=agent_name,
                        description=description,
                        query=query,
                        dependencies=dependencies
                    )
                    tasks.append(task)

        logger.info(f"Parsed {len(tasks)} tasks from plan.") 
        return True, tasks, ""
    
    async def _execute_task(self, task: OrchestratorTask, user_input: Optional[str] = None) -> bool:
        """
        Execute a single task on the appropriate remote agent.
        
        Args:
            task: The task to execute
            user_input: Optional user input for resuming an input_required task
            
        Returns:
            True if successful, False if needs input or failed
        """
        logger.info(f"Executing {task.task_id}: {task.description}")
        
        # Get the remote agent
        agent = self.remote_agents.get(task.agent_url)
        if not agent or not agent.client:
            task.status = TaskStatus.FAILED
            task.error = f"Agent not found or not initialized: {task.agent_url}"
            logger.error(task.error)
            return False
        
        try:
            # Prepare query with dependency results if any
            if user_input:
                # Resuming with user input
                query_text = user_input
            else:
                # Initial execution
                query_text = task.query
                if task.dependency_results:
                    deps_info = "\n\nContext from previous tasks:\n"
                    for dep_id, result in task.dependency_results.items():
                        deps_info += f"- {dep_id}: {result}\n"
                    query_text = query_text + deps_info
            
            # Create message with unique message_id
            message = Message(
                message_id=str(uuid.uuid4()),  # Random UUID for message_id
                role=Role.user,
                parts=[TextPart(text=query_text)]
            )
            
            # If resuming task, add context_id and task_id from remote agent
            if task.remote_context_id:
                message.context_id = task.remote_context_id
            if task.remote_task_id:
                message.task_id = task.remote_task_id
            
            # Send message to agent (non-streaming)
            task.status = TaskStatus.IN_PROGRESS
            
            # Collect responses (agents send non-streaming responses)
            response_parts = []
            final_task_state = None
            
            async for event in agent.client.send_message(message):
                print(event, f'\n{type(event)}')
                sys.stdout.flush()
                # Event can be either a Message or tuple[Task, TaskStatusUpdateEvent | TaskArtifactUpdateEvent | None]
                if isinstance(event, Message):
                    # Direct Message response (non-streaming)
                    for part in event.parts:
                        if hasattr(part, 'root'):
                            response_parts.append(part.root.text)
                            # print("-----", part.root.text)
                            sys.stdout.flush()
                        elif hasattr(part, 'content'):
                            # Handle TextPart with content field
                            response_parts.append(str(part.content))
                            
                elif isinstance(event, tuple) and len(event) == 2:
                    # Tuple format: (Task, TaskStatusUpdateEvent | TaskArtifactUpdateEvent | None)
                    task_obj, update_event = event
                    
                    if isinstance(task_obj, Task):
                        # Extract context_id and task_id from remote agent
                        if task_obj.context_id:
                            task.remote_context_id = task_obj.context_id
                        if task_obj.id:
                            task.remote_task_id = task_obj.id
                        
                        # Extract task state
                        if task_obj.status:
                            final_task_state = task_obj.status.state
                            
                            # Extract message from task status
                            if task_obj.status.message and hasattr(task_obj.status.message, 'parts'):
                                for part in task_obj.status.message.parts:
                                    if hasattr(part, 'root'):
                                        response_parts.append(part.root.text)
                            
                    
                    # Handle TaskStatusUpdateEvent for additional state information
                    if update_event is not None:
                        # Extract state from update event if available
                        if hasattr(update_event, 'status'):
                            final_task_state = update_event.status.state
                            message = update_event.status.message
                            if message and hasattr(message, 'parts'):
                                for part in message.parts:
                                    if hasattr(part, 'root'):
                                        print("Event message", part.root.text)
                                   
                                
            # Combine response data (actual content from agent)
            raw_response = "\n".join(response_parts) if response_parts else ""
            
            # Process based on task state from events
            # The status comes from Task.status.state or update events, not from response content
            if final_task_state == TaskState.failed:
                # Agent reported failure - raw_response contains error message
                task.status = TaskStatus.FAILED
                task.error = raw_response or "Task failed"
                logger.error(f"Task {task.task_id} failed: {task.error}")
                raise Exception(f"Task failed: {task.error}")
                
            elif final_task_state == TaskState.input_required:
                # Agent needs more input - pause execution and wait for user input
                task.status = TaskStatus.WAITING_FOR_INPUT
                task.input_required_message = raw_response
                logger.info(f"Task {task.task_id} requires input: {raw_response}")
                logger.info(f"Remote context_id: {task.remote_context_id}, task_id: {task.remote_task_id}")
                return False  # Signal that task needs input
                
            elif final_task_state == TaskState.completed:
                # Task completed successfully - raw_response contains the result
                task.response = raw_response or "Task completed successfully"
                task.status = TaskStatus.COMPLETED
                logger.info(f"Task {task.task_id} completed successfully")
                return True
                
            else:
                # No explicit state or unknown state - default to completed
                task.response = raw_response or "Task completed successfully"
                task.status = TaskStatus.COMPLETED
                logger.info(f"Task {task.task_id} completed (no explicit state)")
                return True
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            logger.error(f"Task {task.task_id} failed: {e}")
            return False
    
    async def _execute_tasks(self, tasks: List[OrchestratorTask], callback=None, input_callback=None) -> Dict[str, OrchestratorTask]:
        """
        Execute all tasks respecting dependencies and send each task response as available.
        
        Args:
            tasks: List of tasks to execute
            callback: Optional callback function to call with each completed task
                     Signature: callback(task: OrchestratorTask) -> None
            input_callback: Optional async callback to collect user input for input_required tasks
                           Signature: async input_callback(task: OrchestratorTask) -> str
            
        Returns:
            Dictionary mapping task_id to completed task
        """
        completed_tasks: Dict[str, OrchestratorTask] = {}
        pending_tasks = {task.task_id: task for task in tasks}
        waiting_for_input_tasks: Dict[str, OrchestratorTask] = {}
        
        while pending_tasks or waiting_for_input_tasks:
            # Process tasks waiting for input
            if waiting_for_input_tasks:
                for task_id in list(waiting_for_input_tasks.keys()):
                    task = waiting_for_input_tasks[task_id]
                    
                    # Call input callback to get user input
                    if input_callback:
                        try:
                            logger.info(f"Requesting user input for task {task.task_id}")
                            user_input = await input_callback(task)
                            
                            if user_input:
                                # Resume task with user input
                                logger.info(f"Resuming task {task.task_id} with user input")
                                success = await self._execute_task(task, user_input=user_input)
                                
                                if task.status == TaskStatus.WAITING_FOR_INPUT:
                                    # Still needs more input, keep in waiting queue
                                    logger.info(f"Task {task.task_id} still needs more input")
                                    continue
                                else:
                                    # Task completed or failed, remove from waiting
                                    del waiting_for_input_tasks[task_id]
                                    completed_tasks[task_id] = task
                                    
                                    # Send task response via callback
                                    if callback:
                                        callback(task)
                                    
                                    if not success:
                                        logger.warning(f"Task {task.task_id} failed after user input")
                            else:
                                # No input provided, mark as failed
                                task.status = TaskStatus.FAILED
                                task.error = "No user input provided for input_required task"
                                del waiting_for_input_tasks[task_id]
                                completed_tasks[task_id] = task
                                
                                if callback:
                                    callback(task)
                        except Exception as e:
                            logger.error(f"Error processing input for task {task.task_id}: {e}")
                            task.status = TaskStatus.FAILED
                            task.error = f"Error processing user input: {str(e)}"
                            del waiting_for_input_tasks[task_id]
                            completed_tasks[task_id] = task
                            
                            if callback:
                                callback(task)
                    else:
                        # No input callback provided, mark task as failed
                        logger.warning(f"Task {task.task_id} requires input but no input_callback provided")
                        task.status = TaskStatus.FAILED
                        task.error = "Agent requires additional input but no input mechanism available"
                        del waiting_for_input_tasks[task_id]
                        completed_tasks[task_id] = task
                        
                        if callback:
                            callback(task)
            
            # Find tasks that can be executed (no pending dependencies)
            ready_tasks = []
            for task_id, task in list(pending_tasks.items()):
                deps_satisfied = all(
                    dep_id in completed_tasks and completed_tasks[dep_id].status == TaskStatus.COMPLETED
                    for dep_id in task.dependencies
                )
                
                if deps_satisfied:
                    # Add dependency results to task
                    for dep_id in task.dependencies:
                        if dep_id in completed_tasks:
                            task.dependency_results[dep_id] = completed_tasks[dep_id].response or ""
                    ready_tasks.append(task)
                    del pending_tasks[task_id]
            
            if not ready_tasks and not waiting_for_input_tasks:
                # No tasks ready - check for circular dependencies or failed dependencies
                for task_id, task in pending_tasks.items():
                    failed_deps = [
                        dep_id for dep_id in task.dependencies
                        if dep_id in completed_tasks and completed_tasks[dep_id].status == TaskStatus.FAILED
                    ]
                    if failed_deps:
                        task.status = TaskStatus.SKIPPED
                        task.error = f"Skipped due to failed dependencies: {failed_deps}"
                        completed_tasks[task_id] = task
                        logger.warning(f"Task {task_id} skipped due to failed dependencies")
                        # Send skipped task response if callback provided
                        if callback:
                            callback(task)
                
                # Remove skipped tasks from pending
                pending_tasks = {
                    tid: t for tid, t in pending_tasks.items()
                    if t.status != TaskStatus.SKIPPED
                }
                
                if pending_tasks:
                    # Circular dependency detected
                    logger.error("Circular dependency or unresolvable dependencies detected")
                    for task in pending_tasks.values():
                        task.status = TaskStatus.FAILED
                        task.error = "Circular dependency or unresolvable dependencies"
                        completed_tasks[task.task_id] = task
                        # Send failed task response if callback provided
                        if callback:
                            callback(task)
                    break
                else:
                    break
            
            # Execute ready tasks
            for task in ready_tasks:
                success = await self._execute_task(task)
                
                if task.status == TaskStatus.WAITING_FOR_INPUT:
                    # Task needs user input, add to waiting queue
                    waiting_for_input_tasks[task.task_id] = task
                    logger.info(f"Task {task.task_id} moved to waiting_for_input queue")
                    
                    # Notify via callback that task is waiting for input
                    if callback:
                        callback(task)
                else:
                    # Task completed or failed
                    completed_tasks[task.task_id] = task
                    
                    # Send task response as soon as it's available
                    if callback:
                        callback(task)
                    
                    # If task failed and other tasks depend on it, log warning
                    if not success:
                        logger.warning(f"Task {task.task_id} failed. Dependent tasks will be skipped.")
        
        return completed_tasks
    
    def _generate_summary(
        self,
        user_query: str,
        completed_tasks: Dict[str, OrchestratorTask]
    ) -> str:
        """
        Generate final summary of all task executions.
        
        Args:
            user_query: Original user query
            completed_tasks: Dictionary of completed tasks
            
        Returns:
            Formatted summary string
        """
        summary_parts = [
            "=" * 80,
            "ORCHESTRATOR EXECUTION SUMMARY",
            "=" * 80,
            f"\nOriginal Query: {user_query}\n",
            f"Total Tasks: {len(completed_tasks)}",
            ""
        ]
        
        # Group by status
        successful = [t for t in completed_tasks.values() if t.status == TaskStatus.COMPLETED]
        failed = [t for t in completed_tasks.values() if t.status == TaskStatus.FAILED]
        skipped = [t for t in completed_tasks.values() if t.status == TaskStatus.SKIPPED]
        waiting = [t for t in completed_tasks.values() if t.status == TaskStatus.WAITING_FOR_INPUT]
        
        summary_parts.append(f"✓ Successful: {len(successful)}")
        summary_parts.append(f"✗ Failed: {len(failed)}")
        summary_parts.append(f"⊝ Skipped: {len(skipped)}")
        if waiting:
            summary_parts.append(f"⏸ Waiting for Input: {len(waiting)}")
        summary_parts.append("\n" + "-" * 80)
        
        # Individual task results
        for task in completed_tasks.values():
            summary_parts.append(f"\n[{task.task_id}] {task.description}")
            summary_parts.append(f"Agent: {task.agent_name}")
            summary_parts.append(f"Status: {task.status.value.upper()}")
            
            if task.status == TaskStatus.COMPLETED and task.response:
                summary_parts.append(f"Response:\n{task.response}")
            elif task.error:
                summary_parts.append(f"Error: {task.error}")
            
            summary_parts.append("-" * 80)
        
        # Final summary
        summary_parts.append("\nFINAL SUMMARY:")
        if all(t.status == TaskStatus.COMPLETED for t in completed_tasks.values()):
            summary_parts.append("✓ All tasks completed successfully!")
        elif any(t.status == TaskStatus.COMPLETED for t in completed_tasks.values()):
            summary_parts.append("⚠ Some tasks completed, but others failed or were skipped.")
        else:
            summary_parts.append("✗ All tasks failed or were skipped.")
        
        summary_parts.append("=" * 80)
        
        return "\n".join(summary_parts)
    
    async def process_query(self, user_query: str, task_callback=None, input_callback=None) -> str:
        """
        Main entry point for processing user queries.
        
        Args:
            user_query: User's input query
            task_callback: Optional callback function called with each completed task
                          Signature: callback(task: OrchestratorTask) -> None
            input_callback: Optional async callback to collect user input for input_required tasks
                           Signature: async input_callback(task: OrchestratorTask) -> str
                           Should return the user's input string
            
        Returns:
            Response string (either direct response or execution summary)
        """
        logger.info(f"Processing query: {user_query}")

        
        # Plan tasks
        is_task_query, tasks, direct_response = await self._plan_tasks(user_query)
        
        # If not a task query, return direct response
        if not is_task_query:
            logger.info("Query is not a task query, returning direct response")
            return direct_response
        
        # If no tasks generated
        if not tasks:
            return "I understand your query, but I couldn't identify any specific tasks to execute. Could you please rephrase or provide more details?"
        
        logger.info(f"Generated {len(tasks)} tasks")
        
        # Execute tasks with callbacks
        completed_tasks = await self._execute_tasks(
            tasks, 
            callback=task_callback,
            input_callback=input_callback
        )
        
        # Generate and return summary
        summary = self._generate_summary(user_query, completed_tasks)
        # print(summary)
        return summary
    
    async def close(self):
        """Clean up resources"""
        for agent in self.remote_agents.values():
            if agent.client:
                try:
                    await agent.client.close()
                except Exception as e:
                    logger.error(f"Error closing client for {agent.name}: {e}")
        
        if self.httpx_client:
            await self.httpx_client.aclose()


# Example usage
async def main():
    """Example usage of the orchestrator agent"""

    from dotenv import load_dotenv
    from openai import AsyncAzureOpenAI
    load_dotenv()
    import os
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # List of remote agent URLs
    remote_agents = [
        "http://localhost:8000",
        "http://localhost:8080"
    ]

    # Create Azure OpenAI client for task planning
    azure_openai_client = AsyncAzureOpenAI(
        api_key=os.getenv("GPT4_AZURE_API_KEY"),
        api_version=GPT4_API_VERSION,
        azure_endpoint=GPT4_AZURE_ENDPOINT
    )

    # Create orchestrator with LLM client
    try:
        orchestrator = A2AOrchestratorAgent(
            remote_agent_urls=remote_agents,
            model_client=azure_openai_client
        )
    except ValueError as e:
        print(f"Error: {e}")
        print("Please provide a valid LLM model_client")
        return
    
    # Callback to receive task responses as they complete
    def task_response_callback(task: OrchestratorTask):
        print(f"\n[TASK RESPONSE] {task.task_id}: {task.status.value}")
        if task.status == TaskStatus.COMPLETED:
            print(f"Response: {task.response}")
        elif task.status == TaskStatus.WAITING_FOR_INPUT:
            print(f"Waiting for input: {task.input_required_message}")
        elif task.error:
            print(f"Error: {task.error}")
    
    # Callback to collect user input for tasks that need it
    async def input_callback(task: OrchestratorTask) -> str:
        """Collect user input for tasks that require additional information"""
        print(f"\n[INPUT REQUIRED] Task {task.task_id}")
        print(f"Agent message: {task.input_required_message}")
        print(f"Context ID: {task.remote_context_id}")
        print(f"Task ID: {task.remote_task_id}")
        
        # In a real implementation, this would get input from the user interface
        # For this example, we'll simulate user input
        user_input = input("Enter your response: ")
        return user_input
    
    await orchestrator.initialize()
    
    while True:
        # Process queries with callbacks
        query = input("\nEnter your query for the orchestrator: ")
        
        if not query == "quit":
        
            print(f"\n{'='*80}")
            print(f"Query: {query}")
            print('='*80)
            response = await orchestrator.process_query(
                query, 
                task_callback=task_response_callback,  # Get task responses immediately
                input_callback=input_callback  # Handle input_required tasks
            )
            print(response)
        else:
            break
            
    # finally:
    #     await orchestrator.close()


if __name__ == "__main__":
    asyncio.run(main())
