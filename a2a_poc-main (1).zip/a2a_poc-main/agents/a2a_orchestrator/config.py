"""
Configuration for the A2A Orchestrator Agent

This module provides configuration settings for the orchestrator.
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field


@dataclass
class OrchestratorConfig:
    """Configuration for the orchestrator agent"""
    
    # Remote agent URLs
    remote_agent_urls: List[str] = field(default_factory=list)
    
    # HTTP settings
    http_timeout: float = 30.0
    max_connections: int = 20
    max_keepalive_connections: int = 10
    verify_ssl: bool = True
    
    # Task execution settings
    max_retries: int = 2
    retry_delay: float = 1.0
    task_timeout: float = 300.0  # 5 minutes
    
    # LLM settings (optional)
    use_llm_planning: bool = False
    llm_endpoint: Optional[str] = None
    llm_api_key: Optional[str] = None
    llm_model: str = "gpt-4"
    llm_temperature: float = 0.7
    llm_max_tokens: int = 2000
    
    # Logging settings
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Advanced settings
    enable_streaming: bool = True
    enable_polling: bool = False
    max_concurrent_tasks: int = 5
    
    # Custom headers for all requests
    custom_headers: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            "remote_agent_urls": self.remote_agent_urls,
            "http_timeout": self.http_timeout,
            "max_connections": self.max_connections,
            "max_keepalive_connections": self.max_keepalive_connections,
            "verify_ssl": self.verify_ssl,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "task_timeout": self.task_timeout,
            "use_llm_planning": self.use_llm_planning,
            "llm_endpoint": self.llm_endpoint,
            "llm_model": self.llm_model,
            "llm_temperature": self.llm_temperature,
            "llm_max_tokens": self.llm_max_tokens,
            "log_level": self.log_level,
            "log_format": self.log_format,
            "enable_streaming": self.enable_streaming,
            "enable_polling": self.enable_polling,
            "max_concurrent_tasks": self.max_concurrent_tasks,
            "custom_headers": self.custom_headers,
        }
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "OrchestratorConfig":
        """Create config from dictionary"""
        return cls(**{k: v for k, v in config_dict.items() if hasattr(cls, k)})
    
    @classmethod
    def from_env(cls) -> "OrchestratorConfig":
        """Create config from environment variables"""
        import os
        
        config = cls()
        
        # Get agent URLs from environment
        agent_urls_str = os.getenv("A2A_AGENT_URLS", "")
        if agent_urls_str:
            config.remote_agent_urls = [
                url.strip() for url in agent_urls_str.split(",") if url.strip()
            ]
        
        # HTTP settings
        config.http_timeout = float(os.getenv("A2A_HTTP_TIMEOUT", "30.0"))
        config.verify_ssl = os.getenv("A2A_VERIFY_SSL", "true").lower() == "true"
        
        # LLM settings
        config.use_llm_planning = os.getenv("A2A_USE_LLM", "false").lower() == "true"
        config.llm_endpoint = os.getenv("A2A_LLM_ENDPOINT")
        config.llm_api_key = os.getenv("A2A_LLM_API_KEY")
        config.llm_model = os.getenv("A2A_LLM_MODEL", "gpt-4")
        
        # Logging
        config.log_level = os.getenv("A2A_LOG_LEVEL", "INFO")
        
        return config


# Default configuration
DEFAULT_CONFIG = OrchestratorConfig()


# Example configurations
DEVELOPMENT_CONFIG = OrchestratorConfig(
    remote_agent_urls=[
        "http://localhost:8001",
        "http://localhost:8002",
    ],
    http_timeout=60.0,
    log_level="DEBUG",
)

PRODUCTION_CONFIG = OrchestratorConfig(
    remote_agent_urls=[],  # Set via environment
    http_timeout=30.0,
    max_retries=3,
    verify_ssl=True,
    log_level="INFO",
    use_llm_planning=True,
)
