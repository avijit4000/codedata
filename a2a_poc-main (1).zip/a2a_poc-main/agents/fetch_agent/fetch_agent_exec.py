from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import (
    InternalError,
    InvalidParamsError,
    Part,
    TaskState,
    TextPart,
    UnsupportedOperationError,
    TaskStatusUpdateEvent
)
from a2a.utils import (
    new_agent_text_message,
    new_task,
)
from a2a.utils.errors import ServerError

import json, asyncio

from agents.a2a_orchestrator.orchestrator import TaskStatus
from agents.fetch_agent.fetch_agent import invoke_fetch_agent, create_runtime

class FetchAgentExecutor(AgentExecutor):
    "An executor for the Fetch Agent."

    def __init__(self):
        self._ag_runtime = asyncio.run(create_runtime())

    async def execute(
        self,
        request_context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        
        
        try:
            user_message = request_context.get_user_input()
            
            task = request_context.current_task

            if not task:
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)

            task_updater = TaskUpdater(event_queue, task.id, task.context_id)

            response = await invoke_fetch_agent(self._ag_runtime, user_message)

            response  = json.loads(response)

            print("response received in the executor:\n", response)

            print(type(response))

            if response.get("status") == "error":
                await task_updater.update_status(
                    TaskState.failed,
                    new_agent_text_message(
                            str(response.get("fetched_data")),
                            task.context_id,
                            task.id,
                        ),
                        final=True,
                )

                # or

                # await event_queue.enqueue_event(
                #     TaskStatusUpdateEvent(
                #         status=TaskStatus(
                #             state=TaskState.ERROR,
                #             message=new_agent_text_message(
                #                  response.get("fetched_data"),
                #                 task.context_id,
                #                 task.id,
                #             ),
                #         ),
                #         final=True,
                #         context_id=task.context_id,
                #         task_id=task.id,
                #     )
                # )
            elif response.get("status") == "input_required":
                await task_updater.update_status(
                    TaskState.input_required,
                    new_agent_text_message(
                            str(response.get("fetched_data")),
                            task.context_id,
                            task.id,
                        ),
                        final=False,
                )
            elif response.get("status") == "completed":
                await task_updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(
                            str(response.get("fetched_data")),
                            task.context_id,
                            task.id,
                        ),
                        final=True,
                ) 
            
            else:
                await task_updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(
                        str(response.get("fetched_data")),
                            task.context_id,
                            task.id,
                    ),
                    final=True,
                )
        except Exception as e:
            # print(f"FetchAgentExecutor failed: {str(e)}")
            raise InternalError(f"Fetch Agent Executor failed: {str(e)}")
        
    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        raise ServerError(error=UnsupportedOperationError())

