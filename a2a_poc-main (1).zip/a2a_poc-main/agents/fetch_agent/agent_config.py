from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams


fetcher_agent_prompt = """You are a helpful assistant that fetches latency report using the tools provided. 
                        If the date provided is not in the correct format, convert it to the format accepted by the tool.
                        Today's date is 2025-11-25.

                        'Set response status to input_required if the user needs to provide more information to complete the request.'
                        'Set response status to error if there is an error while processing the request.'
                        'Set response status to completed if the request is complete.'

                        Strictly return a JSON response in the following format. Do not include the word json in your response:
                        {
                            "status": "input_required" | "error" | "completed",
                            "fetched_data": "fetched data or the error message or the message asking for more information"
                        }
                        """

agent_name = "fetcher_agent"
agent_type = "fetcher_agent"
agent_description = """An agent that fetches latency report using MCP tools.
                    It can fetch latency report for specific dates or date ranges.
                    Provide insights on the fetched latency report data."""

# MCP Server Parameters for Fetch Agent
# Either a single MCP server params or a list of MCP server params can be provided.
mcp_params = StdioServerParams(
        command = "python",
        args = ["-m", "mcps.pull_metric_api"],
        )
