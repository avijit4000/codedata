import asyncio
import logging
from typing import Any
from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.server.sse import SseServerTransport
from mcp.types import (
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
)
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.responses import JSONResponse
import uvicorn
from pull_metric_api import fetch_latency_report
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("latency-report-mcp-server")

# Create MCP server instance
mcp_server = Server("latency-report-server")

@mcp_server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """
    List available tools.
    """
    return [
        Tool(
            name="fetch_latency_report",
            description="""
            Fetch latency report data from the API with optional filtering.
            
            Parameters:
            - day: Single date to filter (YYYY-MM-DD format)
            - days: Multiple dates as comma-separated string (e.g., "2025-11-13,2025-11-14")
            - start_date: Start date for range filter (YYYY-MM-DD)
            - end_date: End date for range filter (YYYY-MM-DD)
            - app: Specific application to filter (e.g., UMS, AMP)
            
            Filtering precedence:
            1. If 'day' provided -> return only that day
            2. Else if 'days' provided -> return those days
            3. Else if 'start_date' provided -> return date range
            4. Else return all data
            """,
            inputSchema={
                "type": "object",
                "properties": {
                    "day": {
                        "type": "string",
                        "description": "Single date to filter (YYYY-MM-DD)",
                    },
                    "days": {
                        "type": "string",
                        "description": "Comma-separated dates (YYYY-MM-DD,YYYY-MM-DD)",
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date for range (YYYY-MM-DD)",
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date for range (YYYY-MM-DD)",
                    },
                    "app": {
                        "type": "string",
                        "description": "Specific application name (e.g., UMS, AMP)",
                    },
                },
                "additionalProperties": False,
            },
        )
    ]


@mcp_server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict[str, Any] | None
) -> list[TextContent | ImageContent | EmbeddedResource]:
    """
    Handle tool execution requests.
    """
    if name != "fetch_latency_report":
        raise ValueError(f"Unknown tool: {name}")

    if not arguments:
        arguments = {}

    try:
        # Extract parameters
        day = arguments.get("day")
        days_str = arguments.get("days")
        start_date = arguments.get("start_date")
        end_date = arguments.get("end_date")
        app = arguments.get("app")

        # Parse days if provided
        days = None
        if days_str:
            days = [d.strip() for d in days_str.split(",")]

        # Call the fetch function
        logger.info(f"Fetching latency report with params: {arguments}")
        result = fetch_latency_report(
            day=day,
            days=days,
            start_date=start_date,
            end_date=end_date,
            app=app
        )

        # Format response
        response = {
            "status": "success",
            "data": result,
            "filters_applied": {
                "day": day,
                "days": days,
                "start_date": start_date,
                "end_date": end_date,
                "app": app
            },
            "summary": {
                "total_apps": len(result),
                "total_records": sum(len(records) for records in result.values())
            }
        }

        return [
            TextContent(
                type="text",
                text=json.dumps(response, indent=2)
            )
        ]

    except Exception as e:
        logger.error(f"Error fetching latency report: {e}", exc_info=True)
        error_response = {
            "status": "error",
            "error": str(e),
            "type": type(e).__name__
        }
        return [
            TextContent(
                type="text",
                text=json.dumps(error_response, indent=2)
            )
        ]


# Starlette app for HTTP endpoints
async def handle_sse(request):
    """Handle SSE endpoint for MCP"""
    logger.info("SSE connection established")
    
    sse = SseServerTransport("/messages")
    
    async with sse.connect_sse(
        request.scope,
        request.receive,
        request._send
    ) as streams:
        await mcp_server.run(
            streams[0],
            streams[1],
            InitializationOptions(
                server_name="latency-report-server",
                server_version="1.0.0",
                capabilities=mcp_server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


async def handle_health(request):
    """Health check endpoint"""
    return JSONResponse({
        "status": "healthy",
        "service": "latency-report-mcp-server",
        "version": "1.0.0",
        "transport": "SSE"
    })


# Create Starlette app
app = Starlette(
    debug=True,
    routes=[
        Route("/sse", endpoint=handle_sse),
        Route("/health", endpoint=handle_health),
    ],
)


async def main():
    """
    Main entry point for the MCP SSE server.
    """
    host = "localhost"
    port = 8080
    
    logger.info(f"Starting MCP SSE server on http://{host}:{port}")
    logger.info(f"Endpoints:")
    logger.info(f"  - Health: http://{host}:{port}/health")
    logger.info(f"  - SSE: http://{host}:{port}/sse")
    
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level="info"
    )
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    asyncio.run(main())