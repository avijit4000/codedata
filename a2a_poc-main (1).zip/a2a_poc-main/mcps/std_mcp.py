from typing import Any, Dict, Iterable, Optional, Literal
from mcp.server.fastmcp import FastMCP
from .pull_metric_api import fetch_latency_report

# Initialize FastMCP server
mcp = FastMCP("latency_report")

@mcp.tool(strict=False)
async def latency_report_tool(
    day: Optional[str] = None,
    days: Optional[Iterable[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None, 
    app: Optional[Literal["UMS", "AMP", "All"]] = None
) -> Dict[str, Any]:
    
    """
    Fetch latency report JSON and optionally filter by date(s).

    Args:
        day: Single date to filter (YYYY-MM-DD).
        days: Iterable of dates to filter (YYYY-MM-DD).
        start_date: Start date for range filter (YYYY-MM-DD).
        end_date: End date for range filter (YYYY-MM-DD).
        app: Application filter ("UMS", "AMP", or "All").


    Date format: YYYY-MM-DD
    Filtering precedence:
      1. If day provided -> return only that day.
      2. Else if days iterable provided -> return those days.
      3. Else if start_date (and optional end_date) provided -> range filter.
      4. Else return all data.

    Returns dict with same top-level keys (e.g. UMS, AMP) each containing filtered list.
    """
    return fetch_latency_report(
        day=day,
        days=days,
        start_date=start_date,
        end_date=end_date,
        app=app
    )

def main():
    # Initialize and run the server
    mcp.run(transport='stdio')

if __name__ == "__main__":
    main()
