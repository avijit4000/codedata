GPT4_AZURE_ENDPOINT = "https://gpdacq-team-1-eastus-openai.openai.azure.com/"
GPT4_AZURE_DEPLOYMENT = "gpd-ops-gpt-4o"
GPT35_AZURE_DEPLOYMENT = "gpd-ops-gpt-35-turbo"
GPT4_API_VERSION = "2024-12-01-preview"
GPT4_MODEL_NAME = "gpt-4o"


import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)