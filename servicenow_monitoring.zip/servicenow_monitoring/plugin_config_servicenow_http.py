from src.LLM.plugins.MCPPlugin import MCPPlugin
from .servicenow_functions import (
    get_ytd_incident_metrics,
    get_last_month_incident_metrics,
    get_incident_summary
)

servicenow_plugin = MCPPlugin(
    name="servicenow_monitoring",
    description="ServiceNow Incident & ITSM Metrics Plugin via DataMart",
    functions={
        "get_ytd_incident_metrics": get_ytd_incident_metrics,
        "get_last_month_incident_metrics": get_last_month_incident_metrics,
        "get_incident_summary": get_incident_summary,
    }
)
