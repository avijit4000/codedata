from mcp.server.fastmcp import FastMCP
from .servicenow_datamart_api import run_full_datamart_job

# Create MCP instance
servicenow_plugin = FastMCP(
    name="ServiceNow Monitoring Plugin",
    stateless_http=True
)

mcp = servicenow_plugin  # required for multi_server_http_example.py


# ---------------- MCP TOOL ----------------
@servicenow_plugin.tool()
async def run_servicenow_datamart():
    """
    Runs ServiceNow DataMart DB metrics job and sends data to Logstash.
    """
    result = run_full_datamart_job()
    return {
        "status": "success",
        "records_processed": len(result),
        "message": "ServiceNow DataMart metrics collected and sent to Logstash"
    }
