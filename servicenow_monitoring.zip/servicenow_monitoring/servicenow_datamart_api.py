import psycopg2
import os
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dotenv import load_dotenv

load_dotenv()


class ServiceNowDataMartAPI:
    def __init__(self):
        self.conn = psycopg2.connect(
            host="itsm_dm_prod.optum.com",
            database="itsm_dm",
            user=os.getenv("DATA_MART_DB_USER"),
            password=os.getenv("DATA_MART_DB_PASSWORD"),
            port="5432"
        )

    def format_date(self, date):
        return date.strftime('%m/%d/%Y')

    def run_query(self, start_date, end_date):
        query = f"""
        SELECT AVG(MTD), AVG(MTE), AVG(MTI), AVG(MTR), AVG(MTW)
        FROM your_precomputed_metrics_view
        WHERE open_time BETWEEN '{start_date}' AND '{end_date}'
        """
        with self.conn.cursor() as cur:
            cur.execute(query)
            row = cur.fetchone()
        return {
            "MTTD": row[0],
            "MTTE": row[1],
            "MTTI": row[2],
            "MTTR": row[3],
            "MTTW": row[4],
        }

    def get_ytd_metrics(self):
        today = datetime.today()
        start_date = datetime(today.year, 1, 1)
        return self.run_query(self.format_date(start_date), self.format_date(today))

    def get_last_month_metrics(self):
        today = datetime.today()
        last_month = today - relativedelta(months=1)
        start_date = datetime(last_month.year, last_month.month, 1)
        end_date = datetime(today.year, today.month, 1) - timedelta(days=1)
        return self.run_query(self.format_date(start_date), self.format_date(end_date))


servicenow_api = ServiceNowDataMartAPI()
