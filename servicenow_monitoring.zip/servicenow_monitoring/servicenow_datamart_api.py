from datetime import datetime
from .servicenow_functions import (
    generate_prev_month_date_ranges,
    generate_yearly_date_ranges,
    generate_YTD_date_ranges
)
from .datamart_core import run_sql_with_date_ranges, save_to_json, send_to_logstash


def run_full_datamart_job():
    all_data = []
    today = datetime.today()

    if today.day == 1:
        all_data += run_sql_with_date_ranges(generate_prev_month_date_ranges(), "monthly")

    if today.month == 1 and today.day == 1:
        all_data += run_sql_with_date_ranges(generate_yearly_date_ranges(), "yearly")

    all_data += run_sql_with_date_ranges(generate_YTD_date_ranges(), "ytd")

    save_to_json(all_data)
    send_to_logstash(all_data)

    return all_data
