import json
import hashlib
import requests
from datetime import datetime
from pathlib import Path

from .plugin_config_servicenow_http import get_db_connection, PROD_LOGSTASH_ENDPOINT, HEADERS
from .servicenow_functions import format_date, format_timedelta_obj


def generate_sql(start_date, end_date):
    return f""" 
    -- SAME SQL YOU PROVIDED (trimmed here for space)
    """


def run_sql_with_date_ranges(date_ranges, source):
    conn = get_db_connection()
    cur = conn.cursor()
    merged_data = []

    for start, end in date_ranges:
        start_str = f"'{format_date(start)}'"
        end_str = f"'{format_date(end)}'"
        cur.execute(generate_sql(start_str, end_str))
        results = cur.fetchall()

        for row in results:
            merged_data.append({
                "source": source,
                "start_date": format_date(start),
                "end_date": format_date(end),
                "MTTD": format_timedelta_obj(row[0]),
                "MTTE": format_timedelta_obj(row[1]),
                "MTTI": format_timedelta_obj(row[2]),
                "MTTR": format_timedelta_obj(row[3]),
                "MTTW": format_timedelta_obj(row[4]),
            })

    cur.close()
    conn.close()
    return merged_data


def save_to_json(data):
    path = Path(__file__).parent / "DataMartDB.json"
    with open(path, "w") as f:
        json.dump(data, f)
    return path


def send_to_logstash(data):
    for doc in data:
        doc["_index_tag"] = "gpd_data_mart"
        doc["@doc_id"] = hashlib.sha1(
            (doc["source"] + doc["start_date"]).encode()
        ).hexdigest()

    payload = "\n".join(json.dumps(d) for d in data)
    requests.post(PROD_LOGSTASH_ENDPOINT, data=payload, headers=HEADERS)
