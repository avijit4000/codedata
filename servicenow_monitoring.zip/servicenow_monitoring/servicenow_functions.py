from typing import Dict, Any
from .servicenow_datamart_api import servicenow_api


def get_ytd_incident_metrics() -> Dict[str, Any]:
    try:
        data = servicenow_api.get_ytd_metrics()
        return {"status": "success", "period": "YTD", "metrics": data}
    except Exception as e:
        return {"error": str(e)}


def get_last_month_incident_metrics() -> Dict[str, Any]:
    try:
        data = servicenow_api.get_last_month_metrics()
        return {"status": "success", "period": "Last Month", "metrics": data}
    except Exception as e:
        return {"error": str(e)}


def get_incident_summary() -> str:
    try:
        ytd = servicenow_api.get_ytd_metrics()
        last_month = servicenow_api.get_last_month_metrics()

        return f"""
📊 ServiceNow Incident Performance Summary

🔹 YTD Metrics:
- MTTD: {ytd['MTTD']} mins
- MTTR: {ytd['MTTR']} mins

🔹 Last Month:
- MTTD: {last_month['MTTD']} mins
- MTTR: {last_month['MTTR']} mins
"""
    except Exception as e:
        return f"Error generating summary: {str(e)}"
