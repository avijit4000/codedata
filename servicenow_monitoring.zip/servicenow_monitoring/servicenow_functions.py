from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta


def format_date(date):
    return date.strftime('%m/%d/%Y')


def format_timedelta_obj(time_delta_obj):
    if time_delta_obj is None or time_delta_obj == 0:
        return "0"

    total_seconds = time_delta_obj.total_seconds()
    total_minutes = total_seconds / 60
    total_minutes += time_delta_obj.microseconds / (60 * 10**6)
    return str(total_minutes)


# ---------------- DATE RANGE GENERATORS ----------------

def generate_monthly_date_ranges():
    today_dt = datetime.today()
    today = today_dt.date()
    this_month_start = today_dt.replace(day=1).date()

    date_ranges = [(this_month_start, today)]

    for i in range(1, 37):
        start_prev = this_month_start - relativedelta(months=i)
        end_prev = start_prev + relativedelta(months=1) - timedelta(days=1)
        date_ranges.append((start_prev, end_prev))

    return date_ranges


def generate_prev_month_date_ranges():
    today = datetime.today()
    last_month = today - relativedelta(months=1)
    start_date = datetime(last_month.year, last_month.month, 1).date()
    end_date = datetime(today.year, today.month, 1).date() - timedelta(days=1)
    return [(start_date, end_date)]


def generate_YTD_date_ranges():
    today = datetime.today()
    ranges = []

    for i in range(3):
        year = today.year - i
        start_date = datetime(year, 1, 1).date()
        end_date = datetime(year, today.month, today.day).date()
        ranges.append((start_date, end_date))

    return ranges


def generate_yearly_date_ranges():
    today = datetime.today()
    ranges = []

    for i in range(1, 4):
        year = today.year - i
        start_date = datetime(year, 1, 1).date()
        end_date = datetime(year, 12, 31).date()
        ranges.append((start_date, end_date))

    return ranges
