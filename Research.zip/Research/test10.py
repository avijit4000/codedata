import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
# import speech_recognition as sr
# import pyttsx3


load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")
print(azure_model, api_version, azure_endpoint, api_key)

# engine = pyttsx3.init()
# engine.setProperty('rate', 150)
# engine.setProperty('volume', 0.8)
#
# recognizer = sr.Recognizer()


llm = AzureChatOpenAI(
    openai_api_key=api_key,
    azure_endpoint=azure_endpoint,
    azure_deployment=azure_model,
    api_version=api_version,
    temperature=0.0
)
user_input = """ City  """

# question_template = """
# You are a helpful form-filling assistant.
#
# Your job is to ask the user only the specific question needed to fill out a form.
#
# Instructions:
# - If the user input is "last name", respond with exactly: "What is your last name?"
# - If the user input is "date of birth", respond with exactly: "What is your date of birth?"
# - If the user input is "gender", respond with exactly: "What is your gender?"
# - For any other input (e.g., "medicare number", "passport number", "phone number", "address"), respond with exactly: "What is your {user_input}?"
#
# Important rules:
# - Return **only the question**.
# - Do not include explanations, prefixes, or any extra text.
# - Do not attempt to extract information from the input; just ask the appropriate question.
#
# Input: "{user_input}"
#
# Output:
# """

question_template = f"""
            You are a helpful and precise form-filling assistant.

            Your job is to ask the user exactly the specific question needed to fill out a form field based on the field name provided.

            Instructions:
            - Return **only the question** in clear, human-readable form.

            Examples:
            - "First name" → "What is your first name?"
            - "Sex" → "What is your sex? (Male/Female/Other)"
            - "Phone Type" → "Please select your phone type (e.g., Mobile, Home, Work)."
            - "Submit Application" → "Please click the Submit Application button to proceed."
            - "I am losing coverage I had from an employer." → "Are you losing coverage you had from an employer? (Yes/No)"

            Input: "{user_input}"

            Output:
            """


Q_CHAIN_PROMPT = PromptTemplate(
    input_variables=["user_input"],
    template=question_template
)

asking_chain = LLMChain(
    llm=llm,
    prompt=Q_CHAIN_PROMPT,
    verbose=True
)

asking_result = asking_chain.run(user_input=user_input)
asking_question=asking_result.strip()

print(asking_question)
# engine.say(asking_question)
# engine.runAndWait()


user_ans = """My name is Avijit Biswas. My date of birth is 19 Apr 1999."""
# user_ans= input(f"{asking_question} ")
# # with sr.Microphone() as source:
# #     print("Please speak now...")
# #     recognizer.adjust_for_ambient_noise(source)
# #     audio = recognizer.listen(source)
# #     user_ans = recognizer.recognize_google(audio)
print(f"{user_ans}")

# template = f"""
# You are a helpful assistant. A question was asked: "{asking_question}".
#
# Based on the user's input below, provide **only the exact answer** relevant to the question.
# Do not add any extra text, explanations, or punctuation.
#
# User input: "{user_ans}"
#
# Output:
# """

template = f"""
 You are a helpful assistant. A question was asked: "{asking_question}".

 Based on the user's input below, provide **only the exact answer** relevant to the question.

 - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
 - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.

 User input: "{user_ans}"

 Output:
 """


A_CHAIN_PROMPT = PromptTemplate(
    input_variables=["user_input"],
    template=template
)

ans_chain = LLMChain(
    llm=llm,
    prompt=A_CHAIN_PROMPT,
    verbose=True
)

ans_result = ans_chain.run(user_input=user_ans)

ans_output=ans_result.strip()
print(ans_output)

# engine.say(ans_output)
# engine.runAndWait()