import azure.cognitiveservices.speech as speechsdk

SPEECH_KEY = "AZURE_SPEECH_KEY"
SPEECH_REGION = "AZURE_REGION"

def speech_to_text():
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
    print("🎤 Speak now...")
    result = recognizer.recognize_once()
    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        print(f"Recognized: {result.text}")
        return result.text
    else:
        print("No speech recognized.")
        return ""

def text_to_speech(text):
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"  # Change voice as needed
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
    synthesizer.speak_text_async(text).get()

if __name__ == "__main__":
    while True:
        text = speech_to_text()
        if text:
            # Optionally, send text to Azure OpenAI for processing here
            text_to_speech(text)