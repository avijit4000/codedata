def main():
    print("Hello from mcpcrashcourse!")


if __name__ == "__main__":
    main()
