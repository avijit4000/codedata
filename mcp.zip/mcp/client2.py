
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
import requests
import asyncio
import os
from bs4 import BeautifulSoup  # for parsing HTML

# Load environment variables
load_dotenv()
# dotenv_path="D:/Pyn/Test_work/LLMs/.env"
# Custom tool to fetch info from dashboard
async def fetch_dashboard_data(query: str) -> str:
    """
    Fetch data from Optum dashboard and extract key information.
    (You can modify based on how the dashboard exposes info.)
    """
    url = "http://mr-portals-monitoring.optum.com/acquisition/overview/ampKeyMetricsView"
    try:
        response = requests.get(url, timeout=10)
        soup = BeautifulSoup(response.text, "html.parser")

        # Example: extract metric cards, tables, or text content
        metrics = soup.get_text(separator=" ", strip=True)[:2000]  # limit content
        return f"Dashboard data summary (truncated): {metrics}"
    except Exception as e:
        return f"Failed to fetch dashboard: {e}"

async def main():
    client = MultiServerMCPClient({
        "math": {"command": "python", "args": ["mathserver.py"], "transport": "stdio"},
        "weather": {"url": "http://localhost:8000/mcp", "transport": "streamable_http"},
    })

    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    azure_model = os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini")

    model = AzureChatOpenAI(
        azure_endpoint=azure_endpoint,
        api_key=api_key,
        api_version=api_version,
        azure_deployment=azure_model,
        temperature=0.3,
    )

    tools = await client.get_tools()

    # Add dashboard info tool
    async def dashboard_tool(input_text: str):
        return await fetch_dashboard_data(input_text)

    # Add tool manually
    tools.append({
        "name": "fetch_dashboard_info",
        "description": "Fetches and interprets metrics from Optum monitoring dashboard.",
        "func": dashboard_tool,
    })

    agent = create_agent(model, tools)

    print("🤖 Ask_Isaac is ready! Type your question or 'quit' to exit.\n")

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ["quit", "exit"]:
            print("👋 Goodbye from Ask_Isaac!")
            break

        try:
            # If question contains keyword related to dashboard, trigger fetch
            if "metric" in user_input.lower() or "dashboard" in user_input.lower():
                dashboard_info = await fetch_dashboard_data(user_input)
                user_input += f"\n\nReference data:\n{dashboard_info}"

            response = await agent.ainvoke(
                {"messages": [{"role": "user", "content": user_input}]}
            )
            print("Ask_Isaac:", response["messages"][-1].content)

        except Exception as e:
            print("⚠️ Error:", e)


if __name__ == "__main__":
    asyncio.run(main())