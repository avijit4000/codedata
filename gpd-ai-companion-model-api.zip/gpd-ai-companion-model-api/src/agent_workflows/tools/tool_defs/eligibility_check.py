"""  
This module defines the `medicaid_eligibility_check` function
This module provides functionalities to query an eligibility check api using dob, gender , medicaid number , plan etc . It includes a Pydantic model as the `args_schema` 
and corresponding function to execute
"""

from typing import Optional, Literal
from pydantic import BaseModel, Field
import logging
from ...utils.data_models import Plan, Chunk 
from ...utils.utils import get_fips_state_code,extract_names,fetch,get_eligibility_bearer_token
from ...globals import ELIGIBILITY_CHECK_API_ENDPOINT , all_plans_24541
from llama_index.core.workflow import Context
import httpx




logger = logging.getLogger("agents.tools.medicaid_eligibility_check")



    
async def eligibility_check_api(gender,date_of_birth,medicaid_number, full_name ,mbi,proposed_effective_date,plans):
    """
    Asynchronously queries eligibility lookup api using following params
    Args:
        gender (str): The user's
        date_of_birth (str): The date of birth to check.
        medicaid_number (str): The medicaid number to check.
        full_name (str): The full name to check.
        plan (Plan): The plan to filter by.
        plan_id (str): The plan ID to filter by.
    
    Returns:

        list[()]: A list of tuples , where each tuple eligibility details.
    """
        
    try:
        
        
        zip_code = plans[0]['zip'] 
        
        plan_year = plans[0]['plan_year'] 
        
        eligibility_lookup_url = ELIGIBILITY_CHECK_API_ENDPOINT
        
        logger.info(eligibility_lookup_url)       
        
        fips_code,state_code = get_fips_state_code(zip_code)
        
        first_name,middle_name,last_name = extract_names(full_name)
        
        all_plans = all_plans_24541
        
        
        
        dsnp_plans = [plan for plan in all_plans if "D-SNP" in plan['plan_name'].upper()]
        non_dsnp_plans = [plan for plan in all_plans if "D-SNP" not in plan['plan_name'].upper()]
        
        
        if (medicaid_number !="00000" and mbi != "000X00XX0XX00"):
            
            
            
            all_plan_ids = [plan['plan_id'] for plan in all_plans]
            
            payload = {
            "eligibilityType": "MEDICAID",
            "medicare": {
                "medicareNumber": mbi,
                "dateOfBirth": date_of_birth,
                "proposedEffectiveDate": proposed_effective_date
            },
            "medicaid": {
                "gender": gender,
                "dob": date_of_birth,
                "stateCode": state_code,
                "fipsCode": fips_code,
                "zip": zip_code,
                "firstName": first_name,
                "lastName": last_name,
                "medicaidNumber": medicaid_number,
                "planList": all_plan_ids,
                "ssn": "" ,
                "proposedEffectiveDate": "",
                "currentYear": plan_year,
            }
            }
               
            
        elif(medicaid_number =="00000" or medicaid_number == '') and (mbi != '' or mbi != "000X00XX0XX00"):
            
            non_dsnp_plan_ids = [plan['plan_id'] for plan in non_dsnp_plans]
            
            all_plans = non_dsnp_plans
            
            
            
            payload = {
            "eligibilityType": "MEDICARE",
            "medicare": {
                "medicareNumber": mbi,
                "dateOfBirth": date_of_birth,
                "proposedEffectiveDate": proposed_effective_date
            }
            }
        elif(medicaid_number !="00000" or medicaid_number != '') and (mbi == '' or mbi == "000X00XX0XX00"):
            
            
            
            dsnp_plan_ids = [plan['plan_id'] for plan in dsnp_plans]
            
            all_plans = dsnp_plans
            
            payload = {
            "eligibilityType": "MEDICAID",
            "medicaid": {
                "gender": gender,
                "dob": date_of_birth,
                "stateCode": state_code,
                "fipsCode": fips_code,
                "zip": zip_code,
                "firstName": first_name,
                "lastName": last_name,
                "medicaidNumber": medicaid_number,
                "planList": dsnp_plan_ids,
                "ssn": "" ,
                "proposedEffectiveDate": "",
                "currentYear": plan_year,
            }
            } 
        else:
            logger.error("Both medicaid_number and mbi are not provided or invalid. Please provide valid inputs.")
            return [("ERROR", "Both medicaid_number and mbi are not provided or invalid. Please provide valid inputs.","")]
            
            
        
        eligibility_payload = payload
        
    
        headers = {
        'Authorization': f'Bearer {get_eligibility_bearer_token()}',
        'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient(timeout=120) as client:
            

            try:
                
                # logger.debug(details_payload)
                
                
            
                details_response = await fetch(client, eligibility_lookup_url, method='POST', headers=headers, data=eligibility_payload)  

                if details_response is None:
                    
                    logger.debug("No eligibility details found for the given inputs.")
                    
                    return [("NO_SEARCH_RESULTS","No eligibility details found for the given inputs.")]
                
                    #eligibility_details = []
                else:
                    
                    
                    eligibility_details  = [(details_response,plans,all_plans)]
                    
                    

                    logger.debug(eligibility_details)

                    return eligibility_details
                
        
            except httpx.RequestError as e:
                
                logger.error(f"An error occurred: {e}")
                return [("ERROR", f"An error occurred: {e}","")]
    except Exception as e:
        
        logger.error(f"An error occurred: {e}")
        return [("ERROR", f"An error occurred: {e}","")]
    
    
    
def parse_and_check_eligibility(data: dict, plans : list[dict], all_plans :list[dict]) -> str:
    """
    Parses the eligibility data and applies the conditions for DSNP and non-DSNP plans.

    Args:
        data (dict): The eligibility data from the API response.
        plan (Plan): The plan to check eligibility for.
        zip_code (str): The user's ZIP code.

    Returns:
        str: A message indicating the eligibility status.
    """
    try:
                
        
        
        medicare_eligible = data.get("data", {}).get("medicareEligible", False)
        medicaid_eligibility = data.get("data", {}).get("medicaidEligible", [])
        
        eligible_plans = []
        not_eligible_palns = []
        input_plans = [plan['plan_name'] for plan in plans if len(plans)>0]
        
            
        for plan in all_plans:
            # Check if the plan is DSNP
            is_dsnp = "D-SNP" in plan['plan_name'].upper()

            if not is_dsnp:
                # Non-DSNP plan: Check Medicare eligibility only
                #if medicare_eligible:
                eligible_plans.append(plan['plan_name'])
                    
                # else:
                #     not_eligible_palns.append(plan['plan_name'])
                    
            else:
                
                # Check if the user is eligible for Medicaid
                medicaid_eligible = any(entry["eligible"] for entry in medicaid_eligibility if entry["planId"] == plan['plan_id'])

                if medicare_eligible and medicaid_eligible:
                    eligible_plans.append(plan['plan_name'])
                else :
                    not_eligible_palns.append(plan['plan_name'])
                    
        
        
        input_eligible_plans = list(set(input_plans).intersection(set(eligible_plans)))
        
        input_not_eligible_plans = list(set(input_plans).intersection(set(not_eligible_palns)))
        
        not_able_to_check_plans = list(set(input_plans).difference(set(not_eligible_palns)))
        
        if len(not_able_to_check_plans) > 0 : 
            input_not_eligible_plans.extend(not_able_to_check_plans)
        
        other_eligible_plans = list(set(eligible_plans).difference(set(input_eligible_plans)))
        
        if (len(input_plans) != 0) and (list(set(input_plans))[0] !="") :
            if len(eligible_plans)==0:
                output_text = f"You are not eligible for given plans {','.join(input_plans)} or any other plan in this ZIP code  ."
            else:
                if len(input_eligible_plans) == len(input_plans):
                    output_text = f"You are eligible for all the selected plans: {', '.join(input_eligible_plans)}."
                else:
                    if len(input_eligible_plans) == 0 :
                        output_text = f"You are not eligible for selected  plans {','.join(input_plans)} but here are other plans in the zip that you are eligible for {'.'.join(other_eligible_plans)} ."
                    
                    else:
                        output_text = f"You are eligible for {','.join(input_eligible_plans)} but not eligible for {','.join(input_not_eligible_plans)}."
        
        else :
            output_text = f"You are eligible for the following plans: {', '.join(eligible_plans)}. However, you are not eligible for : {', '.join(not_eligible_palns)}."        
        
        
            
        return output_text
    except Exception as e:
        logger.error(f"An error occurred while parsing eligibility {str(data)+str(plans)}: {e}")
        return "An error occurred while checking eligibility. Please try again later."
            
            


async def eligibility_check_api_response(gender:str,
date_of_birth:str,
medicaid_number:str,
full_name:str,
mbi: str,
proposed_effective_date: str,
plans: list[Plan]
) -> list[Chunk]:
    """
    Asynchronously queries eligibility lookup api using  returning relevant eligibility details .

    Args:
    
        gender (str): The user's gender to filter by.
        medicaid_number (str): medicaid number to filter by.
        plan (Plan): The plan to filter by.
        full_name (str): The full name to filter by.
        date_of_birth (str): The date of birth to filter by.

    Returns:
        list[()]: A list of tuples , where each tuple eligibility details.
    """
    

    # logger.debug(
    #     f" gender :{gender},  date_of_birth :{date_of_birth} , medicaid_number :{medicaid_number} , full_name : {full_name}, plan :{plan}"
    # )
    
    result = await eligibility_check_api(gender,date_of_birth,medicaid_number,full_name,mbi,proposed_effective_date,plans) 
    
    results_msg_text = "\n******FOR GIVEN INPUTS, HERE ARE THE ELIGIBILITY DETAILS *******\n"
    
    
    if len(result) == 1 and result[0][0] =='ERROR':  
        results_msg_text = "\n****** ELIGIBILITY API IS DOWN , NOT ABLE TO FETCH  DETAILS AT THE MOMENT *******\n"

    logger.debug(result)
    
    
    return [
            Chunk(
                
                doc_text="eligibility_details :" + str(parse_and_check_eligibility(item[0],item[1],item[2])),
                url=None,
                section=None,
                url_title=None,

            )
            for item in result] , results_msg_text
    



def format_eligibility_check_results(eligibility_detail_chunks: list[Chunk],results_msg_text : str) -> str:
    """
    Formats a list of document chunks into a string containing marked sources.

    Args:
        chunks (list[Chunk]): A list of Chunks, each containing a document chunk.

    Returns:
        str: A string that includes source labels and content for each document chunk.
    """
    formatted_response = f"{results_msg_text}# Sources - Eligibility Details"
    for chunk in eligibility_detail_chunks:
        chunk_text = f"""\n\n{chunk}\n\n"""
        formatted_response += chunk_text
        
    logger.debug(f"eligibility_check_formatted_text :{str(formatted_response)}")
    
    return formatted_response





class eligibility_check(BaseModel):
    """Use this tool to check eligibility for a user under a given inputs below .
        --MAKE SURE you have all the six inputs before running the tool , if not ask user to provide the missing inputs
        --inputs include : 1.gender , 2.date_of_birth , 3.medicaid_number , 4.full_name, 5.mbi(medicare beneficiary identifier), 6.proposed_effective_date
        --if user replies/says he/she dont have medicaid_number or  mbi(medicare beneficiary identifier) than use 00000 as
          default value for medicaid_number and 000X00XX0XX00 for mbi(medicare beneficiary identifier)
        --dont discuss about default values with user , just say will proceed eligibility check with provided inputs
    """

    
    gender : Literal["M", "F"] = Field( None, description=("The user's gender") )

    date_of_birth: str = Field( None, description=("The user's date of birth in YYYY-MM-DD  format "))
    
    medicaid_number: str = Field(  
        None,  
        description=(  
            "The user's medicaid claim number. This is a unique identifier for the user's medicaid account."
            " example format: 00000 "
        ) 
    )
    
    full_name: str = Field(
        None,  
        description=(  
            "The user's full name. This is used to identify the user in the system."
            "example format: first_name, middle_name last_name" 
            "example1 : John, Doe Smith"
            "example2 : John, Smith"
            "example3 : John"
        ) 
    )
    
    mbi: str = Field(  
        None,  
        description=(  
            "The user's Medicare Beneficiary Identifier (MBI). This is a unique identifier for the user's Medicare account."
            " example format: 0X00XX0XX00 "
        ) 
    )  
    
    proposed_effective_date: str = Field( None, description=("The proposed effective date in YYYY-MM-DD format "))
    
    plans: Optional[list[Plan]] 
    
    
  

# Actual function to execute
async def eligibility_check_func(gender,date_of_birth,medicaid_number,full_name,mbi,proposed_effective_date,plans: Optional[list[Plan]],**kwargs) -> tuple[str, list[Chunk]]:
    """
    Actual function to execute based on params provided by llm.
    Orchestrates the process of sending a user given below params for a single plan to the Eligibility Lookup API
    and formatting the resulting chunks.

    Args:
        gender (str): The user's    
        date_of_birth (str): The date of birth to check.
        medicaid_number (str): The medicaid number to check.
        full_name (str): The full name to check.
        mbi (str): The user's Medicare Beneficiary Identifier (MBI).
        proposed_effective_date (str): The proposed effective date in YYYY-MM-DD format.
        plan (Plan): The plan to filter by.
        **kwargs: Keyword arguments containing the plan and other parameters.

    Returns:
        tuple[str, list[Chunk]:
            A tuple consisting of the formatted response string and the list of document chunks.
    """
    
    ctx: Context = kwargs["ctx"]
    
    
    
    
    eligibility_detail_chunks,results_msg_text = await eligibility_check_api_response(gender,date_of_birth,medicaid_number,full_name,mbi,proposed_effective_date,plans)
    
    return format_eligibility_check_results(eligibility_detail_chunks,results_msg_text) , eligibility_detail_chunks
