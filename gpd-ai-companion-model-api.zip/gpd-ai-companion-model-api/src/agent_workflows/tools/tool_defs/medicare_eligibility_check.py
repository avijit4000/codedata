"""  
This module defines the `medicare_eligibility_check` function
This module provides functionalities to query an eligibility check api using dob, gender , medicaid number , plan etc . It includes a Pydantic model as the `args_schema` 
and corresponding function to execute
"""


from typing import Optional, Literal
from pydantic import BaseModel, Field
import logging


from ...utils.data_models import Plan, Chunk
from ...utils.utils import fetch,get_eligibility_bearer_token
from ...globals import ELIGIBILITY_CHECK_API_ENDPOINT


from llama_index.core.workflow import Context
import httpx




logger = logging.getLogger("agents.tools.medicare_eligibility_check")



    
async def medicare_eligibility_check_api(mbi,date_of_birth,proposed_effective_date):
    """
    Asynchronously queries eligibility lookup api using  returning relevant eligibility details .
    Args:   
        
        mbi (str): The medicare beneficiary Identifier to filter by.
        date_of_birth (str): The date of birth to filter by.
        proposed_effective_date (str): The proposed effective date to filter by.
    Returns:
        list[()]: A list of tuples , where each tuple mbi and eligibility details.
    """
    
    try:
        eligibility_lookup_url = ELIGIBILITY_CHECK_API_ENDPOINT
    
        logger.debug(eligibility_lookup_url)        

        details_payload = {
        "eligibilityType": "MEDICARE",
        "medicare": {
            "medicareNumber": mbi,
            "dateOfBirth": date_of_birth,
            "proposedEffectiveDate": proposed_effective_date
        }
        }
        
        headers = {
        'Authorization': f'Bearer {get_eligibility_bearer_token()}',
        'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient(timeout=60) as client:
            

            try:
                
                # logger.debug(details_payload)
                
                
            
                details_response = await fetch(client, eligibility_lookup_url, method='POST', headers=headers, data=details_payload)  

                if details_response is None:
                    
                    logger.debug("No eligibility details found for the given inputs.")
                    
                    return [("NO_SEARCH_RESULTS","No eligibility details found for the given inputs.")]
                
                    #eligibility_details = []
                else:
                    
                    eligibility_details  = [(mbi,details_response)]

                    logger.debug(eligibility_details)

                    return eligibility_details
                
        
            except httpx.RequestError as e:
                
                logger.error(f"An error occurred: {e}")
                return [("ERROR", f"An error occurred: {e}")]
    except Exception as e:
        
        logger.error(f"An error occurred: {e}")
        return [("ERROR", f"An error occurred: {e}")]
            


async def medicare_eligibility_check_api_response(
mbi:str,
date_of_birth:str,
proposed_effective_date:str,
plan_id: str
) -> list[Chunk]:
    """
    Asynchronously queries eligibility lookup api using  returning relevant eligibility details .

    Args:
        
        mbi (str): The medicare claim number to filter by.
        plan (Plan): The plan to filter by.
        date_of_birth (str): The date of birth to filter by.
        proposed_effective_date (str): The proposed effective date to filter by.

    Returns:
        list[()]: A list of tuples , where each tuple mbi and eligibility details.
    """
    
    
    
    # logger.debug(
    #     f"  mbi :{mbi}, date_of_birth :{date_of_birth} , proposed_effective_date :{proposed_effective_date} "
    # )
    
    result = await medicare_eligibility_check_api(mbi,date_of_birth,proposed_effective_date) 
    
    results_msg_text = "\n******FOR GIVEN INPUTS, HERE ARE THE ELIGIBILITY DETAILS *******\n"
    
    

    if len(result) == 1 and result[0][0] =='ERROR':  
        results_msg_text = "\n****** ELIGIBILITY API IS DOWN , NOT ABLE TO FETCH  DETAILS AT THE MOMENT *******\n"

    logger.debug(result)
    
    
    return [
            Chunk(
                
                doc_text=f"mbi :{str(item[0])}" + ",\n eligibility_details :" + str(item[1]),
                url=None,
                section=None,
                url_title=None,

            )
            for item in result] , results_msg_text
    



def format_medicare_eligibility_check_results(eligibility_detail_chunks: list[Chunk],results_msg_text : str) -> str:
    """
    Formats a list of document chunks into a string containing marked sources.

    Args:
        chunks (list[Chunk]): A list of Chunks, each containing a document chunk.

    Returns:
        str: A string that includes source labels and content for each document chunk.
    """
    formatted_response = f"{results_msg_text}# Sources - Eligibility Details"
    for chunk in eligibility_detail_chunks:
        chunk_text = f"""\n\n{chunk}\n\n"""
        formatted_response += chunk_text
        
    logger.debug(f"medicare_eligibility_check_formatted_text :{str(formatted_response)}")
    
    return formatted_response




class medicare_eligibility_check(BaseModel):
    """Use this tool to check eligibility for a users ONLY MEDICARE  under a given inputs below .
       --inputs include  Medicare Beneficiary Identifier (MBI)  , date_of_birth , proposed_effective_date
       --make sure u have provided all the inputs before running the tool , if not ask user to provide the missing inputs with proper format
       --While asking missing inputs , dont recommend/suggest medicaid or any other
       --Along with  medicare eligibility confirmation , also suggest user if he/she interested in medicaid
    """

    mbi: str = Field(  
        None,  
        description=(  
            "The user's Medicare Beneficiary Identifier (MBI). This is a unique identifier for the user's Medicare account."
            " example format: 0X00XX0XX00 "
        ) 
    )  
    date_of_birth: str = Field( None, description=("The user's date of birth in YYYY-MM-DD format "))
    
    proposed_effective_date: str = Field( None, description=("The proposed effective date in YYYY-MM-DD format "))
    
    plan_ids: list[str]
    

# Actual function to execute
async def medicare_eligibility_check_func(mbi,date_of_birth,proposed_effective_date,plan: Optional[Plan],**kwargs) -> tuple[str, list[Chunk]]:
    """
    Actual function to execute based on params provided by llm.
    Orchestrates the process of sending  inputs  to the Eligibility Lookup API for MEDICARE
    and formatting the resulting chunks.

    Args:

        mbi: users  medicare claim number to check.
        date_of_birth: users  date of birth to check.
        proposed_effective_date: users  proposed effective date to check.
        **kwargs: Keyword arguments containing the plan and other parameters.

    Returns:
        tuple[str, list[Chunk]:
            A tuple consisting of the formatted response string and the list of document chunks.
    """
    if not isinstance(plan, Plan):
        raise AssertionError()

    ctx: Context = kwargs["ctx"]
    
    eligibility_detail_chunks,results_msg_text = await medicare_eligibility_check_api_response(mbi,date_of_birth,proposed_effective_date,plan.plan_id)
    
    return format_medicare_eligibility_check_results(eligibility_detail_chunks,results_msg_text) , eligibility_detail_chunks
