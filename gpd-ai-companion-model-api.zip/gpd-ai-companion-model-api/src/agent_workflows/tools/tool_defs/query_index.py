"""
This module defines the `query_index` function
This module provides functionalities to query an Azure Search index with vector-based
search using semantic configurations. It includes a Pydantic model as the `args_schema`
and corresponding function to execute
"""

from typing import Literal, Optional
from pydantic import BaseModel, Field
import logging
from llama_index.core.workflow import Context
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage

from ...utils.utils import get_documents_from_index
from ...utils.data_models import Plan, Chunk
from ...globals import TOP_N_DOCUMENTS
import os
import asyncio

logger = logging.getLogger("agents.tools.query_index")


async def send_query(
    original_query: str,
    query: str,
    plan: Optional[Plan],
    source: Literal["digital", "telesales", "uhccp"] = "digital",
) -> list[Chunk]:
    """
    Asynchronously queries the Azure Search index based on a search query and an optional plan
    object, returning relevant chunks of text.

    If the source is 'digital':
        - A plan object must be provided.
        - Only plan documents are fetched from the plan index.
    If the source is 'telesales':
        - If a plan object is provided, both plan and job aid documents are fetched and the one with
          the higher reranker score is returned.
        - If no plan is provided, only job aid documents are fetched.
    If the source is 'uhccp':
        - A plan object must be provided.
        - Only uhccp documents are fetched from the plan index.

    Args:
        query (str): The search query text.
        plan (Optional[Plan]): The plan object containing plan_id and plan_year. Required for digital.
        source (Literal["digital", "telesales"]): The source of the query.

    Returns:
        list[Chunk]: A list of document chunks containing the search results.
    """
    if "billing section of Member Snapshot" in original_query:
        query = "billing summary details"
    
    # Validate required input for digital queries
    if source == "digital" and plan is None:
        raise ValueError("A plan object must be provided for digital queries.")

    # Log the query details
    if plan:
        logger.debug(
            f"Query: {query}, plan_id: {plan.plan_id}, plan_year: {plan.plan_year}, source: {source}"
        )
    else:
        logger.debug(f"Query: {query}, no plan provided, source: {source}")

    # Get search configuration values from environment variables
    search_endpoint = os.environ["SEARCH_ENDPOINT"]
    search_key = os.environ["SEARCH_KEY"]
    index_name_plans = os.environ["PLAN_INDEX"]
    index_name_jobaids = os.environ["JOBAID_INDEX"]
    index_name_uhccp = os.environ["UHCCP_INDEX"]
    index_name_group_retiree = os.environ["GROUP_RETIREE_INDEX"]
    index_name_meded = os.environ["MEDED_INDEX"]

    
    tasks = []  # List to hold our asynchronous query tasks
    
    # If a plan is provided, create the task to query the plans index
    if plan is not None:
        # Create a filter string to restrict plan documents by plan_id and plan_year
        plan_filter_str = (
            f"planid eq '{plan.plan_id}' and plan_year eq '{plan.plan_year}'"
        )
        plans_task = get_documents_from_index(
            query,
            index_name_plans,
            TOP_N_DOCUMENTS,
            "my-semantic-config",
            search_key,
            search_endpoint,
            plan_filter_str,
        )
        tasks.append(plans_task)

    # Create jobaids task for telesales only
    if source == "telesales":
        jobaids_task = get_documents_from_index(
            query,
            index_name_jobaids,
            TOP_N_DOCUMENTS,
            "my-semantic-config",
            search_key,
            search_endpoint,
            "",  # No filter for job aids
        )
        tasks.append(jobaids_task)

    if source == "telesales" or source == "digital":
        meded_task = get_documents_from_index(
            query,
            index_name_meded,
            TOP_N_DOCUMENTS,
            "my-semantic-config",
            search_key,
            search_endpoint,
            "",  # No filter for meded
        )
        tasks.append(meded_task)
        
    if source == "uhccp":
        uhccp_task = get_documents_from_index(
            query,
            index_name_uhccp,
            TOP_N_DOCUMENTS,
            "my-semantic-config",
            search_key,
            search_endpoint,
            plan_filter_str,
        )
        tasks.append(uhccp_task)
        
    if source == "group_retiree":
        uhccp_task = get_documents_from_index(
            query,
            index_name_group_retiree,
            TOP_N_DOCUMENTS,
            "my-semantic-config",
            search_key,
            search_endpoint,
            (f"planid eq '{plan.plan_id}'"),
        )
        tasks.append(uhccp_task)

    # Await both tasks concurrently (or just one if no plan was provided)
    results = await asyncio.gather(*tasks)
    
    if source == "digital":
        docs_plans = list(results[0])
        #docs_meded = list(results[1])
        
        # # Calculate the max reranker score for plans (use -inf if no documents returned)
        # reranker_score_plans = (
        #     max(doc["@search.reranker_score"] for doc in docs_plans)
        #     if docs_plans
        #     else float("-inf")
        # )
        # logger.debug(f"reranker_score_plans: {reranker_score_plans}")

        # reranker_score_meded = (
        #     max(doc["@search.reranker_score"] for doc in docs_meded)
        #     if docs_meded
        #     else float("-inf")
        # )
        # logger.debug(f"reranker_score_meded: {reranker_score_meded}")

        # if reranker_score_plans> reranker_score_meded:        
        #     return [
        #         Chunk(
        #             doc_text=doc["chunk"],
        #             url=str(doc["url"]) + "#page=" + str(doc["page_number"]),
        #             url_title = doc["url_title"] if doc["url_title"]!= None else "",
        #             section=doc["section_number"],
        #         )
        #         for doc in docs_plans
        #     ]
        
        # else:
        #     return [
        #         Chunk(
        #             doc_text=doc["chunk"],
        #             url=str(doc["url"]),
        #             url_title = doc["url_title"] if doc["url_title"]!= None else "Not Found",
        #             section=doc["section_number"] if doc["section_number"]!= None else "Not Found",
        #         )
        #         for doc in docs_meded
        #     ]

        return [
            Chunk(
                doc_text=doc["chunk"],
                url=str(doc["url"]),
                url_title = doc["url_title"] if doc["url_title"]!= None else "Not Found",
                section=doc["section_number"] if doc["section_number"]!= None else "Not Found",
            )
            for doc in docs_plans
    ]
    
    if source == "uhccp":
        # For digital queries, only the plan documents are used.
        docs_uhccp = list(results[1])
        logger.info(
            f"Using uhccp index only"
        )
        return [
            Chunk(
                doc_text=doc["chunk"],
                url=str(doc["url"]) + "#page=" + str(doc["page_number"]),
                url_title = doc["url_title"] if doc["url_title"]!= None else "",
                section=doc["section_number"] if doc["section_number"]!= None else "",
            )
            for doc in docs_uhccp
        ]
    
    if source == "group_retiree":
        # For digital queries, only the plan documents are used.
        docs_group_retiree = list(results[1])
        logger.info(
            f"Using group_retiree index only"
        )
        return [
            Chunk(
                doc_text=doc["chunk"],
                url=str(doc["url"]) + "#page=" + str(doc["page_number"]),
                url_title = doc["url_title"] if doc["url_title"]!= None else "",
                section=doc["section_number"] if doc["section_number"]!= None else "",
            )
            for doc in docs_group_retiree
        ]
    
    else:  # source == "telesales"
        if ("cover" and "otc" in original_query) or ("cover" and "OTC" in original_query):
            original_query = "does this plan cover OTC?"
        elif ("vendor" and "transportation" in original_query) or ("cover" and "transportation" in original_query):
            original_query = "does this plan cover transportation?"
        if plan is not None:
            # For telesales with a plan, the first result is from the plan index and the second from the job aid index.
            docs_plans = list(results[0])
            docs_jobaids = list(results[1])
            docs_meded = list(results[2])
            

            # Calculate the max reranker score for plans (use -inf if no documents returned)
            reranker_score_plans = (
                max(doc["@search.reranker_score"] for doc in docs_plans)
                if docs_plans
                else float("-inf")
            )
            logger.debug(f"reranker_score_plans: {reranker_score_plans}")

            # Calculate the max reranker score for job aids (use -inf if no documents returned)
            reranker_score_jobaids = (
                max(doc["@search.reranker_score"] for doc in docs_jobaids)
                if docs_jobaids
                else float("-inf")
            )
            logger.debug(f"reranker_score_jobaids: {reranker_score_jobaids}")
            
            reranker_score_meded = (
                max(doc["@search.reranker_score"] for doc in docs_meded)
                if docs_meded
                else float("-inf")
            )
            logger.debug(f"reranker_score_meded: {reranker_score_meded}")

         
                       
            if (any(word in original_query for word in ["high", "low", "offer", "cover", "pay", "otc", "OTC",  "ride", "gym", "transportation"]) and "plan" in original_query) or (reranker_score_plans > reranker_score_jobaids and reranker_score_plans > reranker_score_meded and "phone number for UHC commercial (through an employer) plans customer service" not in original_query):    
                docs = docs_plans
                logger.info(f"Using plan index: {search_endpoint}\n{index_name_plans}")
                return [
                    Chunk(
                        doc_text=doc["chunk"],
                        url=str(doc["url"]) + "#page=" + str(doc["page_number"]),
                        url_title = doc["url_title"] if doc["url_title"]!= None else "Not Found",
                        section=doc["section_number"],
                    )
                    for doc in docs
                ]
            
            elif (reranker_score_meded > reranker_score_jobaids and reranker_score_meded > reranker_score_plans) or ("qualifies as income?" in original_query):
                docs = docs_meded
                return [
                    Chunk(
                        doc_text=doc["chunk"],
                        url=str(doc["url"]),
                        url_title = doc["url_title"] if doc["url_title"]!= None else "Not Found",
                        section=doc["section_number"] if doc["section_number"]!= None else "Not Found",
                    )
                    for doc in docs
                ]
            
            elif (reranker_score_jobaids > reranker_score_plans) and (reranker_score_jobaids > reranker_score_meded) and (abs(reranker_score_jobaids-reranker_score_plans)<= 0.1):
                
                chunks_plan = []
                chunks_ja = []
                scores_plan = []
                scores_ja = []

                for i in range(len(docs_plans)):
                    chunks_plan.append((docs_plans[i]["chunk"], docs_plans[i]["@search.reranker_score"],docs_plans[i]["url"], docs_plans[i]["url_title"]))
                    chunks_ja.append((docs_jobaids[i]["chunk"], docs_jobaids[i]["@search.reranker_score"],docs_jobaids[i]["file_name"], docs_jobaids[i]["sheet_name"]))
                    scores_plan.append(docs_plans[i]["@search.reranker_score"])
                    scores_ja.append(docs_jobaids[i]["@search.reranker_score"])

                all_chunks = chunks_plan + chunks_ja
                sorted_tuples = sorted(all_chunks, key = lambda x:x[1], reverse = True)
                #sorted_chunks = [(x) for x, y in sorted_tuples]

                return [
                        Chunk(
                            doc_text=doc[0],
                            url=str(doc[2]),
                            url_title=doc[3],
                            section="Not Found",
                        )
                        for doc in sorted_tuples[:6]
                     ]
                
                # return [
                #         Chunk(
                #             doc_text=doc,
                #             url=None,
                #             url_title=None,
                #             section=None,
                #         )
                #         for doc in sorted_chunks[:6]
                #      ]
            
            
            else:    
           
                docs = docs_jobaids
                logger.info(
                    f"Using job aid index: {search_endpoint}\n{index_name_jobaids}"
                )
                return [
                    Chunk(
                        doc_text=doc["chunk"],
                        url=None,
                        url_title=doc["file_name"] if doc["file_name"]!= None else "Not Found",
                        section=doc["sheet_name"] if doc["sheet_name"]!= None else "Not Found",
                    )
                    for doc in docs
                ]
        else:
        
            docs_jobaids = list(results[0])
            docs_meded = list(results[1])
            # For telesales without a plan, only the job aids query was executed.
            reranker_score_jobaids = (
                max(doc["@search.reranker_score"] for doc in docs_jobaids)
                if docs_jobaids
                else float("-inf")
            )
            logger.debug(f"reranker_score_jobaids: {reranker_score_jobaids}")
            
            reranker_score_meded = (
                max(doc["@search.reranker_score"] for doc in docs_meded)
                if docs_meded
                else float("-inf")
            )
            logger.debug(f"reranker_score_meded: {reranker_score_meded}")

            
            
            if reranker_score_meded > reranker_score_jobaids or "qualifies as income?" in original_query:
                
                return [
                    Chunk(
                        doc_text=doc["chunk"],
                        url=str(doc["url"]),
                        url_title = doc["url_title"] if doc["url_title"]!= None else "Not Found",
                        section=doc["section_number"] if doc["section_number"]!= None else "Not Found",
                    )
                    for doc in docs_meded
                ]
            else:
                    
                logger.info(
                    f"Using job aid index only (no plan provided): {search_endpoint}\n{index_name_jobaids}"
                )

                return [
                    Chunk(
                        doc_text=doc["chunk"],
                        url=None,
                        url_title=doc["file_name"] if doc["file_name"]!= None else "Not Found",
                        section=doc["sheet_name"] if doc["sheet_name"]!= None else "Not Found",
                    )
                    for doc in docs_jobaids
                ]


def format_query_response(chunks: list[Chunk]) -> str:
    """
    Formats a list of document chunks into a string containing marked sources.

    Args:
        chunks (list[Chunk]): A list of Chunks, each containing a document chunk.

    Returns:
        str: A string that includes source labels and content for each document chunk.
    """
    formatted_response = "# Sources"
    for chunk in chunks:
        chunk_text = f"""\n\n{chunk.doc_id}\n'''\n{chunk.doc_text}\n'''"""
        formatted_response += chunk_text
    return formatted_response


# Function args_schema that LLM will see
# `plan_ids: list[str]` will be replaced in the LLMFunctionWithPlan object upon initialization
# replacing with `list[enum]`. That way the definition the LLM gets is restricted to only
# the plans the user is looking at
class query_index(BaseModel):
    """Use this tool to answer questions related to plan benefits or telesales job aids

    Formulate a search query for a vector-based search index to return relevant documents to answer the question.
        - Query should be CONCISE without sacrificing clarity
        - Add 1-2 synonyms to help match documents, like "CPAP"->"durable medical equipment" or "scleral lens"->"contacts"
        - Imitate the language found in a health plan EOB
        - Limit to 10 terms
    Do NOT include the plan name in the query; there is a SEPARATE field for the plan ID, to be used as a filter in the search

    E.g.:
    "Does this plan cover routine eye exams?" -> "routine eye exam vision plan coverage"
    "How much for this plan do I pay for my drugs while in the coverage gap?" -> "coverage gap drug prescription cost"
    """

    query: str = Field(
        description="The search query to use to answer the user's question. MUST LIMIT TO 10 TERMS ONLY. Adjust this when retrying"
    )
    plan_ids: list[str]


# Actual function to execute
async def query_index_func(
    query: str, plan: Optional[Plan], **kwargs
) -> tuple[str, list[Chunk]]:
    """
    Actual function to execute based on params provided by llm.
    Orchestrates the process of sending a query for a single plan to the Azure Search index
    and formatting the resulting chunks.

    Args:
        query (str): The search query text.
        plans (Plan): A Plan object, of which the first is used to filter the search.
        **kwargs: Additional keyword arguments that this function can choose to use or not. Contains workflow context.

    Returns:
        tuple[str, list[Chunk]:
            A tuple consisting of the formatted response string and the list of document chunks.
    """
    if not (isinstance(plan, Plan) or (plan is None)):
        raise AssertionError()
    # get source from workflow context, default to digital as failsafe
    ctx: Context = kwargs["ctx"]
    
    msgs = await ctx.get('msgs')
    for i in range(len(msgs) - 1, -1, -1):
        if isinstance(msgs[i], HumanMessage):
            user_msg_text = msgs[i].content
    
    source: Literal["digital", "telesales", "uhccp", "group_retiree"] = await ctx.get("source", default="digital")

    chunks = await send_query(user_msg_text, query, plan, source)
    return format_query_response(chunks), chunks
