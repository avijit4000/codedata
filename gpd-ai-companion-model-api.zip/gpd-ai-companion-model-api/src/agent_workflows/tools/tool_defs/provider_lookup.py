"""  
This module defines the `provider_lookup` function
This module provides functionalities to query an provider network , details,  search  urls based on name string , plan
to get complete provider details . It includes a Pydantic model as the `args_schema` 
and corresponding function to execute
"""

from typing import Optional, Literal, List
from pydantic import BaseModel, Field
import logging

from langchain_core.tools import ToolException

from ...utils.data_models import Plan, Chunk, URLInfo
from ...utils.utils import get_fips_state_code,fetch
from ...globals import TOP_N_PROVIDERS,PROVIDER_LOOKUP_API_ENDPOINT,PROVIDER_OUTPUT_KEYS_TO_SELECT


from llama_index.core.workflow import Context
import httpx




logger = logging.getLogger("agents.tools.provider_lookup")





async def provider_lookup_api(provider_text_filter, plan_id,zip_code):
    
        """
        Asynchronously queries provider lookup api using   provider_name , plan_id,
        fips_code,zip_code ,  returning relevant provider details .
        Args:
            provider_text_filter (str): name string of the provider.
            plan_id (str): The plan ID to filter by.
            zip_code (str): The zip_code to filter by.
        Returns:
            list[()]: A list of tuples , where each tuple contains name, address of each provider.
        """

        provider_details_url = PROVIDER_LOOKUP_API_ENDPOINT
        
        logger.info(f"provider_details_url :{provider_details_url}")
        
        fips_code,state_code = get_fips_state_code(zip_code)
        
        details_payload = {
        "partnerCode": "uhc.mnr",
        "clientPortalCode": "UHCMS4",
        "zipCode": zip_code,
        "fipsCode": fips_code,
        "stateCode": state_code,
        "planCodes": [
            plan_id
        ],
        "coverageTypes": [
            "medical",
            "behavioral",
            "dental"
        ],
        "distanceMiles": 100,
        "planYear": "2025",
        "providerTextFilter": provider_text_filter,
        "from": 0,
        "searchType": [
            "person",
            "place",
            "medicalGroup"
        ],
        "specialtyCategory": ""
        }
        headers = {
        'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient(timeout=60) as client:
            

            try:
                
                logger.debug(details_payload)
                #print(details_payload)
                
            
                details_response = await fetch(client, provider_details_url, method='POST', headers=headers, data=details_payload)  


                provider_detail_list = details_response["providerPersons"]

                #logger.info(provider_detail_list)
                
                if (provider_detail_list is not None) and ( len(provider_detail_list) > 0):
                    
                    
                    keys_to_select = PROVIDER_OUTPUT_KEYS_TO_SELECT
                    
                    try:
                        # will use specific provider details/keys 
                        
                        #logger.info("provider detail keys from search  :"+str(keys_to_select.keys()))
                        
                        topN_provider_list = [
                        (
                        item["personName"]["fullName"], {
                        key: eval(keys_to_select[key]) for key in keys_to_select
                        }
                        )
                        for item in provider_detail_list[:TOP_N_PROVIDERS]
                        ]

                    except Exception as e :
                        
                        #will use complete search results 
                        logger.error(f"An error occurred: {e}")
                        
                        topN_provider_list = [(item["personName"]["fullName"],item) for item in provider_detail_list[:int(TOP_N_PROVIDERS)]]
                    
                    logger.debug(topN_provider_list)
                    #print(topN_provider_list)
                
                    return topN_provider_list
                
                else:
                    logger.debug("No providers found for the given inputs.")
                    
                    return [("NO_SEARCH_RESULTS","No providers found for the given inputs.")]
        
            except httpx.RequestError as e:
                logger.error(f"An error occurred: {e}")
                return [("ERROR", f"An error occurred: {e}")]
            
            

async def provider_search(
    plan_id: str,
    zip_code: str   ,
    provider_text_filter: str = "" 
) -> tuple[list[Chunk], str]:
    """
    Asynchronously queries provider lookup api using   provider_name , plan_id,
    fips_code,zip_code ,  returning relevant provider details .

    Args:
        provider_text_filter (str): name string of the provider.
        plan_id (str): The plan ID to filter by.
        zip_code (str): The zip_code to filter by.

    Returns:
        list[()]: A list of tuples , where each tuple contains name, address of each provider.
    """
    
    
    logger.debug(
        f"provider_text_filter: {provider_text_filter}, plan_id: {plan_id}, zip_code: {zip_code}"
    )
    
    result = await provider_lookup_api(provider_text_filter, plan_id,zip_code) 
    
    results_msg_text = "\n******FOR GIVEN INPUT SEARCH , HERE ARE THE AVAILABLE PROVIDER/DOCTOR'S LIST UNDER GIVEN PLAN & ZIP CODE*******\n"
    
    if len(result) == 1 and result[0][0] =='NO_SEARCH_RESULTS':
        
        
        result = await provider_lookup_api("", plan_id,zip_code)  
        results_msg_text = "\n******FOR GIVEN INPUT SEARCH , NO PROVIDER/DOCTOR'S FOUND ! BUT HERE ARE THE AVAILABLE LIST UNDER GIVEN PLAN & ZIP CODE*******\n" 
    
    
    
    if len(result) == 1 and result[0][0] =='ERROR':  
        results_msg_text = "\n****** PROVIDER LOOKUP API IS DOWN , NOT ABLE TO FETCH  PROVIDER/DOCTOR'S LIST AT THE MOMENT *******\n"

    logger.debug(result)
    #print(result)
    
    return [
            Chunk(
                
                doc_text=f"provider_name :{str(item[0])}" + ",\n provider_details :" + str(item[1]),
                url=None,
                section=None,
                url_title=None,

            )
            for item in result] , results_msg_text
    



def format_provider_search_results(provider_detail_chunks: list[Chunk],results_msg_text : str) -> str:
    """
    Formats a list of document chunks into a string containing marked sources.

    Args:
        chunks (list[Chunk]): A list of Chunks, each containing a document chunk.

    Returns:
        str: A string that includes source labels and content for each document chunk.
    """
    formatted_response = f"{results_msg_text}# Sources - Provider Details"
    for chunk in provider_detail_chunks:
        chunk_text = f"""\n\n{chunk}\n\n"""
        formatted_response += chunk_text
        
    logger.debug(f"provider_lookup_formatted_text :{str(formatted_response)}")
    
    return formatted_response


# Function args_schema that LLM will see
# `plan_ids: list[str]` will be replaced in the LLMFunctionWithPlan object upon initialization
# replacing with `list[enum]`. That way the definition the LLM gets is restricted to only
# the plans the user is looking at

class provider_lookup(BaseModel):
    """Use this tool to lookup/answer questions related to provider/doctor's complete details like name , address, providerReview , 
    providerLocations,specialties,email , phonenumbers , what not ,everything about provider/doctor details etc
    --**inputs** : provider_name , provider_type extract from the user query
    --if multiple provider/doctor's list in output , always ask user to confirm the provider name 
    --Also dont answer the user question before confirming the provider name 
    """

    provider_type: Optional[str] = Field(  
        None,  
        description=(  
            "Type of provider to search for, e.g., 'doctor', 'specialist', etc. "  
            "This can be used to refine the search."  
        )  
    )  
    provider_name: Optional[str] = Field(  
        None,  
        description=(  
            "The name of the provider/doctor to search for. This can be a full name "  
            "or partial name. This will be used as the primary filter for the search."  
        )  
    )  
    plan_ids: list[str]
    

class PartialWorkflowOutput(BaseModel):
    response: str  
    status: int = Field(  
        description="Status code of the function execution. Defaults to 2001 if no telesales or digital source found."  
    )  
    chunks: List[Chunk] = [] 
    questions: List[str] = Field(
        [],
        description=(  
            "List of questions to ask the provider. This can be used to refine the search or get more specific information about the provider."
        )
    )
    url_info: List[URLInfo] = Field(
        [],
        description=(  
            "List of URLs or additional information sources related to the provider. This can be used to provide more context or references."
        )
    )



# Actual function to execute
async def provider_lookup_func(provider_type: Optional[str], provider_name: Optional[str], plan: Optional[Plan],**kwargs) -> tuple[str, list[Chunk]] | PartialWorkflowOutput:
    """
    Actual function to execute based on params provided by llm.
    Orchestrates the process of sending a provider_text_filter string for a single plan to the Provider Lookup API
    and formatting the resulting chunks.

    Args:
        provider_text_filter (str): The name string  filter the provider  details 
        plans (Plan): A Plan object, of which the first is used to filter the search.
        zip_code: zip code to filter provider details to specific location 

    Returns:
        tuple[str, list[Chunk]:
            A tuple consisting of the formatted response string and the list of document chunks.
    """
    if not isinstance(plan, Plan):
        raise AssertionError()

    ctx: Context = kwargs["ctx"]
    source: Literal["digital", "telesales"] = await ctx.get("source", default="digital")
    if source == "digital":
        logger.info("Inside digital source")
        return PartialWorkflowOutput(
            status = 2001, 
            response = "",
            chunks =  [],
            questions = [],
            url_info = [])
    
    elif source == "telesales":
        logger.info("Inside telesales source")
        if provider_name:
            logger.info(f"provider_name found in telesales source {provider_name}")
            provider_text_filter = provider_name
        elif provider_type:
            #will be updated when provider api supports provider_type search
            logger.info(f"provider_type found in telesales source {provider_type}")
            # provider_text_filter = provider_type
            return PartialWorkflowOutput(
            status = 2001, 
            response = "",
            chunks =  [],
            questions = [],
            url_info = [])
        else: #both are none
            logger.info(f"provider_type and provider_name both are None in telesales source")
            return PartialWorkflowOutput(
            status = 2001, 
            response = "",
            chunks =  [],
            questions = [],
            url_info = [])
        logger.info(f"provider_text_filter {provider_text_filter}")
        logger.info("calling provider_search")
        provider_detail_chunks,results_msg_text = await provider_search(plan.plan_id,plan.zip,provider_text_filter)
        
        return format_provider_search_results(provider_detail_chunks,results_msg_text) , provider_detail_chunks
    else:
        raise ToolException("There was an error calling the `provider_lookup` tool")

