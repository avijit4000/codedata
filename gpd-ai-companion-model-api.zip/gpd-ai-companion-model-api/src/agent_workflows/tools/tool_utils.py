"""
This module provides functionality for wrapping asynchronous functions into a format
that returns `ToolMessage` objects, optionally handling chunks when the wrapped
function indicates such. It includes classes for representing these wrapped LLM
functions (and their associated schemas) along with specialized handling for functions
that accept 'plan'.
"""

import asyncio
from llama_index.core.workflow import Context
from langchain_core.tools import ToolException
from langchain_core.messages import ToolMessage
from pydantic import Field, create_model, BaseModel, field_validator, model_validator
from typing import Awaitable, Callable, Literal, Union
import inspect
from enum import StrEnum
from .tool_defs import PartialWorkflowOutput
from ..llms.rephraser import Rephrasal
from ..llms.plan_compare_single import (
    SinglePlanAnswer,
    plan_compare_single_chain,
    plan_compare_single_prompt_extension,
)
from ..utils.data_models import Plan, Chunk, InfoClasses, SinglePlanToolArtifact
from ..utils.utils import extract_document_ids_strict
import logging
from typing import Optional, get_type_hints, get_origin, get_args, Any
import types

logger = logging.getLogger("agents.tools.tool_utils")


def _is_str_list_chunk_tuple(tp: Any) -> bool:
    """
    Check whether the annotation tp is exactly tuple[str, list[Chunk]].

    Args:
        tp (Any): A type annotation.

    Returns:
        bool: True if tp is tuple[str, list[Chunk]], False otherwise.
    """
    if get_origin(tp) is not tuple:
        return False
    args = get_args(tp)
    if len(args) != 2:
        return False
    first, second = args
    if first is not str:
        return False
    if get_origin(second) is not list:
        return False
    elt_args = get_args(second)
    if len(elt_args) != 1 or elt_args[0] is not Chunk:
        return False
    return True


def check_returns_chunks(func: Callable[..., Any]) -> bool:
    """
    Validates that `func` accepts **kwargs and that its annotated return type is one of:
      - str
      - tuple[str, list[Chunk]]
      - PartialWorkflowOutput
      - str | PartialWorkflowOutput
      - tuple[str, list[Chunk]] | PartialWorkflowOutput

    Returns:
        bool:
            - True if the return type (or one of its union components) is
              tuple[str, list[Chunk]] (i.e. the function “returns chunks”).
            - False otherwise.

    Raises:
        TypeError:
            - If `func` does not accept **kwargs.
            - If `func` has no return‐type annotation.
            - If the return annotation is not exactly one of the five allowed forms.
    """
    # 1) Ensure func accepts **kwargs
    sig = inspect.signature(func)
    if not any(
        p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
    ):
        raise TypeError("The function must accept **kwargs.")

    # 2) Fetch evaluated type hints
    hints = get_type_hints(func)
    if "return" not in hints:
        raise TypeError("No return type annotated for the given function.")
    ret_type = hints["return"]

    # 3) Handle the three non‐union cases:
    #    str                     -> False
    #    PartialWorkflowOutput   -> False
    #    tuple[str, list[Chunk]] -> True
    if ret_type is str or ret_type is PartialWorkflowOutput:
        return False
    if _is_str_list_chunk_tuple(ret_type):
        return True

    # 4) Handle Union cases (both `typing.Union[...]` and `A | B`):
    origin = get_origin(ret_type)
    if origin in (Union, types.UnionType):
        components = get_args(ret_type)
        if len(components) != 2:
            raise TypeError(f"Unsupported Union return type: {ret_type!r}")

        comp_set = set(components)
        # str | PartialWorkflowOutput  -> False
        if comp_set == {str, PartialWorkflowOutput}:
            return False
        # tuple[str, list[Chunk]] | PartialWorkflowOutput -> True
        if (
            any(_is_str_list_chunk_tuple(c) for c in comp_set)
            and PartialWorkflowOutput in comp_set
        ):
            return True

        raise TypeError(f"Unsupported Union return type: {ret_type!r}")

    # 5) Anything else is invalid
    raise TypeError(
        f"Return type must be one of: "
        f"str, tuple[str, list[Chunk]], PartialWorkflowOutput, "
        f"str | PartialWorkflowOutput, "
        f"tuple[str, list[Chunk]] | PartialWorkflowOutput; got {ret_type!r}"
    )


class LLMFunction(BaseModel):
    """A class representing a function that can be executed by an LLM, along with
    its arguments schema that will be provided as the function definition to the
    llm. The function must have return type hints.

    This class ensures the function is asynchronous and wraps it so that it
    returns a `ToolMessage`. Optionally handles returning chunks as well, if the
    function returns a tuple (str, list[Chunk])

    Attributes:
        func (Optional[Callable]): The asynchronous function to be wrapped.
        args_schema (type[BaseModel]): The Pydantic model class defining the
            function's arguments.
    """

    func: Optional[Callable] = Field(
        description="Function to execute when called by LLM. Must have return type hints. Return a tuple (str, list[chunks]) if returning chunks, otherwise must return str."
    )
    args_schema: type[BaseModel] = Field(
        description="The actual definition passed to the LLM. The parameters will be unpacked into the func"
    )

    @classmethod
    def wrap_func(cls, value: Optional[Callable]) -> Optional[Callable]:
        """Wraps a function to ensure it returns a `ToolMessage` upon completion.

        This wrapped function is expected to be asynchronous and, if the
        function returns a tuple, it is interpreted as `(result, list[chunks])`.
        Otherwise, only the `result` is used.

        Args:
            value (Optional[Callable]): The function to wrap. Must be async.

        Returns:
            Optional[Callable]: The wrapped function if `value` is not None,
            otherwise None.
        """
        if value is None:
            return None
        if not inspect.iscoroutinefunction(value):
            raise ValueError(f"{value} is not awaitable")

        returns_chunks = check_returns_chunks(value)

        async def new_func(*args, tool_call_id: str, ctx: Context, **kwargs):
            """Inner function that executes the original function and constructs
            the appropriate `ToolMessage`. Adds chunks to context chunk store
            """
            try:
                combined_result = await value(*args, ctx=ctx, **kwargs)
                if isinstance(combined_result, PartialWorkflowOutput):
                    return combined_result
                if returns_chunks:
                    result, chunks = combined_result
                    all_chunks: dict[str, Chunk] = await ctx.get("all_chunks")
                    all_chunks.update({chunk.doc_id: chunk for chunk in chunks})
                    await ctx.set("all_chunks", all_chunks)
                else:
                    result = combined_result

                return ToolMessage(
                    content=str(result),
                    tool_call_id=tool_call_id,
                )
            # Exception handling, returns message to llm saying there's error
            except ToolException as e:
                logger.error(f"Tool Error: {e}")
                return ToolMessage(
                    content=f"Function Error: '{e.args[0]}'",
                    tool_call_id=tool_call_id,
                )

        return new_func

    @field_validator("func", mode="after")
    @classmethod
    def validate_func(cls, value: Optional[Callable]) -> Optional[Callable]:
        """Field validator that ensures the function is wrapped after assignment."""
        return cls.wrap_func(value)

    @property
    def func_name(self) -> str:
        """Gets the name of the argument schema, used to identify the function.

        Returns:
            str: The name of the argument schema class.
        """
        return self.args_schema.__name__


async def update_chunks(chunks: list[Chunk], ctx: Context):
    """Update `all_chunks` in the context from a Chunk list provided

    Args:
        chunks (list[Chunk]): Chunks to add to context
        ctx (Context): Workflow context
    """
    all_chunks: dict[str, Chunk] = await ctx.get("all_chunks")
    all_chunks.update({chunk.doc_id: chunk for chunk in chunks})
    await ctx.set("all_chunks", all_chunks)


async def plan_compare(
    func: Callable,
    plan: Plan,
    user_query: str,
    info_classes: Optional[InfoClasses],
    returns_chunks: bool,
    ctx: Context,
    args,
    kwargs,
) -> SinglePlanAnswer | PartialWorkflowOutput:
    """Runs fn for a single plan. Takes the output and asks LLM to answer for single plan
    based on fn results

    Args:
        func (Callable): Function in the LLMFunctionWithPlan
        plan (Plan): Plan object to run for
        user_query (str): Question/ query to answer
        info_classes (Optional[InfoClasses]): Infoclasses object for query
        returns_chunks (bool): Whether of not func returns chunks
        ctx (Context): Workflow context
        args (_type_): args for func (not unpacked)
        kwargs (_type_): kwargs for func (not unpacked)

    Returns:
        SinglePlanAnswer: Answer for single plan
    """
    # Initialize task for updating all_chunks in context
    update_chunks_task = None
    combined_result = await func(*args, plan=plan, ctx=ctx, **kwargs)
    if isinstance(combined_result, PartialWorkflowOutput):
        return combined_result
    elif returns_chunks:
        chunks: list[Chunk]
        result, chunks = combined_result
        # Create task to await later. This allows async run with LLM call
        update_chunks_task = asyncio.create_task(update_chunks(chunks, ctx))
    else:
        result = combined_result

    # Use function result to answer question for this plan
    prompt_extension = ""
    if info_classes:
        prompt_extension = plan_compare_single_prompt_extension.format(
            critical_info=info_classes.critical
        )
    answer: SinglePlanAnswer = await plan_compare_single_chain.ainvoke(
        input={
            "user_query": user_query,
            "sources": result,
            "prompt_extension": prompt_extension,
        }
    )  # type: ignore

    # Finally await context update
    if update_chunks_task:
        await update_chunks_task

    return answer


class LLMFunctionWithPlan(LLMFunction):
    """An `LLMFunction` variant that enforces the presence of a 'plan' parameter
    in the callable and includes validation for the args schema that must define a 'plan_ids'
    field of type list[str]. 'plan' should be annotated as `Optional[Plan]`, func must
    deal with situation where plan is None!!!

    Attributes:
        func (Callable): The asynchronous function to be wrapped. This function must
            accept a parameter named 'plan' annotated as `Optional[Plan]`.
    """

    func: Callable = Field(
        description="Function to execute when called by LLM. Must take parameter plan:Plan. Must have return type hints. Return a tuple (str, list[chunks]) if returning chunks, otherwise must return str."
    )

    # TODO: Share code between wrap_func in this override vs in original
    @classmethod
    def wrap_func(cls, value: Optional[Callable]) -> Optional[Callable]:
        """Wraps a function to ensure it returns a `ToolMessage` upon completion.

        This wrapped function is expected to be asynchronous and, if the
        function returns a tuple, it is interpreted as `(result, list[chunks])`.
        Otherwise, only the `result` is used.

        Args:
            value (Optional[Callable]): The function to wrap. Must be async.

        Returns:
            Optional[Callable]: The wrapped function if `value` is not None,
            otherwise None.
        """
        if value is None:
            return None
        if not inspect.iscoroutinefunction(value):
            raise ValueError(f"{value} is not awaitable")

        returns_chunks = check_returns_chunks(value)

        async def new_func(
            *args,
            tool_call_id: str,
            ctx: Context,
            plans: list[Optional[Plan]],
            **kwargs,
        ):
            """Inner function that executes the original function and constructs
            the appropriate `ToolMessage`. Adds chunks to context chunk store
            """
            try:
                # Not plan compare scenario
                if len(plans) == 1:
                    # Execute fn
                    combined_result = await value(
                        *args, plan=plans[0], ctx=ctx, **kwargs
                    )
                    if isinstance(combined_result, PartialWorkflowOutput):
                        return combined_result
                    elif returns_chunks:
                        chunks: list[Chunk]
                        tool_message, chunks = combined_result
                        await update_chunks(chunks, ctx)
                    else:
                        tool_message = combined_result
                    return ToolMessage(
                        content=str(tool_message),
                        tool_call_id=tool_call_id,
                    )
                # Plan compare scenario
                else:
                    for plan in plans:
                        if plan is None:
                            raise ValueError("Got None plan for plan compare")
                    just_plans: list[Plan] = plans  # type: ignore
                    # Pre-await coros to save time for each plan individually
                    # Info classes is needed so single plan LLMs know to include critical info
                    info_classes: Optional[InfoClasses] = await (
                        await ctx.get("info_class_task")
                    )
                    rephrasal: Rephrasal = await (await ctx.get("rephraser_task"))
                    question_type = rephrasal.question_type
                    user_query = rephrasal.rephrased_message

                    # Execute fn for each plan individually, asking LLM to answer
                    gathered = await asyncio.gather(
                        *[
                            plan_compare(
                                func=value,
                                plan=plan,
                                user_query=user_query,
                                info_classes=info_classes,
                                returns_chunks=returns_chunks,
                                ctx=ctx,
                                args=args,
                                kwargs=kwargs,
                            )
                            for plan in just_plans
                        ]
                    )

                    # Extract answers from each run
                    # result_strings is ultimately what goal seeker will see
                    result_strings = []
                    single_plan_tool_artifacts: list[SinglePlanToolArtifact] = []
                    for single_plan_answer, plan in zip(gathered, just_plans):
                        # if single_plan_answer.missing_info:
                        #     result_strings = ["The necessary info to answer your query could not be found."]
                        #     break
                        # else:
                        if isinstance(single_plan_answer, PartialWorkflowOutput):
                            return single_plan_answer
                        # Single Plan LLM answers look like this:
                        # This is a fact[doc344]. This is another fact[doc632]
                        # Extract docs from answer
                        cleaned_answer, answer_docs = extract_document_ids_strict(
                            single_plan_answer.answer
                        )
                        result_strings.append(
                            f"### {plan.plan_name} - {plan.plan_year}\n\n"
                            f"{cleaned_answer}\n\n"
                            f"**ANSWER_DOCS:** {answer_docs}"
                        )
                        # Store answer for each plan separately as artifacts for downstream use
                        single_plan_tool_artifacts.append(
                            SinglePlanToolArtifact(
                                plan=plan,
                                cleaned_answer=cleaned_answer,
                                answer_docs=answer_docs,
                            )
                        )

                    tool_message = "\n\n".join(result_strings)
                    # Include prompt for listing questions for goal_seeker to maintain plan-by-plan structure of answer
                    if question_type == "listing_question":
                        if info_classes:
                            tool_message += f"\n\n**NOTE:** IF this message has all below info for a COMPLETE answer, please write your answer to the user in the exact same format as this message, i.e. a separate answer for each plan\n\n{info_classes.critical}"
                        else:
                            tool_message += "\n\n**NOTE:** Please write your answer to the user in the exact same format as this message, i.e. a separate answer for each plan"
                    msg = ToolMessage(
                        content=str(tool_message),
                        tool_call_id=tool_call_id,
                        artifact=single_plan_tool_artifacts,
                    )
                    logger.info(msg.pretty_repr())
                    return msg
            # Exception handling, returns message to llm saying there's error
            except ToolException as e:
                return ToolMessage(
                    content=f"Function Error: '{e.args[0]}'",
                    tool_call_id=tool_call_id,
                )

        return new_func

    @field_validator("func", mode="after")
    @classmethod
    def validate_func(cls, value: Callable) -> Optional[Callable]:
        """Ensures the function has a parameter named 'plan' that is annotated as Optional[Plan].

        This validator checks the function signature for a parameter called 'plan' and
        confirms that its type annotation is `Optional[Plan]` (i.e., `Union[Plan, None]`).

        Args:
            value (Callable): The function to validate and wrap.

        Raises:
            ValueError: If the 'plan' parameter is not found or is not annotated as Optional[Plan].

        Returns:
            Optional[Callable]: The wrapped function.
        """
        # Retrieve the signature of the function.
        signature = inspect.signature(value)
        param = signature.parameters.get("plan")
        if param is None:
            raise ValueError(
                f"{value.__name__} must have a parameter named 'plan' annotated as Optional[Plan]."
            )

        # Verify that the 'plan' parameter annotation is Optional[Plan].
        # Optional[Plan] is essentially a Union[Plan, NoneType].
        if not (
            get_origin(param.annotation) is Union
            and set(get_args(param.annotation)) == {Plan, type(None)}
        ):
            raise ValueError(
                f"The parameter 'plan' in {value.__name__} must be annotated as Optional[Plan]."
            )

        return cls.wrap_func(value)

    @field_validator("args_schema", mode="after")
    @classmethod
    def validate_args_schema(cls, value: type[BaseModel]) -> type[BaseModel]:
        """Validates that the `args_schema` has a field named 'plan_ids' of type `list[str]`.

        Args:
            value (type[BaseModel]): The argument schema class to validate.

        Raises:
            ValueError: If 'plan_ids' is missing or incorrectly typed.

        Returns:
            type[BaseModel]: The validated argument schema class.
        """
        # Make sure there's a field named 'plan_ids'
        if "plan_ids" not in value.model_fields:
            raise ValueError(
                f"{value.__name__} must have a field named 'plan_ids' of type list[str]."
            )
        # Check that plan_ids is actually typed as list[str]
        plan_ids_field = value.model_fields["plan_ids"]
        annotation = plan_ids_field.annotation
        if get_origin(annotation) != list or get_args(annotation) != (str,):
            raise ValueError(
                f"The field 'plan_ids' in {value.__name__} must be typed as list[str]."
            )
        return value

    @model_validator(mode="after")
    def copy_original_args_schema(self) -> "LLMFunctionWithPlan":
        """
        Copy the validated args_schema into the private attribute to be
        referenced by enumify_schema

        Returns:
            LLMFunctionWithPlan: The updated model instance.
        """
        self._original_args_schema = self.args_schema
        return self

    def enumify_schema(self, plans: list[Plan]):
        """Dynamically converts the `plan_ids` field into an Enum-based field to restrict
        the LLM to just the IDs of the plans the user is looking at.

        Note that plan IDs used here is different from `plan_id`, as explained in the
        `Plan` data model

        Args:
            plans (list[Plan]): A list of `Plan` objects whose IDs will be allowed
                in the schema.
        """

        if plans:
            ids = [plan.id for plan in plans]
            ID = StrEnum("PlanID", {id: id for id in ids})
        else:
            ID = StrEnum("PlanID", {"NONE": "NONE"})

        new_args_schema = create_model(
            self._original_args_schema.__name__,
            plan_ids=(
                list[ID],
                Field(description="The IDs for plans the user is asking about."),
            ),
            __base__=self._original_args_schema,
        )
        new_args_schema.__doc__ = self._original_args_schema.__doc__
        self.args_schema = new_args_schema
