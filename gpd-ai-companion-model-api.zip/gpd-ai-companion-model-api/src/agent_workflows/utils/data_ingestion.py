import requests
from werkzeug.exceptions import HTTPException
from dataclasses import dataclass
import logging
import traceback
from ..globals import *

logger = logging.getLogger("agents.tools.tool_utils")

@dataclass
class CallSummary:
    
    def fetch_call_summary(self, api_url: str) -> str:
        try:
            full_api_url = f"{summary_api}{api_url}"
            logger.info(f"Fetching call summary from: {full_api_url}")
            response = requests.get(full_api_url, timeout=10)
            response.raise_for_status()
            data = response.json()
            last_value = str(list(list(data[0].items())[-1])[-1])
            logger.info("Call summary fetched successfully.")
            return last_value

        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(description=f"Failed to fetch call summary: {str(e)}", response=None, code=400)

        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(description="Unexpected error while processing the call summary.", response=None, code=500)


summary_data = CallSummary()
