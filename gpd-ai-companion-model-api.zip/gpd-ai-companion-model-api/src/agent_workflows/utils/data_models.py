"""
This module initializes data models used throughout the workflow
"""

from collections import Counter
from typing import Optional
from langchain_core.messages import BaseMessage, AIMessage

from pydantic import BaseModel, Field, model_validator
import hashlib
import re
import math

from .stopwords import stopwords


class Plan(BaseModel):
    # Need a separate ID since plan ID is not unique to year
    id: str = Field(default=None)  # type:ignore
    plan_id: str
    plan_name: str
    plan_year: str
    zip: str

    @model_validator(mode="before")
    def compute_id(cls, values: dict) -> dict:
        # If an 'id' isn't provided, compute it from plan_id, plan_name, and plan_year
        if not values.get("id"):
            to_hash = f"{values.get('plan_id', '')}_{values.get('plan_name', '')}_{values.get('plan_year', '')}"
            values["id"] = hashlib.md5(to_hash.encode()).hexdigest()[:4].upper()
        return values


class URLInfo(BaseModel):
    url: str
    url_title: str
    section: str
    keyword: str


def extract_keyword(
    text: str,
    n: int = 3,
    min_word_length: int = 3,
    stopwords: set[str] = stopwords,
) -> str:
    """Extract an n‑word substring (n‑gram) present in `text`, never containing
    a newline, and always return something.

    1) Tokenize on alphanumeric words (`\\w+`) and record spans.
    2) If fewer than n tokens, return the whole trimmed text.
    3) Build filtered n‑grams (no stopwords/min length, no '\n').
    4) If any filtered candidates exist, score them:
         score = len(substring) / sqrt(frequency_in_chunk)
       and choose the max.
    5) Otherwise, fall back to the longest *raw* n‑gram (still no '\n').
    6) If even that produces nothing (all windows had '\n'), return `text.strip()`.

    Args:
        text: The input text chunk.
        n: Number of consecutive words to form the n‑gram.
        min_word_length: Minimum length of each normalized token.
        stopwords: Lowercased tokens to exclude in the filtered pass.

    Returns:
        An n‑word substring exactly as it appears in `text`, guaranteed
        not to contain newline characters.
    """
    to_return: str

    # 1) Tokenize and record (normalized, start, end)
    tokens = []
    for m in re.finditer(r"\w+", text):
        norm = m.group(0).lower()
        tokens.append((norm, m.start(), m.end()))

    # 2) Not enough tokens -> return full trimmed text
    if len(tokens) < n:
        to_return = text.strip()
        return to_return

    # 3) Build filtered n‑grams
    filtered_subs = []
    for i in range(len(tokens) - n + 1):
        window = tokens[i : i + n]
        # skip if any stopword or too-short
        if any(tok in stopwords or len(tok) < min_word_length for tok, _, _ in window):
            continue
        start, end = window[0][1], window[-1][2]
        substr = text[start:end]
        # skip if contains a newline
        if ("\n" in substr) or ("Qualified Medicare Beneficiary" in substr):
            continue
        filtered_subs.append(substr)

    # 4) If filtered candidates exist, score & choose best
    if filtered_subs:
        freq = Counter(filtered_subs)
        scores = {s: len(s) / math.sqrt(cnt) for s, cnt in freq.items()}
        to_return = max(scores, key=scores.get)  # type:ignore
    else:
        # 5) FALLBACK → build raw n‑grams (only filter out '\n')
        raw_subs = []
        for i in range(len(tokens) - n + 1):
            start, end = tokens[i][1], tokens[i + n - 1][2]
            substr = text[start:end]
            if "\n" in substr:
                continue
            raw_subs.append(substr)

        # pick the longest raw n‑gram, or default to full text
        if raw_subs:
            to_return = max(raw_subs, key=len)
        else:
            to_return = text.strip()

    return to_return


class Chunk(BaseModel):
    doc_id: str = Field(default=None)  # type:ignore
    doc_text: str
    url: Optional[str]
    url_title: Optional[str]
    section: Optional[str]
    keyword: Optional[str] = Field(default=None)

    @model_validator(mode="before")
    def compute_fields(cls, values: dict) -> dict:
        # If a 'doc_id' isn't provided, compute it from doc_text
        if not values.get("doc_id"):
            hash_int = int(hashlib.md5(values["doc_text"].encode()).hexdigest(), 16)
            values["doc_id"] = f"doc{str(hash_int)[:3]}"
        # If keyword is not provided, compute it
        if not values.get("keyword"):
            # Only if we're returning URL info
            if values.get("url"):
                values["keyword"] = extract_keyword(values["doc_text"])
        return values


# For url_info and chunks, you can just use
# .model_dump_json() to convert each item to JSON
class WorkflowOutput(BaseModel):
    response: str
    chat_history: list[BaseMessage]
    questions: list[str]
    url_info: list[URLInfo]
    status: int
    chunks: list[Chunk]


class InfoClasses(BaseModel):
    question: str
    critical: str
    additional: str
    nice_to_have: str
    followup: list[str]


class BusinessGuidelines(BaseModel):
    input: str
    output: str


class AzureClientResult(BaseModel):
    msg: AIMessage
    msg_parsed: BaseModel | None


class SinglePlanToolArtifact(BaseModel):
    plan: Plan
    cleaned_answer: str
    answer_docs: list[str]
