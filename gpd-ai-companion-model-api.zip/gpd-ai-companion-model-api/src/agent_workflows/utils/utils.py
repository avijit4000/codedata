"""
Helper functions
"""

from functools import partial
from typing import Optional
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizableTextQuery
import backoff
from langchain.prompts import (
    ChatPromptTemplate,
    MessagesPlaceholder,
)
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
from llama_index.core.workflow import Context
from .data_models import Plan, Chunk, URLInfo
from ..globals import  ELIGIBILITY_OAUTH_ENDPOINT,ELIGIBILITY_OAUTH_CLIENT_ID,ELIGIBILITY_OAUTH_CLIENT_SECRET
import json
import asyncio
import logging
import unidecode
import re
import os
import pandas as pd
import httpx


import time
import requests

logger = logging.getLogger("agents.utils")




def get_eligibility_bearer_token():
    """
    Function to get bearer token for the eligibility check API.
    Uses environment variables to store and retrieve the token and its expiration time.
    """
    # Retrieve token and expiration time from environment variables
    token = os.environ.get("ELIGIBILITY_BEARER_TOKEN")
    expiry_time = os.environ.get("ELIGIBILITY_TOKEN_EXPIRY")

    # Check if the token is still valid
    if token and expiry_time and time.time() < float(expiry_time):
        
        logger.info('Using cached bearer token for eligibility check API')
        return token
    
    
    logger.info('Generating new bearer token for eligibility check API')
    # Generate a new token
    url = ELIGIBILITY_OAUTH_ENDPOINT
    client_id = ELIGIBILITY_OAUTH_CLIENT_ID
    client_secret = ELIGIBILITY_OAUTH_CLIENT_SECRET

    payload = f"grant_type=client_credentials&client_secret={client_secret}&client_id={client_id}&scope=api%3A%2F%2Fgpd-ole-nonprod-oauth%2F.default"
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    
    logger.debug(f"Payload for token request: {payload}")

    response = requests.request("POST", url, headers=headers, data=payload)
    response_data = response.json()

    # Extract the token and its expiration time
    token = response_data.get("access_token")
    expires_in = response_data.get("expires_in", 1800)  # Default to 30 minutes if not provided
    expiry_time = time.time() + expires_in - 60  # Subtract 60 seconds as a buffer

    if not token:
        logger.error("Failed to retrieve bearer token for eligibility check API")
        raise Exception("Failed to retrieve bearer token")
        

    # Store the token and expiration time in environment variables
    os.environ["ELIGIBILITY_BEARER_TOKEN"] = token
    os.environ["ELIGIBILITY_TOKEN_EXPIRY"] = str(expiry_time)

    return token



#function to fetch data from provider lookup api
    
async def fetch(client, url, method='GET', headers=None, data=None):
    """
    Fetches data from the given URL using the specified HTTP method and headers.
    Args:
        client (httpx.AsyncClient): The HTTP client to use for the request.
        url (str): The URL to fetch data from.
        method (str): The HTTP method to use (GET or POST).
        headers (dict, optional): Headers to include in the request.
        data (dict, optional): Data to include in the request body for POST requests.
    Returns:
        dict: The JSON response from the server.
    Raises:
        httpx.HTTPStatusError: If the response status code indicates an error.
        Exception: For any other exceptions that occur during the request.
    """
    logger.info(f"Fetching data from {url} using {method} method")
    logger.debug(f"Headers: {headers}")
 
    try:
        if method == 'GET':
            response = await client.get(url, headers=headers)
        elif method == 'POST':
            response = await client.post(url, headers=headers, json=data)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
        
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error occurred: {e}")
        raise
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise


# function to extract first, middle and last names from full name
def extract_names(full_name):

    try:
        # Remove extra spaces and commas
        full_name = re.sub(r"\s+", " ", full_name.strip())
        full_name = re.sub(r",", " ", full_name)

        # Split the name into parts
        name_parts = full_name.split()

        # Initialize variables
        first_name = ""
        middle_name = ""
        last_name = ""

        # Assign names based on the number of parts
        if len(name_parts) == 1:
            first_name = name_parts[0]
        elif len(name_parts) == 2:
            first_name, last_name = name_parts
        elif len(name_parts) == 3:
            first_name, middle_name, last_name = name_parts
        else:
            first_name = name_parts[0]
            last_name = name_parts[-1]
            middle_name = " ".join(name_parts[1:-1])

        # Handle initials
        if len(first_name) == 1 and len(middle_name) == 1:
            first_name = f"{first_name}."
            middle_name = f"{middle_name}."

        return first_name, middle_name, last_name
    except Exception as e:
        logger.error(f"Error extracting names: {e}")
        return "", "", ""


# function to lookup of fips & state code using  zip code
def get_fips_state_code(zip_code):

    # Get the directory of the current script
    current_directory = os.path.dirname(os.path.abspath(__file__))

    # File name
    file_name_csv = "./zip_codes_data/zip2fips.csv"

    file_name_json = "./zip_codes_data/zip2fips.json"

    # Construct the full path to the file
    file_path_csv = os.path.join(current_directory, file_name_csv)

    file_path_json = os.path.join(current_directory, file_name_json)

    logger.info(file_path_csv)

    zip2fips = json.load(open(file_path_json))

    df_zip2fips = pd.read_csv(file_path_csv)

    try:

        df_zipcode_filter = df_zip2fips[
            df_zip2fips.zipcode.astype(str) == str(zip_code)
        ]

        fips_code, state_code = zip2fips[zip_code], str(
            df_zipcode_filter["state_code"].values[0]
        )

    except Exception as e:

        logger.error(e)

        fips_code, state_code = "NA", "NA"

    logger.debug(f"fips & state codes :{fips_code} & {state_code}")

    return fips_code, state_code



def generate_plan_hyperlinks(input_data):
    """
    Generate hyperlinks for each plan name based on the input data.

    Args:
        input_data (dict): Dictionary containing plan details.

    Returns:
        dict: Dictionary with plan names as keys and hyperlinks as values.
    """
    
    try:

        zip_code = input_data["zip"]
        plan_ids = input_data["planId"]
        plan_names = input_data["planNames"]
        plan_year = input_data["year"]
        
        fips_code, state_code = get_fips_state_code(zip_code)

        # Extract the last three digits of the FIPS code
        fips_last_three = fips_code[-3:]

        # Generate hyperlinks
        hyperlinks = {}
        for plan_name, plan_id in zip(plan_names, plan_ids):
            hyperlink = f"https://www.aarpmedicareplans.com/health-plans/details.html/{zip_code}/{fips_last_three}/{plan_id.strip()}/{plan_year}"
            hyperlinks[plan_name.strip()] = hyperlink

        return hyperlinks
    
    except Exception as e:
        logger.error(f"Error generating plan hyperlinks: {e}")
        return {}
    
    
def page_detail_hyperlink_formating(user_input,response):
    """
    Formats the response by replacing plan names with hyperlinks and generates an HTML file.

    Args:
        response (str): The original response text.
        user_input (dict): Dictionary containing user input data, including plan names.

    Returns:
        str: The formatted response with hyperlinks for plan names.
    """
    try:
        plan_names_to_replace = user_input["planNames"]
        # Generate hyperlinks for the plan names
        hyperlinks = generate_plan_hyperlinks(user_input)
        logger.debug(f"Hyperlinks generated: {hyperlinks}")
        # Create a mapping of plan names to their hyperlinks
        replacement_mapping = {
            plan_name.strip(): f"<a href='{hyperlinks[plan_name.strip()]}' target='_blank'>{plan_name.strip()}</a>"
            for plan_name in plan_names_to_replace
        }

        # Replace all plan names in the response at once
        response = re.sub("|".join(map(re.escape, replacement_mapping.keys())), 
                        lambda match: replacement_mapping[match.group(0)], 
                        response)
        
        return response 
    except Exception as e:
        logger.error(f"Error formatting response with hyperlinks: {e}")
        return response


def create_chat_prompt_template(initial_msg) -> ChatPromptTemplate:
    """
    Create a ChatPromptTemplate by combining the provided initial message(s) with a messages placeholder.

    Args:
        initial_msg (BaseMessage | list[BaseMessage]):
            The initial message or list of messages that will be included in the prompt template.

    Returns:
        ChatPromptTemplate:
            A ChatPromptTemplate object containing the initial message(s) and a messages placeholder.
    """
    # If initial_msg is a list of messages, unpack it into ChatPromptTemplate; otherwise, just include it
    if isinstance(initial_msg, list):
        return ChatPromptTemplate.from_messages(
            [*initial_msg, MessagesPlaceholder("msgs")]
        )
    else:
        return ChatPromptTemplate.from_messages(
            [initial_msg, MessagesPlaceholder("msgs")]
        )


def inject_context(
    msgs: list[BaseMessage], plans: list[Plan], extra_content: str | None = None
) -> list[BaseMessage]:
    """
    Inject details about the user's plans into the last HumanMessage in the given list of messages.

    Args:
        msgs (list[BaseMessage]):
            A list of BaseMessage objects. The last HumanMessage found will be modified, not in place.
        plans (list[Plan]):
            A list of user Plan objects whose details need to be appended to the last HumanMessage.
        info_class (dict[str, str] | None, optional):
            An optional dictionary containing critical and additional information to be included in the message.

    Returns:
        list[BaseMessage]:
            The updated list of BaseMessages with additional plan context added to the last HumanMessage.
    """
    logger = logging.getLogger("agents.utils.inject_plan_details")
    msgs = msgs.copy()

    plans_pretty = {
        "plans": [
            {
                "id": plan.id,
                "plan_name": plan.plan_name,
                "plan_year": plan.plan_year,
                "zip": plan.zip,
            }
            for plan in plans
        ]
    }
    additional_content = (
        "\n\n# ADDITIONAL CONTEXT:\n"
        f"The user is currently looking at the following plans:\n{json.dumps(plans_pretty, indent=2)}\nRemember: for `plan_ids` function fields, only include plans the user is talking about. May be all, subset, or just 1. Do not mention the Plan ID to the user\n"
    )
    if extra_content:
        additional_content += extra_content

    # Find the last HumanMessage and append the plan details to its content
    for i in range(len(msgs) - 1, -1, -1):
        if isinstance(msgs[i], HumanMessage):
            new_content = msgs[i].content + additional_content  # type: ignore
            new_msg = HumanMessage(content=new_content, id=msgs[i].id)
            logger.debug(new_msg.pretty_repr())
            msgs[i] = new_msg
            break

    return msgs


def get_plan_from_ID(id: str, plans: list[Plan]) -> Optional[Plan]:
    """
    Retrieve a Plan object from a list of plans, matching by the given plan ID.

    Args:
        id (str):
            The ID of the plan to look for.
        plans (list[Plan]):
            A list of Plan objects in which to search.

    Returns:
        Plan:
            The Plan object matching the given ID.

    Raises:
        ValueError: If a plan with the given ID is not found.
    """
    if id == "NONE":
        return None
    for plan in plans:
        if plan.id == id:
            return plan
    raise ValueError(f"ID: {id} not found in plans: {plans}")


async def add_messages(
    ctx: Context, to_add: BaseMessage | list[BaseMessage], key: str = "msgs"
):
    """
    Asynchronously fetch the existing messages in the context, append the provided message(s),
    and store them back in the context.

    Args:
        ctx (Context):
            An instance of the llama_index workflow Context object.
        to_add (BaseMessage | list[BaseMessage]):
            One or more BaseMessage objects to add to the context's list of messages.
        key (str, optional):
            The key under which the messages are stored in the context. Defaults to "msgs".

    Returns:
        None
    """
    if isinstance(to_add, BaseMessage):
        to_add = [to_add]
    msgs = await ctx.get(key)
    msgs += to_add
    await ctx.set(key, msgs)


async def wait_for_context(ctx: Context, key: str):
    """
    Asynchronously wait until the key is available in the provided context.

    Args:
        ctx (Context):
            An instance of the llama_index workflow Context object.
        key (str):
            The key to wait for in the context.
    Returns:
        Any:
            The key's value once it is found in the context.
    """
    retrieved_data = await ctx.get(key, default=None)
    while not retrieved_data:
        logger.debug(f"awaiting {key}")
        await asyncio.sleep(0.05)
        retrieved_data = await ctx.get(key, default=None)
    logger.debug(f"{key} found")
    return retrieved_data


class StreamToLogger(object):
    """
    Custom stream object that redirects writes to a logger instance.
    """

    def __init__(self, logger, log_level=logging.DEBUG):
        """
        Initialize the StreamToLogger object.

        Args:
            logger (logging.Logger):
                The logger instance to which messages will be written.
            log_level (int):
                The logging level at which the messages will be emitted.
        """
        self.logger = logger
        self.log_level = log_level
        self.linebuf = ""

    def write(self, buf):
        """
        Write the provided buffer to the logger instance line by line.

        Args:
            buf (str):
                The text buffer to write to the logger.
        """
        for line in buf.rstrip().splitlines():
            self.logger.log(self.log_level, line.rstrip())

    def flush(self):
        """
        Flush the stream. This method is a no-op for compatibility.
        """
        pass


@backoff.on_exception(backoff.expo, Exception, max_tries=4, jitter=backoff.full_jitter)
async def get_documents_from_index(
    query: str,
    index_name: str,
    top_n_documents: int,
    semantic_configuration: str,
    search_key: str,
    search_endpoint: str,
    filter: str = "",
):
    """
    Asynchronously retrieves documents from an Azure Search index using vector queries
    and semantic search settings.

    Args:
        query (str): The search query text.
        index_name (str): The name of the Azure Search index.
        top_n_documents (int): The number of documents to retrieve.
        semantic_configuration (str): The semantic configuration name.
        search_key (str): The Azure Search key credential.
        search_endpoint (str): The Azure Search endpoint URL.
        filter (str, optional): An OData filter expression. Defaults to "".

    Returns:
        azure.search.documents._paging.SearchItemPaged:
            An iterator of documents returned from the search.
    """
    search_credential = AzureKeyCredential(search_key)
    search_client = SearchClient(search_endpoint, index_name, search_credential)
    vector_query = VectorizableTextQuery(text=query, fields="vector")

    # use search_client to search index_name with semantic configuration "my-semantic-config" and query_type "vectorSemanticHybrid"
    # return the top 5 documents
    loop = asyncio.get_event_loop()
    if filter != "":
        return await loop.run_in_executor(
            None,
            partial(
                search_client.search,
                search_text=query,
                vector_queries=[vector_query],
                query_type="semantic",
                semantic_configuration_name=semantic_configuration,
                top=top_n_documents,
                filter=filter,
            ),
        )
    else:
        return await loop.run_in_executor(
            None,
            partial(
                search_client.search,
                search_text=query,
                vector_queries=[vector_query],
                query_type="semantic",
                semantic_configuration_name=semantic_configuration,
                top=top_n_documents,
            ),
        )


def convert_text_to_ascii(text):
    # Explicitly replace certain characters
    text = text.replace("•", "-")
    text = text.replace("–", "-")
    # Then fallback to unidecode to handle others
    text = unidecode.unidecode(text)
    return text


def get_url_info_from_chunks(
    answer_docs: list[str], chunks_dict: dict[str, Chunk]
) -> list[URLInfo]:
    """
    Filters the given chunks dictionary to only those chunks whose doc_id is present
    in the answer_docs list. For each filtered chunk, creates a URLInfo object IF and
    ONLY IF the chunk has all three optional properties defined (url, section, keyword).

    Args:
        answer_docs (list[str]): List of doc_id strings to filter on.
        chunks_dict (dict[str, Chunk]): A dictionary mapping doc_id to Chunk objects.

    Returns:
        list[URLInfo]: A list of URLInfo objects extracted from the filtered chunks.
            Only chunks with non-empty url, section, and keyword will produce a result.

    Edge cases:
        - If answer_docs is empty, an empty list is returned.
        - If chunks_dict is empty, an empty list is returned.
        - If a doc_id from answer_docs is not present in chunks_dict, it is skipped.
        - If a chunk's url, section, or keyword is None, that chunk does not produce a URLInfo.
    """
    results: list[URLInfo] = []

    # Iterate over all doc_ids that we are interested in (from answer_docs).
    for doc_id in answer_docs:
        chunk = chunks_dict.get(doc_id)
        if chunk is None:
            # If the chunk is not found in the dictionary, skip.
            continue

        # Check if all optional fields exist before creating a URLInfo object.
        if chunk.url and chunk.keyword:
            results.append(
                URLInfo(
                    url=chunk.url,
                    url_title=chunk.url_title,  # type:ignore
                    section=chunk.section,  # type:ignore
                    keyword=chunk.keyword,
                )
            )

    return results


def extract_document_ids_strict(text: str) -> tuple[str, list[str]]:
    """
    Extracts document IDs that strictly follow the format [doc{numbers}] from
    the input text, returning a tuple containing:
      1. A cleaned text with these annotations removed.
      2. A list of the extracted IDs (e.g., ["doc762", "doc238"]).

    Args:
        text (str): The input text that may contain strict-format document ID annotations.

    Returns:
        tuple[str, list[str]]: A tuple containing:
            - The input text with valid [doc{numbers}] annotations removed.
            - A list of the extracted document IDs as strings.
    """
    # Find all occurrences of "[doc" followed by 1 or more digits, then "]"
    # and capture the substring 'doc{digits}' without the square brackets.
    doc_ids = re.findall(r"\[(doc\d+)\]", text)

    # Remove the bracketed "[doc{digits}]" annotations from the original text
    cleaned_text = re.sub(r"\[doc\d+\]", "", text)

    # Remove extra whitespace that might result from removing the annotations
    cleaned_text = re.sub(r"\s+", " ", cleaned_text).strip()

    return cleaned_text, doc_ids


async def cancel_tasks(ctx: Context, task_names: Optional[list[str]] = None) -> None:  # type: ignore
    """Cancels asyncio tasks specified by the given task names in the provided context.

    This function retrieves tasks using the names from the context and only cancels those
    that are still running. It then waits for the tasks to exit, ensuring that any cancellation
    exceptions are handled without propagating them.

    Args:
        ctx (Context): The context from which to retrieve tasks.
        task_names (list[str]): A list of task names representing the tasks to be cancelled.

    Returns:
        None
    """

    # Only cancel those that are still running:
    tasks: list[asyncio.Task] = []
    if not task_names:
        task_names: list[str] = await ctx.get("all_task_names")
    for name in task_names:
        maybe_task = await ctx.get(name, default=None)
        if maybe_task is not None:
            tasks.append(maybe_task)
    pending = [t for t in tasks if not t.done()]
    if not pending:
        return

    for t in pending:
        t.cancel()  # request cancellation

    # Wait for them to actually exit.  return_exceptions=True
    # prevents CancelledError from bubbling up.
    await asyncio.gather(*pending, return_exceptions=True)
    logger.info(f"Tasks cancelled: {task_names}")
