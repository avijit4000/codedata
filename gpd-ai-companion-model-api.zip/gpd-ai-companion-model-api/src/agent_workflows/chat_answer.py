"""
This module defines and is the entry point for the workflow
"""

from llama_index.core.workflow import (
    Context,
    Event,
    StartEvent,
    StopEvent,
    Workflow,
    step,
)
from llama_index.core.workflow.retry_policy import ConstantDelayRetryPolicy

from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage, AIMessage
from typing import Any, Literal, Optional
import asyncio
import json
from pydantic import BaseModel

from .utils.async_queries import get_business_guidelines
from .llms import *
from .globals import NUM_FOLLOWUP_Q
from .tools import tool_dict, convert_tools
from .tools.tool_utils import LLMFunctionWithPlan, LLMFunction
from .tools.tool_defs import PartialWorkflowOutput
from .utils.data_models import (
    Plan,
    WorkflowOutput,
    BusinessGuidelines,
    InfoClasses,
    AzureClientResult,
    Chunk,
)
from .utils.utils import (
    inject_context,
    add_messages,
    get_plan_from_ID,
    get_url_info_from_chunks,
    cancel_tasks,
)
from .utils.async_queries import rephraser, info_class_getter

import logging

logger = logging.getLogger("agents.chat_answer")


# Event classes
class SummarizerEvent(Event):
    msgs_clean: list[BaseMessage]


class SummarizationEvent(Event):
    msgs_summarized: list[BaseMessage]


class InitialGoalSeekerEvent(Event):
    pass


class GoalSeekerEvent(Event):
    pass


class ToolCallEvent(Event):
    tool_call: dict


class ToolResultEvent(Event):
    pass


class OutputBuilderEvent(Event):
    msg_parsed: GoalSeekerOutput | InitialGoalSeekerOutput


class PartialOutputBuilderEvent(Event):
    """
    Used to indicate that the output builder is in a partial state and can be used for intermediate outputs.
    This is useful when the workflow needs to return partial results before completion.
    """

    msg_parsed: PartialWorkflowOutput
    ctx: Context


class ChatAnswer(Workflow):
    """
    The ChatAnswer workflow orchestrates the conversation, tool calls,
    and answer construction process.

    This workflow includes steps for rephrasing the user's question,
    calling external tools if needed, and building a structured answer.
    """

    def __init__(
        self,
        *args: Any,
        max_retries: int = 2,
        max_turns: int = 5,
        **kwargs: Any,
    ) -> None:
        """
        Initialize the ChatAnswer workflow.

        Args:
            max_retries: Maximum number of times to retry goal seeking steps.
            max_turns: Conversation will be summarized so only `max_turns` # of turns remain
        """
        super().__init__(*args, **kwargs)
        self.max_retries = max_retries
        self.max_turns = max_turns

    @step
    async def entrypoint(
        self, ctx: Context, ev: StartEvent
    ) -> InitialGoalSeekerEvent | SummarizerEvent:
        """
        Initial step to rephrase messages and store them in context for later steps.
        """
        await ctx.set("source", ev.source)
        # Copy so we don't mutate original list
        raw_chat_history: list[BaseMessage] = ev.raw_chat_history.copy()

        msgs = raw_chat_history
        await ctx.set("msgs", msgs)
        # Send these to run now
        # Will be awaited when needed
        # Likely awaited multiple times, subsequent awaits just return cached result
        business_guidelines_task = asyncio.create_task(
            get_business_guidelines(ev.source)
        )
        rephraser_task = asyncio.create_task(rephraser(msgs=msgs))
        info_class_task = asyncio.create_task(
            info_class_getter(rephraser_task=rephraser_task)
        )
        await ctx.set("business_guidelines_task", business_guidelines_task)
        await ctx.set("rephraser_task", rephraser_task)
        await ctx.set("info_class_task", info_class_task)
        await ctx.set(
            "all_task_names",
            [
                "business_guidelines_task",
                "info_class_task",
                "rephraser_task",
            ],
        )
        ctx.send_event(SummarizerEvent(msgs_clean=msgs))

        # Store plans and evaluation in context
        plans: list[Plan] = ev.plans
        await ctx.set("plans", plans)
        await ctx.set("all_chunks", {})
        await ctx.set("tools_converted", convert_tools(plans, ev.source))

        return InitialGoalSeekerEvent()

    async def goal_seeker_helper(
        self, ctx: Context, ai_msg_raw: AzureClientResult
    ) -> OutputBuilderEvent | ToolCallEvent | None:
        ai_msg = ai_msg_raw.msg
        ai_msg_parsed = ai_msg_raw.msg_parsed
        logger.info(f"Goal Seeker Message {ai_msg.pretty_repr()}")

        # Determine if there are tool calls
        tool_calls: list[dict] = (
            ai_msg.tool_calls if hasattr(ai_msg, "tool_calls") else []
        )  # type: ignore

        if len(tool_calls) == 0:
            if ai_msg_parsed is None:
                raise AssertionError("AI Message should not be None but it is")
            return OutputBuilderEvent(msg_parsed=ai_msg_parsed)  # type: ignore
        else:
            # Otherwise, proceed with tool calls
            await add_messages(ctx, ai_msg)
            await ctx.set("num_tool_calls", len(tool_calls))
            for tool_call in tool_calls:
                ctx.send_event(ToolCallEvent(tool_call=tool_call))

    @step
    async def initial_goal_seeker(
        self, ctx: Context, ev: InitialGoalSeekerEvent
    ) -> OutputBuilderEvent | ToolCallEvent | None:
        msgs: list[BaseMessage] = await ctx.get("msgs")
        plans: list[Plan] = await ctx.get("plans")
        llm = get_initial_goal_seeker_llm(
            await ctx.get("tools_converted"), source=await ctx.get("source")
        )

        # Inject plan details into the last HumanMessage
        # Does not mutate msgs in context
        msgs_injected = inject_context(msgs, plans)
        business_guidelines: BusinessGuidelines = await (
            await ctx.get("business_guidelines_task")
        )
        ai_msg_raw = await llm.achat(
            msgs=msgs_injected,
            input_guidelines=business_guidelines.input,
            output_guidelines=business_guidelines.output,
        )

        return await self.goal_seeker_helper(ctx, ai_msg_raw)

    @step
    async def summarizer(self, ctx: Context, ev: SummarizerEvent) -> SummarizationEvent:
        # Only `max_turns` number of turns should remain after summarization
        max_turns = self.max_turns
        msgs = await conversation_summary(
            conversations=ev.msgs_clean, turn_around_messages=max_turns
        )
        # ev.msgs_clean = msgs

        return SummarizationEvent(msgs_summarized=msgs)

    @step
    async def goal_seeker(
        self, ctx: Context, ev: GoalSeekerEvent
    ) -> OutputBuilderEvent | ToolCallEvent | None:
        """
        Attempt to produce an AI message guiding the workflow or calling tools if needed.
        Retries if necessary.
        """
        msgs: list[BaseMessage] = await ctx.get("msgs")
        plans: list[Plan] = await ctx.get("plans")
        tools_converted: list[dict] = await ctx.get("tools_converted")
        business_guidelines: BusinessGuidelines = await (
            await ctx.get("business_guidelines_task")
        )
        # These will be None if user is not asking a question
        # or will be None if question does not match index above similarity threshold.
        # If None, inject them into the system prompt. Otherwise, use a generic message
        if await ctx.get("source") == "digital":
            info_classes: InfoClasses = await (await ctx.get("info_class_task"))
            if info_classes:
                prompt_extension = completeness_check_extension.format(
                    critical_info=info_classes.critical,
                    additional_info="\n".join(
                        # not gonna provide nice_to_have since it overloads model
                        [info_classes.additional]  # , info_classes.nice_to_have]
                    ),
                )
                info_class_available = True
            else:
                prompt_extension = ""
                info_class_available = False
        else:
            prompt_extension = ""
            info_class_available = False
        # Inject plan details into the last HumanMessage
        # Does not mutate msgs in context
        msgs_injected = inject_context(msgs, plans, prompt_extension)

        # Collect repeated events to detect when to pass to a max_retries LLM
        events = ctx.collect_events(ev, [GoalSeekerEvent] * self.max_retries)

        ai_msg_raw = await get_goal_seeker(
            tools_converted,
            max_retries=bool(events),
            # Picks correct GoalSeeker response format
            info_class_available=info_class_available,
            source=await ctx.get("source"),
        ).achat(
            msgs=msgs_injected,
            output_guidelines=business_guidelines.output,
            prompt_extension=prompt_extension,
        )
        return await self.goal_seeker_helper(ctx, ai_msg_raw)

    @step
    async def tool_call(
        self, ctx: Context, ev: ToolCallEvent
    ) -> ToolResultEvent | PartialOutputBuilderEvent:
        """
        Invoke the appropriate tool based on the tool call data and add the result to the conversation.
        """
        tool_call: dict = ev.tool_call
        tool: LLMFunction = tool_dict[tool_call["name"]]

        # Ensure the tool is valid before proceeding
        if tool.func:
            # Some tools support additional plans as arguments
            if isinstance(tool, LLMFunctionWithPlan):
                all_plans: list[Plan] = await ctx.get("plans")
                plans: list[Optional[Plan]] = [
                    get_plan_from_ID(id, all_plans)
                    for id in tool_call["args"]["plan_ids"]
                ]
                if plans == []:
                    plans = [None]
                # These are actually kwargs!!!!
                args = tool_call["args"].copy()
                del args["plan_ids"]
                tool_message: ToolMessage | PartialWorkflowOutput = await tool.func(
                    tool_call_id=tool_call["id"], ctx=ctx, plans=plans, **args
                )
            else:
                tool_message: ToolMessage | PartialWorkflowOutput = await tool.func(
                    tool_call_id=tool_call["id"], ctx=ctx, **tool_call["args"]
                )
            # Check if the tool returned a PartialWorkflowOutput
            if isinstance(tool_message, PartialWorkflowOutput):
                logger.info("Tool returned a PartialWorkflowOutput.")
                return PartialOutputBuilderEvent(msg_parsed=tool_message, ctx=ctx)

            logger.debug(tool_message.pretty_repr())
            await add_messages(ctx, tool_message)
            return ToolResultEvent()
        else:
            raise ValueError(f"Tool {tool.func_name} called but it has no func")

    @step
    async def tool_gather(
        self, ctx: Context, ev: ToolResultEvent
    ) -> GoalSeekerEvent | None:
        """
        Gather tool results and trigger a new goal-seeker step
        """
        num_tool_calls: int = await ctx.get("num_tool_calls")
        # Collect events to see if all tools have returned
        events = ctx.collect_events(ev, [ToolResultEvent] * num_tool_calls)
        if not events:
            return None
        else:
            return GoalSeekerEvent()

    @step
    async def output_builder(
        self, ctx: Context, ev: OutputBuilderEvent | SummarizationEvent
    ) -> StopEvent | None:
        source: Literal["digital", "telesales", "uhccp", "group_retiree"] = (
            await ctx.get("source")
        )
        chunks_dict: dict[str, Chunk] = await ctx.get("all_chunks")
        events = ctx.collect_events(ev, [OutputBuilderEvent, SummarizationEvent])
        if not events:
            return None
        output_builder_event: OutputBuilderEvent
        summarization_event: SummarizationEvent
        output_builder_event, summarization_event = events  # type: ignore
        msg_parsed = output_builder_event.msg_parsed

        if (msg_parsed.message_type == "refusal") and (source == "digital"):
            if msg_parsed.refusal_type in ["claims", "appeals", "complaints"]:
                response = "To make a claim or appeal, call 877-699-5710 between 8 a.m.-8 p.m. CT, 7 days a week."
                status = 2003
            else:
                response = "Unfortunately, I can only answer questions about costs, benefits and coverage available with our Medicare Advantage plans. Do you have a question about our plans?"
                status = 2000
            await cancel_tasks(ctx)
            return StopEvent(
                WorkflowOutput(
                    response=response,
                    chat_history=summarization_event.msgs_summarized
                    + [AIMessage(response)],
                    questions=[],
                    url_info=[],
                    status=status,
                    chunks=[],
                )
            )
        elif isinstance(msg_parsed, InitialGoalSeekerOutput):
            await cancel_tasks(ctx)
            return StopEvent(
                WorkflowOutput(
                    response=msg_parsed.message,
                    chat_history=summarization_event.msgs_summarized
                    + [AIMessage(msg_parsed.message)],
                    questions=[],
                    url_info=[],
                    status=200,
                    chunks=[],
                )
            )
        else:
            if not isinstance(msg_parsed, GoalSeekerOutput):
                raise AssertionError(
                    f"`msg_parsed` is of wrong type: {type(msg_parsed)}"
                )
            chunks = list(chunks_dict.values())
            url_info = get_url_info_from_chunks(msg_parsed.answer_docs, chunks_dict)
            status = 200
            if msg_parsed.message_type == "info_not_found":
                if msg_parsed.info_not_found_type == "drug":
                    status = 2002
                elif msg_parsed.info_not_found_type == "provider":
                    status = 2001
                else:
                    status = 2000
            if hasattr(msg_parsed, "followup_questions"):
                questions = msg_parsed.followup_questions  # type: ignore
            else:
                info_classes: InfoClasses = await (await ctx.get("info_class_task"))
                questions = info_classes.followup
            if msg_parsed.message_type != "answer":
                questions = []
                chunks = []
                url_info = []
            await cancel_tasks(ctx)
            return StopEvent(
                WorkflowOutput(
                    response=msg_parsed.message,
                    chat_history=summarization_event.msgs_summarized
                    + [AIMessage(msg_parsed.message)],
                    questions=questions,
                    url_info=url_info,
                    status=status,
                    chunks=chunks,
                )
            )

    @step
    async def partial_output_builder(
        self, ctx: Context, ev: PartialOutputBuilderEvent | SummarizationEvent
    ) -> StopEvent | None:
        """
        Handles PartialWorkflowOutput and completes it into a WorkflowOutput.
        """
        logger.info("partial output builder")
        events = ctx.collect_events(ev, [PartialOutputBuilderEvent, SummarizationEvent])
        if not events:
            return None
        # Retrieve the partial output from the event
        partial_output: PartialWorkflowOutput = events[0].msg_parsed
        summarization_event = events[1]
        assert isinstance(summarization_event, SummarizationEvent)

        # Create chat history by appending the response as an AIMessage to summarized messages
        chat_history = summarization_event.msgs_summarized + [
            AIMessage(content=partial_output.response)
        ]

        workflow_output = WorkflowOutput(
            response=partial_output.response,
            chat_history=chat_history,
            status=partial_output.status,
            chunks=partial_output.chunks,
            questions=(
                partial_output.questions if hasattr(partial_output, "questions") else []
            ),
            url_info=(
                partial_output.url_info if hasattr(partial_output, "url_info") else []
            ),
        )
        await cancel_tasks(ctx)
        return StopEvent(workflow_output)
