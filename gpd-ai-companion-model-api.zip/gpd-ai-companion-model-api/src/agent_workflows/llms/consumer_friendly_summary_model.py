import os
from dotenv import load_dotenv
from openai import AzureOpenAI
import logging
from werkzeug.exceptions import HTTPException
import traceback
logger = logging.getLogger("agents.tools.tool_utils")

load_dotenv()
azure_endpoint = os.getenv("OPENAI_ENDPOINT")
api_key = os.getenv("OPENAI_KEY")
api_version = os.getenv("API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini")

class CallSummaryGenerator:
    def __init__(self):
        self.client = AzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version
        )
        logger.info("Application started")

    def generate_summary(self, prompt: str) -> str:
        try:
            messages = [
                {"role": "system", "content": "You are a helpful summarization assistant."},
                {"role": "user", "content": prompt}
            ]
            response = self.client.chat.completions.create(
                model=azure_model,
                messages=messages,
                temperature=0.4
            )
            summary = response.choices[0].message.content.strip()
            logger.info("Summary generated successfully.")
            return summary
        except Exception as e:
            logger.error(f"OpenAI summarization error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(status_code=500, detail="Error generating summary using AzureOpenAI.")

summary_generator = CallSummaryGenerator()
