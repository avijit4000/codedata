from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from pydantic import BaseModel, Field
from typing import Literal
from ..globals import *

plan_compare_single_system = """Your task is to succinctly answer a query a customer has about medicare plans for UHC. You will be provided the query, sources to use in answering the query, and some facts you should try to include in your answer. You must output an answer, and identify which sources you used to answer (if applicable).

Your answer MUST be grounded in the provided sources, do not make stuff up. If you cannot answer the query from provided sources, please say "I cannot find the information to answer your query"

Annotate each fact with the document ID it's from (if document IDs are available), they look like 'doc835'. E.g.:
"This is a fact[doc762]. This is another fact[doc238]."

# Output Guidelines
- Try to keep your answer within 3 sentences
- Use a factual and succinct tone
- Use markdown formatting as necessary for bolding, italics, lists, etc, but DO NOT use headers
"""

plan_compare_single_human = """QUERY: {user_query}

# SOURCES
Please answer the user query using the following source(s)
{sources}

{prompt_extension}
"""
plan_compare_single_prompt_extension = """# FACTS TO INCLUDE:
Please try to include the following facts from the sources in your answer. If you cannot do so, please say "I cannot find the information to answer your query".
{critical_info}"""
plan_compare_single_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(plan_compare_single_system),
        HumanMessagePromptTemplate.from_template(
            template=plan_compare_single_human,
            input_variables=["user_query", "sources", "prompt_extension"],
        ),
    ]
)


class SinglePlanAnswer(BaseModel):
    answer: str = Field(
        description="Answer to the user's query, must be grounded in provided sources"
    )
    missing_info: bool = Field(
        description="Whether the sources are missing some information to answer the query"
    )


llm = AzureChatOpenAI(
    api_key=API_KEY,  # type:ignore
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4o-mini",
    api_version=API_VERSION,
    temperature=0,
).with_structured_output(SinglePlanAnswer, method="json_schema", include_raw=False)

plan_compare_single_chain = plan_compare_single_template | llm
