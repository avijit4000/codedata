class LLMTemplate:
    def summarytemplate(self, conversation_summary: str) -> str:
        prompt = f"""
    You are a summarization assistant. Your task is to turn the following medical service conversation summary into a short, clear, and user-focused explanation, addressing the reader directly ("you") and making the information easy to understand.
    
    Guidelines:
    - Carefully read the summary and infer the most likely context for the conversation, such as the user contacting us to inquire, confirm, or clarify something.
    - Begin the summary with a phrase that gives context for the user's inquiry, such as "You contacted us to inquire about..." or "You reached out to confirm...", even if the input does not specify this directly.
    - Rewrite all information in the second person, speaking to "you" (do not refer to the member, recipient, customer, or user in the third person).
    - Use a respectful, supportive, and friendly tone.
    - Clearly state what was confirmed, clarified, or explained, highlighting important benefits, eligibility details, and actions taken for you.
    - Emphasize significant outcomes or protections using plain language and attention phrases such as:
      - "Please note..."
      - "You should know that..."
      - "It's important to understand..."
      - "You are eligible for..."
    - If gratitude or appreciation is expressed in the conversation, reflect that in your summary.
    - Avoid technical jargon, repetitive wording, or overly long explanations.
    - Keep the summary concise (2 to 4 sentences), in a single continuous paragraph, and suitable for display to the user.
    
    Conversation Summary:
    {conversation_summary}
    
    Rewrite the above as a user-focused summary. Begin by stating the user's inquiry, then summarize the key findings, clarifications, or benefits, highlighting critical points for the user's attention:
    """
        return prompt

classtem= LLMTemplate()