from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage
from langchain_core.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
)
from pydantic import BaseModel
from typing import Literal
from ..globals import *

compare_questions_human = """
#USER_QUESTION: {user_query}

#index_query_1: {index_query_1}
#index_query_2: {index_query_2}
#index_query_3: {index_query_3}
#index_query_4: {index_query_4}
#index_query_5: {index_query_5}

"""

compare_questions_system = """Your task is to evaluate the semantic similarity between a given user query (which may contain multiple parts or compound questions) and a list of indexed questions. The goal is to determine whether the meaning and intent of the user query and each indexed question are the same or different within the context of the medical domain for UnitedHealth Group.  
  
### **Independent Evaluation:**  
- Assess each indexed question independently.  
- Do not let the content or context of previous indexed questions influence your evaluation of the current question.  
- Treat each indexed question as a standalone comparison with the user query.  
- **Compound/Multiple-Part Queries**:   
  - If the user query contains multiple parts, the match is only **True** if the indexed question aligns with **all parts** of the user query.   
  - If any part of the user query does not align with the indexed question, the match must be **False**.  
  
### **Key Requirements:**  
- **Semantic Similarity in the Medical Domain**:  
  - Evaluate alignment based on meaning and intent, even if the wording differs.  
  - Pay close attention to healthcare-specific differences in terminology, such as "coverage," "cost," "copay," "coinsurance," "provider," and "specialist."  
  - Ensure that the **context** of the medical domain remains consistent across all parts of the user query and indexed question.  
  - For compound queries, the intent of **every part** of the user query must match the indexed question for a **True** result.   
  - If an indexed question addresses only **one part** of a compound query while ignoring other parts, the match must be **False**.  
  
### **Decision-Making Criteria:**  
- **True**: The user query and indexed question express the same meaning and intent across **all parts** of the user query (terminologies match, context matches, and specific focuses align for every part).  
- **False**: The user query and indexed question express different meanings or intents, **or if any part of a compound query does not align** with the indexed question.  
  
### **Examples of Common Scenarios:**  
1. **Exact Match of All Parts**:  
   - User Query: "Is eyewear covered under the plan and does it cover home health care?"  
   - Indexed Question: "Is eyewear covered under the plan and does it cover home health care?"  
   - **True** (Both parts match the intent and meaning exactly).  
  
2. **Partial Match for Compound Questions**:  
   - User Query: "Is eyewear covered under the plan and does it cover home health care?"  
   - Indexed Question 1: "Is eyewear covered under this plan?"  
   - Indexed Question 2: "Does this plan cover home health care?"  
   - **False** (Each indexed question addresses only one part of the compound query and ignores the other part, making it a partial match).  
  
3. **Different Focus**:  
   - User Query: "Is eyewear covered under the plan and does it cover home health care?"  
   - Indexed Question: "Does this plan cover general eye exams?"  
   - **False** (The user query focuses on eyewear coverage, while the indexed question focuses on eye exams, leading to different intents).  
  
4. **Different Terminology in Compound Query**:  
   - User Query: "Can I see a provider and is the copay affordable?"  
   - Indexed Question: "Can I see a provider?"  
   - **False** (The first part aligns, but the second part about copay affordability does not match).  
  
**Handling Ambiguity:**  
- If a question is ambiguous or unclear, use the context of the medical domain and the intent of the user query to make a reasoned decision.  
- If intent cannot be reasonably inferred, default to False and provide a clear explanation.  
- The user query and indexed question have partial match it should be False.
  
**Output Format:**  
For each indexed question, provide a True or False response along with reasoning in JSON format. Ensure that your evaluation for each question is independent.   
  
Example output:  
```json  
{  
    "is_similar1": "False",  
    "reason1": "The user query is about seeing doctors out of network, while the indexed question is unrelated.",  
    "is_similar2": "True",  
    "reason2": "The user query aligns with the coverage question for out of network doctors.",  
    "is_similar3": "False",  
    "reason3": "The user query is about seeing out of network providers and eye cost, which is partial match.",  
    "is_similar4": "False",  
    "reason4": "The user query addresses the ability to see a doctor, while the indexed question is about specific costs.",  
    "is_similar5": "False",  
    "reason5": "The user query is about general doctors, while the indexed question specifies a specialist."  
} ``` """


class SimilarityData(BaseModel):  
    is_similar1: Literal[True, False]  
    is_similar2: Literal[True, False]  
    is_similar3: Literal[True, False]  
    is_similar4: Literal[True, False]  
    is_similar5: Literal[True, False]  
    Reason1: str
    Reason2: str
    Reason3: str
    Reason4: str
    Reason5: str

compare_questions_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(compare_questions_system),
        HumanMessagePromptTemplate.from_template(
            template=compare_questions_human,
            input_variables=["user_query", "index_query"],
        ),
    ]
)



llm = AzureChatOpenAI(
    api_key=API_KEY,  # type:ignore
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4o-mini",
    api_version=API_VERSION,
    temperature=0,
).with_structured_output(SimilarityData, method="json_schema", include_raw=False)

compare_questions_chain = compare_questions_template | llm
