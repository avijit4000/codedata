import os

# Workflow constants
NUM_FOLLOWUP_Q = 3
TOP_N_DOCUMENTS = 5

# LLM Stuff
API_KEY = os.getenv("OPENAI_KEY")
AZURE_ENDPOINT = os.getenv("OPENAI_ENDPOINT")
API_VERSION = "2025-01-01-preview"

O3_MINI_TIMEOUT = 15.0



#PROVIDER LOOKUP API 


PROVIDER_LOOKUP_API_ENDPOINT =  "https://inpage-prov-search-basic-service-api-qa-1.qa.gpd-acq-azure.optum.com/ip-prov-search-bs-api/orchestration/providers/search/v1"

TOP_N_PROVIDERS = 5


#Eligibility check API endpoints and OAuth details
ELIGIBILITY_CHECK_API_ENDPOINT = "https://www.stage-aarpmedicareplans.uhc.com/online-enrollment/eligibility/orchestration/eligibility"


ELIGIBILITY_OAUTH_ENDPOINT = "https://login.microsoftonline.com/db05faca-c82a-4b9d-b9c5-0f64b6755421/oauth2/v2.0/token"

ELIGIBILITY_OAUTH_CLIENT_ID = os.environ["ELIGIBILITY_OAUTH_CLIENT_ID"]

ELIGIBILITY_OAUTH_CLIENT_SECRET = os.environ["ELIGIBILITY_OAUTH_CLIENT_SECRET"]





PROVIDER_OUTPUT_KEYS_TO_SELECT = {
                    "personName": 'item["personName"]',
                    "gender": 'item["gender"]',
                    #"education": 'item["education"]',
                    "languages": 'item["languages"]',
                    "providerReview": 'item["providerReview"]',
                    "agesTreated": 'item["agesTreated"]',
                    "gendersTreated": 'item["gendersTreated"]',
                    "conditionsTreated": 'item["conditionsTreated"]',
                    "providerDetails": '[{"address":item["providerLocations"][i]["address"],"phones":item["providerLocations"][i]["phones"]  \
                    ,"specialties": [(item_a["translatedName"]["en"],item_a["translatedKeywords"]["en"]) for item_a in item["providerLocations"][i]["specialties"] if len(item["providerLocations"][i]["specialties"])>0]  \
                    ,"preferredPlans":item["providerLocations"][i]["preferredPlans"] \
                    ,"acceptsMedicare":item["providerLocations"][i]["acceptsMedicare"]  \
                    ,"officeHours":item["providerLocations"][i]["officeHours"]  \
                    ,"electronicHealthRecords":item["providerLocations"][i]["electronicHealthRecords"]  \
                    ,"amenities":item["providerLocations"][i]["amenities"]  \
                    ,"patientCenteredMedicalHome":item["providerLocations"][i]["patientCenteredMedicalHome"]  \
                    ,"languagesInterpreter":item["providerLocations"][i]["languagesInterpreter"]  \
                    ,"websites":item["providerLocations"][i]["websites"]  \
                    ,"emails":item["providerLocations"][i]["emails"]  \
                    } \
                     for i in range(len(item["providerLocations"])) if len(item["providerLocations"]) > 0 ]', 
                    
                    
                    }
                    
                    
#eligibility plan mapping for different zip codes 

all_plans_35242 = [
            {"plan_id": "H2802041000", "plan_name": "AARP Medicare Advantage from UHC AL-0003 (HMO-POS)"},
            {"plan_id": "H0432003000", "plan_name": "AARP Medicare Advantage from UHC AL-0001 (HMO-POS)"},
            # {"plan_id": "H1889015000", "plan_name": "AARP Medicare Advantage from UHC AL-0004 (PPO)"},
            # {"plan_id": "H0432004000", "plan_name": "AARP Medicare Advantage from UHC AL-0002 (HMO-POS)"},
            # {"plan_id": "H0432012000", "plan_name": "AARP Medicare Advantage Patriot No Rx AL-MA01 (HMO-POS)"},
            # {"plan_id": "H0432017000", "plan_name": "UHC Complete Care AL-5 (HMO-POS C-SNP)"},
            # {"plan_id": "H2802064000", "plan_name": "UHC Dual Complete AL-Y1 (HMO-POS D-SNP)"},
            {"plan_id": "H0432009000", "plan_name": "UHC Dual Complete AL-D001 (HMO-POS D-SNP)"},
            {"plan_id": "H1889009000", "plan_name": "UHC Dual Complete AL-D002 (PPO D-SNP)"},
            {"plan_id": "H2802044000", "plan_name": "UHC Dual Complete AL-V002 (HMO-POS D-SNP)"}
        ]
        
        
all_plans_24541 = [      
        #medicare eligible , medicaid not 
        {"plan_name": "AARP Medicare Advantage Patriot No Rx VA-MA01 (PPO)", "plan_id": "H2001099000"},
        {"plan_name": "AARP Medicare Advantage from UHC VA-0011 (HMO-POS)", "plan_id": "H5253111001"},
        # {"plan_name": "AARP Medicare Advantage from UHC VA-0007 (PPO)", "plan_id": "H2001109000"},
        # {"plan_name": "AARP Medicare Advantage from UHC VA-0012 (HMO-POS)", "plan_id": "H5253112001"},
        # {"plan_name": "AARP Medicare Advantage Access from UHC VA-20 (PPO)", "plan_id": "H200115000"},
        # {"plan_name": "UHC Medicare Advantage VA-0001 (PPO)", "plan_id": "H1659002000"},
        # {"plan_name": "UHC Complete Care VA-23 (HMO-POS C-SNP)", "plan_id": "H5253197000"},
        
        #medicare eligible , medicaid eligible
        {"plan_name": "UHC Dual Complete VA-Y001 (HMO-POS D-SNP)", "plan_id": "H2445001000"},
        {"plan_name": "UHC Dual Complete VA-Y002 (HMO-POS D-SNP)", "plan_id": "H2445003000"},
        # {"plan_name": "UHC Dual Complete VA-Y4 (PPO D-SNP)", "plan_id": "H0421001000"},
        # {"plan_name": "UHC Dual Complete VA-Y3 (HMO-POS D-SNP)", "plan_id": "H2445005000"},
        
        
        #{"plan_name": "AARP Medicare Advantage Giveback from UHC VA-13 (HMO-POS)", "plan_id": "H5253119000"},
        {"plan_name": "UHC Dual Complete VA-Q001 (HMO-POS D-SNP)", "plan_id": "H2445002000"},
        # {"plan_name": "UHC Dual Complete VA-V001 (HMO-POS D-SNP)", "plan_id": "H2445004000"},
        # {"plan_name": "UHC Nursing Home Plan EX-F004 (PPO I-SNP)", "plan_id": "H0710032000"}
        
        ]


summary_api= "https://lca-call-transcript-api-stage-1.stage.gpd-acq-azure.optum.com/"
