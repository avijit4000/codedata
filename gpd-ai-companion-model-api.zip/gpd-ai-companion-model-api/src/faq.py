import openai
from openai import AzureOpenAI,APIError, APIConnectionError, RateLimitError
from pypdf import PdfReader 
#from flask_cors import CORS
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.search.documents.models import VectorizableTextQuery
from logging.config import dictConfig
import io
from urllib.request import Request, urlopen
import os
import json
import re
import pandas as pd
from datetime import datetime, timedelta, timezone
from collections import defaultdict 

# import asyncio
# import nest_asyncio
# nest_asyncio.apply()

import time 

def get_data_from_index(query, index_name, top_n_documents, search_key, search_endpoint, semantic_configuration="",semantic_reranker_threshold = None,filter=""):
    '''
    Function to search the index_name with the query and return the top_n_documents
    '''

    print(f"final query : {query}")
    search_credential = AzureKeyCredential(search_key)
    search_client = SearchClient(search_endpoint, index_name, search_credential)
    vector_query = VectorizableTextQuery(text=query, fields="vector")
    
    if filter != "":
        if semantic_configuration != "":
            docs = search_client.search(search_text=query, vector_queries=[vector_query], query_type="semantic", 
                                semantic_configuration_name=semantic_configuration, top=top_n_documents, filter=filter)
            if semantic_reranker_threshold is not None:
                final_docs = []
                for doc in docs:
                    if '@search.reranker_score' in doc.keys() and doc['@search.reranker_score'] is not None and doc['@search.reranker_score'] >= semantic_reranker_threshold:
                        final_docs.append(doc)
            else:
                final_docs = [doc for doc in docs]
        else:
            docs = search_client.search(search_text=query, top=top_n_documents, filter=filter)
            final_docs = [doc for doc in docs]
    else:
        if semantic_configuration != "":
            docs = search_client.search(search_text=query, vector_queries=[vector_query], query_type="semantic", 
                                semantic_configuration_name=semantic_configuration, top=top_n_documents)
            final_docs = []
            if semantic_reranker_threshold is not None:
                for doc in docs:
                    if '@search.reranker_score' in doc.keys() and doc['@search.reranker_score'] is not None and doc['@search.reranker_score'] >= semantic_reranker_threshold:
                        final_docs.append(doc)
            else:
                final_docs = [doc for doc in docs]
        else:
            docs = search_client.search(search_text=query, top=top_n_documents)
            final_docs = [doc for doc in docs]
    return final_docs

def get_ucids_from_trans_index_using_filter(filters, index_name, search_key, search_endpoint):

    search_credential = AzureKeyCredential(search_key)
    search_client = SearchClient(search_endpoint, index_name, search_credential)

    filter_field = ""
    filter_value = ""
    if len(filters['other_filters']) > 0:
        other_filters = filters['other_filters'][0]
        filter_field = other_filters['field'] if 'field' in other_filters else ""
        filter_value = other_filters['value'] if 'value' in other_filters else ""
    print(f"filter_field : {filter_field}, filter_value : {filter_value}")
        

    explicit_filters = filters['explicit_filters']
    try:
        if filter_field != "" and explicit_filters != "":
            docs = search_client.search(search_text=filter_value,search_fields=[filter_field],filter=explicit_filters,top=30000)
        elif filter_field != "":
            docs = search_client.search(search_text=filter_value,search_fields=[filter_field],top=30000)
        else:
            docs = search_client.search(search_text="*",filter=explicit_filters,top=30000)

        ucids = {}
        for doc in docs:

            doc = check_and_update_glassboxurls(doc)

            ucids[doc['Ucid']] = {
                'glassbox_url':doc['Glassbox_Session_Link'],
                'zip': doc['zip'],
                'county': doc['county'],
                'plan_name': doc['plan_name'],
                'drugs': doc['drugs'],
                'providers': doc['providers'],
                'pharmacy': doc['pharmacy']
                }
            
    except Exception as e:
        print(f"Error in fetching ucids : {e}")
        ucids = {}
    
    return ucids

def format_query_for_filters(input_query):
  
    filters = {}
    filters['other_filters'] = []
    filters['date_filter'] = ""
    if input_query.find(" for ") > 0:
        sub_query = input_query.split("for")[1]
        query_parts = sub_query.split(" ")
        field = query_parts[1]
        if field == "plan":
            field = "plan_name"
        elif field == "drug":
            field = "drugs"
        elif field.find("doctor") >= 0 or field.find("provider") >= 0:
            field = "providers"
        value = query_parts[2]

        filters['other_filters'].append({'field': field, 'value': value})
    
    return filters

def add_explicit_filters(json_data, filters_from_query):

    filters_list = []
    
    if "from" in json_data:
        from_date = json_data["from"] 
        datetime_object = datetime.strptime(from_date, "%Y-%m-%d")
        start_date_formatted = datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        start_date_formatted = ""
    
    if "to" in json_data:
        to_date = json_data["to"] 
        datetime_object = datetime.strptime(to_date, "%Y-%m-%d")
        #make the datetime object 12:59:59
        datetime_object = datetime_object.replace(hour=23, minute=59, second=59)
        end_date_formatted = datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        end_date_formatted = ""
    
    filter_query_date = ""
    if start_date_formatted != "":
        filter_query_date = f"StartTime ge {start_date_formatted}"
    filters_list.append(filter_query_date)

    filter_query_date = ""
    if end_date_formatted != "":
        filter_query_date = f" StartTime le {end_date_formatted}"
    filters_list.append(filter_query_date)
    

    is_digital_filter = ""
    if "is_digital" in json_data and json_data["is_digital"]:
        is_digital_filter = "Is_Digital eq true"
    else:
        is_digital_filter = ""

    filters_list.append(is_digital_filter)
    
    is_enrollment_filter = ""
    if "is_enrollment" in json_data and json_data["is_enrollment"]:
        is_enrollment_filter = "Is_Enrollment eq true"
    else:
        is_enrollment_filter = ""

    filters_list.append(is_enrollment_filter)
    
    category_filter = ""
    if "category" in json_data and json_data["category"]:
        category_filter = f"topic/any(u: u eq '{json_data['category']}')"
    else:
        category_filter = ""
    
    filters_list.append(category_filter)

    filters_list = [item for item in filters_list if item]
    full_filter_term = ' and '.join(filters_list)
    
    filters_from_query['explicit_filters'] = full_filter_term

    return filters_from_query


def fetch_faqs_for_ucids(query, faq_index_name, semantic_configuration, search_key, search_endpoint, ucids): 

    ucids_str = ",".join(ucids)
    faq_ucid_filter =f"source_ucids/any(u: search.in(u, '{ucids_str}'))"

    faq_docs = get_data_from_index(
        query=query, index_name=faq_index_name, top_n_documents=100000, search_key=search_key, search_endpoint=search_endpoint, 
        semantic_configuration=semantic_configuration, filter=faq_ucid_filter, semantic_reranker_threshold=2.08)
    docs = [doc for doc in faq_docs]
    
    return docs


def fetch_faqs(json_data):

    query = json_data["query"]
    top_n_documents = 50

    #if json_data contains filterable search, create the filter, search for ucids for that filter
    filters = format_query_for_filters(query)
    print(f"filters from query : {filters}")

    filters = add_explicit_filters(json_data, filters)
    print(f"filters with explicit : {filters}")

    semantic_configuration="my-semantic-config"
    search_key = os.getenv(f"SEARCH_KEY", default=None)
    search_endpoint = os.getenv(f"SEARCH_ENDPOINT", default=None)
    search_credential = AzureKeyCredential(search_key)
    faq_index = "transcripts-faq-bg-step2-v2"
    qna_index = "transcripts-ucid-qna-v2"
    transcripts_index = "transcripts-mira"

    ucid_docs = get_ucids_from_trans_index_using_filter(filters, transcripts_index, search_key, search_endpoint)
    print(f"ucids: {len(ucid_docs)}")

    documents = {'faqs' : []}  
    if len(ucid_docs) > 0:

        #get ucid_docs keys and store in ucids list
        ucids = list(ucid_docs.keys())
        #break up questions_in_ucids into chunks of 700 and call fetch_faqs_for_source_questions for each chunk
        chunk_size = 10000
        faq_docs_all = []
        for i in range(0, len(ucids), chunk_size):
            chunk = ucids[i:i+chunk_size]
            faq_docs = fetch_faqs_for_ucids(query, faq_index, semantic_configuration, search_key, search_endpoint, chunk)
            faq_docs_all.extend(faq_docs)


        for result in faq_docs_all:
            glassbox_urls = []
            source_questions_per_faq = []
            source_questions_count = 0
            
            already_found_faq = False

            for faq in documents['faqs']:
                if result['faq'] == faq['faq']:
                    already_found_faq = True
                    if faq['source_questions'] is not None and result['source_questions'] is not None:
                        combbed_questions = faq['source_questions'] + result['source_questions']
                        faq['source_questions'] = list(set(combbed_questions))
                    elif result['source_questions'] is not None:
                        faq['source_questions'] = [set(result['source_questions'])]
                    faq['count'] = len(faq['source_questions'])
                    existing_glassbox_urls = faq['glassbox_urls'].split(',')
                    
                    for ucid in result['source_ucids']:
                        if ucid in ucid_docs.keys() and ucid_docs[ucid]['glassbox_url'] is not None:
                            if len(existing_glassbox_urls) > 0:
                                existing_glassbox_urls.append(ucid_docs[ucid]['glassbox_url'])
                            else:
                                existing_glassbox_urls = [ucid_docs[ucid]['glassbox_url']]
                    if len(existing_glassbox_urls) > 0:
                        faq['glassbox_urls'] = ','.join(existing_glassbox_urls)
                
     
            if len(documents['faqs']) == 0 or not already_found_faq:
                glassbox_urls = []
                for ucid in result['source_ucids']:
                    if ucid in ucid_docs.keys() and ucid_docs[ucid]['glassbox_url'] is not None and ucid_docs[ucid]['glassbox_url'] not in glassbox_urls:
                        glassbox_urls.append(ucid_docs[ucid]['glassbox_url'])
                    
                document = {
                    "faq": result["faq"],  
                    "count": result["count"],
                    "glassbox_urls": ','.join(glassbox_urls) if len(glassbox_urls) > 0 else "",
                    "source_questions": result["source_questions"],
                    "score": result["@search.reranker_score"],
                }  

                documents['faqs'].append(document)



    print(f"len of faqs before filtering for irrelevant ones: {len(documents['faqs'])}")
    if len(documents['faqs']) == 0:
        documents['faqs'] = []
        documents['summary'] = {"overview": "", "friction": []}
        return documents
    
    
    faqs_with_relevance = filter_irrelevant_faqs(query, documents)

    sorted_faqs = {}
    sorted_faqs['faqs'] = sorted(faqs_with_relevance['faqs'], key=lambda x: x['count'], reverse=True)

    faq_with_summary_frictionpoints = fetch_summary_frictionpoints_from_faqs(query, sorted_faqs)        

    return faq_with_summary_frictionpoints


def check_validate_faqsinput(input_data):
    '''
    Function to check and validate the input data for FAQs
    '''
        
    # Initialize message list to hold error messages
    final_message = []

    # Check condition 1: query must be a non-empty string
    if 'query' not in input_data:
        msg = "Missing query: Query field is missing in input data, please add proper query"
        final_message.append(msg)
    else:
        query = input_data.get("query", None)
        if not query or not isinstance(query, str) or not query.strip():
            msg = "Invalid query: query should be a non-empty string."
            final_message.append(msg)


    # If no errors, return valid input; otherwise return the errors
    if len(final_message) == 0:
        return 'Valid Input' , True
    else:
        user_final_message = '\n'.join(final_message)
        return user_final_message , False    


def check_and_update_glassboxurls(doc):
    '''
    Function to check and update the glassbox urls in the document
    '''

    try:  

        start_time = None 

        if len(doc['StartTime']) == 24:  
            start_time = datetime.fromisoformat(doc['StartTime'][:-1]).astimezone(timezone.utc)  
        elif len(doc['StartTime']) == 23:  
            start_time = datetime.fromisoformat(doc['StartTime'][:-1] + '0').astimezone(timezone.utc)  
  

        if start_time is not None:          
        
            # Get the current UTC time as offset-aware  
            current_utc_time = datetime.now(timezone.utc)
            
            # Calculate the date 90 days ago from today  
            ninety_days_ago = current_utc_time - timedelta(days=90)  
            
            # Check if 'StartTime' is beyond 90 days from today  
            if start_time < ninety_days_ago: 
                doc['Glassbox_Session_Link'] = None  
            

    except (ValueError, TypeError) as e:  
        print(f"Invalid DateTime format for StartTime: {doc['StartTime']} - {e}")    
        

    return doc


def filter_irrelevant_faqs(query, final_results):
    '''
    Function to filter out irrelevant faqs from the final results
    '''
    prompt_template = """

    You are given a query and a list of FAQs. Analyze the FAQs and determine if they are relevant to the query.
    If the FAQ is not relevant, add them to a list of irrelevant FAQs.
    Create a structured JSON response with the following fields: irrelevant_faqs.
    
    topic: {query}

    Below are FAQs:
    {faqs}

    Format your response like the following JSON:

    ```

    {{ "irrelevant_faqs": [faq1, faq2, faq3] }}

    ```

    Make sure that your responses are always valid JSON and only the required JSON response.


    Below is an example:

    Query: "show me questions about chronic conditions"
    FAQs:
    FAQ:Has a lack of transportation ever caused you to miss medical appointments?
    FAQ:Do you have any chronic illnesses or conditions
    FAQ:Do you have chronic or congestive heart failure

    irrelevant_faqs:[Has a lack of transportation ever caused you to miss medical appointments?]

    """

    # Create a string variable to hold the FAQ information  
    faq_string = ""  
    
    # Build the string with FAQs, their counts, and individual related questions  
    for entry in final_results['faqs']:
        # Add main FAQ and count  

        faq_string += f"FAQ: {entry['faq']}\n"  


    if len(faq_string)!=0 and len(query)!=0:
        client = AzureOpenAI(
                azure_endpoint = os.getenv(f"OPENAI_ENDPOINT", default=None),
                api_key= os.getenv(f"OPENAI_KEY", default=None),
                api_version="2024-02-15-preview"
            )

        prompt = prompt_template.format(faqs=faq_string, query = query)

        message = [{"role": "user", "content": prompt}]

        #implement retry logic for azure openai
        max_retries = 3
        retry_count = 0
        backoff_time = 5  # Start with 1 second backoff
        while retry_count < max_retries:
            try:
                
                completion = client.chat.completions.create(
                    model="gpt-4o",  
                    messages=message,  
                    max_tokens=2000,  
                    temperature=0,
                    top_p=1,
                    frequency_penalty=0,
                    presence_penalty=0,
                    stop=None,
                    stream=False,
                )
                irrelevant_output = completion.choices[0].message.content.strip('```json') 

                result_data = json.loads(irrelevant_output)

                # Check if the variable is a list  
                if isinstance(result_data['irrelevant_faqs'], list):
                    #remove the irrelevant faqs from the faqs list in the final_results
                    final_results['faqs'] = [faq for faq in final_results['faqs'] if faq['faq'] not in result_data['irrelevant_faqs']]  
                    
                return final_results
            except RateLimitError as e:
                retry_count += 1
                if retry_count < max_retries:
                    print(f"Rate limit error in filter_irrelevant_faqs, retrying in {backoff_time} seconds... (Attempt {retry_count}/{max_retries})")
                    time.sleep(backoff_time)
                    backoff_time *= 2  # Exponential backoff
                else:
                    print(f"Failed after {max_retries} attempts in filter_irrelevant_faqs due to rate limiting for index : {starting_index}")
                    # Fall back to the first question
                    return final_results
                    
            except (APIError, APIConnectionError) as e:
                retry_count += 1
                if retry_count < max_retries:
                    print(f"API error: {str(e)} in filter_irrelevant_faqs, retrying in {backoff_time} seconds... (Attempt {retry_count}/{max_retries})")
                    time.sleep(backoff_time)
                    backoff_time *= 2
                else:
                    print(f"Failed after {max_retries} attempts in filter_irrelevant_faqs due to API error: {str(e)} for index : {starting_index}")
                    # Fall back to the first question
                    return final_results
                    
            except Exception as e:
                # For other errors (including 400 bad request), fall back to first question
                print(f"Error occurred: {str(e)} in filter_irrelevant_faqs. Returning results as-is due to inability to find irrelevant faqs ")
                return final_results
        
        # This should not be reached, but as a safeguard:
        return final_results
            


def fetch_summary_frictionpoints_from_faqs(query, documents):
    '''
    Function to fetch summary and friction points from the FAQs
    '''
    

    prompt_template = """

    You are given topic and a list of FAQs for a given topic. Generate summary only based on the below provided high level FAQs without using the individual questions. 
    Summary should only contain top 3 most commonly asked questions amongst all the FAQs. Include the percentage of each of the top 3 commonly asked questions.
    Using the individual questions only and not the high level FAQs, analyze if individual questions contain difficulty or confusion about coverage or specific benefits and generate a list of friction points along with brief explanation based on that.
    
    topic: {query}

    Below are FAQs, their respective supporting individual questions count and individual questions:
    {FAQ_count_individualQuestions}


    ### Context:
    - The questions are asked by customer to an agent in conversation transcript of United Healthcare call center.


    Format your response like the following JSON:

    ```

    {{ "overview": [string], "friction": [string] }}

    ```

    Make sure that your responses are always valid JSON and only the required JSON response.


    Below is an example output for some random input:

    Here is the synthesized overview:
    - High Drop-Off Rates: Approximately 35-40 % of inbound Medicare calls are inititlated by consumers who abandon the digital enrollment process.

    Key Friction Points:
    - Plan Comparison Confusion: Consumers report difficulty between similar plans.
    - Cost and Coverage Details: Unclear explainations around premiums, deductibles, and coverage specifics create uncertainity.
    - Navigation and Technical Issues: Problems with site flow (e.g., non-intuitive layouts and slugging performance) push consumers to seek human assistance.

    """
    
    # Create a string variable to hold the FAQ information  
    faq_string = ""  
    
    # Build the string with FAQs, their counts, and individual related questions  
    for entry in documents['faqs']:
        # Add main FAQ and count  

        faq_string += f"FAQ: {entry['faq']}, Count: {str(entry['count'])}\n"  
        
        # Check if there are related questions and add them  
        if 'individual_questions' in entry:  
            for individual_question in entry['source_questions']:  
                faq_string += f"  - Individual Question: {individual_question}\n"

        faq_string += f"\n" 


    if len(faq_string)!=0 and len(query)!=0:

        prompt = prompt_template.format(FAQ_count_individualQuestions=faq_string, query = query)

        message = [{"role": "user", "content": prompt}]

        client = AzureOpenAI(
        azure_endpoint = os.getenv(f"OPENAI_ENDPOINT", default=None),
        api_key= os.getenv(f"OPENAI_KEY", default=None),   
        api_version="2024-02-15-preview"
        )

        completion = client.chat.completions.create(  
            model="gpt-4o",  
            messages=message,  
            max_tokens=2000,  
            temperature=0,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None,
            stream=False,
        )  


        summary_output = completion.choices[0].message.content.strip('```json') 

        result_data = json.loads(summary_output)

        # Check if the variable is a list  
        if isinstance(result_data['overview'], list):  
            result_data['overview'] = [str(element) for element in result_data['overview']]
            result_data['overview'] = '. '.join(result_data['overview'])

        if isinstance(result_data['friction'], str):
            result_data['friction'] = [result_data['friction']]

        documents['summary'] = {"overview": result_data['overview'], "friction": result_data['friction']}


    else:

        documents['summary'] = {"overview": "", "friction": []}

    
    return documents
