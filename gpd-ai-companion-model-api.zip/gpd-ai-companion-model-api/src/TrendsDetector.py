import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from scipy import stats
from statsmodels.tsa.seasonal import seasonal_decompose

class TrendDetector:
    """
    A class to detect trending topics from time series data of topic counts
    """
   
    def __init__(self, window_data, all_data, date_col='date', topic_col='key', count_col='value'):
        """
        Initialize with DataFrame containing date, topic, and count columns
       
        Parameters:
        -----------
        data : pandas.DataFrame
            DataFrame with topic count data
        date_col : str
            Name of the date column
        topic_col : str
            Name of the topic column
        count_col : str
            Name of the count column
        """
        self.data = window_data.copy()
        self.all_data = all_data.copy()
        self.date_col = date_col
        self.topic_col = topic_col
        self.count_col = count_col

        # Convert date column to datetime if it's not already
        if not pd.api.types.is_datetime64_any_dtype(self.data[date_col]):
            self.data[date_col] = pd.to_datetime(self.data[date_col])
            self.all_data[date_col] = pd.to_datetime(self.all_data[date_col])
        
        # Create a pivot table for easier time series analysis
        self.pivot_data = self.data.pivot_table(
            index=date_col,
            columns=topic_col,
            values=count_col,
            aggfunc='sum'
        ).fillna(0)

        # Create a pivot table for all data just to return daily counts beyond the window period
        self.pivot_data_all = self.all_data.pivot_table(
            index=date_col,
            columns=topic_col,
            values=count_col,
            aggfunc='sum'
        ).fillna(0)
        

   
    def calculate_growth_rates(self, window=7):
        """
        Calculate growth rates over a specified window
       
        Parameters:
        -----------
        None
           
        Returns:
        --------
        pandas.DataFrame
            DataFrame with growth rates for each topic
        """ 
        if len(self.pivot_data) <= window:
            window = len(self.pivot_data) - 1
       
        # Calculate the percentage growth rate
        growth_rates = (self.pivot_data.iloc[-1] - self.pivot_data.iloc[-window-1]) / \
                       (self.pivot_data.iloc[-window-1] + 1) * 100  # +1 to avoid division by zero
       
        return growth_rates.sort_values(ascending=False)
   
    def calculate_z_scores(self, window=7):
        """
        Calculate z-scores to identify statistical anomalies
       
        Parameters:
        -----------
        None
           
        Returns:
        --------
        pandas.DataFrame
            DataFrame with z-scores for each topic
        """
        if len(self.pivot_data) <= window:
            #print(f"Not enough data points for {window}-day window")
            # Use all available data if not enough points
            window = len(self.pivot_data) - 1
        # Use recent data as the baseline
        baseline = self.pivot_data.iloc[-window:-1]
       
        # Calculate mean and standard deviation
        means = baseline.mean()
        stds = baseline.std()
       
        # Calculate z-scores for the most recent day
        latest_counts = self.pivot_data.iloc[-1]
        z_scores = (latest_counts - means) / (stds + 1)  # +1 to avoid division by zero
       
        return z_scores.sort_values(ascending=False)
   
    def calculate_momentum_score(self, short_window=3, long_window=14):
        """
        Calculate momentum score based on short-term and long-term growth
       
        Parameters:
        -----------
        short_window : int
            Number of days for short-term growth calculation
        long_window : int
            Number of days for long-term growth calculation
           
        Returns:
        --------
        pandas.DataFrame
            DataFrame with momentum scores for each topic
        """
        # Calculate short-term and long-term moving averages
        short_ma = self.pivot_data.rolling(window=short_window).mean().iloc[-1]
        long_ma = self.pivot_data.rolling(window=long_window).mean().iloc[-1]
       
        # Calculate momentum score (ratio of short-term to long-term average)
        momentum = (short_ma / (long_ma + 1)) * 100  # +1 to avoid division by zero
       
        return momentum.sort_values(ascending=False)
   
    def mann_kendall_test(self, window=14):
        """
        Perform Mann-Kendall test to detect consistent trends
       
        Parameters:
        -----------
        window : int
            Number of recent days to use for trend detection
           
        Returns:
        --------
        pandas.DataFrame
            DataFrame with trend statistics for each topic
        """
        if len(self.pivot_data) <= window:
            #print(f"Not enough data points for {window}-day window")
            window = len(self.pivot_data) - 1

        recent_data = self.pivot_data.iloc[-window:]
        results = {}
       
        for topic in recent_data.columns:
            # Perform Mann-Kendall test
            trend, h, p, z = stats.mannkendall(recent_data[topic])
           
            results[topic] = {
                'trend': trend,  # +1 for upward, 0 for no trend, -1 for downward
                'p_value': p,
                'z_statistic': z
            }
       
        # Convert to DataFrame
        trend_df = pd.DataFrame(results).T
       
        # Filter for statistically significant upward trends
        significant_trends = trend_df[(trend_df['trend'] > 0) & (trend_df['p_value'] < 0.05)]
       
        return significant_trends.sort_values('z_statistic', ascending=False)
    
   
    def identify_trending_topics(self, date_range=None, method='composite',
                                significance=0.05, top_n=10):
        """
        Identify trending topics using a specified method
       
        Parameters:
        -----------
        date_range : tuple
            Tuple of (start_date, end_date) to analyze
        method : str
            Method to use ('growth', 'zscore', 'momentum', 'mannkendall', or 'composite')
        significance : float
            P-value threshold for statistical significance
        top_n : int
            Number of top trending topics to return
           
        Returns:
        --------
        pandas.DataFrame
            DataFrame with trending topics and their scores
        """
        # Filter data by date range if specified
        if date_range:
            start_date, end_date = date_range
            filtered_data = self.pivot_data.loc[start_date:end_date]
            all_data = self.pivot_data_all
            if len(filtered_data) == 0:
                raise ValueError("No data in the specified date range")
           
            # Create temporary detector with filtered data
            temp_detector = TrendDetector(
                filtered_data.reset_index().melt(
                    id_vars=self.date_col,
                    var_name=self.topic_col,
                    value_name=self.count_col
                ),
                all_data.reset_index().melt(
                    id_vars=self.date_col,
                    var_name=self.topic_col,
                    value_name=self.count_col
                )
            )
            return temp_detector.identify_trending_topics(
                method=method, significance=significance, top_n=top_n
            )
       
        # Calculate scores based on specified method
        if method == 'growth':
            scores = self.calculate_growth_rates()
            label = 'growth_rate'
        elif method == 'zscore':
            scores = self.calculate_z_scores()
            label = 'z_score'
        elif method == 'momentum':
            scores = self.calculate_momentum_score()
            label = 'momentum_score'
        elif method == 'mannkendall':
            trend_df = self.mann_kendall_test()
            return trend_df.head(top_n)
        elif method == 'composite':
            # Combine multiple methods with different weights
            growth_per_window = []
            zscore_per_window = []
            for window in range(1,8):
                print(f"Calculating growth for window: {window}")
                growth_rate = self.calculate_growth_rates(window)
                growth_per_window.append(growth_rate)

                z_scores = self.calculate_z_scores(window)
                zscore_per_window.append(z_scores)

            max_growth = pd.concat(growth_per_window, axis=1).max(axis=1)
            max_growth_ranked = max_growth.rank(pct=True)
            max_z_scores = pd.concat(zscore_per_window, axis=1).max(axis=1)
            max_z_scores_ranked = max_z_scores.rank(pct=True)


            
            #skip for now
            #momentum = self.calculate_momentum_score().rank(pct=True)
           
            # Create composite score (can adjust weights as needed)
            #scores = (0.4 * growth + 0.3 * z_scores + 0.3 * momentum)
            #ignoring z-score for now
            scores = (0.6 * max_growth_ranked + 0.4 * max_z_scores_ranked)
            #scores = avg_growth
            label = 'composite_score'
        else:
            raise ValueError(f"Invalid method: {method}")
               
        # Convert to DataFrame and get top N topics
        result_df = pd.DataFrame({label: scores})
        result_df = result_df.sort_values(label, ascending=False).head(top_n)
        # Add additional stats
        result_df['current_count'] = self.pivot_data.iloc[-1][result_df.index]
        #get sum of all values for each column index
        result_df['total_count'] = self.pivot_data.iloc[:][result_df.index].sum()
        result_df['change_pct'] = max_growth[result_df.index].iloc[0]
        #for each result_df index get each day count from pivot_data
        
        day_counts_for_topics = []
        all_day_counts_for_topics = []
        for topic in result_df.index:
            each_day_counts = []
            all_day_counts = []
            
            for each_date in self.pivot_data[topic].index:
                each_day_counts.append({'date':each_date.strftime('%Y-%m-%d'),'count':self.pivot_data.loc[each_date][topic]})
                
            for each_date in self.pivot_data_all[topic].index:
                all_day_counts.append({'date':each_date.strftime('%Y-%m-%d'),'count':self.pivot_data_all.loc[each_date][topic]})
            
            day_counts_for_topics.append(each_day_counts)
            all_day_counts_for_topics.append(all_day_counts)
                        
        result_df['daily_count'] = all_day_counts_for_topics
        
        return result_df

# # Example usage
# if __name__ == "__main__":
#     # Generate sample data
#     np.random.seed(42)
   
#     # Create date range
#     dates = pd.date_range(start='2023-01-01', end='2023-03-31')
   
#     # Create topics
#     topics = ['AI', 'Blockchain', 'Climate', 'Data Science', 'Metaverse',
#               'Quantum Computing', 'Remote Work', 'Space Exploration']
   
#     # Generate sample data with different patterns
#     data = []
   
#     for topic in topics:
#         base = np.random.randint(10, 100)  # Base volume differs by topic
       
#         for date in dates:
#             # Add a time component (some topics grow over time)
#             time_factor = 0
#             if topic in ['AI', 'Data Science']:
#                 time_factor = (date - dates[0]).days / 10  # Steady growth
#             elif topic == 'Climate':
#                 # Sudden spike in recent days
#                 if date > dates[-20]:
#                     time_factor = 20
#             elif topic == 'Quantum Computing':
#                 # Exponential recent growth
#                 day_factor = (date - dates[0]).days / len(dates)
#                 time_factor = 50 * day_factor**2
               
#             # Calculate count with some randomness
#             count = max(0, base + time_factor + np.random.normal(0, base/10))
           
#             data.append({
#                 'date': date,
#                 'key': topic,
#                 'value': int(count)
#             })
   
#     # Create DataFrame
#     df = pd.DataFrame(data)
   
#     # Initialize trend detector
#     detector = TrendDetector(df, df, datetime(2023, 3, 31))
   
#     # Identify trending topics
#     trending = detector.identify_trending_topics(method='composite', top_n=5)
#     print("Top Trending Topics:")
#     print(trending)
   
#     # Visualize trends
#     #fig = detector.visualize_trends(trending.index.tolist(), days=30)
#     #plt.show() 