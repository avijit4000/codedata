# Conversational Update

## Rules for Contributing

### Committing

- DO NOT COMMIT DIRECTLY TO TO `conv_update` BRANCH
- Create a new feature branch for your code
- Commit and merge from `conv_update` into your branch often to resolve conflicts
- When finished, open a pull request to merge into `conv_update`
  - Assign David or Mo to review
  - PR accepted = story accepted
  - We'll use the PR to communicate changes

### Coding Practices

- Long blocking code must be async (like search index, HTTP request, LLM call)
    - Langchain has async `ainvoke()`
    - Modules without async support can be wrapped with `asyncio.get_event_loop().run_in_executor()`. See the `get_documents_from_index` function in `query_index` module for example
- All code must show no errors when linting with Pylance/Pyright
  - Use `# type: ignore` comment when acceptable
- Must be formatted with Black
- Use type hints as much as possible - this minimizes headaches for other developers working on the same large complex code base
- Must have good documentation & docstrings
  - Include Google formatted docstrings (except when docstrings are unnecessary)
  - Include code comments
  - Use copilot to help do this quickly
- Use `logger = logging.getLogger("agents.{something useful here}")` and `logger.info()`, `logger.debug()` etc. to log useful debugging or process information as demonstrated in the module.
- Organize your code with appropriate submodules & relative imports, not just 1 big file please

The first 2 points are easy with VS Code - enable format on save and use the Python extension for linting within the IDE

### LLM Usage Best Practices

- Try to use structured outputs (make sure it's `method="json_schema"` if using langchain's `with_structured_outputs`) instead of parsing text from the model
  - See the `followup_builder` llm as a good example
- Keep your prompts succinct and clear

## Usage

Install `python 3.12.8` and `requirements.txt`.

Create a file called `.env` in the `src` folder with the following info:

```bash
OPENAI_ENDPOINT="https://gpdacq-dev-1-eastus2-openai.openai.azure.com/"
OPENAI_KEY={dev_openai_key}
SEARCH_ENDPOINT="https://gpdacq-dev-1-eastus-ai-search-cog-svc.search.windows.net"
SEARCH_KEY={stage_search_key}
PLAN_INDEX="sales-copilot-extract-small-embedding-release-sections"
JOBAID_INDEX="jobaid-extract-small-embedding-release-1"
QUESTION_INDEX="get-info-class-question-3"
```

For now, you can use the `agents_test.ipynb` notebook for how to use the module.

The module contents are all in the `./src/agent_workflows` folder. The `ai-companion.py` is not updated yet.

## Diagram

For the latest technical diagram, please see [here](https://uhgazure-my.sharepoint.com/:u:/g/personal/mohammed_modan_optum_com/EZHkhHby7dVNu8BeJT-YnnEBgvLUEwna42c5BeFaCfeG1A?e=NA3Rjb).
