from src.LLM.plugins.latency_report.latency_server import get_latency_data, get_latency_data_pretty
from src.LLM.plugins.MCPPlugin import MCPPlugin

"""
Use the plugin class to register latency report functions.
"""

latency_plugin = MCPPlugin(
    name="latency_report_plugin",
    description="Plugin to fetch latency report data",
    functions={
        "get_latency_data": get_latency_data,
        "get_latency_data_pretty": get_latency_data_pretty,
    }
)

if __name__ == "__main__":
    print("Starting Latency Report Plugin MCP Server...")
    latency_plugin.mcp.run(transport="stdio")