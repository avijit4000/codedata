from mcp.server.fastmcp import FastMCP
from typing import Optional, List, Dict, Any
import json
from pull_metric_api import fetch_latency_report


mcp = FastMCP("latency_server")


@mcp.tool()
def get_latency_data(
    day: Optional[str] = None,
    days: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    app: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch latency report from API with optional filters.
    """
    try:
        return fetch_latency_report(
            day=day,
            days=days,
            start_date=start_date,
            end_date=end_date,
            app=app
        )
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def get_latency_data_pretty(
    app: Optional[str] = None,
    day: Optional[str] = None
) -> str:
    """
    Return readable JSON text for latency report.
    """
    try:
        data = fetch_latency_report(day=day, app=app)
        return json.dumps(data, indent=2)
    except Exception as e:
        return f"Error: {e}"


if __name__ == "__main__":
    print("Starting Latency MCP Server...")
    # mcp.run(transport="stdio")
    mcp.run(transport="streamable-http")


