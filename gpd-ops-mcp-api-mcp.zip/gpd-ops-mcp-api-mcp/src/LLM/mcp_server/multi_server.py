import sys
import os
from pathlib import Path
from src.tools.utils.logging import logger
from langchain_mcp_adapters.client import MultiServerMCPClient

# Get the project root directory
PROJECT_ROOT = Path(__file__).parent.parent.parent.parent

class MultiMCPServer:
    def __init__(self):
        logger.info("Initializing MCP Client...")

        self.client = MultiServerMCPClient(
            {
                "math": {
                    "command": sys.executable,
                    "args": ["src/LLM/mcp_server/servers/mathserver.py"],
                    "transport": "stdio",
                    "env": {**os.environ, "PYTHONPATH": str(PROJECT_ROOT)},
                },
                "weather": {
                    "command": sys.executable,
                    "args": ["src/LLM/mcp_server/servers/weather.py"],
                    "transport": "stdio",
                    "env": {**os.environ, "PYTHONPATH": str(PROJECT_ROOT)},
                },
                "latency_server": {
                     "command": sys.executable,
                     "args": ["src/LLM/mcp_server/servers/latency_server.py"],
                     "transport": "stdio",
                     "env": {**os.environ, "PYTHONPATH": str(PROJECT_ROOT)},
                 },

            }
        )


multi_server = MultiMCPServer()



                # "latency": {
                #     "command": sys.executable,
                #     "args": ["src/LLM/mcp_server/servers/latency_server.py"],
                #     "transport": "stdio",


                #                 "weather": {
                #     "url": "http://localhost:8000/mcp",
                #     "transport": "streamable_http",
                # },


