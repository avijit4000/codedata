from src.tools.utils.logging import logger
from dotenv import load_dotenv
import os
from langchain_openai import AzureChatOpenAI

class llmMCPmodel:
    def __init__(self, client=None):
        load_dotenv()

        logger.info("Initializing Azure OpenAI model...")

        self.client = client    # MCP client will be injected from agent.py

        self.model = AzureChatOpenAI(
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            azure_deployment=os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini"),
            temperature=0.3,
        )

    async def setup(self):
        """Fetch MCP tools."""
        if self.client is None:
            raise RuntimeError("Client is not provided in llmMCPmodel")

        logger.info("Fetching MCP tools...")
        tools = await self.client.get_tools()
        return tools


# Global instance
llmtoolmodel = llmMCPmodel()
