from typing import Any
import httpx
import os
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("weather")

# Constants
NWS_API_BASE = "https://api.weather.gov"
USER_AGENT = "weather-app/1.0"


async def make_nws_request(url: str) -> dict[str, Any] | None:
    """Make a request to the NWS API with proper error handling."""
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/geo+json"
    }
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url, headers=headers, timeout=30.0)
            response.raise_for_status()
            return response.json()
        except Exception:
            return None


def format_alert(feature: dict) -> str:
    """Format an alert feature into a readable string."""
    props = feature["properties"]
    return f"""
Event: {props.get('event', 'Unknown')}
Area: {props.get('areaDesc', 'Unknown')}
Severity: {props.get('severity', 'Unknown')}
Description: {props.get('description', 'No description available')}
Instructions: {props.get('instruction', 'No specific instructions provided')}
"""


@mcp.tool()
async def get_alerts(state: str) -> str:
    """Get weather alerts for a US state (e.g. 'CA', 'NY')."""
    url = f"{NWS_API_BASE}/alerts/active/area/{state}"
    data = await make_nws_request(url)

    if not data or "features" not in data:
        return "Unable to fetch alerts or no alerts found."

    if not data["features"]:
        return "No active alerts for this state."

    alerts = [format_alert(feature) for feature in data["features"]]
    return "\n---\n".join(alerts)


@mcp.tool()
async def get_forecast(latitude: float, longitude: float) -> str:
    """Get weather forecast for a location (by latitude & longitude)."""
    points_url = f"{NWS_API_BASE}/points/{latitude},{longitude}"
    points_data = await make_nws_request(points_url)

    if not points_data or "properties" not in points_data:
        return "Unable to fetch forecast data for this location."

    forecast_url = points_data["properties"].get("forecast")
    if not forecast_url:
        return "Forecast URL not available for this location."

    forecast_data = await make_nws_request(forecast_url)
    if not forecast_data or "properties" not in forecast_data:
        return "Unable to fetch detailed forecast."

    periods = forecast_data["properties"].get("periods", [])
    if not periods:
        return "No forecast data available."

    forecasts = []
    for period in periods[:5]:  # Show only next 5 periods
        forecast = f"""
{period.get('name', 'Unknown Period')}:
Temperature: {period.get('temperature', 'N/A')}°{period.get('temperatureUnit', '')}
Wind: {period.get('windSpeed', 'N/A')} {period.get('windDirection', '')}
Forecast: {period.get('detailedForecast', 'No forecast available.')}
"""
        forecasts.append(forecast.strip())

    return "\n---\n".join(forecasts)

if __name__ == "__main__":
    mcp.run("streamable-http")
    # mcp.run(transport="stdio")
    # , host = "127.0.0.1", port = 9000
    # mcp.run("streamable-http", host="0.0.0.0", port=8080)
    # mcp.run(transport, host="127.0.0.1", port=8020)
    # mcp.run("streamable-http", host="127.0.0.1", port=8020)
    # mcp.serve("127.0.0.1", 8020, transport="streamable-http")

#
# if __name__ == "__main__":
#     # Set the port using environment variable before running the server
#     os.environ["FASTMCP_PORT"] = "8020"   # or any free port, e.g., 8010, 8020, etc.
#     mcp.run(transport="streamable-http")



# if __name__ == "__main__":
#     # Start FastMCP server
#     # mcp.run(transport="streamable-http", host="127.0.0.1", port=8020)
#     mcp.run(transport="streamable-http", config={"host": "127.0.0.1", "port": 8020})

# if __name__ == "__main__":
#     # Start FastMCP server on a custom port
#     mcp.run(transport="streamable-http", port=8020)




# from langchain_mcp_adapters.client import MultiServerMCPClient
# from langchain.agents import create_react_agent   # updated import (as per warning)
# from langchain_openai import AzureChatOpenAI
# from dotenv import load_dotenv
# import asyncio
# import os



# from langchain_mcp_adapters.client import MultiServerMCPClient
# from langgraph.prebuilt import create_react_agent   # ✅ correct import
# from langchain_openai import AzureChatOpenAI
# from dotenv import load_dotenv
# import asyncio
# import os
#
# # Load environment variables
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
#
# async def main():
#     # Connect to math (stdio), weather (HTTP), and database (HTTP) MCP servers
#     client = MultiServerMCPClient(
#         {
#             "math": {
#                 "command": "python",
#                 "args": ["mathserver.py"],
#                 "transport": "stdio",
#             },
#             "weather": {
#                 "url": "http://localhost:8000/mcp",
#                 "transport": "streamable_http",
#             },
#             "database": {
#                 "url": "http://localhost:8010/mcp",  # 👈 run database.py on this port
#                 "transport": "streamable_http",
#             },
#         }
#     )
#
#     # Initialize Azure OpenAI model
#     model = AzureChatOpenAI(
#         azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
#         api_key=os.getenv("AZURE_OPENAI_API_KEY"),
#         api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
#         azure_deployment=os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini"),
#         temperature=0.3,
#     )
#
#     # Load MCP tools
#     tools = await client.get_tools()
#
#     # Create ReAct agent
#     agent = create_react_agent(model, tools)
#
#     # Test math tool
#     math_response = await agent.ainvoke(
#         {"messages": [{"role": "user", "content": "what's (3 + 5) x 12?"}]}
#     )
#     print("\n📐 Math response:", math_response["messages"][-1].content)
#
#     # Test weather tool
#     weather_response = await agent.ainvoke(
#         {"messages": [{"role": "user", "content": "what is the weather in California?"}]}
#     )
#     print("\n🌦️ Weather response:", weather_response["messages"][-1].content)
#
#     # Test database tool
#     db_response = await agent.ainvoke(
#         {"messages": [{"role": "user", "content": "List all tables in the database"}]}
#     )
#     print("\n🗄️ Database response:", db_response["messages"][-1].content)
#
#
# if __name__ == "__main__":
#     asyncio.run(main())



# from typing import Any
# import httpx
# import os
# from mcp.server.fastmcp import FastMCP
#
# # ✅ Set the port BEFORE initializing FastMCP
# os.environ["FASTMCP_PORT"] = "8020"
#
# # Initialize FastMCP server
# mcp = FastMCP("weather")
#
# # Constants
# NWS_API_BASE = "https://api.weather.gov"
# USER_AGENT = "weather-app/1.0"
#
#
# async def make_nws_request(url: str) -> dict[str, Any] | None:
#     """Make a request to the NWS API with proper error handling."""
#     headers = {
#         "User-Agent": USER_AGENT,
#         "Accept": "application/geo+json"
#     }
#     async with httpx.AsyncClient() as client:
#         try:
#             response = await client.get(url, headers=headers, timeout=30.0)
#             response.raise_for_status()
#             return response.json()
#         except Exception:
#             return None
#
#
# def format_alert(feature: dict) -> str:
#     """Format an alert feature into a readable string."""
#     props = feature["properties"]
#     return f"""
# Event: {props.get('event', 'Unknown')}
# Area: {props.get('areaDesc', 'Unknown')}
# Severity: {props.get('severity', 'Unknown')}
# Description: {props.get('description', 'No description available')}
# Instructions: {props.get('instruction', 'No specific instructions provided')}
# """
#
#
# @mcp.tool()
# async def get_alerts(state: str) -> str:
#     """Get weather alerts for a US state (e.g. 'CA', 'NY')."""
#     url = f"{NWS_API_BASE}/alerts/active/area/{state}"
#     data = await make_nws_request(url)
#
#     if not data or "features" not in data:
#         return "Unable to fetch alerts or no alerts found."
#
#     if not data["features"]:
#         return "No active alerts for this state."
#
#     alerts = [format_alert(feature) for feature in data["features"]]
#     return "\n---\n".join(alerts)
#
#
# @mcp.tool()
# async def get_forecast(latitude: float, longitude: float) -> str:
#     """Get weather forecast for a location (by latitude & longitude)."""
#     points_url = f"{NWS_API_BASE}/points/{latitude},{longitude}"
#     points_data = await make_nws_request(points_url)
#
#     if not points_data or "properties" not in points_data:
#         return "Unable to fetch forecast data for this location."
#
#     forecast_url = points_data["properties"].get("forecast")
#     if not forecast_url:
#         return "Forecast URL not available for this location."
#
#     forecast_data = await make_nws_request(forecast_url)
#     if not forecast_data or "properties" not in forecast_data:
#         return "Unable to fetch detailed forecast."
#
#     periods = forecast_data["properties"].get("periods", [])
#     if not periods:
#         return "No forecast data available."
#
#     forecasts = []
#     for period in periods[:5]:  # Show only next 5 periods
#         forecast = f"""
# {period.get('name', 'Unknown Period')}:
# Temperature: {period.get('temperature', 'N/A')}°{period.get('temperatureUnit', '')}
# Wind: {period.get('windSpeed', 'N/A')} {period.get('windDirection', '')}
# Forecast: {period.get('detailedForecast', 'No forecast available.')}
# """
#         forecasts.append(forecast.strip())
#
#     return "\n---\n".join(forecasts)
#
#
# if __name__ == "__main__":
#     # ✅ Run the FastMCP server on port 8020
#     mcp.run(transport="streamable-http")
