import sys
from src.tools.utils.logging import logger
from langchain_mcp_adapters.client import MultiServerMCPClient

class MultiMCPServer:
    def __init__(self):
        logger.info("Initializing MCP Client...")

        self.client = MultiServerMCPClient(
            {
                "math": {
                    "command": sys.executable,
                    "args": ["src/LLM/mcp_server/servers/mathserver.py"],
                    "transport": "stdio",
                },
                "weather": {
                    "url": "http://localhost:8000/mcp",
                    "transport": "streamable_http",
                },
                "alerts": {
                "url": "http://localhost:9000/mcp",
                "transport": "streamable_http",
                }
            }
        )

multi_server = MultiMCPServer()
