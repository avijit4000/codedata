import sys
from src.tools.utils.logging import logger
from langchain_mcp_adapters.client import MultiServerMCPClient

class MultiMCPServer:
    def __init__(self):
        logger.info("Initializing MCP Client...")

        self.client = MultiServerMCPClient(
            {
                "math": {
                    "command": sys.executable,
                    "args": ["src/LLM/mcp_server/servers/mathserver.py"],
                    "transport": "stdio",
                },
                "database": {
                    "url": "http://localhost:8000/mcp",
                    "transport": "streamable_http",
                },
                "weather": {
                    "url": "http://localhost:8000/mcp",
                    "transport": "streamable_http",
                },
            }
        )

# Global instance
multi_server = MultiMCPServer()
