# import asyncio
# from langgraph.prebuilt import create_react_agent
# from src.tools.utils.logging import logger
# from src.LLM.llm_model.llm_model import llmtoolmodel
# from src.LLM.mcp_server.multi_server import multi_server
#
#
# class MCPToolCallSystem:
#
#     async def setup(self):
#         logger.info("Loading model and tools...")
#
#         # Inject MCP client into llm model
#         llmtoolmodel.client = multi_server.client
#
#         # Get model + tools
#         self.model = llmtoolmodel.model
#         self.tools = await llmtoolmodel.setup()
#
#         logger.info("Creating ReAct agent...")
#         self.agent = create_react_agent(self.model, self.tools)
#
#     async def ask(self, prompt: str):
#         logger.info(f"User Prompt: {prompt}")
#
#         response = await self.agent.ainvoke(
#             {"messages": [{"role": "user", "content": prompt}]}
#         )
#
#         final_answer = response["messages"][-1].content
#         logger.info(f"Response: {final_answer}")
#         return final_answer
#
#     async def run_tests(self):
#         logger.info("Running test queries...")
#
#         math_q = "what's (3 + 5) x 12?"
#         weather_q = "What is the weather in Los Angeles?"
#         db_q = "Find the time of day when most people order snacks."
#
#         print("\nMath Response:")
#         print(await self.ask(math_q))
#
#         print("\nWeather Response:")
#         print(await self.ask(weather_q))
#
#         print("\nDatabase Response:")
#         print(await self.ask(db_q))
#
#
# async def main():
#     system = MCPToolCallSystem()
#     await system.setup()
#     await system.run_tests()
#
#
# if __name__ == "__main__":
#     asyncio.run(main())


import asyncio
from langgraph.prebuilt import create_react_agent
from src.tools.utils.logging import logger
from src.LLM.llm_model.llm_model import llmtoolmodel
from src.LLM.mcp_server.multi_server import multi_server


class MCPChatBot:

    async def setup(self):
        logger.info("Initializing MCP Chatbot...")

        # Attach MCP multi-server client to LLM model
        llmtoolmodel.client = multi_server.client

        # Load model & tools
        logger.info("Loading LLM + Tools...")
        self.model = llmtoolmodel.model
        self.tools = await llmtoolmodel.setup()

        # Create ReAct Agent with tools
        logger.info("Creating ReAct Agent with MCP tools...")
        self.agent = create_react_agent(self.model, self.tools)

    async def ask(self, prompt: str) -> str:
        logger.info(f"User Prompt: {prompt}")

        result = await self.agent.ainvoke(
            {"messages": [{"role": "user", "content": prompt}]}
        )

        answer = result["messages"][-1].content
        logger.info(f"Agent Response: {answer}")

        return answer

    async def chat_loop(self):
        print("\n=== MCP Chatbot Ready! ===")
        print("Ask anything. Type 'exit' to quit.\n")

        while True:
            user_input = input("You: ")

            if user_input.lower().strip() in ["exit", "quit"]:
                print("Chatbot: Goodbye!")
                break

            try:
                response = await self.ask(user_input)
                print(f"Chatbot: {response}\n")
            except Exception as e:
                logger.error(f"Error handling request: {e}")
                print("Chatbot: Something went wrong. Check logs.")


async def main():
    bot = MCPChatBot()
    await bot.setup()
    await bot.chat_loop()


if __name__ == "__main__":
    asyncio.run(main())
