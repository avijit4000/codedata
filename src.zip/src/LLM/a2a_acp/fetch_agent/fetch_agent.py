# import asyncio
# from dataclasses import dataclass
# from pydantic import BaseModel
# import json
# from autogen_core import (DefaultTopicId,
#                           MessageContext,
#                           RoutedAgent,
#                           default_subscription,
#                           message_handler,
#                           FunctionCall)
# from autogen_core import AgentId, SingleThreadedAgentRuntime
# from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
# from autogen_core.models import (
#     ChatCompletionClient,
#     SystemMessage,
#     UserMessage,
#     CreateResult,
#     AssistantMessage,
#     LLMMessage,
#     FunctionExecutionResult,
#     FunctionExecutionResultMessage,
# )
# from dotenv import load_dotenv
# from autogen_core.model_context import BufferedChatCompletionContext, ChatCompletionContext, UnboundedChatCompletionContext
# from autogen_core.tools import FunctionTool, Tool, Workbench, ToolResult
# from autogen_ext.tools.mcp import McpWorkbench, SseServerParams, StdioServerParams, StreamableHttpServerParams, mcp_server_tools
# from typing import Any, AsyncGenerator, Callable, Coroutine, Dict, List, Optional, Sequence, Tuple, Literal
#
# import os, json
# from agents.fetch_agent.agent_config import *
# from config import *
# load_dotenv()
#
# class TextMessage(BaseModel):
#     content: str
#     source: str
#     task_id: Optional[str] = None
#     context_id: Optional[str] = None
#
# class ResponseFormat(BaseModel):
#     status: Literal["completed", "input_required", "error"]
#     fetched_data: str
#
#
#
# gpt4_model_client = AzureOpenAIChatCompletionClient(model = GPT4_MODEL_NAME,
#                                       azure_endpoint = GPT4_AZURE_ENDPOINT,
#                                       azure_deployment = GPT4_AZURE_DEPLOYMENT,
#                                       api_version = GPT4_API_VERSION,
#                                       api_key = os.getenv("GPT4_AZURE_API_KEY"),
#                                       model_info = {
#                                           "vision": False,
#                                           "json_output": True,
#                                           "structured_output": True,
#                                           "function_calling": True,
#                                           "family": "gpt-4",
#
#
#                                       }
#                                       )
#
#
# async def create_mcp_workbench(mcp_params: StdioServerParams | SseServerParams | StreamableHttpServerParams |
#                      Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
#                      ) -> Sequence[McpWorkbench]:
#     workbenches = []
#     if isinstance(mcp_params, Sequence):
#         for params in  mcp_params:
#             workbench = McpWorkbench(params)
#             workbenches.append(workbench)
#         return workbenches
#
#     workbench = McpWorkbench(mcp_params)
#     workbenches.append(workbench)
#     return workbenches
#
#
#
#
# class FetchAgent(RoutedAgent):
#     SUPPORTED_CONTENT_TYPES = ['text', 'text/plain', 'application/json']
#     def __init__(self, agent_name: str,
#                  agent_description: str,
#                  system_message: Optional[List[SystemMessage]] = None,
#                  model_client: ChatCompletionClient = gpt4_model_client,
#                  model_context: ChatCompletionContext | None = None,
#                  tools: Optional[Sequence[Tool]] = None,
#                 #  mcp_server_params: StdioServerParams | SseServerParams | StreamableHttpServerParams |
#                 #      Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams] = None,
#                  workbench: Optional[Sequence[Workbench]] = None
#                  ) -> None:
#         super().__init__(description=agent_description,)
#         self._system_message = system_message
#         self._model_client = model_client
#         self._model_context = model_context
#         self._tools = tools
#         self._agent_name  = agent_name
#         self._agent_description = agent_description
#         self._workbench = workbench
#
#
#     @message_handler
#     async def handle_text_message(self, message: TextMessage, context: MessageContext)-> str:
#
#         if self._tools and self._workbench:
#             raise ValueError("Cannot have both tools and workbench defined at the same time.")
#
#
#         if self._workbench is not None:
#             for wb in self._workbench:
#                 await wb.start()
#             tools = await self._fetch_workbench_tools(self._workbench)
#         elif self._tools is not None:
#             tools = self._tools
#         else:
#             tools = []
#
#         user_message = UserMessage(content=message.content, source=message.source)
#
#         if self._model_context is not None:
#             await self._model_context.add_message(user_message)
#             print(await self._model_context.get_messages())
#
#         response_content = ""
#         func_calls = None
#         print("Sending request to model...")
#         model_response = await self._model_client.create(
#             messages=self._system_message + (await self._model_context.get_messages() if self._model_context else user_message),
#             tools=tools,
#             cancellation_token=context.cancellation_token)
#
#
#
#         if isinstance(model_response, CreateResult) and isinstance(model_response.content, str):
#             await self._model_context.add_message(AssistantMessage(content=model_response.content, source=self.id.type))
#             for wb in self._workbench:
#                 await wb.__aexit__(None, None, None)
#             return json.dumps(model_response.content)
#         elif isinstance(model_response, str):
#             await self._model_context.add_message(AssistantMessage(content=model_response, source=self.id.type))
#             for wb in self._workbench:
#                 await wb.__aexit__(None, None, None)
#             return model_response
#         elif isinstance(model_response, CreateResult) and isinstance(model_response.content, list):
#             func_calls = model_response.content
#             if self._model_context is not None:
#                 await self._model_context.add_message(AssistantMessage(content=func_calls, source=self.id.type))
#         else:
#             print("None")
#             for wb in self._workbench:
#                 await wb.__aexit__(None, None, None)
#             raise RuntimeError(f"Invalid LLM response type: {type(model_response)}")
#
#
#         if func_calls is not None:
#
#             tool_results: List[Tuple[FunctionCall, FunctionExecutionResult]] = await asyncio.gather(
#                         *[
#                             self._execute_tool_call(
#                                 workbenches = self._workbench,
#                                 func_call=call,
#                                 cancellation_token=context.cancellation_token,
#                             )
#                             for call in func_calls
#                         ]
#                     )
#
#             func_exec_res_msg = FunctionExecutionResultMessage(content = [result for _, result in tool_results])
#
#             print(func_exec_res_msg)
#
#
#             if self._model_context is not None:
#                 await self._model_context.add_message(func_exec_res_msg)
#
#
#
#             tool_call_summary = await self._model_client.create(
#                 messages=self._system_message + (await self._model_context.get_messages() if self._model_context else func_calls + func_exec_res_msg.content))
#
#
#             for wb in self._workbench:
#                 await wb.__aexit__(None, None, None)
#
#             return json.dumps(tool_call_summary.content)
#
#
#     async def _fetch_workbench_tools(self, workbench: Sequence[Workbench]) -> List[Tool]:
#
#         try:
#             if isinstance(workbench, Sequence):
#                 tools = []
#                 for bench in workbench:
#                     try:
#                         await asyncio.sleep(0.5)  # slight delay to avoid overwhelming
#                         wb_tools = await bench.list_tools()
#                         tools.extend(wb_tools)
#                     except Exception as e:
#                         print(f"Error fetching tools from workbench {bench}: {e}")
#                         import traceback
#                         traceback.print_exc()
#                         continue
#                 return tools
#
#             return []
#         except Exception as e:
#             print(f"Error fetching workbench tools: {e}")
#             return []
#
#     async def _execute_tool_call(self, workbenches: Sequence[Workbench],
#                                  func_call: FunctionCall,
#                                  cancellation_token
#                                  ) -> Tuple[FunctionCall, FunctionExecutionResult]:
#
#         try:
#             arguments = json.loads(func_call.arguments)
#         except json.JSONDecodeError as e:
#             return (
#                 func_call,
#                 FunctionExecutionResult(
#                     content=f"Error: {e}",
#                     call_id=func_call.id,
#                     is_error=True,
#                     name=func_call.name,
#                 ),
#             )
#
#
#         for workbench in workbenches:
#             wb_tools = await workbench.list_tools()
#             if any(t["name"] == func_call.name for t in wb_tools):
#                 func_call_result = await workbench.call_tool(
#                         name=func_call.name,
#                         arguments=arguments,
#                         cancellation_token=cancellation_token,
#                         call_id=func_call.id,
#                     )
#             return (
#                     func_call,
#                     FunctionExecutionResult(
#                         content=func_call_result.to_text(),
#                         call_id=func_call.id,
#                         is_error=func_call_result.is_error,
#                         name=func_call.name,
#                     ),
#                 )
#         return (
#             func_call,
#             FunctionExecutionResult(
#                 content=f"Error: tool '{func_call.name}' not found in any workbench",
#                 call_id=func_call.id,
#                 is_error=True,
#                 name=func_call.name,
#             ),
#         )
#
#
# async def simple_agent_factory():
#
#     try:
#
#         work_benches = await create_mcp_workbench(mcp_params)
#
#     except Exception as e:
#         print(f"Error creating MCP workbench: {e}")
#         work_benches = []
#
#     return FetchAgent(
#         agent_name=agent_name,
#         agent_description = agent_description,
#         system_message=[SystemMessage(content=fetcher_agent_prompt)],
#         model_client=gpt4_model_client,
#         model_context=UnboundedChatCompletionContext(),
#         workbench= work_benches,
#
#     )
#
# async def create_runtime() -> SingleThreadedAgentRuntime:
#
#
#     # Create a runtime and register the agent
#     runtime = SingleThreadedAgentRuntime()
#     await FetchAgent.register(runtime, agent_type, simple_agent_factory)
#
#     return runtime
#
# async def invoke_fetch_agent(ag_runtime: SingleThreadedAgentRuntime,
#                              user_message: str,
#                              source: str = "user",
#                              context_id: Optional[str] = None,
#                              task_id: Optional[str] = None,
#                              ) -> ResponseFormat|str:
#     # Start the runtime
#     ag_runtime.start()
#     fetcher_agent_id = AgentId(agent_type, "default")
#     print("sending message to fetcher agent...")
#     final_response = await ag_runtime.send_message(
#         TextMessage(content = user_message, source = source, context_id = context_id, task_id = task_id),
#         recipient=fetcher_agent_id
#         )
#
#     await ag_runtime.stop_when_idle()
#
#     print(type(final_response))
#
#     return json.loads(final_response)
#
# if __name__ == "__main__":
#     import asyncio
#     runtime = asyncio.run(create_runtime())
#     while True:
#         user_message = input("Enter your message: ")
#
#         if not user_message == "quit":
#             response = asyncio.run(invoke_fetch_agent(runtime, user_message))
#             print("Agent response:", response)
#         else:
#             break


import asyncio
import os
import json
from typing import Sequence, Optional, List, Tuple, Literal
from dataclasses import dataclass
from pydantic import BaseModel
from dotenv import load_dotenv

from src.tools.utils.logging import logger
from autogen_core import (
    RoutedAgent, MessageContext, message_handler,
    SingleThreadedAgentRuntime, AgentId,
    UserMessage, AssistantMessage, SystemMessage,
    CreateResult, FunctionCall, FunctionExecutionResult,
    FunctionExecutionResultMessage, ChatCompletionContext, UnboundedChatCompletionContext
)
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core.tools import Tool, Workbench
from autogen_ext.tools.mcp import McpWorkbench, StdioServerParams, SseServerParams, StreamableHttpServerParams

from agents.fetch_agent.agent_config import *
from config import *

load_dotenv()


# -----------------------------
# Data Models
# -----------------------------
class TextMessage(BaseModel):
    content: str
    source: str
    task_id: Optional[str] = None
    context_id: Optional[str] = None

class ResponseFormat(BaseModel):
    status: Literal["completed", "input_required", "error"]
    fetched_data: str


# -----------------------------
# LLM Client
# -----------------------------
gpt4_model_client = AzureOpenAIChatCompletionClient(
    model=GPT4_MODEL_NAME,
    azure_endpoint=GPT4_AZURE_ENDPOINT,
    azure_deployment=GPT4_AZURE_DEPLOYMENT,
    api_version=GPT4_API_VERSION,
    api_key=os.getenv("GPT4_AZURE_API_KEY"),
    model_info={
        "vision": False,
        "json_output": True,
        "structured_output": True,
        "function_calling": True,
        "family": "gpt-4",
    }
)


# -----------------------------
# MCP Workbench Factory
# -----------------------------
async def create_mcp_workbench(
    mcp_params: StdioServerParams | SseServerParams | StreamableHttpServerParams |
                Sequence[StdioServerParams | SseServerParams | StreamableHttpServerParams]
) -> Sequence[McpWorkbench]:
    workbenches = []
    try:
        if isinstance(mcp_params, Sequence):
            for params in mcp_params:
                wb = McpWorkbench(params)
                workbenches.append(wb)
        else:
            workbenches.append(McpWorkbench(mcp_params))
        logger.info(f"Created {len(workbenches)} MCP workbench(es).")
    except Exception as e:
        logger.error(f"Failed to create MCP workbench: {e}")
    return workbenches


# -----------------------------
# FetchAgent Class
# -----------------------------
class FetchAgent(RoutedAgent):
    SUPPORTED_CONTENT_TYPES = ['text', 'text/plain', 'application/json']

    def __init__(self, agent_name: str,
                 agent_description: str,
                 system_message: Optional[List[SystemMessage]] = None,
                 model_client=None,
                 model_context: Optional[ChatCompletionContext] = None,
                 tools: Optional[Sequence[Tool]] = None,
                 workbench: Optional[Sequence[Workbench]] = None):
        super().__init__(description=agent_description)
        self._agent_name = agent_name
        self._agent_description = agent_description
        self._system_message = system_message or []
        self._model_client = model_client or gpt4_model_client
        self._model_context = model_context
        self._tools = tools
        self._workbench = workbench or []

        logger.info(f"FetchAgent '{agent_name}' initialized.")

    @message_handler
    async def handle_text_message(self, message: TextMessage, context: MessageContext) -> str:
        logger.info(f"Received message from {message.source}: {message.content}")

        if self._tools and self._workbench:
            raise ValueError("Cannot have both tools and workbench defined at the same time.")

        tools_to_use = await self._prepare_tools()
        user_message = UserMessage(content=message.content, source=message.source)

        if self._model_context:
            await self._model_context.add_message(user_message)

        logger.info("Sending request to model...")
        model_response = await self._model_client.create(
            messages=self._system_message + (await self._model_context.get_messages() if self._model_context else [user_message]),
            tools=tools_to_use,
            cancellation_token=context.cancellation_token
        )

        response = await self._process_model_response(model_response)
        return response

    async def _prepare_tools(self) -> List[Tool]:
        if self._workbench:
            for wb in self._workbench:
                await wb.start()
            tools = await self._fetch_workbench_tools(self._workbench)
        elif self._tools:
            tools = self._tools
        else:
            tools = []
        return tools

    async def _fetch_workbench_tools(self, workbench: Sequence[Workbench]) -> List[Tool]:
        tools = []
        try:
            for wb in workbench:
                await asyncio.sleep(0.5)
                wb_tools = await wb.list_tools()
                tools.extend(wb_tools)
        except Exception as e:
            logger.error(f"Error fetching tools from workbench: {e}")
        return tools

    async def _process_model_response(self, model_response) -> str:
        if isinstance(model_response, CreateResult) and isinstance(model_response.content, str):
            await self._model_context.add_message(AssistantMessage(content=model_response.content, source=self.id.type))
            await self._cleanup_workbenches()
            return json.dumps(model_response.content)
        elif isinstance(model_response, str):
            await self._model_context.add_message(AssistantMessage(content=model_response, source=self.id.type))
            await self._cleanup_workbenches()
            return model_response
        else:
            await self._cleanup_workbenches()
            logger.error(f"Invalid model response type: {type(model_response)}")
            raise RuntimeError(f"Invalid LLM response type: {type(model_response)}")

    async def _cleanup_workbenches(self):
        for wb in self._workbench:
            try:
                await wb.__aexit__(None, None, None)
            except Exception as e:
                logger.error(f"Error closing workbench {wb}: {e}")


# -----------------------------
# Agent Factory & Runtime
# -----------------------------
async def simple_agent_factory():
    workbenches = await create_mcp_workbench(mcp_params)
    agent = FetchAgent(
        agent_name=agent_name,
        agent_description=agent_description,
        system_message=[SystemMessage(content=fetcher_agent_prompt)],
        model_client=gpt4_model_client,
        model_context=UnboundedChatCompletionContext(),
        workbench=workbenches
    )
    return agent

async def create_runtime() -> SingleThreadedAgentRuntime:
    runtime = SingleThreadedAgentRuntime()
    await FetchAgent.register(runtime, agent_type, simple_agent_factory)
    return runtime

async def invoke_fetch_agent(ag_runtime: SingleThreadedAgentRuntime,
                             user_message: str,
                             source: str = "user",
                             context_id: Optional[str] = None,
                             task_id: Optional[str] = None) -> ResponseFormat | str:
    ag_runtime.start()
    fetcher_agent_id = AgentId(agent_type, "default")
    logger.info(f"Sending message to fetcher agent: {user_message}")
    final_response = await ag_runtime.send_message(
        TextMessage(content=user_message, source=source, context_id=context_id, task_id=task_id),
        recipient=fetcher_agent_id
    )
    await ag_runtime.stop_when_idle()
    logger.info(f"Received response from fetcher agent: {final_response}")
    return json.loads(final_response)


# # -----------------------------
# # CLI Execution
# # -----------------------------
# if __name__ == "__main__":
#     async def main_loop():
#         runtime = await create_runtime()
#         while True:
#             user_message = input("Enter your message: ")
#             if user_message.lower() == "quit":
#                 break
#             response = await invoke_fetch_agent(runtime, user_message)
#             logger.info(f"Agent response: {response}")
#
#     asyncio.run(main_loop())
