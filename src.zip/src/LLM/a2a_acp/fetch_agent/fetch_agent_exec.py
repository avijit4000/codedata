# from a2a.server.agent_execution import AgentExecutor, RequestContext
# from a2a.server.events import EventQueue
# from a2a.server.tasks import TaskUpdater
# from a2a.types import (
#     InternalError,
#     InvalidParamsError,
#     Part,
#     TaskState,
#     TextPart,
#     UnsupportedOperationError,
# )
# from a2a.utils import (
#     new_agent_text_message,
#     new_task,
# )
# from a2a.utils.errors import ServerError
#
# import json
#
# from agents.fetch_agent.fetch_agent import invoke_fetch_agent, create_fetch_agent_runtime
#
# class FetchAgentExecutor(AgentExecutor):
#     "An executor for the Fetch Agent."
#
#     def __init__(self):
#         self._ag_runtime = create_fetch_agent_runtime()
#
#     async def execute(
#         self,
#         request_context: RequestContext,
#         event_queue: EventQueue,
#         task_updater: TaskUpdater,
#     ) -> None:
#         error = self._validate_request(request_context)
#
#         if error:
#             raise ServerError(error=InvalidParamsError())
#
#         try:
#             user_message = request_context.get_user_input()
#
#             task = request_context.current_task
#
#             if not task:
#                 task = new_task(request_context.message)
#                 await event_queue.enqueue_event(task)
#
#             updater = TaskUpdater(event_queue, task.id, task.context_id)
#
#             response = await invoke_fetch_agent(self._ag_runtime, user_message)
#
#             if response.get("status") == "error":
#                 await task_updater.update_status(
#                     TaskState.FAILED,
#                     new_agent_text_message(
#                             response.get("fetched_data"),
#                             task.context_id,
#                             task.id,
#                         ),
#                         final=True,
#                 )
#             elif response.get("status") == "input_required":
#                 await task_updater.update_status(
#                     TaskState.INPUT_REQUIRED,
#                     new_agent_text_message(
#                             response.get("fetched_data"),
#                             task.context_id,
#                             task.id,
#                         ),
#                         final=False,
#                 )
#             elif response.get("status") == "completed":
#                 await task_updater.update_status(
#                     TaskState.COMPLETED,
#                     new_agent_text_message(
#                             response.get("fetched_data"),
#                             task.context_id,
#                             task.id,
#                         ),
#                         final=True,
#                 )
#
#             response_part = TextPart(content=response)
#             await task_updater.update_task(
#                 state=TaskState.COMPLETED,
#                 output={"response": response_part},
#             )
#         except Exception as e:
#             raise InternalError(f"FetchAgentExecutor failed: {str(e)}") from e
#
#     async def cancel(
#         self, context: RequestContext, event_queue: EventQueue
#     ) -> None:
#         raise ServerError(error=UnsupportedOperationError())
#
# from src.tools.utils.logging import logger
#
# from a2a.server.agent_execution import AgentExecutor, RequestContext
# from a2a.server.events import EventQueue
# from a2a.server.tasks import TaskUpdater
# from a2a.types import (
#     InternalError,
#     InvalidParamsError,
#     TaskState,
#     TextPart,
#     UnsupportedOperationError,
# )
# from a2a.utils import new_agent_text_message, new_task
# from a2a.utils.errors import ServerError
#
# from agents.fetch_agent.fetch_agent import invoke_fetch_agent, create_fetch_agent_runtime
#
#
# class FetchAgentExecutor(AgentExecutor):
#     """Executor for the Fetch Agent."""
#
#     def __init__(self):
#         logger.info("Initializing FetchAgentExecutor...")
#         self._ag_runtime = create_fetch_agent_runtime()
#         logger.info("FetchAgent runtime created.")
#
#     async def execute(
#         self,
#         request_context: RequestContext,
#         event_queue: EventQueue,
#         task_updater: TaskUpdater,
#     ) -> None:
#         logger.info("Executing FetchAgentExecutor task...")
#         error = self._validate_request(request_context)
#
#         if error:
#             logger.error("Invalid request received.")
#             raise ServerError(error=InvalidParamsError())
#
#         try:
#             user_message = request_context.get_user_input()
#             logger.info(f"User message received: {user_message}")
#
#             task = request_context.current_task
#             if not task:
#                 logger.info("No existing task found. Creating new task...")
#                 task = new_task(request_context.message)
#                 await event_queue.enqueue_event(task)
#                 logger.info(f"Task created with ID: {task.id}")
#
#             updater = TaskUpdater(event_queue, task.id, task.context_id)
#
#             # Invoke the fetch agent runtime
#             response = await invoke_fetch_agent(self._ag_runtime, user_message)
#             logger.info(f"Fetch agent response: {response}")
#
#             # Update task status based on response
#             await self._update_task_status(task_updater, task, response)
#
#             # Update final task output
#             response_part = TextPart(content=response)
#             await task_updater.update_task(
#                 state=TaskState.COMPLETED,
#                 output={"response": response_part},
#             )
#             logger.info(f"Task {task.id} completed successfully.")
#
#         except Exception as e:
#             logger.exception("FetchAgentExecutor failed.")
#             raise InternalError(f"FetchAgentExecutor failed: {str(e)}") from e
#
#     async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
#         logger.warning("Cancel requested but operation not supported.")
#         raise ServerError(error=UnsupportedOperationError())
#
#     async def _update_task_status(self, task_updater: TaskUpdater, task, response: dict):
#         """Internal helper to update the task status based on agent response."""
#         status = response.get("status")
#         fetched_data = response.get("fetched_data", "")
#
#         if status == "error":
#             logger.error(f"Task {task.id} failed: {fetched_data}")
#             await task_updater.update_status(
#                 TaskState.FAILED,
#                 new_agent_text_message(fetched_data, task.context_id, task.id),
#                 final=True,
#             )
#         elif status == "input_required":
#             logger.info(f"Task {task.id} requires additional input.")
#             await task_updater.update_status(
#                 TaskState.INPUT_REQUIRED,
#                 new_agent_text_message(fetched_data, task.context_id, task.id),
#                 final=False,
#             )
#         elif status == "completed":
#             logger.info(f"Task {task.id} completed successfully.")
#             await task_updater.update_status(
#                 TaskState.COMPLETED,
#                 new_agent_text_message(fetched_data, task.context_id, task.id),
#                 final=True,
#             )
#         else:
#             logger.warning(f"Task {task.id} received unknown status: {status}")


from src.tools.utils.logging import logger

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import (
    InternalError,
    InvalidParamsError,
    TaskState,
    TextPart,
    UnsupportedOperationError,
)
from a2a.utils import new_agent_text_message, new_task
from a2a.utils.errors import ServerError
from src.LLM.a2a_acp.fetch_agent.fetch_agent import invoke_fetch_agent, create_fetch_agent_runtime


class FetchAgentExecutor(AgentExecutor):
    """Executor for the Fetch Agent."""

    def __init__(self):
        logger.info("Initializing FetchAgentExecutor...")
        self._ag_runtime = create_fetch_agent_runtime()
        logger.info("FetchAgent runtime created.")

    async def execute(
        self,
        request_context: RequestContext,
        event_queue: EventQueue,
        task_updater: TaskUpdater,
    ) -> None:
        logger.info("Executing FetchAgentExecutor task...")
        error = self._validate_request(request_context)

        if error:
            logger.error("Invalid request received.")
            raise ServerError(error=InvalidParamsError())

        try:
            user_message = request_context.get_user_input()
            logger.info(f"User message received: {user_message}")

            task = request_context.current_task
            if not task:
                logger.info("No existing task found. Creating new task...")
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)
                logger.info(f"Task created with ID: {task.id}")

            updater = TaskUpdater(event_queue, task.id, task.context_id)

            # Invoke the fetch agent runtime
            response = await invoke_fetch_agent(self._ag_runtime, user_message)
            logger.info(f"Fetch agent response: {response}")

            # Update task status based on response
            await self._update_task_status(task_updater, task, response)

            # Update final task output
            response_part = TextPart(content=response)
            await task_updater.update_task(
                state=TaskState.COMPLETED,
                output={"response": response_part},
            )
            logger.info(f"Task {task.id} completed successfully.")

        except Exception as e:
            logger.exception("FetchAgentExecutor failed.")
            raise InternalError(f"FetchAgentExecutor failed: {str(e)}") from e

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        logger.warning("Cancel requested but operation not supported.")
        raise ServerError(error=UnsupportedOperationError())

    async def _update_task_status(self, task_updater: TaskUpdater, task, response: dict):
        """Internal helper to update the task status based on agent response."""
        status = response.get("status")
        fetched_data = response.get("fetched_data", "")

        if status == "error":
            logger.error(f"Task {task.id} failed: {fetched_data}")
            await task_updater.update_status(
                TaskState.FAILED,
                new_agent_text_message(fetched_data, task.context_id, task.id),
                final=True,
            )
        elif status == "input_required":
            logger.info(f"Task {task.id} requires additional input.")
            await task_updater.update_status(
                TaskState.INPUT_REQUIRED,
                new_agent_text_message(fetched_data, task.context_id, task.id),
                final=False,
            )
        elif status == "completed":
            logger.info(f"Task {task.id} completed successfully.")
            await task_updater.update_status(
                TaskState.COMPLETED,
                new_agent_text_message(fetched_data, task.context_id, task.id),
                final=True,
            )
        else:
            logger.warning(f"Task {task.id} received unknown status: {status}")
