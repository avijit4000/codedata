# from autogen_ext.tools.mcp import SseServerParams, StdioServerParams, StreamableHttpServerParams
#
#
# fetcher_agent_prompt = """You are a helpful assistant that fetches latency report using the tools provided.
#                         If the date provided is not in the correct format, convert it to the format accepted by the tool.
#                         Today's date is 2025-11-25.
#
#                         'Set response status to input_required if the user needs to provide more information to complete the request.'
#                         'Set response status to error if there is an error while processing the request.'
#                         'Set response status to completed if the request is complete.'
#
#                         Strictly return a JSON response in the following format :
#                         {
#                             "status": "input_required" | "error" | "completed",
#                             "fetched_data": "fetched data or the error message or the message asking for more information"
#                         }
#                         """
#
# agent_name = "fetcher_agent"
# agent_type = "fetcher_agent"
# agent_description = """An agent that fetches latency report using MCP tools.
#                     It can fetch latency report for specific dates or date ranges.
#                     Provide insights on the fetched latency report data."""
#
# # MCP Server Parameters for Fetch Agent
# # Either a single MCP server params or a list of MCP server params can be provided.
# mcp_params = StdioServerParams(
#         command = "python",
#         args = ["-m", "mcps.pull_metric_api"],
#         )


import asyncio
from typing import Sequence
from src.tools.utils.logging import logger
from autogen_ext.tools.mcp import StdioServerParams, SseServerParams, StreamableHttpServerParams, McpWorkbench

# Agent configuration
fetcher_agent_prompt = """You are a helpful assistant that fetches latency report using the tools provided. 
If the date provided is not in the correct format, convert it to the format accepted by the tool.
Today's date is 2025-11-25.

'Set response status to input_required if the user needs to provide more information to complete the request.'
'Set response status to error if there is an error while processing the request.'
'Set response status to completed if the request is complete.'

Strictly return a JSON response in the following format:
{
    "status": "input_required" | "error" | "completed",
    "fetched_data": "fetched data or the error message or the message asking for more information"
}
"""

AGENT_NAME = "fetcher_agent"
AGENT_TYPE = "fetcher_agent"
AGENT_DESCRIPTION = """An agent that fetches latency report using MCP tools.
It can fetch latency report for specific dates or date ranges.
Provide insights on the fetched latency report data."""

# MCP parameters
MCP_PARAMS = StdioServerParams(
    command="python",
    args=["-m", "mcps.pull_metric_api"]
)


class FetcherAgentManager:
    """Class to manage fetcher agent and its MCP workbench."""

    def __init__(self, mcp_params=MCP_PARAMS):
        self.mcp_params = mcp_params
        self.workbenches = []
        logger.info(f"FetcherAgentManager initialized with MCP params: {mcp_params}")

    async def create_workbench(self) -> McpWorkbench:
        """Create MCP workbench for the agent."""
        try:
            workbench = McpWorkbench(self.mcp_params)
            await workbench.__aenter__()
            self.workbenches.append(workbench)
            logger.info("MCP workbench created successfully.")
            return workbench
        except Exception as e:
            logger.error(f"Failed to create MCP workbench: {e}")
            raise

    async def close_workbenches(self):
        """Clean up all workbenches."""
        for wb in self.workbenches:
            try:
                await wb.__aexit__(None, None, None)
                logger.info(f"Workbench {wb} closed successfully.")
            except Exception as e:
                logger.error(f"Error closing workbench {wb}: {e}")

    async def setup_agent(self):
        """Setup the fetcher agent (future integration with AssistantAgent or RoutedAgent)."""
        workbench = await self.create_workbench()
        logger.info(f"Fetcher agent '{AGENT_NAME}' setup with workbench: {workbench}")
        return {
            "agent_name": AGENT_NAME,
            "agent_type": AGENT_TYPE,
            "agent_description": AGENT_DESCRIPTION,
            "system_message": fetcher_agent_prompt,
            "workbench": workbench
        }


# # Example usage
# if __name__ == "__main__":
#     async def main():
#         manager = FetcherAgentManager()
#         agent_config = await manager.setup_agent()
#         logger.info(f"Fetcher agent configuration: {agent_config}")
#         # Do something with agent_config (like initializing RoutedAgent or AssistantAgent)
#         await manager.close_workbenches()
#
#     asyncio.run(main())
