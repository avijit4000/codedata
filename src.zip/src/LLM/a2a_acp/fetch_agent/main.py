# import os
# import sys
#
# import click
# import httpx
# import uvicorn
#
# from a2a.server.apps import A2AStarletteApplication
# from a2a.server.request_handlers import DefaultRequestHandler
# from a2a.server.tasks import (
#     BasePushNotificationSender,
#     InMemoryPushNotificationConfigStore,
#     InMemoryTaskStore,
# )
# from a2a.types import (
#     AgentCapabilities,
#     AgentCard,
#     AgentSkill,
# )
# from dotenv import load_dotenv
#
# from agents.fetch_agent.fetch_agent import FetchAgent
# from agents.fetch_agent.fetch_agent_exec import FetchAgentExecutor
# from agents.fetch_agent.agent_config import agent_name, agent_type, agent_description, mcp_params
#
# from config import logger
#
#
# def main(host, port):
#     """Starts the Fetcher Agent server."""
#     try:
#
#         capabilities = AgentCapabilities(streaming=False, push_notifications=False)
#         skill = AgentSkill(
#             id='fetch_latency_report',
#             name='Latency Report Fetching',
#             description=agent_description,
#             tags=["latency report"],
#             examples=['What is the latency report for 2025/11/13?','Fetch the latency report from 2025/11/12 to 2025/11/14 and provide a python code to plot the fetched result'],
#         )
#         agent_card = AgentCard(
#             name=agent_name,
#             description=agent_description,
#             url=f'http://{host}:{port}/',
#             version='1.0.0',
#             default_input_modes=FetchAgent.SUPPORTED_CONTENT_TYPES,
#             default_output_modes=FetchAgent.SUPPORTED_CONTENT_TYPES,
#             capabilities=capabilities,
#             skills=[skill],
#         )
#
#
#         # --8<-- [start:DefaultRequestHandler]
#         httpx_client = httpx.AsyncClient()
#         push_config_store = InMemoryPushNotificationConfigStore()
#         push_sender = BasePushNotificationSender(httpx_client=httpx_client,
#                         config_store=push_config_store)
#         request_handler = DefaultRequestHandler(
#             agent_executor=FetchAgentExecutor(),
#             task_store=InMemoryTaskStore(),
#             push_config_store=push_config_store,
#             push_sender= push_sender
#         )
#         server = A2AStarletteApplication(
#             agent_card=agent_card, http_handler=request_handler
#         )
#
#         uvicorn.run(server.build(), host=host, port=port)
#         # --8<-- [end:DefaultRequestHandler]
#
#     except Exception as e:
#         logger.error(f'An error occurred during server startup: {e}')
#         sys.exit(1)
#
#
# if __name__ == '__main__':
#     main()


import os
import sys
import click
import httpx
import uvicorn
from dotenv import load_dotenv

from src.tools.utils.logging import logger
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import (
    BasePushNotificationSender,
    InMemoryPushNotificationConfigStore,
    InMemoryTaskStore,
)
from a2a.types import AgentCapabilities, AgentCard, AgentSkill

from agents.fetch_agent.fetch_agent import FetchAgent
from agents.fetch_agent.fetch_agent_exec import FetchAgentExecutor
from agents.fetch_agent.agent_config import agent_name, agent_type, agent_description, mcp_params


class FetchAgentServer:
    """Class to start the Fetcher Agent server."""

    def __init__(self, host: str = "0.0.0.0", port: int = 8000):
        self.host = host
        self.port = port
        logger.info(f"Initializing FetchAgentServer on {self.host}:{self.port}...")

    def build_agent_card(self) -> AgentCard:
        """Build the AgentCard with capabilities and skills."""
        logger.info("Building agent card...")
        capabilities = AgentCapabilities(streaming=False, push_notifications=False)
        skill = AgentSkill(
            id="fetch_latency_report",
            name="Latency Report Fetching",
            description=agent_description,
            tags=["latency report"],
            examples=[
                "What is the latency report for 2025/11/13?",
                "Fetch the latency report from 2025/11/12 to 2025/11/14 and provide a python code to plot the fetched result",
            ],
        )
        agent_card = AgentCard(
            name=agent_name,
            description=agent_description,
            url=f"http://{self.host}:{self.port}/",
            version="1.0.0",
            default_input_modes=FetchAgent.SUPPORTED_CONTENT_TYPES,
            default_output_modes=FetchAgent.SUPPORTED_CONTENT_TYPES,
            capabilities=capabilities,
            skills=[skill],
        )
        logger.info("Agent card built successfully.")
        return agent_card

    def start(self):
        """Start the server."""
        try:
            logger.info("Starting FetchAgent server...")

            # Async HTTP client and push notification setup
            httpx_client = httpx.AsyncClient()
            push_config_store = InMemoryPushNotificationConfigStore()
            push_sender = BasePushNotificationSender(
                httpx_client=httpx_client, config_store=push_config_store
            )

            # Request handler with FetchAgentExecutor
            request_handler = DefaultRequestHandler(
                agent_executor=FetchAgentExecutor(),
                task_store=InMemoryTaskStore(),
                push_config_store=push_config_store,
                push_sender=push_sender,
            )

            server_app = A2AStarletteApplication(
                agent_card=self.build_agent_card(), http_handler=request_handler
            )

            logger.info(f"Running server on {self.host}:{self.port}...")
            uvicorn.run(server_app.build(), host=self.host, port=self.port)

        except Exception as e:
            logger.error(f"An error occurred during server startup: {e}", exc_info=True)
            sys.exit(1)


# if __name__ == "__main__":
#     load_dotenv()
#     # Use environment variables or defaults
#     host = os.getenv("FETCH_AGENT_HOST", "0.0.0.0")
#     port = int(os.getenv("FETCH_AGENT_PORT", 8000))
#     FetchAgentServer(host=host, port=port).start()
