class prompTemplate:
    def create_question(self, field_name:str) -> str:
        create_question_template="""
            You are a helpful assistant that converts a form field name into a natural question.
            Example:
            "first_name" → "What is your first name?"
            "address" → "Please provide your address."
            Input: "{field_name}"
            Output:
            """
        return create_question_template
    def question_ask(self, asking_question:str, user_input:str, questions_list: list) -> str:
        question_template=f"""
            You are a validation AI. A form chatbot asked the user a question: "{asking_question}".

            User replied: "{user_input}"

            List of possible fields: {questions_list}

            Your task:
            - If the question is about address (e.g., "What is your address?" or "Where are you from?"), accept any city, town, village, or location name (e.g., "Kolkata", "Texas", "New York") as a valid answer, even if the user says "I am from Kolkata" or "My address is Texas".
            - If the question is about first name or last name, accept either a single name (e.g., "Avijit") or a full name (e.g., "Avijit Biswas") as a valid answer. If the user provides a full name for either first name or last name, consider it valid.
            - For other questions, check if the answer matches the expected type (e.g., name, gender, yes/no).
            - If this is a valid answer to the question, return: ANSWER
            - If this is a correction like "I need to change first name" or "wrong last name", return: CORRECT <field_name>

            Only reply exactly "ANSWER" or "CORRECT <field_name>".
            """
        return question_template

    def question_answer(self, asking_question:str, user_ans:str) -> str:

        template =f"""
            You are a helpful assistant. A question was asked: "{asking_question}".

            Based on the user's input below, provide only the exact answer relevant to the question.

            - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
            - For other fields, return the relevant answer as-is, without any extra text or explanation.

            User input: "{user_ans}"
            Output:
            """
        return template

