import asyncio
from src.LLM.llm_model.llm_model import llmtoolmodel


async def main():
    # Access the model
    model = llmtoolmodel.model
    print("Model loaded:", model)

    # Access the tools (setup is async)
    tools = await llmtoolmodel.setup()
    print("Tools fetched:", tools)


if __name__ == "__main__":
    asyncio.run(main())
