from flask import Flask, request, jsonify
from src.utils.logging import logger
from src.LLM.llm_azure import FormChatBot

app = Flask(__name__)

chatbot = FormChatBot()
@app.route("/chatbot", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "").strip()
    logger.info(f"User input: {user_input}")
    user_id = data.get("user_id", "").strip()

    if not user_input:
        if chatbot.index == 0:
            return jsonify({
                "message": "Hello! 👋",
                "next_question": chatbot.generate_question(chatbot.asked_keys[0])
            })
        else:
            current_key = chatbot.asked_keys[chatbot.index]
            return jsonify({
                "message": "Please provide input to continue.",
                "next_question": chatbot.questions[current_key]
            })

    if user_input.lower() in ["exit", "quit"]:
        logger.info("Chatbot exited by user.")
        return jsonify({
            "message": "Chatbot: Exiting. Goodbye! 👋",
            "end": True
        })

    bot_response = chatbot.process_input(user_input,user_id)

    if bot_response == "invalid":
        current_key = chatbot.asked_keys[chatbot.index]
        return jsonify({
            "message": "Invalid input, please answer correctly.",
            "next_question": chatbot.questions[current_key]
        })

    next_question = chatbot.get_next_question()

    if not next_question:
        return jsonify({
            "message": "Completed ",
            "responses": chatbot.responses,
            "end": True
        })

    return jsonify({"message": bot_response, "question": next_question})

if __name__ == '__main__':
    logger.info("Starting Flask API server on http://0.0.0.0:8080")
    app.run(host="0.0.0.0", port=8080)