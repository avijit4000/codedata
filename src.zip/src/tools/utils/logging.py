import logging
import sys
import os

# Path to mcpdata folder (project root)
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))

# logs folder inside mcpdata
LOG_DIR = os.path.join(ROOT_DIR, "logs")

# Create logs folder if missing
os.makedirs(LOG_DIR, exist_ok=True)

# Full path to log file
LOG_FILE = os.path.join(LOG_DIR, "a2a_mcp.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("A2A-MCP-Logs")
