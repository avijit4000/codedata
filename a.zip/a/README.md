# gpd-ops-mcp-api


# Usage
Create virtual environment
command python3 -m venv env

Install `python 3.12.6` and `requirements.txt`.
activate environment
command 
mac:source env/bin/activate
windows: env\bin\activate
pip install -r requirements.txt  

Create a file called `.env` in the `src` folder with the following info:

```bash
#Azure AI Search Service details
SEARCH_API_VERSION = 2025-03-01-preview
#Azure OpenAI Service details
AZURE_OPENAI_ENDPOINT=https://gpdacq-dev-1-eastus-openai.openai.azure.com/
AZURE_OPENAI_KEY={AZURE_OPENAI_KEY}
GPT_ENGINE=gpt-4.1-mini
EMBEDDING_MODEL=text-embedding-3-small
```

please get the key from azure portal based on the access.
# Test API
Sample command

curl --location 'http://localhost:8080/agent'
