import asyncio
from langgraph.prebuilt import create_react_agent
from src.tools.utils.logging import logger
from src.LLM.llm_model import llm_model

toolemodle=llm_model.llmtoolmodel 
tool=toolemodle.setup
model=toolemodle.self.model


class A2AMCPSystem:

    async def setup(self,model,tools ):
        logger.info("Creating ReAct agent...")
        self.agent = create_react_agent(self.model, tools)

    async def ask(self, prompt: str):
        """Send a prompt to the agent and return the response."""
        logger.info(f"User Prompt: {prompt}")
        response = await self.agent.ainvoke(
            {"messages": [{"role": "user", "content": prompt}]}
        )
        final_answer = response["messages"][-1].content
        logger.info(f"Response: {final_answer}")
        return final_answer
    async def run_tests(self):
        """Run all sample tests."""
        logger.info("Running test queries...")

        math_q = "what's (3 + 5) x 12?"
        weather_q = "What is the current weather in Los Angeles, California?"
        db_q = "Find the time of day when most people order snacks, and identify the location that receives the highest number of snack orders"

        print("\nMath Response:")
        print(await self.ask(math_q))

        print("\nWeather Response:")
        print(await self.ask(weather_q))

        print("\nDatabase Response:")
        print(await self.ask(db_q))


async def main():
    system = A2AMCPSystem()
    await system.setup()
    await system.run_tests()


if __name__ == "__main__":
    asyncio.run(main())