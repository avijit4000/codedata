class prompTemplate:
    def create_question(self, field_name:str) -> str:
        create_question_template = """
        You are a friendly and natural-sounding person having a casual but respectful conversation. 
        Your task is to turn a form field name into a direct, human-like question — as if you’re personally asking someone. 
        Keep it simple, natural, and conversational. Avoid overly formal or robotic language like “May I have” or “Could you please”. 
        Make it sound like how a person would actually talk.

        Examples:
        - "first_name" → "What's your first name?"
        - "last_name" → "What's your last name?"
        - "middle_name" → "Do you have a middle name?"
        - "address" → "Where do you live?"
        - "email" → "What's your email address?"
        - "phone_number" → "What's your phone number?"
        - "age" → "How old are you?"
        - "city" → "Which city are you from?"

        Input: "{field_name}"
        Output:
        """

        return create_question_template
    def question_ask(self, asking_question:str, user_input:str, questions_list: list) -> str:
        question_template=f"""
            You are a validation AI. A form chatbot asked the user a question: "{asking_question}".

            User replied: "{user_input}"

            List of possible fields: {questions_list}

            Your task:
            - If the question is about address (e.g., "What is your address?" or "Where are you from?"), accept any city, town, village, or location name (e.g., "Kolkata", "Texas", "New York") as a valid answer, even if the user says "I am from Kolkata" or "My address is Texas".
            - If the question is about first name or last name, accept either a single name (e.g., "Avijit") or a full name (e.g., "Avijit Biswas") as a valid answer. If the user provides a full name for either first name or last name, consider it valid.
            - For other questions, check if the answer matches the expected type (e.g., name, gender, yes/no).
            - If this is a valid answer to the question, return: ANSWER
            - If this is a correction like "I need to change first name" or "wrong last name", return: CORRECT <field_name>

            Only reply exactly "ANSWER" or "CORRECT <field_name>".
            """
        return question_template

    def question_answer(self, asking_question:str, user_ans:str) -> str:

        answer_template =f"""
            You are a helpful assistant. A question was asked: "{asking_question}".

            Based on the user's input below, provide only the exact answer relevant to the question.

            - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
            - For other fields, return the relevant answer as-is, without any extra text or explanation.

            User input: "{user_ans}"
            Output:
            """
        return answer_template
    def validate_question(self, asking_question:str, user_ans:str) -> str:
        validate_question_template = f"""
        You are an intelligent assistant that determines user intent based on the user response.

        Question: "{asking_question}"
        User response: "{user_ans}"

        Your task:
        1. If the question is about a middle name (i.e., contains the words "middle name"), and the user response is empty, only spaces, or indicates no middle name 
           (e.g., "no", "none", "no middle name", "skip", "I don't have a middle name", "na", "n/a"), output "next".
        2. If the user explicitly wants to go back to the previous question (e.g., says "go back", "previous", "earlier one", "before this"), output "previous".
        3. If the user explicitly wants to move to the next question (e.g., says "go next", "continue", "skip", "proceed"), output "next".
        4. If the user gives an empty or whitespace-only response and it’s not about middle name, output "same".
        5. Otherwise, if the user provides a valid or normal response, output "none".

        Output only **one word**:
        - "previous"
        - "next"
        - "same"
        - "none"

        Output:
        """

        return validate_question_template
