import os
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
from src.LLM.prompts.llm_template import prompTemplate
from langchain.memory import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from ..globals import *

load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")

promptemplate = prompTemplate()


class FormChatBot:
    def __init__(self):
        self.store = {}
        self.responses = {}
        self.asked_keys = qlist1
        self.index = 0
        self.return_index = None

        self.chat_model = AzureChatOpenAI(
            openai_api_key=api_key,
            azure_endpoint=azure_endpoint,
            azure_deployment=azure_model,
            api_version=api_version,
            temperature=0.7
        )

    def get_session_history(self, session_id: str):
        if session_id not in self.store:
            self.store[session_id] = ChatMessageHistory()
        return self.store[session_id]

    def generate_question(self, field_name):
        create_question_template = promptemplate.create_question(field_name)
        create_question_prompt = PromptTemplate(
            input_variables=["field_name"],
            template=create_question_template
        )
        chain = LLMChain(llm=self.chat_model, prompt=create_question_prompt, verbose=False)
        question_result = chain.run(field_name=field_name).strip().replace('"', '').replace("'", "").capitalize()
        return question_result

    def get_next_question(self):
        if self.index < len(self.asked_keys):
            field_name = self.asked_keys[self.index]
            question = self.generate_question(field_name)
            return question
        return None

    def process_input(self, user_input, user1):
        user_input_lower = user_input.lower()

        for field, value in self.responses.items():
            field_clean = field.replace("_", " ").lower()
            if f"what is my {field_clean}" in user_input_lower:
                return f"Your {field_clean} is {value}."

        key = self.asked_keys[self.index]
        question = self.generate_question(key)
     
        question_template = promptemplate.question_ask(question, user_input, ", ".join(self.asked_keys))
        validation_prompt = PromptTemplate(
            input_variables=["asking_question", "user_input", "questions_list"],
            template=question_template
        )
        self.validator = LLMChain(llm=self.chat_model, prompt=validation_prompt, verbose=False)

        validation_result = self.validator.run({
            "asking_question": question,
            "user_input": user_input,
            "questions_list": ", ".join(self.asked_keys)
        }).strip()

        if validation_result.startswith("CORRECT"):
            correction_field = validation_result.replace("CORRECT", "").strip()
            if correction_field in self.asked_keys:
                if self.return_index is None:
                    self.return_index = self.index
                self.index = self.asked_keys.index(correction_field)
                return f"Okay, let's update {correction_field}."


        validate_response_template = promptemplate.validate_question(question, user_input)
        validate_response_prompt = PromptTemplate(
            input_variables=["question", "user_input"],
            template=validate_response_template
        )
        chain = LLMChain(llm=self.chat_model, prompt=validate_response_prompt, verbose=False)
        validate_response_result = chain.run(question=question, user_input=user_input)
        print(validate_response_result)

        if "previous" in validate_response_result:
            if self.index > 0:
                self.index -= 1
            field_name = self.asked_keys[self.index]
            return self.generate_question(field_name)

        elif "next" in validate_response_result:
            if self.index < len(self.asked_keys) - 1:
                self.index += 1
            field_name = self.asked_keys[self.index]
            return self.generate_question(field_name)

        elif "same" in validate_response_result:
            return question


        ans_template = promptemplate.question_answer(question, user_input)
        extraction_prompt = PromptTemplate(
            input_variables=["asking_question", "user_input"],
            template=ans_template
        )
        prompt = ChatPromptTemplate.from_messages([
            ("system", extraction_prompt.template),
            MessagesPlaceholder(variable_name="history"),
            ("human", "{input}")
        ])
        self.chain = prompt | self.chat_model

        with_memory = RunnableWithMessageHistory(
            self.chain,
            self.get_session_history,
            input_messages_key="input",
            history_messages_key="history",
        )

        config = {"configurable": {"session_id": f"{user1}"}}

        response = with_memory.invoke({
            "input": question,
            "asking_question": question,
            "user_input": user_input
        }, config=config)

        extractor_result = response.content.strip()
        self.responses[key] = extractor_result

        # if self.return_index is not None:
        #     if self.index == self.return_index:
        #         self.return_index = None
        #         self.index += 1
        #     else:
        #         self.index = self.return_index
        # else:
        #     self.index += 1


        # --- Update index logic ---
        if self.return_index is not None:
            if self.index == self.return_index:
                self.return_index = None
                self.index += 1
            else:
                self.index = self.return_index
        else:
            self.index += 1

        # Return both the extracted result and updated responses
        # return extractor_result


        # if self.index >= len(self.asked_keys):
        #     final_response = f"All questions completed. Here are your responses:\n{self.responses}"
        #     # Reset chatbot to start over
        #     self.index = 0
        #     self.responses = {}
        #     self.return_index = None
        #     return final_response

        return extractor_result
