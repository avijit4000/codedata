from flask import Flask, request, jsonify
from src.utils.logging import logger
from src.LLM.llm_azure import FormChatBot

app = Flask(__name__)
chatbot = FormChatBot()
user_sessions = {}

@app.route("/chatbot", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "").strip()
    user_id = data.get("user_id", "").strip()
    logger.info(f"User input: '{user_input}' | User ID: {user_id}")

    # --- First-time user welcome ---
    if user_id not in user_sessions:
        user_sessions[user_id] = True
        return jsonify({
            "Message": "Hello! 👋 Welcome to the chatbot. Let's get started.",
            "Question": chatbot.generate_question(chatbot.asked_keys[0]),
            "Field_name": chatbot.asked_keys[0],
            "Responses": chatbot.responses
        })

    # --- Handle exit/quit ---
    if user_input.lower() in ["exit", "quit"]:
        logger.info(f"Chatbot exited by user: {user_id}")
        chatbot.index = 0
        chatbot.responses = {}
        chatbot.return_index = None
        user_sessions.pop(user_id, None)
        return jsonify({
            "Message": "Chatbot: Exiting. Goodbye! 👋",
            "End": True
        })

    # --- Process input ---
    bot_response = chatbot.process_input(user_input, user_id)

    # --- Handle invalid input ---
    if bot_response == "invalid":
        current_key = chatbot.asked_keys[chatbot.index]
        return jsonify({
            "Message": "Invalid input, please answer correctly.",
            "Question": chatbot.generate_question(current_key),
            "Field_name": current_key,
            "Responses": chatbot.responses
        })

    # --- Get next question ---
    if chatbot.index < len(chatbot.asked_keys):
        field_name = chatbot.asked_keys[chatbot.index]
        next_question = chatbot.get_next_question()
    else:
        field_name = None
        next_question = None

    # --- Conversation completed ---
    if not next_question:
        final_responses = chatbot.responses.copy()
        chatbot.index = 0
        chatbot.responses = {}
        chatbot.return_index = None
        user_sessions.pop(user_id, None)
        return jsonify({
            "Message": "All questions completed! 🎉",
            "Responses": final_responses,
            "End": True
        })

    # --- Continue conversation ---
    return jsonify({
        "Field_name": field_name,
        "Message": bot_response,
        "Question": next_question,
        "Responses": chatbot.responses
    })

if __name__ == '__main__':
    logger.info("Starting Flask API server on http://0.0.0.0:8080")
    app.run(host="0.0.0.0", port=8080)
