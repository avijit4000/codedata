# import os
# from flask import Flask, jsonify, request
# from dotenv import load_dotenv
# from langchain_openai import AzureChatOpenAI
# from langchain_core.prompts import PromptTemplate
# from langchain.chains import LLMChain
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
# from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
# # import speech_recognition as sr
# # import pyttsx3
#
#
# load_dotenv()
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
#
# app = Flask(__name__)
#
#
# # engine = pyttsx3.init()
# # engine.setProperty('rate', 150)
# # engine.setProperty('volume', 0.8)
#
# # recognizer = sr.Recognizer()
# store = {}
#
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
#
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0
# )
#
# @app.route('/ask_question', methods=['POST'])
# def ask_question():
#     data = request.get_json()
#     user_input = data.get('user_input', 'last name')
#
#     question_template = """
#     You are a helpful form-filling assistant.
#
#     Your job is to ask the user only the specific question needed to fill out a form.
#
#     Instructions:
#     - If the user input is "last name", respond with exactly: "What is your last name?"
#     - If the user input is "date of birth", respond with exactly: "What is your date of birth?"
#     - If the user input is "gender", respond with exactly: "What is your gender?"
#     - For any other input (e.g., "medicare number", "passport number", "phone number", "address"), respond with exactly: "What is your {user_input}?"
#
#     Important rules:
#     - Return **only the question**.
#     - Do not include explanations, prefixes, or any extra text.
#     - Do not attempt to extract information from the input; just ask the appropriate question.
#
#     Input: "{user_input}"
#
#     Output:
#     """
#
#     Q_CHAIN_PROMPT = PromptTemplate(
#         input_variables=["user_input"],
#         template=question_template
#     )
#
#     asking_chain = LLMChain(
#         llm=llm,
#         prompt=Q_CHAIN_PROMPT,
#         verbose=False
#     )
#
#     asking_result = asking_chain.run(user_input=user_input)
#     asking_question = asking_result.strip()
#
#     # Speak the question
#     # engine.say(asking_question)
#     # engine.runAndWait()
#
#     return jsonify({"question": asking_question})
#
# @app.route('/get_answer', methods=['POST'])
# def get_answer():
#     data = request.get_json()
#     asking_question = data.get('asking_question')
#
#     # with sr.Microphone() as source:
#     #     print("Please speak now...")
#     #     recognizer.adjust_for_ambient_noise(source)
#     #     audio = recognizer.listen(source)
#     #
#     # try:
#     #     user_ans = recognizer.recognize_google(audio)
#     # except sr.UnknownValueError:
#     #     return jsonify({"error": "Could not understand audio."}), 400
#     # except sr.RequestError as e:
#     #     return jsonify({"error": f"Google API error: {e}"}), 500
#     #
#     # print(f"User said: {user_ans}")
#
#     template = """
#     You are a helpful assistant. A question was asked: "{asking_question}".
#
#     Based on the user's input below, provide **only the exact answer** relevant to the question.
#     Do not add any extra text, explanations, or punctuation.
#
#     User input: "{user_ans}"
#
#     Output:
#     """
#
#     # A_CHAIN_PROMPT = PromptTemplate(
#     #     input_variables=["asking_question", "user_ans"],
#     #     template=template
#     # )
#     #
#     # ans_chain = LLMChain(
#     #     llm=llm,
#     #     prompt=A_CHAIN_PROMPT,
#     #     verbose=False
#     # )
#     #
#     # ans_result = ans_chain.run(asking_question=asking_question, user_ans=user_ans)
#     # ans_output = ans_result.strip()
#
#     # engine.say(ans_output)
#     # engine.runAndWait()
#     prompt = ChatPromptTemplate.from_messages([
#         ("system",
#          "You are a helpful assistant that remembers user details. "
#          "When answering questions, always reply in a friendly style like:\n"
#          "- 'Hi, your first name is Avijit.'\n"
#          "- 'Hi, your last name is Biswas.'\n"
#          "- 'Hi, your date of birth year is 1996.'\n"),
#         MessagesPlaceholder(variable_name="history"),
#         ("human", "{input}")
#     ])
#     print(prompt)
#     chain = prompt | llm
#     with_memory = RunnableWithMessageHistory(
#         chain,
#         get_session_history,
#         input_messages_key="input",
#         history_messages_key="history",
#     )
#
#     config = {"configurable": {"session_id": "user1"}}
#
#     with_memory.invoke({"input": "My name is Avijit Biswas. "}, config=config)
#
#     response = with_memory.invoke({"input": "What is my first name?"}, config=config)
#     print(response.content)
#
#
#     return jsonify({
#         "user_spoken_text": user_ans,
#         "extracted_answer": ans_output
#     })
#
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000)


#
# import os
# from flask import Flask, jsonify, request
# from dotenv import load_dotenv
# from langchain_openai import AzureChatOpenAI
# from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
# from langchain.chains import LLMChain
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
#
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# app = Flask(__name__)
#
# store = {}
#
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0
# )
#
# @app.route('/ask_question', methods=['POST'])
# def ask_question():
#     data = request.get_json()
#     user_input = data.get('user_input', 'last name')
#
#     question_template = """
#     You are a helpful form-filling assistant.
#
#     Your job is to ask the user only the specific question needed to fill out a form.
#
#     Instructions:
#     - If the user input is "last name", respond with exactly: "What is your last name?"
#     - If the user input is "date of birth", respond with exactly: "What is your date of birth?"
#     - If the user input is "gender", respond with exactly: "What is your gender?"
#     - For any other input (e.g., "medicare number", "passport number", "phone number", "address"), respond with exactly: "What is your {user_input}?"
#
#     Important rules:
#     - Return **only the question**.
#     - Do not include explanations or extra text.
#
#     Input: "{user_input}"
#     Output:
#     """
#
#     prompt = PromptTemplate(input_variables=["user_input"], template=question_template)
#     chain = LLMChain(llm=llm, prompt=prompt, verbose=False)
#     asking_result = chain.run(user_input=user_input)
#
#     return jsonify({"question": asking_result.strip()})
#
# @app.route('/extract_answer', methods=['POST'])
# def extract_answer():
#     data = request.get_json()
#     asking_question = data.get('asking_question', '')
#     user_ans = data.get('user_answer', '')
#
#     template = f"""
#     You are a precise text extraction assistant.
#
#     Task:
#     - Identify the exact answer to the given question from the user's text below.
#     - Return only the relevant word(s) — no extra words, punctuation, or explanation.
#
#     Special rule:
#     - If the question is about "date of birth" or any date, detect the date in any format (e.g., "April 19, 1999", "19/04/1999")
#       and return it in DD-MM-YYYY format.
#     - If the question asks for "first name", "last name", "gender", etc., extract only that piece of info from the user text.
#     - If the info isn’t found, respond with an empty string.
#
#     Example:
#     Q: What is your first name?
#     Text: My name is Avijit Biswas.
#     A: Avijit
#
#     Q: What is your date of birth?
#     Text: I was born on 19 Apr 1993.
#     A: 19-04-1993
#
#     ---
#     Question: "{asking_question}"
#     User Text: "{user_ans}"
#     Answer:
#     """
#
#     prompt = PromptTemplate(
#         input_variables=["asking_question", "user_ans"],
#         template=template
#     )
#
#     chain = LLMChain(llm=llm, prompt=prompt, verbose=False)
#     result = chain.run(asking_question=asking_question, user_ans=user_ans)
#
#     return jsonify({
#         "extracted_answer": result.strip()
#     })
#
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)

#
# import os
# from flask import Flask, jsonify, request
# from dotenv import load_dotenv
# from langchain_openai import AzureChatOpenAI
# from langchain_core.prompts import PromptTemplate
# from langchain.chains import LLMChain
#
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# app = Flask(__name__)
#
#
# class prompTemplate:
#     def question_ask(self, user_input: str) -> str:
#         question_template = f"""
# You are a helpful and precise assistant that converts a form field name into a clear, natural question.
#
# Instructions:
# - Use simple, human-like question phrasing.
# - Do not add any extra words or explanation.
# - Only return the question text.
# - Examples are very important — follow them closely.
#
# Examples:
# - "First Name" → "What is your first name?"
# - "Last Name" → "What is your last name?"
# - "Date of Birth" → "What is your date of birth?"
# - "Sex" → "What is your sex? (Male/Female/Other)"
# - "Phone Type" → "Please select your phone type (e.g., Mobile, Home, Work)."
# - "Submit Application" → "Please click the Submit Application button to proceed."
# - "I am losing coverage I had from an employer." → "Are you losing coverage you had from an employer? (Yes/No)"
#
# Input: "{user_input}"
#
# Output:
# """
#         return question_template
#
#     def question_answer(self, asking_question: str, user_ans: str) -> str:
#         template = f"""
# You are a helpful assistant. A question was asked: "{asking_question}".
#
# Based on the user's input below, provide **only the exact answer** relevant to the question.
#
# - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
# - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
#
# User input: "{user_ans}"
#
# Output:
# """
#         return template
#
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0
# )
#
# template_builder = prompTemplate()
#
#
# @app.route('/ask_question', methods=['POST'])
# def ask_question():
#     data = request.get_json()
#     user_input = data.get('field_name', '').strip()
#     question_template = template_builder.question_ask(user_input)
#
#     prompt = PromptTemplate(
#         input_variables=["user_input"],
#         template=question_template
#     )
#     chain = LLMChain(llm=llm, prompt=prompt, verbose=False)
#     result = chain.run(user_input=user_input).strip()
#     return jsonify({"question": result})
#
# @app.route('/extract_answer', methods=['POST'])
# def extract_answer():
#     data = request.get_json()
#     asking_question = data.get('asking_question', '')
#     user_ans = data.get('user_answer', '')
#
#     answer_template = template_builder.question_answer(asking_question, user_ans)
#     prompt = PromptTemplate(input_variables=["asking_question", "user_ans"], template=answer_template)
#     chain = LLMChain(llm=llm, prompt=prompt)
#     result = chain.run(asking_question=asking_question, user_ans=user_ans).strip()
#
#     return jsonify({"extracted_answer": result})
#
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)


import os
from flask import Flask, jsonify, request
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from langchain.chains import LLMChain
from langchain.memory import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")

app = Flask(__name__)

store = {}

def get_session_history(session_id: str):
    if session_id not in store:
        store[session_id] = ChatMessageHistory()
    return store[session_id]

llm = AzureChatOpenAI(
    openai_api_key=api_key,
    azure_endpoint=azure_endpoint,
    azure_deployment=azure_model,
    api_version=api_version,
    temperature=0.0
)

class prompTemplate:
    def question_ask(self, user_input: str) -> str:
        question_template = f"""
You are a helpful and precise assistant that converts a form field name into a clear, natural question.

Instructions:
- Use simple, human-like question phrasing.
- Do not add any extra words or explanation.
- Only return the question text.
- Examples are very important — follow them closely.

Examples:
- "First Name" → "What is your first name?"
- "Last Name" → "What is your last name?"
- "Date of Birth" → "What is your date of birth?"
- "Sex" → "What is your sex? (Male/Female/Other)"
- "Phone Type" → "Please select your phone type (e.g., Mobile, Home, Work)."

Input: "{user_input}"

Output:
"""
        return question_template

    def question_answer(self, asking_question: str, user_ans: str) -> str:
        template = f"""
You are a helpful assistant. A question was asked: "{asking_question}".

Based on the user's input below, provide **only the exact answer** relevant to the question.

- If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
- For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.

User input: "{user_ans}"

Output:
"""
        return template

template_builder = prompTemplate()

@app.route('/ask_question', methods=['POST'])
def ask_question():
    data = request.get_json()
    user_input = data.get('field_name', '').strip()
    question_template = template_builder.question_ask(user_input)

    prompt = PromptTemplate(input_variables=["user_input"], template=question_template)
    chain = LLMChain(llm=llm, prompt=prompt, verbose=False)
    result = chain.run(user_input=user_input).strip()
    return jsonify({"question": result})

@app.route('/extract_answer', methods=['POST'])
def extract_answer():
    data = request.get_json()
    asking_question = data.get('asking_question', '')
    user_ans = data.get('user_answer', '')
    session_id = data.get('session_id', 'user1')

    history = get_session_history(session_id)

    answer_template = template_builder.question_answer(asking_question, user_ans)
    prompt = ChatPromptTemplate.from_messages([
        ("system", answer_template),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}")
    ])

    chain = prompt | llm

    with_memory = RunnableWithMessageHistory(
        chain,
        get_session_history,
        input_messages_key="input",
        history_messages_key="history"
    )

    config = {"configurable": {"session_id": session_id}}

    if user_ans:
        with_memory.invoke({"input": user_ans}, config=config)

    response = with_memory.invoke({"input": asking_question}, config=config)

    return jsonify({
        "extracted_answer": response.content
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
