# from langchain_openai import AzureChatOpenAI
# from langchain.chains import LLMChain
# from langchain.prompts import PromptTemplate
# from langchain.memory import ChatMessageHistory
# import os
# import logging
# from dotenv import load_dotenv
#
# logging.basicConfig(
#     filename="chatbot.log",
#     level=logging.INFO,
#     format="%(asctime)s - %(levelname)s - %(message)s"
# )
# logger = logging.getLogger()
#
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
# from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
# store = {}
# llm = AzureChatOpenAI(
#             openai_api_key=api_key,
#             azure_endpoint=azure_endpoint,
#             azure_deployment=azure_model,
#             api_version=api_version,
#             temperature=0.7
#         )
#
# @staticmethod
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
#
#
# asking_question = "What is your date of birth?"
# user_ans = "My name is avijit biswas. My date of birth is 19 Apr 1999."
#
#
# template = f"""
# You are a helpful assistant. A question was asked: "{asking_question}".
#
# Based on the user's input below, provide **only the exact answer** relevant to the question.
#
# - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
# - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
#
# User input: "{user_ans}"
#
# Output:
# """
#
# prompt = ChatPromptTemplate.from_messages([
#     ("system", template),
#     MessagesPlaceholder(variable_name="history"),
#     ("human", "{input}")
# ])
#
# chain = prompt | llm
#
#
# with_memory = RunnableWithMessageHistory(
#     chain,
#     get_session_history,
#     input_messages_key="input",
#     history_messages_key="history",
# )
#
# config = {"configurable": {"session_id": "user1"}}
# with_memory.invoke({"input": user_ans}, config=config)
#
# response = with_memory.invoke({"input": asking_question}, config=config)
# ans_result=response.content
# print(ans_result)

#
# from langchain_openai import AzureChatOpenAI
# from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
# import os
# from dotenv import load_dotenv
#
# # Load environment variables
# load_dotenv("D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# # Session Memory Store
# store = {}
#
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
#
# # Initialize Azure LLM
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0  # Set to 0 for consistent extraction
# )
#
# # Example Input
# asking_question = "What is your date of birth?"
# user_ans = "My name is avijit biswas. My date of birth is 19 Apr 1999."
#
# # Prompt Template
# prompt = ChatPromptTemplate.from_messages([
#     ("system", """
#     You are a helpful assistant. A question was asked: "{asking_question}".
#
#     Based on the user's input below, provide **only the exact answer** relevant to the question.
#
#     - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
#     - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
#     """),
#     MessagesPlaceholder(variable_name="history"),
#     ("human", "{input}")
# ])
#
# # Bind chain
# chain = prompt | llm
#
# # Enable memory
# with_memory = RunnableWithMessageHistory(
#     chain,
#     get_session_history,
#     input_messages_key="input",
#     history_messages_key="history",
# )
#
# config = {"configurable": {"session_id": "user1"}}
#
# # First provide context
# with_memory.invoke({"input": user_ans, "asking_question": asking_question}, config=config)
#
# # Then extract clean result
# response = with_memory.invoke({"input": asking_question, "asking_question": asking_question}, config=config)
#
# ans_result = response.content
# print("Extracted Answer:", ans_result)


#
# from langchain_openai import AzureChatOpenAI
# from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
# import os
# from dotenv import load_dotenv
#
# # Load environment variables
# load_dotenv("D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# store = {}
#
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
#
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.7
# )
#
# asking_question = "What is your date of birth?"
# user_ans = "My name is avijit biswas. My date of birth is 19 Apr 1999."
#
# # 🚀 STRONG extraction prompt
# system_instruction = """
# You are a strict data extraction bot.
# You must only extract answers **from the previous user message**, do not generate or assume anything.
# If the answer is found, return it directly (converted to DD-MM-YYYY if it's a date).
# If the answer is NOT found in user messages, respond with exactly: "NOT_FOUND".
#
# User was asked: "{asking_question}"
# """
#
# prompt = ChatPromptTemplate.from_messages([
#     ("system", system_instruction),
#     MessagesPlaceholder(variable_name="history"),
#     ("human", "{input}")
# ])
#
# chain = prompt | llm
#
# with_memory = RunnableWithMessageHistory(
#     chain,
#     get_session_history,
#     input_messages_key="input",
#     history_messages_key="history",
# )
#
# config = {"configurable": {"session_id": "user1"}}
#
# # First store user statement
# with_memory.invoke({"input": user_ans, "asking_question": asking_question}, config=config)
#
# # Then extract answer ONLY from previous context
# response = with_memory.invoke({"input": asking_question, "asking_question": asking_question}, config=config)
#
# result = response.content
# print("Extracted Answer:", result)


#
# from langchain_openai import AzureChatOpenAI
# from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain.memory import ChatMessageHistory
# from langchain_core.runnables.history import RunnableWithMessageHistory
# import os
# from dotenv import load_dotenv
#
# # Load environment variables
# load_dotenv("D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# store = {}
#
# def get_session_history(session_id: str):
#     if session_id not in store:
#         store[session_id] = ChatMessageHistory()
#     return store[session_id]
#
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0  # Keep deterministic
# )
#
# asking_question = "What is your first name ?"
# user_ans = "My name is avijit biswas. My date of birth is 19 Apr 1999."
#
# #
#
# system_instruction = """
# You are a strict data extraction assistant. Only extract values from previous **user messages**.
# Do not generate new answers. If a field is present, return it in required format.
#
# Extraction Rules:
# - If extracting DATE OF BIRTH → Convert to **DD-MM-YYYY**
# - Look only in conversation history, do not infer.
# - If not found, return exactly → NOT_FOUND
#
# When input is in format: EXTRACT|<field_name>
# → Then extract only that field from memory.
# """
#
# prompt = ChatPromptTemplate.from_messages([
#     ("system", system_instruction),
#     MessagesPlaceholder(variable_name="history"),
#     ("human", "{input}")
# ])
#
# chain = prompt | llm
#
# with_memory = RunnableWithMessageHistory(
#     chain,
#     get_session_history,
#     input_messages_key="input",
#     history_messages_key="history",
# )
#
# config = {"configurable": {"session_id": "user1"}}
#
# with_memory.invoke({"input": user_ans}, config=config)
#
# extract_trigger = "EXTRACT|date of birth"
# response = with_memory.invoke({"input": extract_trigger}, config=config)
#
# print("Extracted Answer:", response.content)


from langchain_openai import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
import os
from dotenv import load_dotenv

# -----------------------
# Load environment variables
# -----------------------
load_dotenv("D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")

# -----------------------
# Memory store per session
# -----------------------
store = {}
def get_session_history(session_id: str):
    if session_id not in store:
        store[session_id] = ChatMessageHistory()
    return store[session_id]

# -----------------------
# Initialize LLM
# -----------------------
llm = AzureChatOpenAI(
    openai_api_key=api_key,
    azure_endpoint=azure_endpoint,
    azure_deployment=azure_model,
    api_version=api_version,
    temperature=0.0
)

system_instruction = """
You are a strict data extraction assistant. Only extract values from previous **user messages**.
Do not generate new answers. 

Extraction Rules:
- If the question is about DATE OF BIRTH → Convert to DD-MM-YYYY
- If the question is about FIRST NAME → Extract only first name
- If the question is about LAST NAME → Extract only last name
- Look only in conversation history, do not infer.
- If the answer is not found, return exactly → NOT_FOUND
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", system_instruction),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

chain = prompt | llm

with_memory = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history",
)

session_id = "user1"
user_input = "My name is Avijit Biswas. My date of birth is 19 Apr 1999."

with_memory.invoke({"input": user_input}, config={"configurable": {"session_id": session_id}})

questions = ["What is your first name?", "What is your last name?", "What is your date of birth?"]

for q in questions:
    response = with_memory.invoke({"input": q}, config={"configurable": {"session_id": session_id}})
    print(f"Question: {q}")
    print(f"Answer: {response.content}")
    print("------")

