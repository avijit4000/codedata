from langchain_openai import AzureChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
import os
from dotenv import load_dotenv

load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")

qlist=["first_name","last_name", "address", "gender", "terms_and_conditions"]

class FormChatBot:
    def __init__(self):
        self.store = {}
        self.responses = {}
        self.asked_keys = qlist
        self.index = 0
        self.return_index = None

        self.chat_model = AzureChatOpenAI(
            openai_api_key=api_key,
            azure_endpoint=azure_endpoint,
            azure_deployment=azure_model,
            api_version=api_version,
            temperature=0.7
        )

        validation_prompt = PromptTemplate(
            input_variables=["asking_question", "user_input", "questions_list"],
            template="""
            You are a validation AI. A form chatbot asked the user a question: "{asking_question}".
            User replied: "{user_input}"
            List of possible fields: {questions_list}

            Your task:
            - If this is a valid answer to the question, return: ANSWER
            - If this is a correction like "I need to change first name" or "wrong last name", return: CORRECT <field_name>
            Only reply exactly "ANSWER" or "CORRECT <field_name>".
            """
        )

        self.validator = LLMChain(llm=self.chat_model, prompt=validation_prompt, verbose=False)

        extraction_prompt = PromptTemplate(
            input_variables=["asking_question", "user_input"],
            template="""
            You are a helpful assistant. A question was asked: "{asking_question}".
            Based on the user's input below, provide only the exact answer relevant to the question.
            - If the question is about "date of birth", return date in DD-MM-YYYY format.
            - For other fields, return only the answer.
            User input: "{user_input}"
            Output:
            """
        )

        prompt = ChatPromptTemplate.from_messages([
            ("system", extraction_prompt.template),
            MessagesPlaceholder(variable_name="history"),
            ("human", "{input}")
        ])

        self.chain = prompt | self.chat_model

    def generate_question(self, field_name):
        question_prompt = PromptTemplate(
            input_variables=["field_name"],
            template="""
            You are a helpful assistant that converts a form field name into a natural question.
            Example:
            "first_name" → "What is your first name?"
            "address" → "Please provide your address."
            Input: "{field_name}"
            Output:
            """
        )
        chain = LLMChain(llm=self.chat_model, prompt=question_prompt, verbose=False)
        question_result = chain.run(field_name=field_name).strip().capitalize()
        return question_result

    def get_session_history(self, session_id: str):
        if session_id not in self.store:
            self.store[session_id] = ChatMessageHistory()
        return self.store[session_id]


    def get_next_question(self ):
        if self.index < len(self.asked_keys):
            field_name = self.asked_keys[self.index]
            question = self.generate_question(field_name)
            return question
        return None


    def store_cache_memory(self, user_id: str, user_input: str):
        key = self.asked_keys[self.index]
        if not hasattr(self, "cache_memory"):
            self.cache_memory = {}

        if user_id not in self.cache_memory:
            self.cache_memory[user_id] = {}

        self.cache_memory[user_id][key] = user_input.strip()

        if len(self.cache_memory[user_id]) > 100:
            items = list(self.cache_memory[user_id].items())[-100:]
            self.cache_memory[user_id] = dict(items)

    def process_input(self, user_input, user_id):

        self.store_cache_memory(user_id, user_input)

        for field in self.responses:
            if field.replace("_", " ") in user_input.lower() or field in user_input.lower():
                return f"Your {field.replace('_', ' ')} is: {self.responses[field]}"


        key = self.asked_keys[self.index]
        question = self.generate_question(key)

        validation_result = self.validator.run({
            "asking_question": question,
            "user_input": user_input,
            "questions_list": ", ".join(self.asked_keys)
        }).strip()

        if validation_result.startswith("CORRECT"):
            correction_field = validation_result.replace("CORRECT", "").strip()
            if correction_field in self.asked_keys:
                if self.return_index is None:
                    self.return_index = self.index
                self.index = self.asked_keys.index(correction_field)
                return f"Okay, let's update {correction_field}. What is your {correction_field.replace('_', ' ')}?"

        with_memory = RunnableWithMessageHistory(
            self.chain,
            self.get_session_history,
            input_messages_key="input",
            history_messages_key="history",
        )

        config = {"configurable": {"session_id": f"{user_id}"}}

        response = with_memory.invoke({
            "input": question,
            "asking_question": question,
            "user_input": user_input
        }, config=config)

        extractor_result = response.content.strip().capitalize()
        self.responses[key] = extractor_result

        if self.return_index is not None:
            if self.index == self.return_index:
                self.return_index = None
                self.index += 1
            else:
                self.index = self.return_index
        else:
            self.index += 1

        return extractor_result


if __name__ == "__main__":
    chatbot = FormChatBot()
    user_id = "user123"

    print("👋 Welcome! Let's start filling your form.\n")

    while True:
        next_question = chatbot.get_next_question()
        if not next_question:
            for key, val in chatbot.responses.items():
                print(f"- {key}: {val}")
            break

        user_input = input(f"{next_question}\n> ").strip()
        chatbot.store_cache_memory(user_id, user_input )
        chatbot.index += 1

        if user_input.lower() in ["exit", "quit"]:
            print("Chatbot: Exiting. Goodbye! 👋")
            break

        response = chatbot.process_input(user_input, user_id)
        print(f"🧠 {response}\n")
        print(chatbot.cache_memory)

