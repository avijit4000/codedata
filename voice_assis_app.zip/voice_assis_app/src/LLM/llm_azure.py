import os
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
from LLM.prompts.llm_template import prompTemplate

promptemplate=prompTemplate()

class FormAssistant:
    def __init__(self):
        load_dotenv()
        self.azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.api_key        = os.getenv("AZURE_OPENAI_API_KEY")
        self.api_version    = os.getenv("AZURE_OPENAI_API_VERSION")
        self.azure_model    = os.getenv("AZURE_OAI_MODEL")
        self.llm = AzureChatOpenAI(
            openai_api_key=self.api_key,
            azure_endpoint=self.azure_endpoint,
            azure_deployment=self.azure_model,
            api_version=self.api_version,
            temperature=0.0
        )

    def generate_question(self, user_input):

        question_template = promptemplate.question_ask(user_input)

        prompt = PromptTemplate(
            input_variables=["user_input"],
            template=question_template
        )
        asking_chain = LLMChain(
            llm=self.llm,
            prompt=prompt,
            verbose=False
        )
        asking_result = asking_chain.run(user_input=user_input)
        return asking_result.strip()

    def extract_answer(self, asking_question, user_ans):
        
        ans_template = promptemplate.question_answer(asking_question, user_ans)

        prompt = PromptTemplate(
            input_variables=["user_input"],
            template= ans_template
        )
        ans_chain = LLMChain(
            llm=self.llm,
            prompt=prompt,
            verbose=False
        )
        ans_result = ans_chain.run(user_input=user_ans)
        return ans_result.strip()