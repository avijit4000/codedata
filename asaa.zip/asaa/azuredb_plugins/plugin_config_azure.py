from src.LLM.plugins.azure_monitoring.azure_functions import get_azure_db_metrics
from src.LLM.plugins.MCPPlugin import MCPPlugin

azure_plugin = MCPPlugin(
    name="azure_db_monitoring",
    description="Plugin to monitor Azure MySQL and Cosmos DB metrics",
    functions={
        "get_azure_db_metrics": get_azure_db_metrics
    }
)

if __name__ == "__main__":
    azure_plugin.mcp.run(transport="streamable-http")
