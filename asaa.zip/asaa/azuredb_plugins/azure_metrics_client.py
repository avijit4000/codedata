import os
import requests
import datetime
from azure.identity import ClientSecretCredential
from dotenv import load_dotenv

load_dotenv()

SUBSCRIPTION_ID = "c3ca2369-06db-4f15-a401-532d029a563e"
RESOURCE_GROUP = "gpdacq-prod-1-rg"
MYSQL_SERVER = "gpdacq-prod-1-mysql"
COSMOS_ACCOUNT = "gpdacq-prod"

API_VERSION = "2023-10-01"

credential = ClientSecretCredential(
    tenant_id=os.getenv("AZURE_TENANT_ID"),
    client_id=os.getenv("AZURE_CLIENT_ID"),
    client_secret=os.getenv("AZURE_CLIENT_SECRET")
)

def _get_token():
    return credential.get_token("https://management.azure.com/.default").token

def get_azure_metrics():
    bearer = _get_token()
    headers = {"Authorization": f"Bearer {bearer}"}

    start_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT00:00:00Z')
    end_time = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    timespan = f"{start_time}/{end_time}"

    results = {}

    # MySQL metrics
    mysql_metrics = "cpu_percent,memory_percent"
    mysql_url = (
        f"https://management.azure.com/subscriptions/{SUBSCRIPTION_ID}"
        f"/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.DBforMySQL/flexibleServers/{MYSQL_SERVER}"
        f"/providers/microsoft.insights/metrics"
    )

    params = {
        "metricnames": mysql_metrics,
        "timespan": timespan,
        "aggregation": "maximum",
        "api-version": API_VERSION
    }

    res = requests.get(mysql_url, headers=headers, params=params).json()
    for val in res.get("value", []):
        results[val["name"]["value"]] = max(
            (d.get("maximum", 0) for ts in val["timeseries"] for d in ts["data"]),
            default=0
        )

    # Cosmos metrics
    cosmos_metric = "NormalizedRUConsumption"
    cosmos_url = (
        f"https://management.azure.com/subscriptions/{SUBSCRIPTION_ID}"
        f"/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.DocumentDB/databaseAccounts/{COSMOS_ACCOUNT}"
        f"/providers/microsoft.insights/metrics"
    )

    params["metricnames"] = cosmos_metric
    res = requests.get(cosmos_url, headers=headers, params=params).json()
    for val in res.get("value", []):
        results[val["name"]["value"]] = max(
            (d.get("maximum", 0) for ts in val["timeseries"] for d in ts["data"]),
            default=0
        )

    return {"success": True, "metrics": results}
