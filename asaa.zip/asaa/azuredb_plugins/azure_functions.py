from typing import Dict, Any
from src.LLM.plugins.azure_monitoring.azure_metrics_client import get_azure_metrics

def get_azure_db_metrics() -> Dict[str, Any]:
    """
    Fetch CPU, memory and RU metrics from Azure DB.
    """
    try:
        return get_azure_metrics()
    except Exception as e:
        return {"success": False, "error": str(e)}
