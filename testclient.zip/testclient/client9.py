# import os
# import sys
# import asyncio
# import logging
# from dotenv import load_dotenv
#
# from langchain_mcp_adapters.client import MultiServerMCPClient
# from langgraph.prebuilt import create_react_agent
# from langchain_openai import AzureChatOpenAI
#
#
# # -------------------------------------------------------
# # Setup Logging
# # -------------------------------------------------------
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
#     handlers=[
#         logging.FileHandler("latency_chatbot.log"),
#         logging.StreamHandler(sys.stdout)
#     ]
# )
# logger = logging.getLogger("LATENCY-CHATBOT")
#
#
# # -------------------------------------------------------
# # MCP + A2A CHATBOT
# # -------------------------------------------------------
# class LatencyChatbot:
#     def __init__(self):
#         load_dotenv()
#
#         logger.info("Starting MCP Latency Server...")
#         self.client = MultiServerMCPClient(
#             {
#                 "latency": {
#                     "command": sys.executable,
#                     "args": ["latency_server.py"],
#                     "transport": "stdio",
#                 }
#             }
#         )
#
#         logger.info("Loading Azure OpenAI...")
#         self.model = AzureChatOpenAI(
#             azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
#             api_key=os.getenv("AZURE_OPENAI_API_KEY"),
#             api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
#             azure_deployment=os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini"),
#             temperature=0.2,
#         )
#
#         self.agent = None
#
#     async def setup(self):
#         logger.info("Loading MCP tools...")
#         tools = await self.client.get_tools()
#
#         logger.info("Creating ReAct Agent...")
#         self.agent = create_react_agent(self.model, tools)
#
#     async def ask(self, prompt: str):
#         logger.info(f"Prompt: {prompt}")
#         response = await self.agent.ainvoke(
#             {"messages": [{"role": "user", "content": prompt}]}
#         )
#
#         return response["messages"][-1].content
#
#     async def chat(self):
#         print("\n🤖 Latency MCP Chatbot Started")
#         print("Ask like:")
#         print("• Show latency for AMP today")
#         print("• Show last 7 days latency")
#         print("• Show latency from 2025-03-01 to 2025-03-07 for UMS")
#         print("Type 'exit' to stop.\n")
#
#         while True:
#             user_input = input("You: ")
#
#             if user_input.lower() in ["exit", "quit"]:
#                 print("👋 Chatbot stopped.")
#                 break
#
#             try:
#                 reply = await self.ask(user_input)
#                 print(f"Bot: {reply}\n")
#
#             except Exception as e:
#                 logger.error(e)
#                 print("❌ Error fetching latency\n")
#
#
# # -------------------------------------------------------
# # MAIN
# # -------------------------------------------------------
# async def main():
#     bot = LatencyChatbot()
#     await bot.setup()
#     await bot.chat()
#
#
# if __name__ == "__main__":
#     asyncio.run(main())



import os
import sys
import asyncio
import logging
from dotenv import load_dotenv

from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent
from langchain_openai import AzureChatOpenAI


# -------------------------------------------------------
# Logging
# -------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("latency_chatbot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("LATENCY-CHATBOT")


# -------------------------------------------------------
# CHATBOT CLASS
# -------------------------------------------------------
class LatencyChatbot:
    def __init__(self):
        load_dotenv()

        logger.info("Initializing FastMCP Latency Server...")
        self.client = MultiServerMCPClient(
            {
                "latency": {
                    "command": sys.executable,
                    "args": ["latency_server.py"],
                    "transport": "stdio",
                }
            }
        )

        logger.info("Initializing Azure OpenAI...")
        self.model = AzureChatOpenAI(
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            azure_deployment=os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini"),
            temperature=0.2,
        )

        self.agent = None

    async def setup(self):
        logger.info("Loading MCP tools...")
        tools = await self.client.get_tools()

        logger.info("Creating ReAct agent...")
        self.agent = create_react_agent(self.model, tools)

    async def ask(self, prompt: str):
        response = await self.agent.ainvoke(
            {"messages": [{"role": "user", "content": prompt}]}
        )
        return response["messages"][-1].content

    async def chat(self):
        print("\n🤖 Latency MCP Chatbot Started")
        print("Examples:")
        print("• Show AMP latency today")
        print("• Show UMS latency last 7 days")
        print("• Latency from 2025-03-01 to 2025-03-07 for AMP")
        print("• Which app has highest latency today?")
        print("Type 'exit' to stop.\n")

        while True:
            user_input = input("You: ")

            if user_input.lower() in ["exit", "quit"]:
                print("👋 Chatbot stopped.")
                break

            try:
                reply = await self.ask(user_input)
                print(f"Bot: {reply}\n")

            except Exception as e:
                logger.error(e)
                print("❌ Error fetching latency\n")


# -------------------------------------------------------
# MAIN
# -------------------------------------------------------
async def main():
    bot = LatencyChatbot()
    await bot.setup()
    await bot.chat()


if __name__ == "__main__":
    asyncio.run(main())
