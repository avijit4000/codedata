from mcp.server.fastmcp import FastMCP
from pull_metric_api import fetch_latency_report
from typing import Optional, List, Dict, Any
import json

# Initialize MCP server
mcp = FastMCP("matrix_server")

@mcp.tool()
def get_latency_data(
    day: Optional[str] = None,
    days: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    app: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch dynamic latency report data.
    """
    try:
        return fetch_latency_report(day, days, start_date, end_date, app)
    except Exception as e:
        return {"error": str(e)}

@mcp.tool()
def get_latency_data_pretty(
    app: Optional[str] = None,
    day: Optional[str] = None
) -> str:
    """
    Fetch latency report and return formatted JSON.
    """
    try:
        data = fetch_latency_report(day=day, app=app)
        return json.dumps(data, indent=2)
    except Exception as e:
        return f"Error fetching latency data: {e}"

# 👇 expose as HTTP app (IMPORTANT)
matrix_app = mcp.http_app()
