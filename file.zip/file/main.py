from fastapi import FastAPI
import uvicorn

from mathserver import math_app
from pullmetrix import matrix_app

app = FastAPI()

# Mount MCP servers
app.mount("/math", math_app)
app.mount("/matrix", matrix_app)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
