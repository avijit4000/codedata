"""  
This module defines the `medicaid_eligibility_check` function
This module provides functionalities to query an eligibility check api using dob, gender , medicaid number , plan etc . It includes a Pydantic model as the `args_schema` 
and corresponding function to execute
"""

from typing import Optional, Literal
from pydantic import BaseModel, Field
import logging
from ...utils.data_models import Plan, Chunk 
from ...utils.utils import get_fips_state_code,extract_names,fetch,get_eligibility_bearer_token
from ...globals import ELIGIBILITY_CHECK_API_ENDPOINT
from llama_index.core.workflow import Context
import httpx




logger = logging.getLogger("agents.tools.medicaid_eligibility_check")



    
async def medicaid_eligibility_check_api(gender,date_of_birth,medicaid_number, full_name ,plan,plan_id):
    """
    Asynchronously queries eligibility lookup api using following params
    Args:
        gender (str): The user's
        date_of_birth (str): The date of birth to check.
        medicaid_number (str): The medicaid number to check.
        full_name (str): The full name to check.
        plan (Plan): The plan to filter by.
        plan_id (str): The plan ID to filter by.
    
    Returns:

        list[()]: A list of tuples , where each tuple eligibility details.
    """
        
    try:
        
    
        
        eligibility_lookup_url = ELIGIBILITY_CHECK_API_ENDPOINT
        
        logger.info(eligibility_lookup_url)       
        
        fips_code,state_code = get_fips_state_code(plan.zip)
        
        first_name,middle_name,last_name = extract_names(full_name)
        
        
        details_payload = {
                "eligibilityType": "MEDICAID",
                "medicaid": {
                "gender": gender,
                "dob": date_of_birth,
                "stateCode": state_code,
                "fipsCode": fips_code,
                "zip": plan.zip,
                "firstName": first_name,
                "lastName": last_name,
                "medicaidNumber": medicaid_number,
                "planList": [plan.plan_id],
                "ssn": "" ,
                "proposedEffectiveDate": "",
                "currentYear": plan.plan_year,
                }
                }
            
        
            
        headers = {
        'Authorization': f'Bearer {get_eligibility_bearer_token()}',
        'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient(timeout=60) as client:
            

            try:
                
                # logger.debug(details_payload)
                
                
            
                details_response = await fetch(client, eligibility_lookup_url, method='POST', headers=headers, data=details_payload)  

                if details_response is None:
                    
                    logger.debug("No eligibility details found for the given inputs.")
                    
                    return [("NO_SEARCH_RESULTS","No eligibility details found for the given inputs.")]
                
                    #eligibility_details = []
                else:
                    
                    eligibility_details  = [(medicaid_number,details_response)]

                    logger.debug(eligibility_details)

                    return eligibility_details
                
        
            except httpx.RequestError as e:
                
                logger.error(f"An error occurred: {e}")
                return [("ERROR", f"An error occurred: {e}")]
    except Exception as e:
        
        logger.error(f"An error occurred: {e}")
        return [("ERROR", f"An error occurred: {e}")]
            
            


async def medicaid_eligibility_check_api_response(gender:str,
date_of_birth:str,
medicaid_number:str,
full_name:str,
plan: Plan,
plan_ids: list[str]
) -> list[Chunk]:
    """
    Asynchronously queries eligibility lookup api using  returning relevant eligibility details .

    Args:
    
        gender (str): The user's gender to filter by.
        medicaid_number (str): medicaid number to filter by.
        plan (Plan): The plan to filter by.
        full_name (str): The full name to filter by.
        date_of_birth (str): The date of birth to filter by.

    Returns:
        list[()]: A list of tuples , where each tuple eligibility details.
    """
    

    # logger.debug(
    #     f" gender :{gender},  date_of_birth :{date_of_birth} , medicaid_number :{medicaid_number} , full_name : {full_name}, plan :{plan}"
    # )
    
    result = await medicaid_eligibility_check_api(gender,date_of_birth,medicaid_number,full_name,plan,plan.plan_id) 
    
    results_msg_text = "\n******FOR GIVEN INPUTS, HERE ARE THE ELIGIBILITY DETAILS *******\n"
    
    

    if len(result) == 1 and result[0][0] =='ERROR':  
        results_msg_text = "\n****** ELIGIBILITY API IS DOWN , NOT ABLE TO FETCH  DETAILS AT THE MOMENT *******\n"

    logger.debug(result)
    
    
    return [
            Chunk(
                
                doc_text=f"medicaid_number :{str(item[0])}" + ",\n eligibility_details :" + str(item[1]),
                url=None,
                section=None,
                url_title=None,

            )
            for item in result] , results_msg_text
    



def format_medicaid_eligibility_check_results(eligibility_detail_chunks: list[Chunk],results_msg_text : str) -> str:
    """
    Formats a list of document chunks into a string containing marked sources.

    Args:
        chunks (list[Chunk]): A list of Chunks, each containing a document chunk.

    Returns:
        str: A string that includes source labels and content for each document chunk.
    """
    formatted_response = f"{results_msg_text}# Sources - Eligibility Details"
    for chunk in eligibility_detail_chunks:
        chunk_text = f"""\n\n{chunk}\n\n"""
        formatted_response += chunk_text
        
    logger.debug(f"medicaid_eligibility_check_formatted_text :{str(formatted_response)}")
    
    return formatted_response




class medicaid_eligibility_check(BaseModel):
    """Use this tool to check eligibility for a users ONLY MEDICAID  under a given inputs below .
       --inputs include  gender, date_of_birth , medicaid_number , full_name
       --make sure u have provided all the inputs before running the tool , if not ask user to provide the missing inputs with proper format
       --if user is not eligible for medicaid , than suggest/recommend user to check for medicare eligibility
    """

    
    gender : Literal["M", "F"] = Field( None, description=("The user's gender") )

    date_of_birth: str = Field( None, description=("The user's date of birth in YYYY-MM-DD  format "))
    
    medicaid_number: str = Field(  
        None,  
        description=(  
            "The user's medicaid claim number. This is a unique identifier for the user's medicaid account."
            " example format: 00000 "
        ) 
    )
    
    full_name: str = Field(
        None,  
        description=(  
            "The user's full name. This is used to identify the user in the system."
            "example format: first_name, middle_name last_name" 
            "example1 : John, Doe Smith"
            "example2 : John, Smith"
            "example3 : John"
        ) 
    )
    
    
    plan_ids: list[str]
    

# Actual function to execute
async def medicaid_eligibility_check_func(gender,date_of_birth,medicaid_number,full_name,plan: Optional[Plan],**kwargs) -> tuple[str, list[Chunk]]:
    """
    Actual function to execute based on params provided by llm.
    Orchestrates the process of sending a user given below params for a single plan to the Eligibility Lookup API
    and formatting the resulting chunks.

    Args:
        gender (str): The user's    
        date_of_birth (str): The date of birth to check.
        medicaid_number (str): The medicaid number to check.
        full_name (str): The full name to check.
        plan (Plan): The plan to filter by.
        **kwargs: Keyword arguments containing the plan and other parameters.

    Returns:
        tuple[str, list[Chunk]:
            A tuple consisting of the formatted response string and the list of document chunks.
    """
    if not isinstance(plan, Plan):
        raise AssertionError()

    ctx: Context = kwargs["ctx"]
    
    eligibility_detail_chunks,results_msg_text = await medicaid_eligibility_check_api_response(gender,date_of_birth,medicaid_number,full_name,plan,plan.plan_id)
    
    return format_medicaid_eligibility_check_results(eligibility_detail_chunks,results_msg_text) , eligibility_detail_chunks
