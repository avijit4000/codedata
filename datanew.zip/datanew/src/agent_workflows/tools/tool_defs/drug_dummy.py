from pydantic import BaseModel, Field
from typing import Optional
from ...utils.data_models import Plan
from ..tool_defs import PartialWorkflowOutput


class drug_search(BaseModel):
    """Search for cost, coverage, etc. on any type of drug/medication. Can search brand name, generic, or drug type/category.
    Examples:
    - ibuprofen
    - depression
    - GLP-1 agonist
    - lipitor
    """

    drug_query: str
    plan_ids: list[str]


async def drug_search_fun(
    drug_query: str, plan: Optional[Plan], **kwargs
) -> PartialWorkflowOutput:
    return PartialWorkflowOutput(
        status=2002, response="", chunks=[], questions=[], url_info=[]
    )
