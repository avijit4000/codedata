from pydantic import BaseModel, Field
from typing import Literal, Optional
from ...utils.data_models import Plan
from ..tool_defs import PartialWorkflowOutput
from langchain_core.tools import ToolException

import os
import json
import asyncio
import httpx
import us
import pandas as pd
import logging

logger = logging.getLogger("agents.tools.drug_search")


async def fetch(
    session: httpx.AsyncClient,
    url: str,
    method: str = "GET",
    headers: Optional[dict] = None,
    data: Optional[dict] = None,
) -> dict:
    """
    Send an HTTP request using httpx and return the parsed JSON response.

    Args:
        session (httpx.AsyncClient): The HTTPX async client.
        url (str): The URL to send the request to.
        method (str): HTTP method to use (e.g. "GET", "POST").
        headers (dict, optional): HTTP headers to include.
        data (dict, optional): JSON-serializable payload for POST/PUT.

    Returns:
        dict: The JSON-decoded response body.

    Raises:
        httpx.HTTPError: If the request fails or the status is not 2xx.
    """
    response = await session.request(method, url, headers=headers, json=data)
    response.raise_for_status()
    return response.json()


async def check_drug_search_data(drug_name, n_results=10):
    # Base URLs for API endpoints
    drug_search_url = "https://www.aarpmedicareplans.com/druginfo/drugsearch/"
    async with httpx.AsyncClient() as session:
        try:
            drug_search_url_1 = drug_search_url + drug_name
            json_data = await fetch(session, drug_search_url_1)
            # Filter out only the desired fields from each drug in drugList
            filtered_data = [
                {
                    "drugId": d.get("drugId"),
                    "drugName": d.get("drugName"),
                    "drugType": d.get("drugType"),
                }
                for d in json_data["data"].get("drugList", [])
            ]
            return filtered_data[:n_results]
        except httpx.HTTPError as e:
            raise ToolException(e)


async def check_drug_dosage_n_cost_data(
    drug_id,
    plan_id,
    drug_frequency,
    drug_quantity,
    drug_supply_length,
    plan_year,
    zip_code,
):
    drug_dosage_url = "https://www.aarpmedicareplans.com/druginfo/drugdosages/"
    drug_cost_estimate_url = (
        "https://www.aarpmedicareplans.com/drugpricing/estimateplancostWithLco"
    )
    async with httpx.AsyncClient() as session:
        try:
            # Read the CSV file containing zip-to-FIPS mappings
            current_directory = os.path.dirname(os.path.abspath(__file__))
            df = pd.read_csv(os.path.join(current_directory, "zip2fips.csv"), dtype=str)
            # Filter rows where zipcode matches the input
            row = df[df["zipcode"] == zip_code]
            if row.empty:
                raise ToolException(
                    f"No corresponding FIPS found for zip code '{zip_code}'"
                )
            # Return the FIPS code from the first matching record
            fips_code = str(row.iloc[0]["FIPS"]).strip()

            drug_dosage_url_1 = drug_dosage_url + drug_id
            json_data1 = await fetch(session, drug_dosage_url_1)
            formatted_json = json.dumps(json_data1, indent=4)
            logger.debug("--------------drug-dosage-json-----------------")
            logger.debug(formatted_json)

            def get_fips_details(fips_code):
                """
                Given a FIPS code, return the county code, state code, CMS county codes,
                and state abbreviation.

                Args:
                    fips_code (str): A 5-digit FIPS code.

                Returns:
                    dict: A dictionary with county code, state code, CMS county codes,
                        and state abbreviation.
                """
                # Ensure the input is a string with 5 digits
                fips_code = str(fips_code).zfill(5)

                # Extract state code (first 2 digits) and county code (last 3 digits)
                state_code = fips_code[:2]
                county_code = fips_code[2:]

                # Use us package to get state abbreviation and CMS county codes
                state = us.states.lookup(
                    state_code
                )  # Get state object from the us package
                state_abbr = state.abbr if state else None  # State abbreviation

                return {
                    "county_code": county_code,
                    "state_code": state_code,
                    "state_abbr": state_abbr,
                }

            details = get_fips_details(fips_code)

            def get_value_in_same_row_pandas(
                file_path, search_column, target_column1, target_column2, search_value
            ):
                """
                Get a value from the same row but a different column in a CSV file using pandas.

                Args:
                    file_path (str): Path to the CSV file.
                    search_column (str): Column to search for the value.
                    target_column (str): Column to get the value from.
                    search_value (str): Value to search for in the search_column.

                Returns:
                    str: Value from the target column in the same row as the search value.
                """
                # Load the CSV file into a DataFrame
                df = pd.read_csv(file_path, dtype=str, na_filter=False)
                # Filter the row where search_column matches search_value
                row = df[df[search_column] == search_value]
                # If the row is found, return the value from the target column
                if not row.empty:
                    x, y = row.iloc[0][target_column1], row.iloc[0][target_column2]
                    return x, y
                x, y = "Value not found.", "Value not found."
                return x, y

            file_path = os.path.join(
                current_directory, "ssa_fips_state_county_2025.csv"
            )
            search_column = "fipscounty"
            target_column1 = "countyname_fips"
            target_column2 = "ssa_code"
            search_value = fips_code

            fips_county_name, ssa_code = get_value_in_same_row_pandas(
                file_path, search_column, target_column1, target_column2, search_value
            )

            drug_list = json_data1["data"]["drugList"][0]["drugDosageInfoList"]
            I = len(drug_list)
            payload_list = []
            drug_info_list = []

            for i in range(I):
                dosage = drug_list[i]
                # If package info exists, iterate over each package
                if dosage.get("drugPackageInfo") is not None:
                    for pkg in dosage["drugPackageInfo"]:
                        payload = {
                            "planStartMonth": 1,
                            "zipCode": zip_code,
                            "includeLCODrug": False,
                            "includeLCOPharmacy": True,
                            "county": {
                                "cmsCountyCodes": [ssa_code[2:]],
                                "fipsCountyCode": details["county_code"],
                                "fipsCountyName": fips_county_name,
                                "fipsStateCode": details["state_code"],
                                "stateCode": details["state_abbr"],
                            },
                            "plans": [
                                {
                                    "contractId": plan_id[:5],
                                    "pbpNumber": plan_id[5:8],
                                    "planYear": plan_year,
                                    "segmentId": plan_id[8:11],
                                }
                            ],
                            "pharmacies": [
                                {
                                    "mailOrder": False,
                                    "pharmacyNumber": "2426814",
                                    "pharmacySaver": False,
                                    "preferred": False,
                                }
                            ],
                            "drugs": [
                                {
                                    "drugFrequency": drug_frequency,
                                    "drugQuantity": drug_quantity,
                                    "drugSupplyLength": drug_supply_length,
                                    "drugType": json_data1["data"]["drugList"][0][
                                        "drugType"
                                    ],
                                    "nationalDrugCode": dosage["nationalDrugCode"],
                                    "packageQuantity": pkg["packageQuantity"],
                                    "packageSize": pkg["packageSize"],
                                }
                            ],
                            "accumulatedTotalDrugCost": None,
                            "accumulatedTroopBalance": None,
                        }
                        payload_list.append(payload)
                        drug_info = {
                            "dosageName": dosage.get("labelName"),
                            "drugPackageType": pkg.get("packageDisplayName"),
                        }
                        drug_info_list.append(drug_info)
                else:
                    payload = {
                        "planStartMonth": 1,
                        "zipCode": zip_code,
                        "includeLCODrug": False,
                        "includeLCOPharmacy": True,
                        "county": {
                            "cmsCountyCodes": [ssa_code[2:]],
                            "fipsCountyCode": details["county_code"],
                            "fipsCountyName": fips_county_name,
                            "fipsStateCode": details["state_code"],
                            "stateCode": details["state_abbr"],
                        },
                        "plans": [
                            {
                                "contractId": plan_id[:5],
                                "pbpNumber": plan_id[5:8],
                                "planYear": plan_year,
                                "segmentId": plan_id[8:11],
                            }
                        ],
                        "pharmacies": [
                            {
                                "mailOrder": False,
                                "pharmacyNumber": "2426814",
                                "pharmacySaver": False,
                                "preferred": False,
                            }
                        ],
                        "drugs": [
                            {
                                "drugFrequency": drug_frequency,
                                "drugQuantity": drug_quantity,
                                "drugSupplyLength": drug_supply_length,
                                "drugType": json_data1["data"]["drugList"][0][
                                    "drugType"
                                ],
                                "nationalDrugCode": dosage["nationalDrugCode"],
                                "packageQuantity": None,
                                "packageSize": None,
                            }
                        ],
                        "accumulatedTotalDrugCost": None,
                        "accumulatedTroopBalance": None,
                    }
                    payload_list.append(payload)
                    drug_info = {
                        "dosageName": dosage.get("labelName"),
                        "drugPackageInfo": None,
                    }

                    drug_info_list.append(drug_info)

            headers = {"Content-Type": "application/json"}
            fetch_coroutines = [
                fetch(
                    session,
                    drug_cost_estimate_url,
                    method="POST",
                    headers=headers,
                    data=payload,
                )
                for payload in payload_list
            ]

            try:
                all_responses = await asyncio.gather(*fetch_coroutines)
            except Exception as e:
                raise ToolException(e)

            # logger.debug each response in formatted JSON
            logger.debug("--------------cost-estimates-responses-----------------")
            for i, response in enumerate(all_responses[:3]):
                logger.debug(f"Response {i+1}:")
                logger.debug(json.dumps(response, indent=4))
                logger.debug("---------------------------------------------------")
            # Combine each cost response with corresponding drugInfo.
            combined_results = []
            for idx, resp in enumerate(all_responses):
                formularyInfo = (
                    resp["data"]["plans"][0]["pharmacyCosts"][0]["drugsCost"][0][
                        "formularyStatus"
                    ]
                    if resp["data"]["plans"][0]["pharmacyCosts"]
                    else None
                )
                formularyInfo = {
                    k: v
                    for k, v in formularyInfo.items()  # type:ignore
                    if not (
                        k
                        in [
                            "hasLimitedAccess",
                            "quantityLimitDays",
                            "quantityLimitDescription",
                            "opioidOneMonthSupply",
                            "opioidSevenDaySupply",
                        ]
                    )
                }

                full_plan_summary = resp["data"]["plans"][0]["pharmacyCosts"][0][
                    "planSummaryCost"
                ]
                filtered_plan_summary = {
                    "covered": (
                        resp["data"]["plans"][0]["pharmacyCosts"][0]["drugsCost"][0][
                            "covered"
                        ]
                        if resp["data"]["plans"][0]["pharmacyCosts"]
                        else None
                    ),
                    "totalDrugCostYear": full_plan_summary.get("totalDrugCost"),
                    "coverageGapStartMonth": full_plan_summary.get(
                        "coverageGapStartMonth"
                    ),
                    "monthsInCoverageGap": full_plan_summary.get("monthsInCoverageGap"),
                    "costInCatastrophic": full_plan_summary.get("costInCatastrophic"),
                    "costInCoverageGap": full_plan_summary.get("costInCoverageGap"),
                    "costInInitialCoverageYear": full_plan_summary.get(
                        "costInInitialCoverage"
                    ),
                }
                combined = {
                    "drugInfo": {
                        **drug_info_list[idx],
                        "formularyInfo": formularyInfo,
                    },
                    "yearlyPlanSummaryCost": filtered_plan_summary,
                }
                combined_results.append(combined)
                logger.debug(json.dumps(combined_results, indent=2))
            return combined_results
        except httpx.HTTPError as e:
            raise ToolException(e)


class get_drug_id(BaseModel):
    """Search for a medication by name (brand name or generic) and return the drug_id."""

    drug_name: str = Field(
        description="Brand name or generic. Eg: ibuprofen, advil, lipitor"
    )


async def get_drug_id_fun(drug_name: str, **kwargs) -> str:
    return json.dumps(await check_drug_search_data(drug_name), indent=2)


class get_drug_pricing_info(BaseModel):
    """Get info on a medication like coverage, total cost over the year, cost in specific stages (like coverage gap, etc), drug tier, step therapy, prior auth, etc.
    Always ask the user for THEIR PRESCRIPTION DETAILS: quantity + frequency, supply length, DOSAGE (5mg, 10ml, etc), and FORM (tablet, solution, powder, cream, etc.). DO NOT MAKE UP INPUTS, but provide suggestions to the user for common values.
    Requires calling `get_drug_id` to get the drug ID.

    Eg:
    I take liquid ibuprofen 100mg/5ml, a 120ml bottle once a month, refilled 3 months
    quantity: 1
    quantity_frequency: Month
    supply_length_days: 90"""

    drug_id: str = Field(description="Use `get_drug_id` function to get this")
    quantity: int = Field(
        description="Quantity of medication TAKEN per month, week, or day. NOT FILLED QTY. This is quantity of ITEMS. If it's 2 10ml vials, qty is 2, not 10."
    )
    quantity_frequency: Literal["Month", "Week", "Day"] = Field(
        # description=""
    )
    supply_length_days: int = Field(description="How often refilled")
    plan_ids: list[str]


async def get_drug_pricing_info_fun(
    drug_id: str,
    quantity: int,
    quantity_frequency: Literal["Month", "Week", "Day"],
    supply_length_days: int,
    plan: Optional[Plan],
    **kwargs,
) -> str:
    if not plan:
        raise ToolException("Error, plan is required for this function")
    to_return = json.dumps(
        await check_drug_dosage_n_cost_data(
            drug_id,
            plan.plan_id,
            quantity_frequency,
            quantity,
            supply_length_days,
            plan.plan_year,
            plan.zip,
        ),
        indent=2,
    )
    to_return += """GUIDANCE TO RESPOND: If a similar option shows better coverage or cost compared to the user's specific dosage/package/etc, please suggest that to the user.\nIf the user's brand name prescription has high cost and you can think of a generic, ask the user if you should check the generic."""
    return to_return
