"""
This module initializes the tools
"""

from ..utils.data_models import Plan
from .tool_utils import LLMFunction, LLMFunctionWithPlan
from .tool_defs.query_index import query_index_func, query_index
from .tool_defs.provider_lookup import provider_lookup_func, provider_lookup
from .tool_defs.drug_search import (
    get_drug_id,
    get_drug_id_fun,
    get_drug_pricing_info,
    get_drug_pricing_info_fun,
)
from .tool_defs.drug_dummy import drug_search, drug_search_fun
from .tool_defs.medicare_eligibility_check import (
    medicare_eligibility_check_func,
    medicare_eligibility_check,
)
from .tool_defs.medicaid_eligibility_check import (
    medicaid_eligibility_check_func,
    medicaid_eligibility_check,
)

from .tool_defs.eligibility_check import (
    eligibility_check_func,
    eligibility_check
)

from openai import pydantic_function_tool
import logging
import json

logger = logging.getLogger("agents.tools.tools")

# Should be ALL TOOLS
all_tool_list: list[LLMFunction] = [
    LLMFunctionWithPlan(func=query_index_func, args_schema=query_index),
    LLMFunctionWithPlan(func=provider_lookup_func, args_schema=provider_lookup),
    # LLMFunctionWithPlan(
        # func=medicare_eligibility_check_func, args_schema=medicare_eligibility_check
    # ),
    # LLMFunctionWithPlan(
        # func=medicaid_eligibility_check_func, args_schema=medicaid_eligibility_check
    # ),
    # LLMFunction(func=eligibility_check_func, args_schema=eligibility_check),
    # LLMFunction(func=get_drug_id_fun, args_schema=get_drug_id),
    # LLMFunctionWithPlan(
    #     func=get_drug_pricing_info_fun, args_schema=get_drug_pricing_info
    # ),
    LLMFunctionWithPlan(func=drug_search_fun, args_schema=drug_search),
]

tool_dict: dict[str, LLMFunction] = {func.func_name: func for func in all_tool_list}


def remove_tools(tools_to_remove: list[str]) -> list[LLMFunction]:
    """
    Creates a new tool list from the global tool list excluding `tools_to_remove`
    Strings are tool names (class name of args schema)

    Args:
        tools_to_remove (list[str]): A list of function names identifying the tools to be removed.

    Returns:
        list[LLMFunction]: A new list containing tools whose function names are not in tools_to_remove.
    """
    new_tool_list = []
    for tool in all_tool_list:
        if not (tool.func_name in tools_to_remove):
            new_tool_list.append(tool)
    return new_tool_list


def get_tool_list_from_source(source: str) -> list[LLMFunction]:
    """
    Retrieves a list of tool functions based on the provided source identifier.

    Args:
        source (str): A string that designates the tool source context.

    Returns:
        list[LLMFunction]: A list of LLMFunction objects representing the filtered tool set.
    """
    if source == "digital":
        return remove_tools(["get_drug_id", "get_drug_pricing_info"])
    # default, like for telesales
    else:
        return remove_tools(["drug_search", "provider_lookup"])


def convert_tools(plans: list[Plan], source: str) -> list[dict]:
    """Converts tool schemas to only use plans user is looking at
    and returns a list of openAI tool schemas.

    Args:
        plans (list[Plan]): List of Plans user is looking at

    Returns:
        list[dict]: Schemas converted to OpenAI tool format
    """
    tools_converted = []
    for tool in get_tool_list_from_source(source):
        if isinstance(tool, LLMFunctionWithPlan):
            tool.enumify_schema(plans)
        # Sets strict to True by default
        converted = pydantic_function_tool(tool.args_schema)
        logger.debug(
            f"Tool schema `{tool.func_name}`:\n{json.dumps(converted, indent=2)}"
        )
        tools_converted.append(converted)
    return tools_converted
