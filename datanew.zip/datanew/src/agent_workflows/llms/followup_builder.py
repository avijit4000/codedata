from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel

from agent_workflows.globals import NUM_FOLLOWUP_Q
from ..globals import *

followup_builder = f"""Based on the conversation history, create a list of EXACTLY {NUM_FOLLOWUP_Q} SHORT followup questions that could be answered from TOOL MESSAGES.

# CONDITIONS:
 - Use THE LAST TOOL MESSAGE WITH MEANINGFUL INFORMATION in the conversation history
 - The followup questions SHOULD NOT ALREADY BE ANSWERED BY THE ASSISTANT
 
 In the event those 2 conditions are not satisfied, return an empty list."""

followup_builder_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(followup_builder),
        MessagesPlaceholder("msgs"),
        HumanMessage(followup_builder),
    ]
)


class FollowupQuestions(BaseModel):
    followup_questions: list[str]


llm = AzureChatOpenAI(
    api_key=API_KEY,  # type:ignore
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4o-mini",
    api_version=API_VERSION,
).with_structured_output(FollowupQuestions, method="json_schema", include_raw=True)

followup_builder_chain = followup_builder_template | llm
