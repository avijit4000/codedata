"""
This module provides a wrapper for Azure OpenAI chat completions and LLMs for
the goal seeker
"""

from typing import Any, Literal, Optional
from openai import AsyncAzureOpenAI, pydantic_function_tool
from pydantic import BaseModel, Field, create_model

from agent_workflows.llms.azure_client import AzureClient
from .prompts import goal_seeker_template, goal_seeker_template_telesales, goal_seeker_template_uhccp
from ..globals import *
import os
import json
import logging

logger = logging.getLogger("agents.utils.llms")

deployment = "o3-mini-dz"
deployment_fast = "gpt-4o"
reasoning_effort = "low"
client = AsyncAzureOpenAI(
    api_key=API_KEY,
    azure_endpoint=AZURE_ENDPOINT,  # type:ignore
    azure_deployment=deployment,
    api_version=API_VERSION,
    timeout=O3_MINI_TIMEOUT,
)
client_fast = AsyncAzureOpenAI(
    api_key=API_KEY,
    azure_endpoint=AZURE_ENDPOINT,  # type:ignore
    azure_deployment=deployment_fast,
    api_version=API_VERSION,
)


class GoalSeekerOutput(BaseModel):
    message: str = Field(description="Your message to the user")
    message_type: Literal["answer", "question", "refusal", "info_not_found"] = Field(
        description="What kind of message was sent to the user"
    )
    info_not_found_type: Optional[Literal["provider", "drug", "other"]] = Field(
        description="What kind of info was not found? If applicable"
    )
    refusal_type: Literal[""] = Field(description="Ignore this field")
    answer_docs: list[str] = Field(
        description="List of document IDs used to answer the question, looks like 'doc835'. Empty if N/A"
    )


def get_goal_seeker(
    tools_converted: list[dict],
    max_retries: bool,
    info_class_available: bool,
    source: Literal["digital", "telesales", "uhccp"],
) -> AzureClient:
    """
    Creates and returns an instance of AzureClient configured for goal seeking.

    Args:
        tools_converted (list[dict]): A list of dictionaries representing the tools to be used by the AzureClient.
        max_retries (bool): A flag indicating whether to use the maximum retries template.
        info_class_available (bool): A flag indicating whether the information class is available.

    Returns:
        AzureClient: An instance of AzureClient configured based on the provided parameters.
    """
    response_format = GoalSeekerOutput
    gs_deployment = deployment
    gs_client = client
    kwargs: dict[str, Any] = {"reasoning_effort": reasoning_effort}
    if not info_class_available:
        response_format = create_model(
            response_format.__name__ + "WithFollowup",
            followup_questions=(
                list[str],
                Field(
                    description=f"List of {NUM_FOLLOWUP_Q} questions that could be answered from tool results, from the USER's perspective, that the USER could ask"
                ),
            ),
            __base__=response_format,
        )
        gs_deployment = deployment_fast
        gs_client = client_fast
        kwargs = {"temperature": 0}
    logger.info(f"GS Deployment: {gs_deployment}")
    if source == "digital":
        template = goal_seeker_template
    elif source == "uhccp":
        template = goal_seeker_template_uhccp
    else:
        template = goal_seeker_template_telesales
    if max_retries:
        llm = AzureClient(
            client=gs_client,
            model=gs_deployment,
            template=template,
            response_format=response_format,
            **kwargs,
        )
    else:
        llm = AzureClient(
            client=gs_client,
            model=gs_deployment,
            template=template,
            response_format=response_format,
            tools=tools_converted,
            tool_choice="auto",
            # TODO: Disable parallel tool calling once o3-mini supports it
            # parallel_tool_calls=False,
            **kwargs,
        )
    return llm
