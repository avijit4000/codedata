from typing import Literal, Optional
from pydantic import BaseModel, Field
from openai import AsyncAzureOpenAI
from langchain_core.prompts import SystemMessagePromptTemplate

from ..utils.utils import create_chat_prompt_template
from .prompts.goal_seeker import (
    base_goal_seeker_instructions,
    base_goal_seeker_instructions_telesales,
    base_goal_seeker_instructions_uhccp,
)
from ..globals import *
from .azure_client import AzureClient


initial_goal_seeker_instructions = """{base_goal_seeker_instructions}

# Question Scope Guidelines
{input_guidelines}

# Tone Guidelines
{output_guidelines}
"""

initial_goal_seeker_template_base = create_chat_prompt_template(
    SystemMessagePromptTemplate.from_template(
        template=initial_goal_seeker_instructions,
        input_variables=[
            "base_goal_seeker_instructions",
            "input_guidelines",
            "output_guidelines",
        ],
    )
)


class InitialGoalSeekerOutput(BaseModel):
    message: str = Field(description="Your message to the user")
    message_type: Literal["refusal", "question", "other_message"] = Field(
        description="What kind of message was sent to the user"
    )
    refusal_type: Optional[
        Literal[
            "claims",
            "appeals",
            "complaints",
            "aggression",
            "unintelligible",
            "off_topic",
            "adversarial_prompt",
            "other",
        ]
    ] = Field(description="Reason for refusal")


class TelesalesInitialGoalSeekerOutput(InitialGoalSeekerOutput):
    refusal_type: Optional[
        Literal[
            "unintelligible",
            "adversarial_prompt",
        ]
    ] = Field(description="Reason for refusal")


class UHCCPInitialGoalSeekerOutput(InitialGoalSeekerOutput):
    refusal_type: Optional[
        Literal[
            "aggression", "unintelligible", "off_topic", "adversarial_prompt", "other"
        ]
    ] = Field(description="Reason for refusal")


# deployment = "o3-mini"
deployment = "gpt-4o"
client = AsyncAzureOpenAI(
    api_key=API_KEY,
    azure_endpoint=AZURE_ENDPOINT,  # type:ignore
    azure_deployment=deployment,
    api_version=API_VERSION,
)


def get_initial_goal_seeker_llm(
    tools_converted: list[dict],
    source: Literal["digital", "telesales", "uhccp", "group_retiree"],
):
    """Generates LLM clients based on provided plans.

    This function instantiates AzureClient objects with goal-seeker templates.

    Args:
        tools_converted (list[dict]): A list of OpenAI format tools

    Returns:
        AzureClient: An AzureClient instance for the initial goal seeker
    """
    if source == "digital":
        instructions = base_goal_seeker_instructions
        output_format = InitialGoalSeekerOutput
    elif source == "uhccp":
        instructions = base_goal_seeker_instructions_uhccp
        output_format = UHCCPInitialGoalSeekerOutput
    else:
        instructions = base_goal_seeker_instructions_telesales
        output_format = TelesalesInitialGoalSeekerOutput
    template = initial_goal_seeker_template_base.partial(
        base_goal_seeker_instructions=instructions
    )
    return AzureClient(
        client=client,
        model=deployment,
        template=template,
        response_format=output_format,
        tools=tools_converted,
        parallel_tool_calls=False,
        temperature=0,
        tool_choice="auto",
        # reasoning_effort="low",
    )
