from openai import AsyncAzureOpenAI, APITimeoutError
from langchain.prompts import ChatPromptTemplate
from langchain_core.messages import (
    BaseMessage,
    convert_to_messages,
    convert_to_openai_messages,
)
from pydantic import BaseModel
import logging
import pprint

from ..utils.data_models import AzureClientResult

logger = logging.getLogger("agents.utils.llms.azure_client")


class AzureClient:
    """Handles Azure OpenAI chat completions. Used instead of Langchain to enable tools AND
    structured output at the same time (not supported by langchain)

    Args:
        template (ChatPromptTemplate): A template for chat prompt formatting.
        response_format (type[BaseModel]): The Pydantic model class to parse the response into.
        **kwargs: Additional keyword arguments passed to the client.
    """

    def __init__(
        self,
        client: AsyncAzureOpenAI,
        model: str,
        template: ChatPromptTemplate,
        response_format: type[BaseModel],
        max_tries: int = 3,
        **kwargs,
    ):
        self.client = client
        self.model = model
        self.template = template
        self.response_format = response_format
        self.max_tries = max_tries
        self.kwargs = kwargs

    async def achat(self, **kwargs) -> AzureClientResult:
        """Send a list of messages to the Azure OpenAI chat endpoint and return the parsed response.

        Args:
            **kwargs: inputs for the template invocation

        Returns:
            dict: A dictionary containing the parsed response and the raw message.
        """
        complete_messages = await self.template.ainvoke(kwargs)
        logger.debug(complete_messages.to_messages()[0].pretty_repr())
        tries = 0
        while True:
            try:
                tries += 1
                result = await self.client.beta.chat.completions.parse(
                    model=self.model,
                    messages=convert_to_openai_messages(
                        await self.template.ainvoke(kwargs)  # type:ignore
                    ),
                    response_format=self.response_format,
                    **self.kwargs,
                )
                break
            except APITimeoutError as e:
                if tries >= self.max_tries:
                    raise e
                else:
                    logger.warning("Azure API call timed out, retrying")
        message = result.choices[0].message
        return AzureClientResult(
            msg_parsed=message.parsed,
            msg=convert_to_messages(
                [message.model_dump(exclude=["parsed", "audio"])]  # type:ignore
            )[0],
        )
