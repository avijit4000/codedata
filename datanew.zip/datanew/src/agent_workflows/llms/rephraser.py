from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, BaseMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from pydantic import BaseModel, Field
from typing import Literal, Optional, List, Any, Dict
from ..globals import *
import asyncio
import json
import logging

logger = logging.getLogger("agents.chat_answer")

rephraser_prompt = """Your task is to rephrase the last user message from the conversation history  while removing the plan name and identify if user is asking question while ensuring the following:
1. Identify if user is asking question in last messages:
    - If last messages is question or conversation 

2. Remove Plan Names
    - If any specific plan name is mentioned in last or conversation history, do not include it in the rephrased version but you can include drug , provider or doctor name for search

3. Modify Multi-Plan Comparisons
    - If the user is comparing multiple plans , you need rephrase with single plan with below examples:
        User's original Question
        - "Which plan has lowest copay?" 
        - "Which plan has the lowest out of pocket maximum?" 
        - "List of copay of each plan" 
        - "Which plan has the lowest premium?",
        - "Which plan covers Dr. ABC?" 
        - "List the plans that cover Dr. XYZ"
        - "is doctor xyz covered?"


        Rephrased Questions
        - "What is the cost of this plan?"
        - "What is the out of pocket maximum?"
        - "What is the copay for this plan?"
        - "What is the premium for this plan?"
        - "Does this plan cover Dr. ABC"
        - "Does this plan cover Dr. XYZ?"
        -"is doctor xyz covered?"
    
5. Handle Ambiguities and Edge Cases
    - If the user's intent is unclear(e.g., indirect references to plans), infer the most relevant rephrased version while maintaining neutrality.
    - Do Not try to answer any question even you know the answer, Your task is to only rephrase 
    _ Make sure to think for classification type before responding

Output Format:
    - rephrased_message: provide the reworded version of the last messages.
    - is_question: "Whether or not the user is in the process of asking a question (last message need not be a question)"
    - question_type: clearly state listing_question or summary_question
"""
rephraser_classification_prompt = """ Classify the Question Type (Ensure Accurate Classification)	
	1. Listing Questions(Multiple Plans Compared or Listed)
    - Definition: If the user ask for details about multiple plans, it's A Listing Question
    - Trigger Keywords: "each", "all", "list", "list of which", "compare", "any of these plans", "among these plans", "for each of these plans"
    2. Summary Question(Single Plan Evaluation)
    - Definition: If the user ask which plan or what plan is the based based on a criterion, It is a Summary Question
    - Trigger Keywords: "which", "what"
    Below are Examples for Listing  ans Summary Question:
        - "List the copay for all plans" - Listing Question
        - "Do any of these plans cover dental" - Listing Question
        - "What's the highest copay among these plans"- Listing Question
        - "Compare the deductibles for each plans"- Listing Question
        - "Which plan has the lowest premium?"- Summary Question
        - "What plan offers the best coverage?"- Summary Question

    Priority Rules(Strictly Follow These):
    - if a Listing Keyword is present, it is ALWAYS a Listing Question, even if summary-related words exist.
    - If neither category fits, assume it is a Summary Question as the fallback
Output Format:
    - question_type: clearly state listing_question or summary_question
"""

rephraser_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(rephraser_prompt),
        MessagesPlaceholder("msgs"),
    ]
)


rephraser_classification_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(rephraser_classification_prompt),
        MessagesPlaceholder("msgs"),
    ]
)


class RephrasalQuestion(BaseModel):
    rephrased_message: str = Field(description="The user's rephrased complete message")
    is_question: bool = Field(
        description="Whether or not the user is in the process of asking a question (last message need not be a question)"
    )
    # question_type: Optional[str]


class Rephrasal(BaseModel):
    rephrased_message: str = Field(description="The user's rephrased complete message")
    is_question: bool = Field(
        description="Whether or not the user is in the process of asking a question (last message need not be a question)"
    )
    question_type: Optional[str]


class RephrasalClassification(BaseModel):
    question_type: Literal["listing_question", "summary_question"]


llm = AzureChatOpenAI(
    api_key=API_KEY,  # type:ignore
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4.1-mini",
    api_version=API_VERSION,
    temperature=0,
)
rephraser_chain = rephraser_template | llm.with_structured_output(
    RephrasalQuestion, method="json_schema", include_raw=True
)
rephraser_chain_classification = (
    rephraser_classification_template
    | llm.with_structured_output(
        RephrasalClassification, method="json_schema", include_raw=True
    )
)


async def rephraser_classifier(msgs: List[BaseMessage]) -> dict[str, Any]:
    """
    Rephrase the given messages and classify the type of question.

    Args:
        msgs (List[Dict[str, Any]]): A list of message dictionaries to be rephrased and classified.

    Returns:
        Dict[str, Any]: A dictionary containing the rephrased message, whether it is a question, and the question type.

    Raises:
        Exception: If there is an error during the rephrasing or classification process.
    """

    try:
        output_1, output_2 = await asyncio.gather(
            rephraser_chain.ainvoke({"msgs": msgs}),
            rephraser_chain_classification.ainvoke({"msgs": msgs}),
        )  # type:ignore
        data = json.loads(output_1["raw"].content)
        data["question_type"] = list(json.loads(output_2["raw"].content).values())[0]
        output_1["raw"] = AIMessage(json.dumps(data))
        output_1["parsed"] = Rephrasal(
            rephrased_message=output_1["parsed"].model_dump()["rephrased_message"],
            is_question=output_1["parsed"].model_dump()["is_question"],
            question_type=output_2["parsed"].model_dump()["question_type"],
        )
        return output_1
    except Exception as e:
        logging.error(f"Error in rephraser function: {e}")
        raise
