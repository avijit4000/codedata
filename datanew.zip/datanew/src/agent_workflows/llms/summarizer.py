import langchain_core
from langchain_core.prompts import PromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.messages.base import BaseMessage
from pydantic import BaseModel
from typing import List  # type:ignore
from langchain_openai import AzureChatOpenAI
from ..globals import *  # type:ignore
import logging
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

logger = logging.getLogger("agents.chat_answer")


class Summarizer(BaseModel):
    summarized_message: str


llm = AzureChatOpenAI(
    api_key=API_KEY,  # type:ignore
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4o-mini",
    api_version=API_VERSION,
    temperature=0,
).with_structured_output(Summarizer)

summarizer_prompt = """ You are an AI language model tasked with summarizing the conversation focusing on the customer's health insurance needs, including their medical requirements,
                    doctor preferences, and what the customer prefers or asks about regarding the plan. Avoid including detailed plan descriptions or pricing.
                    Avoid mentioning unrelated or sensitive topics to ensure Compliance with Azure openAI guidelines.
                    You can exclude information that is not important and comes under PII and PHI but be specific and concise."""

summarizer_template = ChatPromptTemplate.from_messages(
    [
        SystemMessage(summarizer_prompt),
         SystemMessage(content="{msgs}")
    ]
)


summarizer_chain = summarizer_template | llm


async def summarize_messages(messages: List[str]) -> HumanMessage:
    """
    Summarizes a list of messages using a summarization chain and returns a HumanMessage object.

    Args:
        messages (List[str]): A list of messages to be summarized.

    Returns:
        HumanMessage: A HumanMessage object containing the summarized text.
    """
    try:
        # Invoke the summarization chain to summarize the messages
        summarization_text = await summarizer_chain.ainvoke({"msgs": messages})
        # Create a HumanMessage object with the summarized text
        process = HumanMessage(content=summarization_text.summarized_message)
    except Exception as e:  # type:ignore
        logger.error(f"Error in summarize messages: {e}")
        process = None  # Ensure process is defined even if an error occurs

    return process


def get_turn_around_messages(
    conversation: List[BaseMessage], turn_around_human_messages: int = 3
) -> list:
    """
    Separates a conversation into messages to summarize and messages to keep based on a specified number of human messages.

    Args:
        conversation (List[BaseMessage]): A list of chat message histories.
        turn_around_human_messages (int): The number of human messages to return after summarization

    Returns:
        list: A tuple containing two lists - messages to summarize and messages to keep.
    """
    try:
        number_of_human_messages = sum(
            1
            for msg in conversation
            if isinstance(msg, langchain_core.messages.human.HumanMessage)
        )
        # messages_to_keep_count should less than 1 of given turn_around_human_messages
        messages_to_keep_count = (
            number_of_human_messages - turn_around_human_messages + 1
        )
        messages_to_summarize, messages_to_keep = [], []
        human_count = 1
        for msg in conversation:
            if human_count <= messages_to_keep_count:
                messages_to_summarize.append(msg)
                if msg.type == "human":
                    human_count += 1
            else:
                messages_to_keep.append(msg)
        return messages_to_summarize, messages_to_keep
    except Exception as e:  # type:ignore
        logger.error(f"Error in getting turn around messages: {e}")
        return [], []


async def conversation_summary(
    conversations: List[BaseMessage], turn_around_messages: int = 5
) -> List[BaseMessage]:
    """
    Summarizes a conversation if the number of human messages exceeds a specified limit.

    Args:
        conversations (BaseMessage): A BaseMessage object containing the conversation messages.
        turn_around_messages (int): The number of human messages to include before summarizing. Default is 3.

    Returns:
        BaseMessage: A BaseMessage object containing the summarized conversation.
    """
    try:
        # Find the number of human messages
        number_of_human_messages = sum(
            1
            for msg in conversations
            if isinstance(msg, langchain_core.messages.human.HumanMessage)
        )
        if number_of_human_messages >= turn_around_messages:
            logger.debug("Summarizing messages")
            # Separate messages to summarize and messages to keep
            messages_to_summarize, messages_to_keep = get_turn_around_messages(
                conversations, turn_around_messages
            )
            # Convert to Langchain object
            if messages_to_summarize:
                for msg in messages_to_summarize.copy():
                    if not isinstance(
                        msg, langchain_core.messages.human.HumanMessage
                    ) and not isinstance(msg, langchain_core.messages.ai.AIMessage):
                        messages_to_summarize.remove(msg)  # type: ignore
                # Summarize messages
                summarized_messages = await summarize_messages(messages_to_summarize)

                final_messages = []
                if summarized_messages:
                    final_messages.append(summarized_messages)
                    final_messages.extend(messages_to_keep)
                    return final_messages
            return conversations
        else:
            logger.debug(f" No need to summarize, return conversation as it is.")
            return conversations
    except Exception as e:  # type:ignore
        logger.error(f"Error in conversation summary: {e}")

        return conversations
