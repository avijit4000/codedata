from dotenv import load_dotenv

load_dotenv()

from flask import Flask, jsonify, request, Response
import openai
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.search.documents.models import VectorizableTextQuery
from logging.config import dictConfig

from agent_workflows import ChatAnswer
from agent_workflows.utils.data_models import Plan, WorkflowOutput
from agent_workflows.utils.utils import page_detail_hyperlink_formating

from langchain_core.messages import convert_to_openai_messages
from langchain_core.messages import convert_to_messages

from llama_index.core.workflow import Workflow
from llama_index.utils.workflow import draw_most_recent_execution
from llama_index.utils.workflow import draw_all_possible_flows
from langchain_core.messages import (
    HumanMessage,
    AIMessage,
    get_buffer_string,
    BaseMessage,
)
from pydantic import BaseModel, Field
import json
import asyncio
import nest_asyncio
nest_asyncio.apply()
import re
import io
from urllib.request import Request, urlopen
import os

import faq
import trends
import json


dictConfig(
    {
        "version": 1,
        "formatters": {
            "default": {
                "format": "%(message)s"
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
                "formatter": "default",
            }
        },
        "root": {"level": "INFO", "handlers": ["console"]},
    }
)

# creating a Flask app 
app = Flask(__name__) 
  

@app.route('/actuator/health')
def get():
    """
    'If service is up and running, this response will be returned with the content ''Healthy'''
    ---
    """
    return Response("Healthy", 200)
@app.route('/getinput/') 
async def disp(): 
    
    #grab input data
    data = request.args.get("input")
    json_data = json.loads(data)

    #convert it to openai format
    converted_message = convert_to_messages(json_data["query"])
    
    plans = []
    #grabbing plan info
    if "planId" in json_data and "planNames" in json_data and len(json_data["planId"]) == len(json_data["planNames"]):
        plans = []
        for count, planid  in enumerate(json_data["planId"]):
            plan = Plan(plan_id = planid, 
                        plan_name = json_data["planNames"][count],
                        plan_year = json_data["year"],
                        zip=json_data["zip"])

            plans.append(plan)

    
    #checking for evaluation
    if "evaluation" in json_data and json_data["evaluation"] == "True":
        results = await chat_response(converted_message, plans, True, json_data["source"])
        output = {
            "response": page_detail_hyperlink_formating(json_data,results.response) if json_data["source"] in ["digital", "telesales"] else results.response,
            "chunks": [chunk.model_dump_json() for chunk in results.chunks],
            "code": results.status,
            "persona": json_data["source"]
        }

    else:
        results = await chat_response(converted_message, plans, False, json_data["source"])
        # print(f"results: {results}")
        # print(f"results url: {results.url_info}")
        # url_list = [model.model_dump_json() for model in results.url_info]
        # print(f"results url list: {[model.model_dump_json() for model in results.url_info]}")
        # print(f"results url list: {url_list}")
        
        output =  {
        "response": page_detail_hyperlink_formating(json_data,results.response) if json_data["source"] in ["digital", "telesales"] else results.response,
        "chat_history": convert_to_openai_messages(results.chat_history),
        "questions": results.questions, 
        "code": results.status,
        "persona": json_data["source"],
        "url_info": list(set([model.model_dump_json() for model in results.url_info]))
    }

    return output


@app.route('/telesales/getinput/', methods=['POST'])
async def add_message():
    json_data = request.json
    #json_data = json.loads(data)

    #convert it to openai format
    converted_message = convert_to_messages(json_data["query"])

    print(f"json_data: {json_data}")
    print(f"converted_messafe: {converted_message}")
    
    plans = []
    #grabbing plan info
    if "planId" in json_data and "planNames" in json_data and len(json_data["planId"]) == len(json_data["planNames"]):
        plans = []
        for count, planid  in enumerate(json_data["planId"]):
            plan = Plan(plan_id = planid, 
                        plan_name = json_data["planNames"][count],
                        plan_year = json_data["year"],
                        zip=json_data["zip"])

            plans.append(plan)

    

    #checking for evaluation
    if "evaluation" in json_data and json_data["evaluation"] == "True":
        if "source" in json_data and (json_data["source"] == "pcl" or json_data["source"] == "jarvis"):
            first_response, chunks = model_response_poc(json_data)
            
            output = {
                "response": first_response,
                "chunks": chunks,
                "persona": json_data["source"]
            }
        else:
            results = await chat_response(converted_message, plans, True, json_data["source"])
            output = {
                "response": page_detail_hyperlink_formating(json_data,results.response) if json_data["source"] in ["digital", "telesales"] else results.response ,
                "chunks": [chunk.model_dump_json() for chunk in results.chunks],
                "code": results.status,
                "persona": json_data["source"]
            }

    else:
        if "source" in json_data and (json_data["source"] == "pcl" or json_data["source"] == "jarvis"):
        
            initial_response, response, urls = model_response_poc(json_data)
    
            questions = followupQ(initial_response)
            
            output = {
                "response": response,
                "questions": questions,
                "url_info": [json.dumps(url) for url in urls],
                "source": json_data["source"]
            }
        else:
        
            results = await chat_response(converted_message, plans, False, json_data["source"])
            
            output =  {
            "response": page_detail_hyperlink_formating(json_data,results.response) if json_data["source"] in ["digital", "telesales"] else results.response,
            "chat_history": convert_to_openai_messages(results.chat_history),
            "questions": results.questions, 
            "code": results.status,
            "persona": json_data["source"], 
            "url_info": list(set([model.model_dump_json() for model in results.url_info]))   
        }


    return output


async def chat_response(msg, plans_list, eval_flag, source_param):


    workflow = ChatAnswer(timeout=60, verbose=True)

    results = await workflow.run(
                raw_chat_history=msg, plans=plans_list, evaluation=eval_flag, source = source_param
            )

    return results

def followupQ(input_data):

    message = [
        {"role": "system", "content":"You are an AI assistant that outputs plan benefit related followup questions based on the input."},
        {"role": "user", "content": "Medicare is a government health insurance program in the United States that provides coverage for individuals who are 65 years old or older, as well as certain younger individuals with disabilities or end-stage renal disease ."},
        {"role": "assistant", "content": "Where can I learn more about medicare?\n Who else is eligible for medicare?\n What types of coverage is available?\n"},
        {"role": "user", "content": input_data}

    ]

    client = AzureOpenAI(
      azure_endpoint =os.getenv(f"OPENAI_ENDPOINT", default=None), 
      api_key=os.getenv(f"OPENAI_KEY", default=None),  
      api_version="2024-02-15-preview"
    )

    #message = [{"role": "user", "content": query}]

    deployment_id = "gpt-4o-mini"
    completion = client.chat.completions.create(
        model=deployment_id,
        messages=message,
    #    dataSources=[],
    )

    questions = completion.choices[0].message.content

    newQ = questions.split('?')

    newQ = newQ[:3]

    final_questions = []

    for i in range(len(newQ)):
        newQ[i] = newQ[i].replace('\n', '')
        if "Thank you" not in newQ[i]:
            final_questions.append(newQ[i].lstrip('0123456789.- '))

    return final_questions    

def get_documents_from_index(query, index_name, top_n_documents, semantic_configuration, search_key, search_endpoint, filter=""):

    sanitized_query = query.replace('\n', '').replace('\r', '')
    app.logger.info(f"final query (sanitized): {sanitized_query}")
    app.logger.info(f"Hitting vector search")


    print(f"final query : {query}")
    search_credential = AzureKeyCredential(search_key)
    search_client = SearchClient(search_endpoint, index_name, search_credential)
    vector_query = VectorizableTextQuery(text=query, fields="vector")
    #use search_client to search index_name with semantic configuration "my-semantic-config" and query_type "vectorSemanticHybrid"
    #return the top 5 documents
    if filter != "":
        return search_client.search(search_text=query, vector_queries=[vector_query], query_type="semantic", 
                                    semantic_configuration_name=semantic_configuration, top=top_n_documents, 
                                    filter=filter)
    else:
        return search_client.search(search_text=query, vector_queries=[vector_query], query_type="semantic", semantic_configuration_name=semantic_configuration, top=top_n_documents)

def aggregate_responses(responses):
    reranker_scores = []
    doc_chunks = []
    urls = []
    url_titles=[]
    page_numbers = []
    plan_names = []
    section_numbers = []
    file_names = []

    for doc in responses:
        #print(f"Reranker score for doc: {doc['@search.reranker_score']}")
        reranker_scores.append(doc['@search.reranker_score']) #if doc['@search.reranker_score'] > reranker_max_score else reranker_max_score
        doc_chunks.append(doc['chunk'])
        urls.append(doc['url'] if 'url' in doc else "")
        url_titles.append(doc['url_title'] if 'url_title' in doc else "")
        page_numbers.append(doc['page_number'] if 'page_number' in doc else "")
        plan_names.append(doc['plan_name'] if 'plan_name' in doc else "")  
        section_numbers.append(doc['section_number'] if 'section_number' in doc else "")
        file_names.append(doc['file_name'] if 'file_name' in doc else "")


    return reranker_scores, doc_chunks, urls,url_titles, page_numbers, plan_names, section_numbers, file_names

def aggregate_plan_docs(plan_ids,index_name,search_key,search_endpoint,original_question,num_default_chunks=5,plan_type_filter = "", plan_year_filter = ""):
    doc_chunks = []
    plan_docs_urls = []
    page_numbers = []
    plan_names = []
    section_numbers = []
    reranker_max_score = 0

    if len(plan_ids) >= 1:
        #set some limits for num of chunks per plan id. the more the num of plans, the fewer the chunks to avoid running into token limits
        if len(plan_ids) > 5:
            num_chunks = 2   
        else:
            num_chunks = num_default_chunks

        print(plan_ids)
        for plan_id in plan_ids:
            query = original_question
            plan_id_filter = "planid eq '" + plan_id + "'"
            first_filter = plan_id_filter + " and " + plan_type_filter if plan_type_filter != "" else plan_id_filter
            final_filter = first_filter + " and " + plan_year_filter if plan_year_filter != "" else first_filter

            print(f"final id filter: {final_filter}")

            plan_docs = get_documents_from_index(query, index_name, num_chunks, "my-semantic-config", search_key, search_endpoint, filter=final_filter)
            reranker_scores, doc_chunks_comp, plan_docs_urls_comp, page_number_comp,plan_number_comp, section_number_comp = aggregate_responses(plan_docs)
            print(f"Reranker scores for plan id: {plan_id} are {reranker_scores}")
            #print(page_number_comp)

            #print(f"Doc chunks for plan id: {plan_id} are {doc_chunks_comp}")
            if len(reranker_scores) > 0:
                reranker_max_score = max(reranker_scores) if max(reranker_scores) > reranker_max_score else reranker_max_score
                print(f"Reranker max score within plan individual: {max(reranker_scores)}")

            doc_chunks += doc_chunks_comp
            plan_docs_urls += plan_docs_urls_comp
            page_numbers += page_number_comp
            plan_names += plan_number_comp
            section_numbers += section_number_comp

        #print(page_numbers)
        print(f"Reranker max score across all plans total: {reranker_max_score}")



    return reranker_max_score,doc_chunks,plan_docs_urls, page_numbers, plan_names, section_numbers


    


def openAIChatAssistant(system_prompt , user_prompt):
    
    client = AzureOpenAI(
      azure_endpoint =os.getenv(f"OPENAI_ENDPOINT", default=None), 
      api_key=os.getenv(f"OPENAI_KEY", default=None),  
      api_version="2024-02-15-preview"
    )

  

    message = [{"role": "system", "content": system_prompt},{"role": "user", "content": user_prompt}]

    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=message,
        max_tokens=500,
        temperature=0,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        stream=False,
    )

    #print(message)

    response = completion.choices[0].message.content
    
    return response

def model_response_poc(scen):
    
    #pcl
    if scen["source"] == "pcl":
        index_name = os.getenv(f"JOBAID_INDEX_PCL", default=None) 
        final_filter = ""
    #jarvis
    else:
        index_name = os.getenv(f"JOBAID_INDEX_JARVIS", default=None)
        final_filter = f"persona eq '{scen['persona']}'" if 'persona' in scen else ""

    
    search_endpoint = os.getenv(f"SEARCH_ENDPOINT", default=None)
    search_key = os.getenv(f"SEARCH_KEY", default=None)

    if isinstance(scen["query"], list):
        query = scen["query"][0]["content"]
    else:
        query =  scen["query"]
    job_aids = get_documents_from_index(query, index_name, 5, "my-semantic-config", search_key, search_endpoint, final_filter)
    reranker_scores, doc_chunks, urls, url_titles, empty_page_numbers, empty_plan_names, empty_section_numbers,file_names = aggregate_responses(job_aids)
    
    merged_docs = [chunk for chunk in doc_chunks]
    page_numbers = empty_page_numbers

    print(len(page_numbers))    
    print(len(merged_docs))    

    content = f"""\n#Question\n{query}\n\n# Sources\n"""

    stopwords = []
    for count, chunk in enumerate(merged_docs):
        stopwords.append(f'[doc{count}]')
        content_new = f"""\n\ndoc{count}\n\n'''{chunk}\n'''"""
        content+=content_new
        
    prompt = """    
        Answer the question using only the context provided in the `# Sources` below the question
        Ensure your responses are concise and strictly based context provided in the `# Sources` below the question without any additional interpreation or elaboration.
        Politely refuse to answer the question if unanswerable from given data. 
        Avoid answering creative questions and wrong facts.
        
        Each source has a document name followed by the source text enclosed in triple backticks
        Always cite the doc name for each fact you use in the response, in the following format:
        "This is a fact[doc2]. This is another fact[doc0]"
        
        You are helping agents looking for help with questions about plan related documents.
        They might use direct and short questions such as "I need this form" or "I need help with this form".
        Use your best judgement to associate questions like "I need this form" with "where can I find this form?".
        """
    
    response = openAIChatAssistant(prompt,content)
    initial_response = response
    url_info = []
    
    
    if len(stopwords) > 0:
        for count, word in enumerate(stopwords):
            page_url_used = []
            if word in response:
                response = response.replace(word, "") 
                
                if len(page_numbers)>count:
                    url = f"{urls[count]}#page={page_numbers[count]}"
                    url_title = url_titles[count]
                    url_dict = {"url": url, "url_title": url_title, "section": "", "keyword": ""}
                    #page_url_used.append(f"{urls[count]}#page={page_numbers[count]}")
                else:
                    #page_url_used.append(f"{urls[count]}")
                    #page_url_used = list(set(page_url_used))
                    url = f"{urls[count]}"
                    url_title = url_titles[count]
                    url_dict = {"url": url, "url_title": url_title, "section": "", "keyword": ""}
                url_info.append(url_dict)

    if "evaluation" in scen and scen["evaluation"] == "True":
        chunks = []
        for num in range(len(doc_chunks)):
            chunk = {f"{file_names[num]} (doc{num}))":doc_chunks[num]}
            chunks.append(chunk)
        return initial_response, chunks
        
    else:
        
        return initial_response, response, url_info
        
    
# driver function 
if __name__ == '__main__': 
  
    app.run(host="0.0.0.0", port=8080,debug=False)
