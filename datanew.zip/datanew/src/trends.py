import io
import json
import os
import pickle
import re
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from logging.config import dictConfig
from urllib.request import Request, urlopen

import openai
import pandas as pd
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
#from flask_cors import CORS
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizableTextQuery
from openai import AzureOpenAI
from pypdf import PdfReader

import TrendsDetector


def check_validate_topic_trends_input(input_data):
    '''
    This function checks if the input data is valid for the topic trends API.
    '''

    # Initialize message list to hold error messages
    final_message = []

    # Check condition 1: start_date must be a non-empty string
    if 'start_date' not in input_data or 'end_date' not in input_data:
        msg = "Missing dates: Dates field is missing in input data, please add proper dates"
        final_message.append(msg)
    else:
        # start_date = input_data.get("start_date", None)
        # if not start_date or not isinstance(start_date, str) or not start_date.strip():
        #     msg = "Invalid start_date: start_date should be a non-empty string."
        #     final_message.append(msg)
        end_date = input_data.get("end_date", None)
        if not end_date or not isinstance(end_date, str) or not end_date.strip():
            msg = "Invalid end_date: end_date should be a non-empty string."
            final_message.append(msg)

    
    # If no errors, return valid input; otherwise return the errors
    if len(final_message) == 0:
        return 'Valid Input' , True
    
    user_final_message = '\n'.join(final_message)
    return user_final_message , False

def add_explicit_filters_for_ucids(json_data):
    '''
    This function adds explicit filters to the query based on the input data.
    It checks for the presence of start_date and end_date in the input data and formats them accordingly.
    It also checks for the presence of is_digital and formats it as a filter.
    The function returns a dictionary with the explicit filters to be used in the query.

    '''
    
    filters_from_query = {}
    if "start_date" in json_data:
        from_date = json_data["start_date"] 
        datetime_object = datetime.strptime(from_date, "%Y-%m-%d")
        start_date_formatted = datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        start_date_formatted = ""
    
    if "end_date" in json_data:
        to_date = json_data["end_date"] 
        datetime_object = datetime.strptime(to_date, "%Y-%m-%d")
        end_date_formatted = datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        end_date_formatted = ""
    
    filter_query_date = ""
    if start_date_formatted != "":
        filter_query_date = f"StartTime ge {start_date_formatted}"
    if end_date_formatted != "":
        filter_query_date += f" and StartTime lt {end_date_formatted}"


    is_digital_filter = ""
    if "is_digital" in json_data and json_data["is_digital"]:
        is_digital_filter = "Is_Digital eq true"
    else:
        is_digital_filter = ""
    
    if filter_query_date != "" and is_digital_filter != "":
        full_filter_term = filter_query_date + " and " + is_digital_filter 
    elif filter_query_date != "":
        full_filter_term = filter_query_date
    else:
        full_filter_term = is_digital_filter

    filters_from_query['explicit_filters'] = full_filter_term

    return filters_from_query
    

def add_explicit_filters_for_trends(json_data):
    '''
    This function adds explicit filters to the query based on the input data.
    '''

    filters = {}
    filters_list = []
    
    end_datetime_object = None
    if "end_date" in json_data:
        end_date = json_data["end_date"] 
        end_datetime_object = datetime.strptime(end_date, "%Y-%m-%d")
        end_datetime_object = end_datetime_object.replace(hour=23, minute=59, second=59)
        end_date_formatted = end_datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        end_date_formatted = ""
    
    if "start_date" in json_data and json_data["start_date"] != "":
        start_date = json_data["start_date"] 
        datetime_object = datetime.strptime(start_date, "%Y-%m-%d")
        start_date_formatted = datetime_object.strftime('%Y-%m-%dT%H:%M:%SZ')
    elif end_datetime_object is not None:
        #set start_date_formatted to 15 days prior to end_date
        start_date_formatted = (end_datetime_object - timedelta(days=15)).strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        start_date_formatted = ""

    filter_start_date = ""
    if start_date_formatted != "":
        filter_start_date = f"date ge {start_date_formatted}"
    
    filters_list.append(filter_start_date)


    filter_end_date = ""
    if end_date_formatted != "":
        filter_end_date = f"date le {end_date_formatted}"
    
    filters_list.append(filter_end_date)


    is_digital_filter = ""
    if "is_digital" in json_data:
        if  json_data["is_digital"]==1:
            is_digital_filter = "is_digital eq true"
        if  json_data["is_digital"]==0:
            is_digital_filter = "is_digital eq false"
    else:
        is_digital_filter = ""

    filters_list.append(is_digital_filter)

    
    topic_category_filter = ""
    if "topic_category" in json_data and json_data["topic_category"]:
        topic_category_filter = f"type eq '{json_data['topic_category']}'"
    else:
        topic_category_filter = ""

    filters_list.append(topic_category_filter)

    #when searching for trends,filter out some well known topics that are not useful
    key_exclusion_filter = "key ne 'united healthcare' and key ne 'medicare advantage' and key ne 'aarp medicare advantage' and key ne 'medicare advantage plan' and key ne 'aarp' and key ne 'hmo' and key ne 'advantage plan' and key ne 'ppo'"
    filters_list.append(key_exclusion_filter)


    filters_list = [item for item in filters_list if item]
    full_filter_term = ' and '.join(filters_list)

    filters['explicit_filters'] = full_filter_term

    return filters



def get_trends_from_trends_index_using_filter(trends_index, search_key, search_endpoint, filters):
    '''
    This function fetches the trends data from the trends index based on the input data.
    '''

    search_credential = AzureKeyCredential(search_key)
    search_client = SearchClient(search_endpoint, trends_index, search_credential)

    explicit_filters = filters['explicit_filters']

    try:
        docs = search_client.search(search_text="*",filter=explicit_filters)

        documents = []
        for doc in docs:
            document = {
                "date": doc["date"],
                "is_digital": doc['is_digital'],
                "key": doc['key'],
                "value": doc['value'],
                "type": doc['type'],
                "zip": doc['zip'],
                "county": doc['county'],
                "plan_name": doc['plan_name']
                }  
            documents.append(document)  

    except Exception as e:
        print(f"Error in fetching trends : {e}")
        documents = []

    return documents

def get_weekly_trend_for_start_date(start_datetime_object, all_stats):
    '''
    This function fetches the weekly trend for the given start date.
    It filters the all_stats data frame for the given start date and then identifies the trending topics.
    It returns a dictionary with the start date and the trending topics. 
    '''
    #filter all_stats with date <= start_datetime_object
    filtered_docs = all_stats[(all_stats['date'] <= start_datetime_object) & (all_stats['date'] >= (start_datetime_object - timedelta(days=7)))]

    print(f"total trends: {len(filtered_docs)}")
    if len(filtered_docs) <= 0:
        print('No data found for the input parameters')
        return {'start_date': start_datetime_object.strftime("%Y-%m-%d"), 'trends': []}
    
    trends_detector = TrendsDetector.TrendDetector(window_data=pd.DataFrame(filtered_docs),all_data=pd.DataFrame(all_stats))
    trending = trends_detector.identify_trending_topics(method='composite', top_n=10)
    trending = trending.reset_index()

    #convert trending data frame  to a list of dictionaries
    trend_by_start_date = {'start_date': start_datetime_object.strftime("%Y-%m-%d"), 'trends': []}
    for idx,trend in trending.iterrows():
        if trend['change_pct'] >= 50 and trend['current_count'] >= 10 and trend['key'] != 'Other' and trend['key'].lower() != 'na':
            topic_data = filtered_docs[filtered_docs['key'] == trend['key']]

            #get the first value in filtered_docs where key = trend['key']
            trend_type = topic_data['type'].values[0]

            #in topic_data, group by zip, county and plan_name and get the percent of values for zip, county and plan_name
            zip_count = topic_data.groupby('zip').size().reset_index(name='count')
            county_count = topic_data.groupby('county').size().reset_index(name='count')
            plan_name_count = topic_data.groupby('plan_name').size().reset_index(name='count')
            #get the percent of values for zip and county in zip_count, county_count and plan_name_count
            zip_count['percent'] = round((zip_count['count'] / zip_count['count'].sum()) * 100, 2)
            county_count['percent'] = round((county_count['count'] / county_count['count'].sum()) * 100, 2)
            plan_name_count['percent'] = round((plan_name_count['count'] / plan_name_count['count'].sum()) * 100, 2)
            #put zips and their corresponding percent into a list of dictionaries
            zip_list = []
            for index, row in zip_count.iterrows():
                zip_list.append({'zip': row['zip'], 'percent': row['percent']})
            #put counties and their corresponding percent into a list of dictionaries
            county_list = []
            for index, row in county_count.iterrows():
                county_list.append({'county': row['county'], 'percent': row['percent']})
            #put plan name and their corresponding percent into a list of dictionaries
            plan_name_list = []
            for index, row in plan_name_count.iterrows():
                plan_name_list.append({'plan_name': row['plan_name'], 'percent': row['percent']})


            trend_type = 'Plan Name' if trend_type == 'plan_name' else trend_type
            trend_dict = {
                'topic': trend['key'],
                'change_pct': trend['change_pct'],
                'total_count': int(trend['total_count']),
                'category': trend_type,
                'daily_count': trend['daily_count'],
                'breakdown_by_zip': zip_list,
                'breakdown_by_county': county_list,
                'breakdown_by_plan_name': plan_name_list,
                'trending_date': start_datetime_object.strftime("%Y-%m-%d")
            }
            trend_by_start_date['trends'].append(trend_dict)
    return trend_by_start_date

def fetch_trends(json_data):
    '''
    This function fetches the trends data from the trends index based on the input data.
    '''

    filters = add_explicit_filters_for_trends(json_data)
    print(f"filters with explicit : {filters}")

    search_key = os.getenv("SEARCH_KEY", default=None)
    search_endpoint = os.getenv("SEARCH_ENDPOINT", default=None)
    trends_index = "transcripts-mira-metadata-stats-v4"

    documents = get_trends_from_trends_index_using_filter(trends_index, search_key, search_endpoint, filters)
    all_docs = pd.DataFrame(documents)
    #convert all_docs['date'] to datetime
    all_docs['date'] = pd.to_datetime(all_docs['date'], format='%Y-%m-%dT%H:%M:%SZ')
    #loop backwards through each day from json_data['end_date'] for 7 days and for each day filter out all_docs with date <= each day
    #and append to documents
    start_date_for_trends = json_data["end_date"]
    start_datetime_object = datetime.strptime(start_date_for_trends, "%Y-%m-%d")
    end_datetime_object = start_datetime_object - timedelta(days=7)
    all_trends = []
    while start_datetime_object >= end_datetime_object:

        trend_by_start_date = get_weekly_trend_for_start_date(start_datetime_object, all_docs)
        
        start_datetime_object -= timedelta(days=1)

        #append trend_by_start_date to all_trends
        all_trends.append(trend_by_start_date)
    
    return all_trends