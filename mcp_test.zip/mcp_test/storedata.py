# import pandas as pd
# import sqlite3
# import os
#
# # Paths
# excel_path = r"D:\Pyn\Project\FoodTimeDeliveryPrediction\notebooks\data"
# db_path = r"D:\Pyn\Test_work\LLMs\test\mcp_test\food_delivery.db"
#
# # Find the Excel file (assuming only one Excel file in the folder)
# excel_files = [f for f in os.listdir(excel_path) if f.endswith(('.xlsx', '.xls','.csv'))]
# if not excel_files:
#     raise FileNotFoundError("No Excel file found in the given directory.")
# excel_file = os.path.join(excel_path, excel_files[0])
#
# # Read Excel file
# df = pd.read_excel(excel_file)
#
# # Create SQLite database connection
# conn = sqlite3.connect(db_path)
#
# # Store data into SQLite table
# table_name = "food_delivery"
# df.to_sql(table_name, conn, if_exists='replace', index=False)
#
# # Commit and close
# conn.commit()
# conn.close()
#
# print(f"✅ Data from '{excel_file}' successfully stored in '{db_path}' as table '{table_name}'.")


# import pandas as pd
# import sqlite3
# import os
#
# # Paths
# excel_file = r"D:\Pyn\Project\FoodTimeDeliveryPrediction\notebooks\data\finalTrain.csv"  # <-- make sure it's .xlsx
# db_path = r"D:\Pyn\Test_work\LLMs\test\mcp_test\food_delivery.db"
#
# # Read Excel file
# df = pd.read_excel(excel_file, engine='openpyxl')
#
# # Create SQLite database
# conn = sqlite3.connect(db_path)
#
# # Store data into SQLite
# df.to_sql('food_delivery_data', conn, if_exists='replace', index=False)
#
# conn.close()
# print("✅ Data successfully stored in SQLite database at:", db_path)



import pandas as pd
import sqlite3
import os

# Paths
csv_file = r"D:\Pyn\Project\FoodTimeDeliveryPrediction\notebooks\data\finalTrain.csv"
db_path = r"D:\Pyn\Test_work\LLMs\test\mcp_test\food_delivery.db"

# Read CSV file
df = pd.read_csv(csv_file)

# Create SQLite database
conn = sqlite3.connect(db_path)

# Store data into SQLite
df.to_sql('food_delivery_data', conn, if_exists='replace', index=False)

conn.close()
print("✅ Data successfully stored in SQLite database at:", db_path)
