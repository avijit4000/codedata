# import sqlite3
# import pandas as pd
# from mcp.server.fastmcp import FastMCP
#
# # Initialize MCP server
# mcp = FastMCP("database")
#
# # Path to your SQLite database
# DB_PATH = r"D:\Pyn\Test_work\LLMs\test\mcp_test\food_delivery.db"
#
#
# def fetch_query(query: str) -> str:
#     """Execute a SELECT query and return results as a formatted string."""
#     try:
#         conn = sqlite3.connect(DB_PATH)
#         df = pd.read_sql_query(query, conn)
#         conn.close()
#
#         if df.empty:
#             return "No results found for the given query."
#         return df.to_string(index=False)
#     except Exception as e:
#         return f"Error executing query: {str(e)}"
#
#
# @mcp.tool()
# def list_tables() -> str:
#     """List all tables available in the SQLite database."""
#     try:
#         conn = sqlite3.connect(DB_PATH)
#         cursor = conn.cursor()
#         cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
#         tables = cursor.fetchall()
#         conn.close()
#
#         if not tables:
#             return "No tables found in the database."
#
#         return "\n".join([t[0] for t in tables])
#     except Exception as e:
#         return f"Error listing tables: {str(e)}"
#
#
# @mcp.tool()
# def get_table_preview(table_name: str, limit: int = 5) -> str:
#     """Preview the first few rows of a table."""
#     query = f"SELECT * FROM {table_name} LIMIT {limit};"
#     return fetch_query(query)
#
#
# @mcp.tool()
# def run_sql_query(query: str) -> str:
#     """Run a custom SQL SELECT query."""
#     if not query.strip().lower().startswith("select"):
#         return "Only SELECT queries are allowed."
#     return fetch_query(query)
#
#
#
# if __name__ == "__main__":
#     mcp.run(transport="streamable-http", host="127.0.0.1", port=8010)



import sqlite3
import pandas as pd
from mcp.server.fastmcp import FastMCP

# Initialize MCP server
mcp = FastMCP("database")

# Path to your SQLite database
DB_PATH = r"D:\Pyn\Test_work\LLMs\test\mcp_test\food_delivery.db"


def fetch_query(query: str) -> str:
    """Execute a SELECT query and return results as a formatted string."""
    try:
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query(query, conn)
        conn.close()

        if df.empty:
            return "No results found for the given query."
        print(df.to_string(index=False))
        return df.to_string(index=False)
    except Exception as e:
        return f"Error executing query: {str(e)}"


@mcp.tool()
def list_tables() -> str:
    """List all tables available in the SQLite database."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        conn.close()

        if not tables:
            return "No tables found in the database."

        return "\n".join([t[0] for t in tables])
    except Exception as e:
        return f"Error listing tables: {str(e)}"


@mcp.tool()
def get_table_preview(table_name: str, limit: int = 5) -> str:
    """Preview the first few rows of a table."""
    query = f"SELECT * FROM {table_name} LIMIT {limit};"

    print(fetch_query(query))
    return fetch_query(query)


@mcp.tool()
def run_sql_query(query: str) -> str:
    """Run a custom SQL SELECT query."""
    if not query.strip().lower().startswith("select"):
        return "Only SELECT queries are allowed."

    print(fetch_query(query))

    return fetch_query(query)

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
    # mcp.run(transport="stdio")
    # mcp.run(transport="streamable-http", host="127.0.0.1", port=8010)
    # mcp.run(transport="streamable-http", config={"host": "127.0.0.1", "port": 8010})

# streamable-http
# stdio