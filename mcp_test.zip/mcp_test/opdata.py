from fastmcp import FastMCP, tool
from typing import Optional, Iterable, Dict, Any
from datetime import datetime
import requests

API_URL = "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/gpd-backend-python/Latency-Report-7day"

# ---------------- Core Function ---------------- #
def fetch_latency_report(
    day: Optional[str] = None,
    days: Optional[Iterable[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    app: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch latency report JSON and optionally filter by date(s).
    """
    resp = requests.get(API_URL, verify="standard_trusts.pem")
    resp.raise_for_status()
    data = resp.json()
    if not isinstance(data, dict):
        raise ValueError("Unexpected response shape (expected dict)")

    single = {day} if day else None
    multi = set(days) if days else None
    range_start = datetime.strptime(start_date, "%Y-%m-%d") if start_date else None
    range_end = datetime.strptime(end_date, "%Y-%m-%d") if end_date else range_start

    def include(d: str) -> bool:
        if single:
            return d in single
        if multi:
            return d in multi
        if range_start:
            try:
                dt = datetime.strptime(d, "%Y-%m-%d")
            except ValueError:
                return False
            return range_start <= dt <= range_end
        return True

    filtered: Dict[str, Any] = {}
    if app:
        app = app.strip().upper()
        if app not in data:
            raise ValueError(f"Unknown app '{app}'. Available keys: {', '.join(sorted(data.keys()))}")
        rows = data.get(app, [])
        filtered[app] = [r for r in rows if isinstance(r, dict) and include(r.get("date", ""))]
        return filtered

    for product, rows in data.items():
        if not isinstance(rows, list):
            continue
        keep = [r for r in rows if isinstance(r, dict) and include(r.get("date", ""))]
        filtered[product] = keep

    return filtered


# ---------------- MCP Integration ---------------- #
mcp = FastMCP("latency-metrics")

@tool
def get_latency_report(
    day: Optional[str] = None,
    days: Optional[list[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    app: Optional[str] = None
) -> Dict[str, Any]:
    """
    Retrieve latency report with optional filters.
    """
    return fetch_latency_report(day, days, start_date, end_date, app)


if __name__ == "__main__":
    # Run as a streamable-http MCP server on port 8020
    mcp.run("streamable-http", host="127.0.0.1", port=8020)
