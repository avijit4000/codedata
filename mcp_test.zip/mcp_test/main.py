def main():
    print("Hello from mcp-test!")


if __name__ == "__main__":
    main()
