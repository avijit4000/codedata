from tools.tools import tools
import datetime

def get_persona_tool_call_messages(user_input): 
    print(f"User Input: {user_input}")
    return [
        {"role": "system","content": f"You only respond if there is a tool call. If the user does not need to call any functions then exit quick with response 'N/A'. Today is {datetime.datetime.now()}."},
        {"role": "user", "content": user_input}
    ]

mira_tools = {
    "message": get_persona_tool_call_messages,
    "search_service": "gpdacq-team-1-eastus-ai-search-cog-svc",
    "search_index": "persona-mira",
    "vbf_contacts": False,
    "tools": []}
