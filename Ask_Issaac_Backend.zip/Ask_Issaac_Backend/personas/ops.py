from tools.tools import tools
import datetime

def get_persona_tool_call_messages(user_input): 
    print(f"User Input: {user_input}")
    return [
        {"role": "system","content": f"You only respond if there is a tool call. If the user does not need to call any functions then exit quick with response 'N/A'. Today is {datetime.datetime.now()}."},
        {"role": "user", "content": user_input}
    ]

ops_tools = {
    "message": get_persona_tool_call_messages,
    "search_service": "gpdacq-team-1-eastus-ai-search-cog-svc",
    "search_index": "gpd-ops-persona",
    "vbf_contacts": True,
    "tools": [
    "get_related_tickets",
    "get_related_stories",
    "get_architecture_info",
    "get_manual_checkout_info",
    "get_contact_info",
    "get_quick_links",
    "get_dynatrace_problems",
    "get_ole_count",
    "chg_algo",
    "get_user_stories",
    # "get_user_story_estimates",
    "get_features",
    # "get_features_states",
    # "get_features_plan_estimates",
    # "get_accepted_features_plan_estimates",
    # "get_user_story_acceptance_criteria",
    # "get_user_story_descriptions",
    # "get_user_story_states",
    # "get_accepted_user_story_estimates",
    "get_current_iterations",
    "get_current_releases",
    #"get_allowed_teams",
    "get_rally_obj_info",
    "get_rally_obj_info_no_id",
    # "get_completed_user_story_estimates",
    # "get_user_stories_no_acceptance_criteria",
    "get_latest_inc",
    "get_latest_prb",
    "get_latest_chg",
    "get_hourglass_repo_riskiness",
    "get_release_milestone_info",
    "get_defects",
    "get_release_defects",
    "get_release_features",
    "get_hourglass_metrics",
    "get_gating_status",
    "get_portal_velocity",
    # "get_mnr_portals_overview",
    "get_crux_report",
    "get_performance_report",
    "get_splunk_report",
    "get_capabilites",
]}
