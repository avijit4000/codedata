from personas.ops import ops_tools
from personas.qae import qae_tools
from personas.dev import dev_tools
from personas.sm import sm_tools
from personas.all import all_tools
from personas.mira import mira_tools
from azure_funcs import *

def set_search_client(persona):
    return {**persona,"search_client": SearchClient(endpoint=f"https://{persona['search_service']}.search.windows.net",index_name=persona['search_index'],credential=azure_credential)} if 'search_service' in persona and 'search_index' in persona else persona

personas = {
    "ops": set_search_client(ops_tools),
    "qae": set_search_client(qae_tools),
    "dev": set_search_client(dev_tools),
    "sm": set_search_client(sm_tools),
    "all": set_search_client(all_tools),
    "mira": set_search_client(mira_tools),
}