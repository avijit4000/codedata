# GPD-OPS-chatbot
an ai chatbot for internal use 
