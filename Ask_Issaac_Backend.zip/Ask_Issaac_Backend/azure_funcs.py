
import openai
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.models import VectorizedQuery
from chat_input_template import chat_prompt_template
from environment import AZURE_KEY, AZURE_API_KEY
import os
import datetime
import requests
import json
import time
import tiktoken
import httpx

# https://gpdacq-team-1-eastus-openai.openai.azure.com/openai/deployments/gpd-ops-gpt-4o/chat/completions?api-version=2024-08-01-preview

AZURE_SEARCH_SERVICE = "gpdacq-team-1-eastus-ai-search-cog-svc"
AZURE_SEARCH_INDEX = 'gpd-ops-chatbot'
AZURE_TOPSCRUM_SEARCH_INDEX = 'vector-top-scrum-poc' 
AZURE_OPENAI_SERVICE = "gpdacq-team-1-eastus-openai"
AZURE_OPENAI_GPT_4o_DEPLOYMENT = 'gpd-ops-gpt-4o'
AZURE_OPENAI_GPT_35_TURBO_DEPLOYMENT = "gpd-ops-gpt-35-turbo"
AZURE_OPENAI_CHATGPT_DEPLOYMENT = "chat"
AZURE_STATIC_INDEX = 'chatbot-store' 

HISTORY_MSG_MODEL = AZURE_OPENAI_GPT_35_TURBO_DEPLOYMENT
COMPLETION_MODEL = AZURE_OPENAI_GPT_4o_DEPLOYMENT
TOOL_CALL_MODEL = AZURE_OPENAI_GPT_4o_DEPLOYMENT
PILL_BOTTLE_MODEL = AZURE_OPENAI_GPT_35_TURBO_DEPLOYMENT

azure_credential = AzureKeyCredential(AZURE_KEY)

# Used by the OpenAI SDK
openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
openai.api_version = "2024-12-01-preview" #"2023-03-15-preview"

http_client = httpx.Client(verify="./standard_trusts.pem")

openaii = AzureOpenAI(
    azure_endpoint=f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com",
    api_key= AZURE_API_KEY,
    api_version= "2024-12-01-preview", #"2024-02-15-preview"
    # http_client=http_client,
)

search_client = SearchClient(
    endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_SEARCH_INDEX,
    credential=azure_credential)

scrum_search_client = SearchClient(
    endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_TOPSCRUM_SEARCH_INDEX,
    credential=azure_credential)

def stream_chatbot_response(messages, opneaiii,outdata="", long_res=False, scrum=False, logger=None, rally=False, rally_messages=None, history_func=None):
    chatbot_response = ''
    print("========================================================================================= Function =============================")
    completion = opneaiii.chat.completions.create(model=COMPLETION_MODEL, messages=messages, stream=True, max_tokens=(800 if not long_res else 1200),temperature=0.4 if scrum else 0.3,top_p=1)
    #print(messages)
    # print(outdata)
    for line in completion:
        #print(line)
        if (line.id.startswith('chatcmpl')):
            if(line.choices[0].delta.content ==None):
                break
            if('\n' in line.choices[0].delta.content):
                line.choices[0].delta.content.replace('\n','<br>').replace('\t',' ')
            #print("data:" + line.choices[0].delta.content + "\n\n")
            # yield line.choices[0].delta.content
            deltacontent = line.choices[0].delta.content
            chatbot_response += deltacontent
            yield "data: a" + deltacontent.replace("\n","<br>") + "\n\n"
    if scrum:
        tokens = outdata.split("\n")
    else:
        tokens = outdata #.split("")
    for token in tokens:
        #time.sleep(1)
        yield f"data: a{token}\n\n" 
    if logger:
        logger.set_answer(chatbot_response+outdata)
        # logger.write_to_log()
        logger.send_to_logstash()
    if rally and rally_messages:
        rally_messages.set_messages({"role": "assistant", "content": chatbot_response})
        # messages.append({"role": "assistant", "content": chatbot_response})
    if history_func:
        history_func(chatbot_response)
    yield "data: [DONE]\n\n"

def get_embeddings(text: str):
    open_ai_endpoint = 'https://gpdacq-team-1-eastus-openai.openai.azure.com/'  # https://gpdacq-team-1-eastus-openai.openai.azure.com/
    open_ai_key = AZURE_API_KEY

    client = openai.AzureOpenAI(
        azure_endpoint=open_ai_endpoint,
        api_key=open_ai_key,

        api_version="2023-05-15",
    )
    embedding = openaii.embeddings.create(input=[text],
                                          model='gpd-ops-text-embedding-ada-002')  # "text-embedding-ada-002" "david-deployment"

    return embedding.data[0].embedding

def get_vectorized_query(search, scrum=False):
    return VectorizedQuery(vector=get_embeddings(search), k_nearest_neighbors=1, fields=('vector' if scrum else 'text_vector'),exhaustive=True)

def format_data_as_assistant(data, description):
    formatted_list = []
    if data:
        for datum in data:
            formatted_list.append({'role':'assistant','content':f'{description}\n{str(datum)}'})
    return formatted_list

def get_doc_content(search, vectorized_queries, scrum=False, history=None, search_client=search_client, doc_count=8):
    print(vectorized_queries)
    try:
        if scrum:
            results = scrum_search_client.search(search, vector_queries=vectorized_queries, top=4)
        else:
            results = search_client.search(search, vector_queries=vectorized_queries, top=doc_count)
        data = " "
        print(results)
        # with open('results.txt', 'w') as f:
            
        # confidence = 0
        for i,doc in enumerate(results):
            # print(doc)
            # print(doc['chunk'])
            print(doc.keys())
            print("Confidence score : " + str(doc['@search.score']))
            print("Confidence reranker score : " + str(doc['@search.reranker_score']))
            # confidence = confidence + doc['@search.score']
            # f.write(doc['chunk'] + '\n\n//\n\n')
            data = data + "Documents: " + doc['chunk'] if scrum else data + "MKDocs: " + doc['chunk'].replace("\n", "").replace("\r", "")
        return_obj = {"role": "user", "content":  "question: " + search + "\n Data : " + data}
        if history and len(history) > 0:
            return_obj["content"] += f"\nChat History: {str(history)}"
        return return_obj
    except Exception as e:
        print("Failed to search documents ",e)
    return_obj = {"role": "user", "content":  "question: " + search + "\n Data : failed to provide additional data"}
    if history and len(history) > 0:
        return_obj["content"] += f"\nChat History: {str(history)}"
    return return_obj

def get_history_message(user_input,history):
    # need to cleanly remove
    if len(history) > 0:
        # completion = openaii.chat.completions.create(
        #     model=HISTORY_MSG_MODEL,
        #     messages=chat_prompt_template(summary="\n".join(history), question=user_input),
        #     temperature=0.7,
        #     max_tokens=100)
        # print(completion.choices[0].message.content)
        # return str(completion.choices[0].message.content)
        return user_input
    else:
        return user_input

class AzureBlobConnect:
    def __init__(self):
        self.host = "https://trainingdataforoai.blob.core.windows.net"
        self.credential = os.environ.get('AZ_BLOBSTORE_SAS')
        self.headers = {
            "x-ms-blob-type": "BlockBlob",
            "x-ms-version": "2022-11-02"
        }
    
    def get_blob_list(self, container: str):
        blobs = []
        url = f"{self.host}/{container}/?restype=container&comp=list&{self.credential}"
        self.headers["x-ms-date"] = datetime.datetime.utcnow().strftime(
            "%a, %d %b %Y %H:%M:%S UTC")
        response = requests.get(url, headers=self.headers)
        for words in response.text.split('<Name>')[1:]:
            blobs.append(words.split('<')[0])
        return blobs

    def get_blob(self, container: str, blob: str):
        try:
            url = f"{self.host}/{container}/{blob}?{self.credential}"
            self.headers["x-ms-date"] = datetime.datetime.utcnow().strftime(
                "%a, %d %b %Y %H:%M:%S UTC")
            response = requests.get(url, headers=self.headers)
            return response.text
        except Exception as e:
            print(e)
            print("Check SAS expiry")
            return str(e)

    def put_blob(self, container: str, blob: str, data: str):
        try:
            url = f"{self.host}/{container}/{blob}?{self.credential}"
            self.headers["x-ms-date"] = datetime.datetime.utcnow().strftime(
                "%a, %d %b %Y %H:%M:%S UTC")
            temp_headers = self.headers
            temp_headers["Content-Length"] = str(json.dumps(data))
            response = requests.put(
                url, headers=temp_headers, data=json.dumps(data))
            return response.text
        except Exception as e:
            print(e)
            print("Check SAS expiry")
            return str(e)

    def put_file_to_blob(self, container: str, file: str):
        try:
            today = datetime.datetime.today().strftime("%Y_%m_%d")
            url = f"{self.host}/{container}/{today}_{file}?{self.credential}"
            self.headers["x-ms-date"] = datetime.datetime.utcnow().strftime(
                "%a, %d %b %Y %H:%M:%S UTC")
            temp_headers = self.headers
            temp_headers["Content-Length"] = str(os.path.getsize(file))
            with open(file, 'rb') as f:
                response = requests.put(url, headers=temp_headers, data=f)
            return response.text
        except Exception as e:
            print(e)
            print("Check SAS expiry")
            return str(e)

    def close(self):
        return "Connection closed"

def truncate_text(text, max_tokens, encoding):
    encoded_text = encoding.encode(text)
    truncated_text = encoding.decode(encoded_text[:max_tokens])
    return truncated_text

# {"response": "", "questions": [""], "persona": "digital", "urlInfo": [{"url": "https://www.aarpmedicareplans.com", "section": "", "keyword": "premium"}, {"url": "https://www.aarpmedicareplans.com", "section": "Section 4", "keyword": "premium"}, {"url": "https://www.aarpmedicareplans.com", "section": "Section 4.1", "keyword": "premium"}]}
def single_chatbot_response(messages, opneaiii,outdata="", long_res=False, scrum=False, logger=None, rally=False, rally_messages=None, history_func=None, prt_data=None):
    chatbot_response = ''
    print("========================================================================================= Function =============================")
    if prt_data is not None:
        search_links = False
        link_msg = "You find related questions for follow up and links that will be used in the response. Use the user's question asked and the following data to provide a response. Take all links in the data and create a key name for the link. The key will be shown as the text for the link, keep them short. Pass the name as the key and the url as the value. Only respond in the format {\"questions\":[\"question\",\"question\",\"question\"],\"links\":{\"keyword\":\"url\",\"keyword\":\"url\"}}. Respond with three follow up questions only using the supporting data. Keep rally id's in their format, such as US12345, F12345, DE12345."
        follow_up_messages = [{
            "role": "system",
            "content": link_msg if search_links else "You find related questions for follow up that will be used in the response. Use the user's question asked and the following data to provide a response. Only respond in the format {\"questions\":[\"question\",\"question\",\"question\"]}. Respond with three follow up questions only using the supporting data. Keep rally id's in their format, such as US12345, F12345, DE12345."
        },messages[1]]
        try:
            encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")
            follow_up_messages[1]['content'] = truncate_text(follow_up_messages[1]['content'], 13000, encoding)
            follow_up_completion = opneaiii.chat.completions.create(model=HISTORY_MSG_MODEL, messages=follow_up_messages, max_tokens=400,temperature=0.3,top_p=1)
            print(follow_up_completion.choices[0].message.content)
            prt_res = json.loads(follow_up_completion.choices[0].message.content)
            for q in prt_res['questions']:
                if 'questions' not in prt_data:
                    prt_data['questions'] = []
                prt_data['questions'].append(q)
            if 'links' not in prt_data:
                prt_data['links'] = {}
            if 'links' in prt_res:
                for k,v in prt_res['links'].items():
                    prt_data['links'][k] = v
                for k,v in prt_data['links'].items():
                    messages[1]['content'].replace(v,f"~Treat this as a link: {k}~")
                
            time.sleep(1)
        except Exception as e:
            print("Error in follow up questions")
            print(e)
    completion = opneaiii.chat.completions.create(model=COMPLETION_MODEL, messages=messages, max_tokens=(900 if not long_res else 2500),temperature=0.4 if scrum else 0.3,top_p=1)
    #print(messages)
    # print(outdata)
    respond_message = completion.choices[0].message.content
    if scrum:
        tokens = outdata.split("\n")
    else:
        tokens = outdata #.split("")
    respond_message += outdata
    if logger:
        logger.set_answer(respond_message)
        # logger.write_to_log()
        logger.send_to_logstash()
    if rally and rally_messages:
        rally_messages.set_messages({"role": "assistant", "content": respond_message})
        # messages.append({"role": "assistant", "content": chatbot_response})
    return respond_message