import os

AZURE_KEY = os.getenv("AZURE_KEY")
AZURE_API_KEY = os.getenv("AZURE_API_KEY")
AZURE_DOC_KEY = os.getenv("AZURE_DOC_KEY")


class Environment:
    def __init__(self):
        self.DEVELOPMENT = False
        self.SCRUM = False
        self.CHATBOT_ENDPOINT = "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/lpm-gpd-chatbot"
        self.TICKETS_ENDPOINT = "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/lpm-gpd-tickets"

    def set_env(self,dev=False,scrum=False,rally=False):
        self.DEVELOPMENT = dev
        self.SCRUM = scrum
        self.RALLY = rally
        self.TICKETS_ENDPOINT = "http://127.0.0.1:8082" if dev else "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/lpm-gpd-tickets"
        self.CHATBOT_ENDPOINT = "http://127.0.0.1:7668" if dev else "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/lpm-gpd-chatbot"
        if self.SCRUM:
            self.TEAM = None
            self.CALL_SIGN = None
            self.TICKETS_DATA = []
    
    def get_tickets_endpoint(self):
        return self.TICKETS_ENDPOINT

    def get_chatbot_endpoint(self):
        return self.CHATBOT_ENDPOINT
    
    def previous_asks(self):
        if self.SCRUM:
            return {'Team':self.TEAM,'Call Sign':self.CALL_SIGN,'Data':self.TICKETS_DATA}
        return None
    
    def set_asks(self,team,call_sign,data):
        if self.SCRUM:
            self.TEAM = team
            self.CALL_SIGN = call_sign
            self.TICKETS_DATA = data

    def set_team(self,team):
        if self.SCRUM:
            self.TEAM = team
            self.CALL_SIGN = None
            self.TICKETS_DATA = []

    def get_team(self):
        if self.SCRUM:
            return self.TEAM
        return None

environment = Environment()
#environment.set_env(True)
