import datetime
import json
import requests

top_scrum_team_list = {}
top_scrum_team_with_id_list = {}
top_scrum_call_sign_list = []


def get_top_scrum_messages(user_input): 
    return [
        {"role": "system","content": f"You only respond if there is a tool call. Make at most one tool call. Future X is a team and will not always result in the future call sign function. A sprint is equal to the last two weeks. If the user is not looking for Top scrum score information then exit quick with response 'N/A'. Today is {datetime.datetime.now()}. The only teams that can be queried are in this list: {top_scrum_team_with_id_list}. The only call signs that can be queried are in this list: {top_scrum_call_sign_list}"},
        {"role": "user", "content": user_input}
    ]

def populate_top_scrum_lists():
    if top_scrum_team_with_id_list == {}:
        for block in requests.post("https://app.q2e.com/api/ExternalReportApi/GetReportDetailForExternalReport",
                    data={"ReportGUID": "2ba2af84-5fc5-48bf-bcff-697b4f3211da"}
                    ).json()['CustomReportDTO']['ReportFilterItems']:
            # if block['DatabaseColumnName'] == 'ProjectName':
            #     top_scrum_team_with_id_list.append(block['Title']+ '#' + str(block['CustomFieldItemId']))
            #     top_scrum_team_list.append(block['Title'])
            if block['DatabaseColumnName'] == 'Title':
                call_sign = block['Title']+ '#' + str(block['CustomFieldItemId'])
                if call_sign not in top_scrum_call_sign_list:
                    top_scrum_call_sign_list.append(call_sign)
        query_param = {"PassingObjects": {"Filters": [],"DrillToChildData": [],"ClientId": 98,"ReportId": 5325,"LevelNumber": 1,"LevelViewNumber": 1,"IsDrillToTask": False},"IsPrimary": True,"UserId": 1}
        for block in requests.post("https://app.q2e.com/api/ExternalReportApi/GetCustomReportData",
                headers={"Content-Type":"application/json"},
                data=json.dumps(query_param)).json():
            team = block['ProjectName_113']
            team_id = block['Q2EProjectId']
            leader = block['CONF_3012']
            if leader not in top_scrum_team_list:
                top_scrum_team_with_id_list[leader] = []
                top_scrum_team_list[leader] = []
            if team + '#' + str(team_id) not in top_scrum_team_with_id_list[leader]:
                top_scrum_team_with_id_list[leader].append(team + '#' + str(team_id))
            if team not in top_scrum_team_list[leader]:
                top_scrum_team_list[leader].append(team)
            print(top_scrum_team_with_id_list)
            print("LEADERS: ", list(top_scrum_team_list.keys()))

def get_top_scrum_tool_list():
    return [
        {
            "type": "function",
            "function" : {
                "name": "get_top_scrum_scores",
                "description": "Use this when the ask is similar to 'did ?team get points for ?call_sign'. This function calls the Quest2Excel API to get the scores for a given team. Use this tool when scores are asked about in past tense. Use this to find main failure reasons, and use the last 6 months for main reason. Only use this tool if at least one team is mentioned. Use this for when more information is needed than just overall team scores in an unspecified timeframe. People may ask for a score for a team or teams, a call sign or signs, and a date range. If no date range is used, have the time frame be 14 days ago for from_date and tomorrow for to_date. If the time period is for a vague time like a day or month, then do the start (00:00 or 1st) to the end (23:59 or 31st as example). The function will return the scores for the given parameters.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "teams": {
                            "type": "array",
                            "items": {
                                "type": "string"
                            },
                            "description": f"The team or teams the user wants information on a score for. Put all teams together in a list. Teams are formatted as team name#id. Keep the id. The only teams that can be used are in the given list"
                        },
                        "call_sign": {
                            "type": "array",
                            "items": {
                                "type": "string"
                            },
                            "description": f"The name of the scoring metric the user wants to know about. Put all call signs together in a list. Call signs are formatted as call sign#id. Keep the exact string from the list. Only use the given call signs or 'NONE'"
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. The game started on May 7th, 2024, so use that as a beginning date at the earliest. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Only change this from today if the user explicitly says an earlier date. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_all_top_scrum_scores",
                "description": "This function should be used when the user wants the score for a team or teams without mentioning awards, what place a team is in, what the top/bottom performing teams are, or if the user wants to compare the scores between teams. The function will return the scores for all teams. If a team is asking whether they will get points or not but there is no team found, set the team to NONE.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "teams": {
                            "type": "array",
                            "items": {
                                "type": "string"
                            },
                            "description": f"Only use teams or leaders. The team or teams the user wants information on a score for. Teams are formatted as team name. The only teams that can be used are in the given list"
                        },
                        # "leaders": {
                        #     "type": "array",
                        #     "items": {
                        #         "type": "string"
                        #     },
                        #     "description": f"Only use teams or leaders. The team or teams the user wants information on a score for. Leaders are formatted as name. The only leaders that can be used are in this list: {list(top_scrum_team_list.keys())}"
                        # }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_future_top_scrum_score",
                "description": "Never use when asked in past tense. This function should be used when the user wants to know the score for a team in the next award time. Only use this tool when scores are asked about in not past or present tense. The function will return if the award will be completed and reasoning for getting or failing the award. Both team and call sign must be filled out. If the team asks for multiple call signs or general next call signs, return call sign as NONE. Allow typos in the team name and call sign and determine which team and call sign the user is asking for.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"Only use one team. The team the user wants information on a score for. Team are formatted as team name. The only teams that can be used are in the given list"
                        },
                        "call_sign": {
                            "type": "string",
                            "description": f"Only use one call sign. If none provided but they ask for future score make this value NONE. If multiple provided value NONE. The call sign is the award the team is requesting data for. Only use the given call signs or 'NONE'"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_leader_specifics",
                "description": "Get data for a specific leader. Users can ask about the total points a leader has or the failure rates for all call signs, or the failure rate for a specified call sign.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "leader": {
                            "type": "string",
                            "description": f"Only use one leader. The leader the user wants information on scoring for. The only leaders that can be used are in this list: {list(top_scrum_team_list.keys())}"
                        },
                        "op": {
                            "type": "string",
                            "description": f"Only use one operation. The operation the user wants information on scoring for. The only operations that can be used are in this list: ['total_points','failure_percents'] or for a call sign use the given call signs"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        }
    ]