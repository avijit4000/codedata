import requests
import json

class ChatbotLogger:
    def __init__(self,chatbot,persona=None):
        self.data = {}
        self.data['_index_tag'] = "chatbot_usage"
        self.data['_index_frequency'] = "YEARLY"
        self.data['chatbot'] = chatbot
        if persona:
            self.data['persona'] = persona

    def set_question(self,question):
        self.data['question'] = question.replace('\n',' ')

    def set_answer(self,answer):
        self.data['answer'] = answer.replace('\n',' ')

    def add_incident(self,incident):
        if 'incidents' not in self.data:
            self.data['incidents'] = []
        if incident not in self.data['incidents']:
            self.data['incidents'].append(incident)

    def add_problem(self,problem):
        if 'problems' not in self.data:
            self.data['problems'] = []
        if problem not in self.data['problems']:
            self.data['problems'].append(problem)

    def add_story(self,story):
        if 'stories' not in self.data:
            self.data['stories'] = []
        if story not in self.data['stories']:
            self.data['stories'].append(story)

    def add_defect(self,defect):
        if 'defects' not in self.data:
            self.data['defects'] = []
        self.data['defects'].append(defect)

    def set_team(self,team):
        self.data['team'] = team

    def set_call_sign(self,call_sign):
        self.data['call_sign'] = call_sign

    def set_award_date(self,award_date):
        self.data['award_date'] = award_date

    def set_tense(self,tense):
        self.data['tense'] = tense

    def set_ask_type(self,ask_type):
        self.data['ask_type'] = ask_type

    def set_environment(self,environment):
        self.data['environment'] = environment

    def set_vbf(self,vbf):
        self.data['vbf'] = vbf

    def set_username(self,username):
        self.data['username'] = username

    def write_to_log(self):
        def formatReport(report):
            return '\n'.join(json.dumps(d) for d in report)
        with open('chatbot_log.json','w') as f:
            json.dump(self.data,f)
        report = formatReport(self.data)
        with open('chatbot_log.txt','w') as f:
            f.write(report)
        
    def send_to_logstash(self, endpoint="http://rn000125170:8080/generic_export"):
        try:
            def formatReport(report):
                return '\n'.join(json.dumps(d) for d in report)
            print("Sending user interation to Logstash")
            url = endpoint
            headers = {'Content-type': 'application/json'}
            r = requests.post(url, data=formatReport([self.data]), headers=headers)
            print(r)

        except Exception as e:
            print("Error occured while sending data to Logstash",e)
