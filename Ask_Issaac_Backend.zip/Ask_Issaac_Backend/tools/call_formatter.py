
def tool_call_format_obj(obj,user_input,search="",logger=None,team_contact="", history=None):
    use_user_input = False
    use_search = False
    use_logger = False
    use_team_contact = False
    use_history = False
    if 'user_input' in obj and obj['user_input']:
        use_user_input = True
    if 'search' in obj and obj['search']:
        use_search = True
    if 'logger' in obj and obj['logger']:
        use_logger = True
    if 'team_contact' in obj and obj['team_contact']:
        use_team_contact = True
    if 'history' in obj and obj['history']:
        use_history = True
    if 'function' in obj and 'args' in obj:
        args = {"args":obj['args']}
        if use_user_input:
            args['user_input'] = user_input
        if use_search:
            args['search'] = search
        if use_logger:
            args['logger'] = logger
        if use_history:
            args['history'] = history
        # print(f"Arg Obj:\n\n{args}\n")
        return obj['function'](**args)
    else:
        return None
