from tools.list_formatter import create_tool_list, create_tool_functions
from tools.call_formatter import tool_call_format_obj
from azure_funcs import TOOL_CALL_MODEL, openaii

import json

def tool_call(persona,user_input,search="",team_contact="",logger=None,history=None):
    messages_input = persona['message'](user_input)
    if history:
        messages_input[1]["content"] += f"\n\nHere is the last few questions and responses in ask order: {history}."
    tool_list = create_tool_list(persona['tools'])
    tool_funcs = create_tool_functions(persona['tools'])
    # with open('tools.json', 'w') as f:
    #     json.dump(persona['tools'], f)
    completion = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=tool_list)
    finish_reason = completion.choices[0].finish_reason
    return_data = []
    outdata = ""
    long_res = False
    props = {"long_res":False}
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return outdata, None, props
    elif finish_reason =='tool_calls':
        print(completion.choices[0].message.tool_calls)
        for tool_call in completion.choices[0].message.tool_calls:
            print(tool_call.function.name)
            args = json.loads(tool_call.function.arguments)
            # print(tool_call)
            if tool_call.function.name in tool_funcs:
                # print(tool_funcs[tool_call.function.name])
                if "long_res" in tool_funcs[tool_call.function.name] and tool_funcs[tool_call.function.name]["long_res"]:
                    props['long_res'] = True
                if "doc_count" in tool_funcs[tool_call.function.name] and type(tool_funcs[tool_call.function.name]["doc_count"]) == int:
                    props['doc_count'] = tool_funcs[tool_call.function.name]["doc_count"]
                    print(f"DOC COUNT FOUND: {props['doc_count']}")
                return_data.append(tool_call_format_obj(obj={"args":args,**tool_funcs[tool_call.function.name]},user_input=user_input,search=search,logger=logger,team_contact=team_contact,history=history))
            else:
                print("Tool not found")
                return_data.append(None)
    return outdata, return_data, props