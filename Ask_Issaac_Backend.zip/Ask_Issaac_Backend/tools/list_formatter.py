from tools.tools import tools

def tool_list_format_obj(obj):
    # this only supports function tools in tool calls
    if obj["type"] == "function":
        return {
            "type": "function",
            "function" : {
                "name": obj["name"],
                "description": obj["description"],
                "parameters": obj["parameters"],
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        }
    else:
        print("Unknown type")
        return None

def create_tool_list(tool_list):
    formatted_tool_list = []
    for tool in tool_list:
        if tool in tools:
            formatted_tool_list.append(tool_list_format_obj({"name":tool,**tools[tool]}))
    return formatted_tool_list

def create_tool_functions(tool_list):
    formatted_tool_list = {}
    for tool in tool_list:
        if tool in tools:
            formatted_tool_list[tool] = {"name":tool,**tools[tool]}
    return formatted_tool_list