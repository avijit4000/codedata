import datetime
import json
import requests
import os

import psycopg2

from azure_funcs import TOOL_CALL_MODEL, openaii, get_vectorized_query, SearchClient, AZURE_SEARCH_SERVICE, azure_credential, AzureBlobConnect
from environment import environment
from tickets_funcs import get_incidents, get_problems, get_us, query_quick_links, get_mnr_site_overview

from ops_chatbot.tool_list import get_ops_tool_list
from rally_chatbot.tool_list import rally_teams
from rally_chatbot.tool_calling import *

ARCH_SEARCH_SERVICE_INDEX = "gpd-ops-architecture-docs"
PROBES_SEARCH_SERVICE_INDEX = "gpd-ops-manual-checkout"

conn_details ={
        "host":"itsm_dm_prod.optum.com",
        "database":"itsm_dm",
        "user":os.getenv('DATA_MART_DB_USER'),
        "password":os.getenv('DATA_MART_DB_PASSWORD'),
        "port":"5432"
}

try:
    release_res = requests.get("http://dashboard-api-core-elr.optum.com/api/release/dates/all").json()
    release_names = [release['releaseName'] for release in release_res]
except:
    release_names = []
    print("Failed to get release names from Comprehensive Dashboard API")

def get_ops_messages(user_input, search=""): 
    print(f"User Input: {user_input}")
    return [
        {"role": "system","content": f"You only respond if there is a tool call. If the user does not need to call any functions then exit quick with response 'N/A'. Today is {datetime.datetime.now()}."},
        {"role": "user", "content": user_input}
    ]

def ops_tool_call(user_input,search="",logger=None,team_contact=""):
    messages_input = get_ops_messages(user_input,search=search)
    outdata = ""
    return_data = []
    long_res = False
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_ops_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return outdata, None, long_res
    elif finish_reason =='tool_calls':
        print(compl.choices[0].message.tool_calls)
        for tool_call in compl.choices[0].message.tool_calls:
            if tool_call.function.name == 'get_related_tickets':
                args = json.loads(tool_call.function.arguments)
                tickets_res = get_related_tickets(user_input,search,logger=logger)
                return_data.append(tickets_res)
                outdata += tickets_res
            elif tool_call.function.name == 'get_related_stories':
                args = json.loads(tool_call.function.arguments)
                stories_res = get_related_stories(search,args)
                return_data.append(stories_res)
                outdata += stories_res
            elif tool_call.function.name == 'get_architecture_info':
                args = json.loads(tool_call.function.arguments)
                arch_info = get_architecture_info(search,args)
                return_data.append(arch_info)
                long_res = True
            elif tool_call.function.name == 'get_dynatrace_problems':
                #args = json.loads(tool_call.function.arguments)
                dyna = get_dynatrace_problems(search,args)
                return_data.append(dyna)
                long_res = True
            elif tool_call.function.name == 'get_manual_checkout_info':
                args = json.loads(tool_call.function.arguments)
                manual_checkout_info = get_manual_checkout_info(search,args)
                return_data.append(manual_checkout_info)
                long_res = True
            elif tool_call.function.name == 'get_contact_info':
                if (len(team_contact)==0):   
                    args = json.loads(tool_call.function.arguments)
                    return_data.append(get_contact_info(search,args))
            elif tool_call.function.name == 'get_quick_links':
                args = json.loads(tool_call.function.arguments)
                quick_links_info = get_quick_links_info(search,args)
                return_data.append(quick_links_info)
                long_res = True
    return outdata, return_data, long_res

def ops_rally_tool_call(user_input,search="",logger=None,team_contact="", history=None):
    messages_input = get_ops_messages(user_input,search=search)
    outdata = ""
    return_data = []
    long_res = False
    if history:
        messages_input.append({"role": "assistant", "content": f"Here is the last few questions and responses in ask order: {history}"})
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_ops_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return outdata, None, long_res
    elif finish_reason =='tool_calls':
        print(compl.choices[0].message.tool_calls)
        for tool_call in compl.choices[0].message.tool_calls:
            print(tool_call.function.name)
            if tool_call.function.name == 'get_related_tickets':
                args = json.loads(tool_call.function.arguments)
                tickets_res = get_related_tickets(user_input,search,logger=logger)
                return_data.append(tickets_res)
                outdata += tickets_res
            elif tool_call.function.name == 'get_related_stories':
                args = json.loads(tool_call.function.arguments)
                stories_res = get_related_stories(search,args)
                return_data.append(stories_res)
                outdata += stories_res
            elif tool_call.function.name == 'get_architecture_info':
                args = json.loads(tool_call.function.arguments)
                arch_info = get_architecture_info(search,args)
                return_data.append(arch_info)
                long_res = True
            elif tool_call.function.name == 'get_manual_checkout_info':
                args = json.loads(tool_call.function.arguments)
                manual_checkout_info = get_manual_checkout_info(search,args)
                return_data.append(manual_checkout_info)
                long_res = True
            elif tool_call.function.name == 'get_quick_links':
                args = json.loads(tool_call.function.arguments)
                quick_links_info = get_quick_links_info(search,args)
                return_data.append(quick_links_info)
                long_res = True
            elif tool_call.function.name == 'get_contact_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_contact_info(search,args))
            elif tool_call.function.name == 'get_user_stories':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories(args))
            elif tool_call.function.name == 'get_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_estimates(args))
            elif tool_call.function.name == 'get_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features(args))
            elif tool_call.function.name == 'get_features_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_states(args))
            elif tool_call.function.name == 'get_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_plan_estimates(args))
            elif tool_call.function.name == 'get_accepted_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_features_plan_estimates(args))
            elif tool_call.function.name == 'get_user_story_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_acceptance_criteria(args))
            elif tool_call.function.name == 'get_user_story_descriptions':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_descriptions(args))
            elif tool_call.function.name == 'get_user_story_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_states(args))
            elif tool_call.function.name == 'get_accepted_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_user_story_estimates(args))
            elif tool_call.function.name == 'get_current_iterations':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_iterations(args))
            elif tool_call.function.name == 'get_current_releases':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_releases(args))
            elif tool_call.function.name == 'get_allowed_teams':
                return_data.append(f"Here are the teams thay are asking for: {rally_teams}")
            elif tool_call.function.name == 'get_rally_obj_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_rally_obj_info(args))
            elif tool_call.function.name == 'get_rally_obj_info_no_id':
                return_data.append(get_rally_obj_info_no_id(user_input))
            elif tool_call.function.name == 'get_completed_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_completed_user_story_estimates(args))
            elif tool_call.function.name == 'get_user_stories_no_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories_no_acceptance_criteria(args))
            elif tool_call.function.name == 'get_latest_inc':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_latest_inc(args))
            elif tool_call.function.name == 'get_hourglass_repo_riskiness':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_hourglass_repo_riskiness(args))
            elif tool_call.function.name == 'get_release_milestone_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_milestone_info(args))
            elif tool_call.function.name == 'get_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_defects(args))
            elif tool_call.function.name == 'get_release_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_defects(args))
            elif tool_call.function.name == 'get_release_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_features(args))
            elif tool_call.function.name == 'get_hourglass_metrics':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_hourglass_metrics(args))
    return outdata, return_data, long_res



def get_related_tickets(user_input,search,logger=None):
    inc_res, inc_search = get_incidents(user_input,search,logger=logger)
    prb_res, prb_search = get_problems(user_input,search,logger=logger)
    return inc_res + prb_res

def get_related_stories(search, args, logger=None):
    # return get_user_stories(search,args['vbf'],logger=logger)
    return get_us(search,None,logger=logger)

def get_architecture_info(search, args):
    arch_search_client = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=ARCH_SEARCH_SERVICE_INDEX,
        credential=azure_credential)
    print(f"Architecture Search: {search}")
    results = arch_search_client.search(search, vector_queries=[get_vectorized_query(search)], top=4)
    return_data = ""
    for doc in results:
        return_data += f"Architecture chunk: {doc['chunk']}\n\n"
    return return_data

def get_manual_checkout_info(search, args):
    probes_search_client = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=PROBES_SEARCH_SERVICE_INDEX,
        credential=azure_credential)
    results = probes_search_client.search(search, vector_queries=[get_vectorized_query(search)], top=4)
    return_data = ""
    for doc in results:
        return_data += f"Manual Checkout chunk: {doc['chunk']}\n\n"
    return return_data

def get_contact_info(search, args):
    print("Contact Information: " + str(args))
    blob_client = AzureBlobConnect()
    res1 = blob_client.get_blob("chatbot-store", "contact_information.txt")
    res2 = blob_client.get_blob("chatbot-store", 'teamcontact.txt')
    res = []
    res.extend(res1.split("/n"))
    res.extend(res2.split(";"))
    founder =""
    for line in res :
        if args['name'].lower() in line.lower():
            founder = founder + line +"/n"
    if len(founder)==0 :
        return res1
    return founder

def get_quick_links_info(search, args):
    quick_links = query_quick_links(args['category'] if 'category' in args else None)
    print(quick_links)
    return quick_links

def get_dynatrace_problems(search,args):
    url = "https://dtsaas.uhc.com/e/4944fc42-016d-4462-8104-a110143a2322/api/v2/problems"

    querystring = {"from":"now-1d","pageSize":"500"}

    payload = ""
    headers = {
    'Authorization': os.getenv("DYNATRACE_API"),
    'Accept': "application/json"
    }

    response = requests.request("GET", url, data=payload, headers=headers, params=querystring,verify='C:/Users/kgupta94/OneDrive - UHG/Desktop/repos/lpm-gpd-chatbot/standard_trusts.pem')
    prblms =  response.json()
    active_prb = []
    for i in range(len(prblms['problems'])):
        if prblms['problems'][i]["status"]== "OPEN":
            active_prb.append(prblms['problems'][i])
    summary_out =""
    if len(active_prb) <1: 
        summary_out = "There are no Active problem in Dynatrace as of Now!"
        #return summary_out
    else :
        summary_out = "There are "+str(len(active_prb)) +" Active problems in Dynatrace. Few of them are : " 
        for p in active_prb:
            summary_out = summary_out + " <br>-  <a href='https://dtsaas.uhc.com/e/4944fc42-016d-4462-8104-a110143a2322/#problems/problemdetails;gtf=today;gf=all;pid="+ p["problemId"]+"' ><Strong>"+ p["displayId"]+"</Strong></a> : "+p["displayId"]+" in " + p["impactedEntities"][0]["name"]
    return summary_out

def get_latest_inc(args):
    last_X_days = 30
    def generate_sql(start_date, end_date,fields):
        # fields = '*'
        field_str = ', '.join(fields)
        sql = f"select {field_str} from SM_DM.SM_INCIDENTS where \"assignment\" = 'GOVERNMENT PROGRAMS DIGITAL (UNT) - APP' and open_time between \'" + start_date + "\' and \'" + end_date + "\'"
        return sql
    fields = ['uh_assignee_full_name', 'brief_description', 'in_id', 'update_action', 'resolution', 'open_time', 'priority_code', 'sm_incidents.status']
    sql = generate_sql((datetime.datetime.now() - datetime.timedelta(days=last_X_days)).strftime('%Y-%m-%d 00:00:00.000'),(datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00.000'),fields)
    print(sql)
    conn = psycopg2.connect(**conn_details)
    cur = conn.cursor()
    cur.execute(sql)
    results = cur.fetchall()
    print(results)
    for i,r in enumerate(results):
        r = list(r)
        r[fields.index('priority_code')] = "Priority Code: " + r[fields.index('priority_code')]
        r[fields.index('sm_incidents.status')] = "INC State: " + r[fields.index('sm_incidents.status')]
        results[i] = r
    cur.close()
    return (f"Here are incidents from the last {last_X_days} days.",results if len(results) > 0 else f"No Incidents found in the last {last_X_days} days.")

def get_latest_prb(args):
    last_X_days = 30
    def generate_sql(start_date, end_date,fields):
        # fields = '*'
        field_str = ', '.join(fields)
        sql = f"select {field_str} from SM_DM.sm_problems sp where \"assignment\" = 'GOVERNMENT PROGRAMS DIGITAL (UNT) - APP' and open_time between \'" + start_date + "\' and \'" + end_date + "\'"
        return sql
    fields = ['pr_id', '\"assignment\"', 'status', 'brief_description', 'description_details', '\"open\"', 'open_time', 'update_time', 'close_time', 'priority_code', 'incident_category', 'incident_count', 'closure_code', 'resolution', 'rootcausedate', 'rootcause', 'update_work_log', 'workaround', 'uh_solution_summary', 'uh_root_cause_summary', 'uh_assignee_full_name', 'uh_goal_resolution_planned', 'uh_type', 'uh_category_explanation', 'sn_created_to_support_inc', 'uh_total_days_open', 'uh_days_since_last_worked', 'uh_closed_at', 'sn_rca_review', 'failed_service_ci_id', 'sys_created_on']
    sql = generate_sql((datetime.datetime.now() - datetime.timedelta(days=last_X_days)).strftime('%Y-%m-%dT00:00:00.000Z'),(datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%dT00:00:00.000Z'),fields)
    print(sql)
    conn = psycopg2.connect(**conn_details)
    cur = conn.cursor()
    cur.execute(sql)
    results = cur.fetchall()
    # print(results)
    for i,r in enumerate(results):
        r = list(r)
        r[fields.index('priority_code')] = "Priority Code: " + r[fields.index('priority_code')]
        r[fields.index('status')] = "PRB State: " + r[fields.index('status')]
        results[i] = r
    cur.close()
    return (f"Here are PRBs from the last {last_X_days} days.",results if len(results) > 0 else f"No PRBs found in the last {last_X_days} days.")

def get_latest_chg(args):
    last_X_days = 30
    def generate_sql(start_date, end_date,fields):
        # fields = '*'
        field_str = ', '.join(fields)
        sql = f"select {field_str} from sm_dm.sm_changes sc  where sc.assign_dept = 'GOVERNMENT PROGRAMS DIGITAL (UNT) - CHG' and sc.close_time >= '{start_date}' and sc.close_time <= '{end_date}'"
        return sql
    fields = ['ch_id', 'current_phase', 'ch_category', 'brief_description', 'status', 'risk_assessment', 'date_entered', 'subcategory', 'description', 'justification', 'backout_method', 'closing_comments', 'implementationcomments', 'uh_requester_name', 'uh_assigned_to_name', 'implementation_plan']
    sql = generate_sql((datetime.datetime.now() - datetime.timedelta(days=last_X_days)).strftime('%Y-%m-%dT00:00:00.000Z'),(datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%dT00:00:00.000Z'),fields)
    print(sql)
    conn = psycopg2.connect(**conn_details)
    cur = conn.cursor()
    cur.execute(sql)
    results = cur.fetchall()
    # print(results)
    for i,r in enumerate(results):
        r = list(r)
        # r[fields.index('priority_code')] = "Risk: " + r[fields.index('risk_assessment')]
        r[fields.index('status')] = "CHG State: " + r[fields.index('status')]
        results[i] = r
    cur.close()
    return (f"Here are CHGs from the last {last_X_days} days.",results if len(results) > 0 else f"No CHGs found in the last {last_X_days} days.")

def chg_algo(args):
    query=args.get('category', "")
    query = query.lower()
    tasks = "You needed to perform following task(s) : \n"
    if 'isb' in query or 'banner' in query or 'aop' in query:
        tasks = tasks + " - Bannering OF AARP and UHCM Medsupp \n - Perform Cache Clear \n - Unbannering OF AARP and UHCM Medsupp \n - Perform Cache Clear Again!"
    elif 'healthsafe' in query :
        tasks = tasks + " - Perform the Manual checkout on Shopper Profile and Visitor profile flow"
    elif 'digital' in query :
        tasks = tasks + " - Perform Complete GPD Application Probes Suppresion \n - Perform Cache Clear \n - Perform Complete Application Checkouts \n - Run Cache Rebuild Scripts"
    elif 'gps' in query or  'compas' in query :
        tasks = tasks + " - Perform the Manual checkout on OLE flow and Submit TEST OLE !"
    elif 'server' in query or 'rxweb' in query:
        tasks = tasks + " - Perform Cache Clear \n - Perform Complete Application Checkouts \n - Ask Rahul Gupta if there is any adhoc task required to perform"
    elif 'gpd' in query or 'mnr' in query or 'lpm' in query:
        tasks = tasks + " - Perform Cache Clear \n - Perform Complete Application Checkouts \n - Ask Rahul Gupta if there is any adhoc task required to perform"
    else:
        return 'For furher assistance with this Change tasks contact Mulla M. or Sindhe VenkatPrakash'
    
    tasks = tasks + " \n - Perform the System Stability Check and report if any anomaly Found ! "
    return tasks

def get_ole_count(args):
    url = "https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/cache-admin-api/ole_totalOleCount"

    payload = {
            "urls": args.get('from_to', "2025-04-02"),
            "url": args.get('from_date', "2025-04-02"),
        }
    headers = {
    'cookie': "dtCookie=v_4_srv_9_sn_2D6E86768C6F29756FAC4B5B3E3169AF_perc_100000_ol_0_mul_1_app-3A4a91485632b51fef_1_app-3Ae0e66f0f4bc69ba4_1",
    'Content-Type': "application/json"
    }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers,verify="./standard_trusts.pem")

    print(response.text)
    return response.json()['totalOleCountListDto']


def get_crux_report(args):
    url = "http://mr-portals-monitoring.optum.com/elasticsearch/google_psi*/_search"

    querystring = {"ignore_throttled":"false"}
    print(args)
    
    payload = {"query": { "bool": {"must_not": [{"match_phrase": {"strategy.keyword": "desktop"}} ], "filter": [{"range": {"startTime": {"time_zone": "America/Chicago","gte":args.get('from_date', "now-1d/d/d-8d/d") ,"lte": args.get('to_date', "now-1d/d") ,"format": "strict_date_optional_time"}}},{"match_phrase": {"Env.keyword": "Online - Prod"}},{"match_phrase": {"Application.keyword": "AMP"}},{"match_phrase": {"VBF":args.get('VBF', "DCE")}}],"should": []}},"aggs": {"dates": {"date_histogram": {"field": "startTime","fixed_interval": "1d","time_zone": "US/Central","min_doc_count": 0},"aggs": {"crux_interaction_to_next_paint": {"avg": {"field": "crux_interaction_to_next_paint"}},"crux_cumulative_layout_shift_score": {"avg": {"field": "crux_cumulative_layout_shift_score","script": {"lang": "painless","source": "doc['crux_cumulative_layout_shift_score'].value /100.0"}}},"crux_experimental_time_to_first_byte": {"avg": {"field": "crux_experimental_time_to_first_byte","script": {"lang": "painless","source": "doc['crux_experimental_time_to_first_byte'].value /1000.0"}}},"crux_first_contentful_paint_ms": {"avg": {"field": "crux_first_contentful_paint_ms","script": {"lang": "painless","source": "doc['crux_first_contentful_paint_ms'].value /1000.0"}}},"crux_largest_contentful_paint_ms": {"avg": {"field": "crux_largest_contentful_paint_ms","script": {"lang": "painless","source": "doc['crux_largest_contentful_paint_ms'].value /1000.0"}}},"crux_first_input_delay_ms": {"avg": {"field": "crux_first_input_delay_ms"}}}}}}
    #payload = "{\"query\":{\"bool\":{\"must\":[{\"match_phrase\":{\"strategy.keyword\":\"desktop\"}}],\"filter\":[{\"range\":{\"startTime\":{\"time_zone\":\"America/Chicago\",\"gte\":\"now-1d/d/d-8d/d\",\"lte\":\"now-1d/d\",\"format\":\"strict_date_optional_time\"}}},{\"match_phrase\":{\"Env.keyword\":\"Online - Prod\"}},{\"match_phrase\":{\"Application.keyword\":\"AMP\"}},{\"match_phrase\":{\"VBF\":\"DCE\"}}],\"should\":[]}},\"aggs\":{\"dates\":{\"date_histogram\":{\"field\":\"startTime\",\"fixed_interval\":\"1d\",\"time_zone\":\"US/Central\",\"min_doc_count\":0},\"aggs\":{\"crux_interaction_to_next_paint\":{\"avg\":{\"field\":\"crux_interaction_to_next_paint\"}},\"crux_cumulative_layout_shift_score\":{\"avg\":{\"field\":\"crux_cumulative_layout_shift_score\",\"script\":{\"lang\":\"painless\",\"source\":\"doc['crux_cumulative_layout_shift_score'].value /100.0\"}}},\"crux_experimental_time_to_first_byte\":{\"avg\":{\"field\":\"crux_experimental_time_to_first_byte\",\"script\":{\"lang\":\"painless\",\"source\":\"doc['crux_experimental_time_to_first_byte'].value /1000.0\"}}},\"crux_first_contentful_paint_ms\":{\"avg\":{\"field\":\"crux_first_contentful_paint_ms\",\"script\":{\"lang\":\"painless\",\"source\":\"doc['crux_first_contentful_paint_ms'].value /1000.0\"}}},\"crux_largest_contentful_paint_ms\":{\"avg\":{\"field\":\"crux_largest_contentful_paint_ms\",\"script\":{\"lang\":\"painless\",\"source\":\"doc['crux_largest_contentful_paint_ms'].value /1000.0\"}}},\"crux_first_input_delay_ms\":{\"avg\":{\"field\":\"crux_first_input_delay_ms\"}}}}}}"
    headers = {'Content-Type': 'application/json'}

    response = requests.request("GET", url, json=payload, headers=headers, params=querystring) 
    print(response.text)
    return response.json()["aggregations"]["dates"]["buckets"][0]

def get_performance_report(args):
    try:
        url = "http://mr-portals-monitoring.optum.com/elasticsearch/user_actions*/_search"

        querystring = {"ignore_throttled":"false"}
        print(args)
        
        payload = { "size": 0,"query": {"bool": {"must": [],"filter": [{"range": {"startTime": {"format": "strict_date_optional_time","gte": args.get('from_date', "now-1d/d/d-8d/d") ,"lte": args.get('to_date', "now-1d/d")}}},{"bool": {"must": [],"filter": [{"bool": {"minimum_should_match": 1,"should": [{"match_phrase": {"vbf.keyword": "VPP"}},{"match_phrase": {"vbf.keyword": "TFN"}},{"match_phrase": {"vbf.keyword": "Home Page"}},{"match_phrase": {"vbf.keyword": "DCE"}},{"match_phrase": {"vbf.keyword": "PRE"}},{"match_phrase": {"vbf.keyword": "OLE"}},{"match_phrase": {"vbf.keyword": "Shop"}},{"match_phrase": {"vbf.keyword": "Provider Search"}},{"match_phrase": {"vbf.keyword": "MedEd"}},{"match_phrase": {"vbf.keyword": "VPP - MedSupp"}},{"match_phrase": {"vbf.keyword": "Visitor Profile"}},{"match_phrase": {"vbf.keyword": "SiteSearch"}}]}},{"bool": {"minimum_should_match": 1,"should": [{"match_phrase": {"application.keyword": "Online - aarpmedicareplans.com"}},{"match_phrase": {"application.keyword": "Online - uhcmedicaresolutions.com"}}]}},{"match_phrase": {"supported_browser": True}}],"should": [],"must_not": []}}],"should": [],"must_not": []}},"aggs": {"0":{"terms": {"field": "vbf.keyword","size": 50,"shard_size": 25},"aggs": {"90th Percentile Performance": { "percentiles": {"field": "performanceMetric","percents": [90],"script": {"lang": "painless","source": "doc['performanceMetric'].value /1000.0"}}},"Median Performance": { "percentiles": {"field": "performanceMetric","percents": [50],"script": {"lang": "painless","source": "doc['performanceMetric'].value /1000.0"}}}}}}}
        headers = {'Content-Type': 'application/json'}
        print(json.dumps(payload))

        response = requests.request("GET", url, json=payload, headers=headers, params=querystring) 
        print(response.text)
        return response.json()["aggregations"]["0"]["buckets"]
    except Exception as e:
        print(f"Error in getting performance report: {str(e)}")
        return str(e)
    
def get_splunk_report(args):
    try:
        url = "http://mr-portals-monitoring.optum.com/elasticsearch/splunk-status-codes*/_search"

        querystring = {"ignore_throttled":"false"}
        print(args)
        
        payload = {"aggs": {"0": {"terms": {"field": "VBF.keyword","size": 50},"aggs": {"4xx Count": {"sum": {"field": "4xx_count"}},"Total Traffic": {"sum": {"field": "count"}},"5xx Count": {"sum": {"field": "5xx_count"}},"4xx Percent": {"bucket_script": {"buckets_path": {"fourxx": "4xx Count","total": "Total Traffic"},"script": "params.fourxx / params.total * 100"}},"5xx Percent": {"bucket_script": {"buckets_path": {"fivexx": "5xx Count","total": "Total Traffic"},"script": "params.fivexx / params.total * 100"}}}}},"size": 0,"query": {"bool": {"must": [],"filter": [{"bool": {"must": [],"filter": [{"bool": {"minimum_should_match": 1,"should": [{"match_phrase": {"application.keyword": "AMP"}},{"match_phrase": {"application.keyword": "UMS"}}]}},{"match_phrase": {"env.keyword": "Online - Prod"}}],"should": [],"must_not": []}},{"range": {"startTime": {"format": "strict_date_optional_time","gte": args.get('from_date', "now-1d/d/d-8d/d") ,"lte": args.get('to_date', "now-1d/d")}}}],"should": [],"must_not": []}}}
        headers = {'Content-Type': 'application/json'}

        response = requests.request("POST", url, json=payload, headers=headers, params=querystring) 
        print(response.text)
        return response.json()["aggregations"]["0"]["buckets"]
    except Exception as e:
        print(f"Error in getting splunk report: {str(e)}")
        return str(e)


def get_hourglass_repo_riskiness(args):
    # http://comprehensivedashboard-core-elr.optum.com/assets/hourglass-data/repoLateCommits.json
    repo_res = requests.get("http://comprehensivedashboard-core-elr.optum.com/assets/hourglass-data/repoLateCommits.json",verify='./optum.pem')
    if repo_res.status_code != 200:
        return "Failed to get Hourglass Repo Riskiness. Please check the availability in http://comprehensivedashboard-core-elr.optum.com/"
    repo_data = repo_res.json()
    return repo_data

def get_release_milestone_info(args):
    blob_client = AzureBlobConnect()
    release_milestone_data = blob_client.get_blob('chatbot-store', 'release_milestones.csv')
    return release_milestone_data

def get_hourglass_metrics(args):
    blob_client = AzureBlobConnect()
    hourglass_metrics = blob_client.get_blob('chatbot-store', 'hourglass_metrics.txt')
    temp_message = "The only available data is for the March 5th release. Reach out to Ted Youel and the Hourglass team for more information.\n\n"
    return f"{temp_message}{hourglass_metrics}"

def get_feature_repo_conflicts(args):
    # http://comprehensivedashboard-core-elr.optum.com/assets/hourglass-data/repoLateCommits.json
    repo_res = requests.get("http://dashboard-api-core-elr.optum.com/api/featureConflicts",verify='./optum.pem')
    if repo_res.status_code != 200:
        return "Failed to get Hourglass Repo Riskiness. Please check the availability in http://comprehensivedashboard-core-elr.optum.com/"
    repo_data = repo_res.json()
    return repo_data

def get_gating_status(args):
    outdata = ""
    def rally_rel(outdata):
        url = f'{environment.get_tickets_endpoint()}/rally/Spartans/releases/current'
        response = requests.get(url,verify='./optum.pem').json()
        release = response[0]['Name']
        print(f"Using current release: {release}")
        outdata += f"Using current release: {release}\n"
        return release,outdata
    if len(release_names) == 0 or 'release' not in args:
        release,outdata = rally_rel(outdata)
    else:
        release = args['release']
        if release.lower() not in [r.lower() for r in release_names]:
            release,outdata = rally_rel(outdata)
    outdata += f"Release: {release}\n"
    url = f'http://dashboard-api-core-elr.optum.com/api/getGatingReportByRelease/{release}'
    print(url)
    repo_res = requests.get(url,verify='./optum.pem')
    if repo_res.status_code != 200:
        return "Failed to get Gating Status. Please check the availability in http://dashboard-api-core-elr.optum.com/"
    repo_data = repo_res.json()
    if 'teams' in args:
        teams = args['teams']
        temp_repo_data = [r for r in repo_data if r['teamName'].lower() in (teams.lower() if type(teams) == str else [t.lower() for t in teams])]
        repo_data = temp_repo_data if len(temp_repo_data) > 0 else repo_data
    for r in repo_data:
        outdata += f"Release: {r['releaseName']}, Feature: {r['formatedId']}, Team: {r['teamName']}, Gate Status: {r['gateStatus'] if r['gateStatus'] else 'No gating ran'}, Message: {r['message']}\n"
    return outdata

def get_portal_velocity(args):
    try:
        url = "http://dashboard-api-core-elr.optum.com/api/portalITVelocities"
        response = requests.get(url,verify='./optum.pem')
        if response.status_code != 200:
            return "Failed to get Portal Velocity. Please check the availability in http://dashboard-api-core-elr.optum.com/"
        res = response.json()['portalITVelocities']
        for team in res:
            for release in res[team]['releaseCounts']:
                for feature in res[team]['releaseCounts'][release]['components']:
                    val = 0
                    for us in res[team]['releaseCounts'][release]['components'][feature]:
                        try:
                            res[team]['releaseCounts'][release]['features'][feature] += float(us['planEstimate']) if 'planEstimate' in us and us['planEstimate'] else 0
                        except:
                            pass
                    res[team]['releaseCounts'][release]['components'][feature] = val
        return str(res)

    except Exception as e:
        return f"Failed to get Portal Velocity. Error: {str(e)}"

def get_mnr_portals_overview(args, logger=None):
    # return get_user_stories(search,args['vbf'],logger=logger)
    return get_mnr_site_overview(logger=logger)