from tools.ops.functions import *
from tools.rally.functions import *
from tools.vbf_list import vbf_list

tools = {
    "get_related_stories": {
        "type": "function",
        "description": "Use this to pull related user stories. Call this function any time a user is asking about any kind of problem or is looking for information from rally.",
        "parameters":{
                    "type": "object",
                    "properties": {
                        "vbf": {
                            "type": "string",
                            "description": f"This is the vital business function that the user is asking about. This is a string that is used to filter the user stories. The only vbf values the user can ask for are {vbf_list}."
                        }
                    }
                },
        "search": True,
        "logger": True,
        "function": get_related_stories
    },
    "get_architecture_info": {
        "type": "function",
        "description": "Use this to pull architecture document information. Call this function any time a user is asking about architecture, failover, webserver, micro apps, or system dependency information.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "search": True,
        "long_res": True,
        "function": get_architecture_info
    },
    "get_manual_checkout_info": {
        "type": "function",
        "description": "Use this to pull information on manual checkouts. Call this function only when a user is asking about manual checkouts or how to find problems with a zabbix probe.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "search": True,
        "long_res": True,
        "function": get_manual_checkout_info
    },
    "get_contact_info": {
        "type": "function",
        "description": "Only use this when someone is asking for a person's contact information. That being the persons phone number, email id, or if they are onshore or offshore. This will return the contact information for the person that is asked about.",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": f"The name of the person you are looking for."
                }
            }
        },
        "search": True,
        "function": get_contact_info
    },
    "get_dynatrace_problems":{
            "type": "function",
            "description": "Use this to pull the active or open Dynatrace ( dtsaas ) problems  .This should be used always when the user is asking about any open or active Dynatrace or Dtsaas problems , it will return list of problems detected by dynatrace .",
             "parameters": {},
             "search": True,
        "long_res": True,
        "function": get_dynatrace_problems   
               
        },
    "get_quick_links": {
        "type": "function",
        "description": "Use this to pull quick links. Call this function any time a user is asking about links or quick links.",
        "parameters": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": f"If the user is asking for a specific category of links, you can provide that here. The only categories that are currently supported are Splunk,Dynatrace,Azure,Zabbix,Other."
                }
            }
        },
        "search": True,
        "long_res": True,
        "function": get_quick_links_info
    },
    "get_latest_inc": {
        "type": "function",
        "description": "Use this to pull last week worth of incidents from Servicenow. Call this function without any parameters.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_latest_inc
    },
    "get_latest_prb": {
        "type": "function",
        "description": "Use this to pull last 30 days worth of PRB tickets from Servicenow. Call this function without any parameters.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_latest_prb
    },
    "get_latest_chg": {
        "type": "function",
        "description": "Use this to pull last 30 days worth of CHG tickets from Servicenow. Call this function without any parameters.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_latest_chg
    },
     "chg_algo": {
        "type": "function",
        "description": "Only use this when want to pull change (CHG) tickets tasks from Servicenow. Call this function with task description.",
        "parameters": {
            "type": "object",
           "properties": {
                "category": {
                    "type": "string",
                    "description": f"Provide the complete change (CHG) ticket description without any manipulation."
                }
            }
        },
        "search": True,
        "outdata":True,
        "function": chg_algo
    },
    "get_ole_count": {
        "type": "function",
        "description": "This will return the online enrollment (ole) count for a specifict date or date range . Types of OLE are jarvis,rvo,uhcgr(group retiree),T65,uhccp,consumer(default).",
        "parameters": {
            "type": "object",
            "properties": {
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01"
                }
            }
        },
        "function": get_ole_count
    },
    "get_crux_report": {
        "type": "function",
        "description": "This will return the crux or seo metrics a specific vbf in datetime range . Types of VBF are ."+ str(vbf_list),
        "parameters": {
            "type": "object",
            "properties": {
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                 "VBF": {
                    "type": "string",
                    "description": "The VBF key for the query. Fill this field with Uppercase if the user specifies the VBF from as follows: "+ str(vbf_list)
                }
            }
        },
        "function": get_crux_report
    },
    "get_performance_report": {
        "type": "function",
        "description": "This will return the page performance scores in datetime range.",
        "parameters": {
            "type": "object",
            "properties": {
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                #  "VBF": {
                #     "type": "string",
                #     "description": "The VBF key for the query. Fill this field with Uppercase if the user specifies the VBF from as follows: "+ str(vbf_list)
                # }
            }
        },
        "function": get_performance_report
    },
    "get_splunk_report": {
        "type": "function",
        "description": "This will return the 4xx traffic and 5xx traffic or the HTTP traffic by VBF in datetime range.",
        "parameters": {
            "type": "object",
            "properties": {
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2025-05-01T09:37:01.754Z"
                },
                #  "VBF": {
                #     "type": "string",
                #     "description": "The VBF key for the query. Fill this field with Uppercase if the user specifies the VBF from as follows: "+ str(vbf_list)
                # }
            }
        },
        "function": get_splunk_report
    },
    "get_hourglass_repo_riskiness": {
        "type": "function",
        "description": "Use this to pull the riskiness of github repos using Hourglass metrics. This should be used when the user is asking about Hourglass or when asking about repo riskiness.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_hourglass_repo_riskiness
    },
    "get_release_milestone_info": {
        "type": "function",
        "description": "Use this to pull release milestone information. This should be used when the user is asking about release milestones. Release milestones include [Sprint 1, Soft Code Freeze (SCF), Push to Redwood Dev, Intergration Sanity in Dev, Push to Redwood QA, QA&E - Sprint Hardening/Regression in QA (Redwood), UAT (Content / Accessibility/ Analytics) Non QA&E in QA (Redwood), Push to Stage (Redwood) for Perf Testing Only, Performance Test Scripting & Execution Stage (Redwood), Hard Code Freeze (HCF), Green Deployment (Redwood), Green Deployment Validation (Redwood), Go/NoGo, Deployment (Redwood)]",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "doc_count": 2,
        "function": get_release_milestone_info
    },
    "get_hourglass_metrics": {
        "type": "function",
        "description": "Use this to pull hourglass metrics. This should be used when the user is asking about hourglass metrics. This can also be used when asking about git velocity, branch score, or simplicity scores.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_hourglass_metrics
    },
    "get_user_stories": {
        "type": "function",
        "description": "Call this when a user asks for user stories. This will return all data for user stories that are asked about that a team is working on. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user stories for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "ai": {
                    "type": "string",
                    "description": "Make this True if the user is asking about any AI use. Make this empty if the user is not asking about AI."
                },
                "milestone": {
                    "type": "string",
                    "description": "Make this True if the user is asking about any milestone information. Make this empty if the user is not asking about milestone info."
                },
                "ppm": {
                    "type": "string",
                    "description": "Make this True if the user is asking about PPM projects or PPM IDs. Make this empty if the user is not asking about PPM."
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_stories
    },
    "get_user_stories_no_acceptance_criteria": {
        "type": "function",
        "description": "This will return all data for user stories that are missing the acceptance criteria. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user stories for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_stories_no_acceptance_criteria
    },
    # "get_user_stories_no_description": {
    #     "type": "function",
    #     "description": "This will return all data for user stories that are missing the description. The user stories can also be filtered by date, iteration, release, or feature.",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "team": {
    #                 "type": "string",
    #                 "description": f"The team the user wants user stories for."
    #             },
    #             "iteration": {
    #                 "type": "string",
    #                 "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
    #             },
    #             "release": {
    #                 "type": "string",
    #                 "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
    #             },
    #             "feature": {
    #                 "type": "string",
    #                 "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
    #             },
    #             "from_date": {
    #                 "type": "string",
    #                 "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
    #             },
    #             "to_date": {
    #                 "type": "string",
    #                 "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
    #             }
    #         }
    #     },
    #     "function": get_user_stories_no_description
    # },
    "get_user_story_estimates": {
        "type": "function",
        "description": "This will return only the estimates for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user story estimates for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_story_estimates
    },
    "get_user_story_descriptions": {
        "type": "function",
        "description": "This will return only the descriptions for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user story descriptions for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_story_descriptions
    },
    "get_user_story_states": {
        "type": "function",
        "description": "This will return only the work progress states for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user story states for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_story_states
    },
    "get_user_story_acceptance_criteria": {
        "type": "function",
        "description": "This will return only the acceptance criteria for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user story acceptance criterias for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "feature": {
                    "type": "string",
                    "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_user_story_acceptance_criteria
    },
    "get_features": {
        "type": "function",
        "description": "This will return all data for features that are asked about that a team is working on. The features can also be filtered by date, or release.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants features for. The only teams that can be used are listed before."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "ai": {
                    "type": "string",
                    "description": "Make this True if the user is asking about any AI use. Make this empty if the user is not asking about AI."
                },
                "milestone": {
                    "type": "string",
                    "description": "Make this True if the user is asking about any milestone information. Make this empty if the user is not asking about milestone info."
                },
                "ppm": {
                    "type": "string",
                    "description": "Make this True if the user is asking about PPM projects or PPM IDs. Make this empty if the user is not asking about PPM."
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_features
    },
    "get_features_states": {
        "type": "function",
        "description": "This will return the work progress state data for features that are asked about. The features can also be filtered by date, or release.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants the work progress state of features for. The only teams that can be used are listed before."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_features_states
    },
    "get_features_plan_estimates": {
        "type": "function",
        "description": "This will return the plan estimates for features that are asked about. The features can also be filtered by date, or release.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants the plan estimates of features for. The only teams that can be used are listed before."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_features_plan_estimates
    },
    "get_current_iterations": {
        "type": "function",
        "description": "Use this when a user asks for current iteration or sprint. This will return the name and dates for the recent iterations for a team.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants the current iteration for. The only teams that can be used are listed before."
                }
            }
        },
        "function": get_current_iterations
    },
    "get_current_releases": {
        "type": "function",
        "description": "Use this when a user asks for what is the current release. This will return the name and dates for the recent releases for a team.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants the current release for. The only teams that can be used are listed before."
                }
            }
        },
        "function": get_current_releases
    },
    "get_rally_obj_info": {
        "type": "function",
        "description": "Get information for a rally object. The user must give an object ID. Determine if the object is a user story, feature, defect or capability.",
        "parameters": {
            "type": "object",
            "properties": {
                "FormattedID": {
                    "type": "string",
                    "description": f"The id given for the object. Examples: US123456, F123456, DE123456, C123456. Do not make up object IDs."
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_rally_obj_info
    },
    "get_rally_obj_info_no_id": {
        "type": "function",
        "description": "Get information for a rally object. The user must be looking for features or user stories without providing an ID. Only call this when the user is describing a task",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "search": True,
        "function": get_rally_obj_info_no_id
    },
    "get_allowed_teams": {
        "type": "function",
        "description": "This will return the teams that are allowed to be queried with this chatbot.",
        "parameters": {},
        "function": get_allowed_teams
    },
    "get_defects": {
        "type": "function",
        "description": "This will return all data for defects that are asked about that a team is working on. The defects can be filtered by date, iteration, or release.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants user stories for."
                },
                "iteration": {
                    "type": "string",
                    "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_defects
    },
    "get_release_defects": {
        "type": "function",
        "description": "This will return all data for defects in the next release. Use this when the user is asking about defects without specifying a team.",
        "parameters": {},
        "doc_count": 2,
        "long_res": True,
        "function": get_release_defects
    },
    "get_release_features": {
        "type": "function",
        "description": "This will return all data for features in the next release. Use this when the user is asking about defects without specifying a team.",
        "parameters": {
            "type": "object",
            "properties": {
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_release_features
    },
    # "get_accepted_features_plan_estimates": {
    #    "type": "function",
    #     "description": "This will return the plan estimates for features that are complete or in an accepted state. The features can also be filtered by date, or release.",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "team": {
    #                 "type": "string",
    #                 "description": f"The team the user wants the plan estimates of features for. The only teams that can be used are listed before."
    #             },
    #             "release": {
    #                 "type": "string",
    #                 "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
    #             },
    #             "from_date": {
    #                 "type": "string",
    #                 "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
    #             },
    #             "to_date": {
    #                 "type": "string",
    #                 "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
    #             }
    #         }
    #     },
    #     "function": get_accepted_features_plan_estimates
    # },
    "get_gating_status": {
        "type": "function",
        "description": "Gets the gating information of work or features. Only call this when there is any questions about or asks for gating. Teams can be specified for searching for gating information.",
        "parameters": {
            "type": "object",
            "properties": {
                "teams": {
                    "type": "string",
                    "description": f"The team names to search for gating information."
                },
                "release": {
                    "type": "string",
                    "description": f"The release to search for gating information. Not required. Should be in the format of YEAR_Mon_dd_GPP-MRPR-Dev."
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_gating_status
    },
    "get_portal_velocity": {
        "type": "function",
        "description": "Gets the velocity information by teams. Only call this when there is any questions about or asks for velocity.",
        "parameters": {
            "type": "object",
            "properties": {
                "teams": {
                    "type": "string",
                    "description": f"The team names to search for velocity information."
                },
                "release": {
                    "type": "string",
                    "description": f"The release to search for velocity information. Not required. Should be in the format of YEAR_Mon_dd_GPP-MRPR-Dev."
                }
            }
        },
        "function": get_portal_velocity
    },
    "get_mnr_portals_overview": {
        "type": "function",
        "description": "Gets the Splunk error rate, the Dynatrace page performance metrics, and the Google CRUX metrics for the MNR portals broken into site and VBF. Call this when there is any questions about the MNR portals numbers, page speeds, error rates, or CRUX scores.",
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_mnr_portals_overview
    },
    "get_capabilites": {
        "type": "function",
        "description": "This will return all data for capabilites that are asked about that a team is working on. The capabilites can also be filtered by date, or release.",
        "parameters": {
            "type": "object",
            "properties": {
                "team": {
                    "type": "string",
                    "description": f"The team the user wants capabilites for. The only teams that can be used are listed before."
                },
                "release": {
                    "type": "string",
                    "description": "The release for a certain capability. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                },
                "from_date": {
                    "type": "string",
                    "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                },
                "to_date": {
                    "type": "string",
                    "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                }
            }
        },
        "doc_count": 2,
        "long_res": True,
        "function": get_capabilities
    },
}

