import re
import json
import hashlib
import requests

from environment import environment
from azure_funcs import *

def get_incidents(user_input,search,logger=None):
    try:
        pattern = r"\bINC\d+\b"
        outdata = ""
        matches = re.findall(pattern, user_input, re.IGNORECASE)  # Case-insensitive match
        if matches:
            print("Found:", matches[0])
            hashed_input_inc = hashlib.sha256(matches[0].encode()).hexdigest()
            # url = f'{environment.get_tickets_endpoint()}/incidents/similar?id=' + matches[0]
            similar_inc_base_url = f'{environment.get_tickets_endpoint()}/tickets/incidents/similar?id='
            similar_inc_url = similar_inc_base_url + hashed_input_inc
            response = requests.get(similar_inc_url,verify='./optum.pem')
            # print(response.content)
            if response.status_code != 200 : 
                cont =  response.content
            if response.status_code == 200 :
                data = json.loads(response.content)
                cont = "<br><br><strong>Similar Incident Tickets: </strong><br>"
                for d in data:
                    cont = cont + " "+ d["ID"] + f' [{int(d["Similarity score"]*100)}% Similar]' + "<br>"
                    if logger:
                        logger.add_incident(d["ID"])
                inc_base_url = f'{environment.get_tickets_endpoint()}/tickets/incidents/get?id='
                inc_url = inc_base_url + hashed_input_inc
                response = requests.get(inc_url,verify='./optum.pem')
                data = json.loads(response.content)
                search += data["description"] + ' '
        else :
            print("else")
            req_body = {
                "desc" : get_embeddings(user_input)
            }
            response = requests.post(f'{environment.get_tickets_endpoint()}/tickets/incidents/similar/list',data=json.dumps(req_body),verify='./optum.pem')
            if (response.status_code == 200):
                data = json.loads(response.content)
                # print(data)
                    
                cont = "<br><br><strong>Similar Incident Tickets: </strong><br>"
                for d in data[:5]:
                    print(d.keys())
                    short_desc = d['short_description'].replace('\n',' ')
                    short_desc = short_desc[:150] + '...' if len(short_desc) > 150 else short_desc
                    cont = cont + d['id'] + " " + short_desc + "<br>"
                    if logger:
                        logger.add_incident(d["id"])
                outdata = cont
        return outdata,search
    except Exception as e:
        print("Failed to get Incident Tickets ",e)
        return '',''
    
def get_problems(user_input,search,logger=None):
    try:
        pattern = r"\bPRB\d+\b"
        outdata = ""
        matches = re.findall(pattern, user_input, re.IGNORECASE)  # Case-insensitive match
        if matches:
            print("Found:", matches[0])
            hashed_input_prb = hashlib.sha256(matches[0].encode()).hexdigest()
            # url = f'{environment.get_tickets_endpoint()}/incidents/similar?id=' + matches[0]
            similar_prb_base_url = f'{environment.get_tickets_endpoint()}/tickets/problems/similar?id='
            similar_prb_url = similar_prb_base_url + hashed_input_prb
            response = requests.get(similar_prb_url,verify='./optum.pem')
            # print(response.content)
            if response.status_code != 200 : 
                cont =  response.content
            if response.status_code == 200 :
                data = json.loads(response.content)
                cont = "<br><br><strong>Similar Problem Tickets: </strong><br>"
                for d in data:
                    cont = cont + " "+ d["ID"] + f' [{int(d["Similarity score"]*100)}% Similar]' + "<br>"
                    if logger:
                        logger.add_problem(d["ID"])
                outdata =  cont + "You can find detailed information about each Similar Problem by using their ID :  https://hcccloud-uhgdlm-dtlapi-dev.uhc.com/lpm-gpd-tickets/."
                # urll = f'{environment.get_tickets_endpoint()}/prbidents/get?id=' + matches[0]
                prb_base_url = f'{environment.get_tickets_endpoint()}/tickets/problems/get?id='
                prb_url = prb_base_url + hashed_input_prb
                response = requests.get(prb_url,verify='./optum.pem')
                data = json.loads(response.content)
                search += data["description"] + ' '
        # ENDPOINT NOT YET DEFINED
        # else :
        #     print("else")
        #     req_body = {
        #         "desc" : get_embeddings(user_input)
        #     }
        #     response = requests.post(f'{environment.get_tickets_endpoint()}/problems/similar/list',data=json.dumps(req_body),verify='./optum.pem')
        #     if (response.status_code == 200):
        #         data = json.loads(response.content)
                    
        #         cont = "<br><br><strong>Similar Problem Tickets: </strong><br>"
        #         for d in data[:5]:
        #             print(d.keys())
        #             short_desc = d['short_description'].replace('\n',' ')
        #             short_desc = short_desc[:150] + '...' if len(short_desc) > 150 else short_desc
        #             cont = cont + d['id'] + " " + short_desc + "<br>"
                    # if logger:
                    #     logger.add_problem(d["id"])
        #         outdata = cont
        return outdata,search
    except Exception as e:
        print("Failed to get Problem Tickets ",e)
        return '',''

def get_us(search,vbf=None,logger=None):
    try:
        url = f'{environment.get_tickets_endpoint()}/tickets/rally/get' #?desc='+ str(get_embeddings(search)) + '&vbf=' + v
        req_body = {
            "desc" : get_embeddings(search),
            "vbf": vbf
        }
        if vbf and logger:
            logger.set_vbf(vbf)
        print(url)
        response = requests.post(url,data=json.dumps(req_body),verify='./optum.pem')
        if (response.status_code == 200):
            datas = json.loads(response.content)
            #print(data)
            if len(datas) > 0:
                print('\n\n',datas[0],'\n\n')
                outdata = " <br>" + "<strong>Recent User Stories</strong> :"
                for data in datas[:2]:
                    outdata += " <br>" + data['FormattedID'][0] + " ⦂ "+ data["FeatureName"][0] + " worked By <strong>"+ data["Project"][0] +"</strong>" 
                    outdata += "<br>"
                    if logger:
                        logger.add_story(data['FormattedID'][0])
                return outdata
    except Exception as e:
        print("Failed to get User Stories ",e)
    return ''
        
def query_quick_links(category=None):
    try:
        url = f'{environment.get_tickets_endpoint()}/tickets/quick_links{"" if category is None else "?category="+category}' 
        response = requests.get(url,verify='./optum.pem')
        if (response.status_code == 200):
            datas = json.loads(response.content)
            return datas
    except Exception as e:
        print("Failed to get Quick Links ",e)
    return 'Failed to get Quick Links'

def get_rally_obj(search,logger=None):
    try:
        url = f'{environment.get_tickets_endpoint()}/tickets/rally/obj' 
        req_body = {
            "desc" : get_embeddings(search)
        }
        print(url)
        response = requests.post(url,data=json.dumps(req_body),verify='./optum.pem')
        if (response.status_code == 200):
            data = json.loads(response.content)
            return f"This feature and user story data was found: {data}" if len(data) > 0 else "No feature or user story data was found."
    except Exception as e:
        print("Failed to get similar Rally datas ",e)
    return ''

def get_latest_releases():
    url = f'{environment.get_tickets_endpoint()}/rally/releases'
    res = requests.get(url,verify='./optum.pem')
    return f"Recent Releases found: {res.json()}"

def get_latest_iterations():
    url = f'{environment.get_tickets_endpoint()}/rally/iterations'
    res = requests.get(url,verify='./optum.pem')
    return f"Recent Iterations found: {res.json()}"

def get_mnr_site_overview(logger=None):
    url = f'{environment.get_tickets_endpoint()}/tickets/mnr_portals_overview'
    print(f"IN MNR SITE OVERVIEW - {url}")
    res = requests.get(url,verify='./optum.pem')
    if (res.status_code == 200):
        data = json.loads(res.content)
        return data
    return 'Failed to get MNR Site Overview'