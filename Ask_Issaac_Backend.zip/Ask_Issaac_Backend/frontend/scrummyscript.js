const title_text = String(document.getElementById("page-title").innerText)
console.log(title_text)
const DEVELOPMENT = title_text.includes('DEVELOPMENT')
const TOP_SCRUM = title_text.includes("TOP SCRUM")

var send_icon = document.getElementsByClassName("send-icon")[0];
var input = document.getElementsByClassName("InputMSG")[0];
var ContentChat = document.getElementsByClassName("ContentChat")[0];
var san1 = document.getElementById("send1");
var san2 = document.getElementById("send2");
var randid = 1


send_icon.addEventListener("click", SendMsgUser);

input.addEventListener("keydown", (e) => {
  if (e.key == "Enter") {
    SendMsgUser();
  }
});

//With the help of this parameter, we can find out whether the function status_func_SendMsgBot is difficult to send a message or not (0 = no | 1 = yes)
var status_func_SendMsgBot = 0;

// Function Send Massage user in content chat
function SendMsgUser() {
  if (input.value != "" && status_func_SendMsgBot == 0) {
    send1.classList.add("none");
    send2.classList.remove("none");

    let elementCPT = document.createElement("div");
    elementCPT.classList.add("massage", "msgCaption");
    elementCPT.setAttribute("data-user", "true");
    elementCPT.innerHTML = '<span class="captionUser">You</span>';
    ContentChat.appendChild(elementCPT);

    let elementMSG = document.createElement("div");
    elementMSG.classList.add("massage");
    elementMSG.setAttribute("data-user", "true");

    // let userResponsiveDiv = document.createElement("div");
    // userResponsiveDiv.classList.add("user-response");
    // let textNode = document.createTextNode(input.value);
    // elementMSG.appendChild(textNode);
    // elementMSG.appendChild(userResponsiveDiv);
    elementMSG.innerHTML = `<div class="user-response">${input.value}</div>`;
    ContentChat.appendChild(elementMSG);
    
    SendMsgBot(input.value);
    input.value = "";
    //playSound();
  }
}

function replaceURLWithHTMLLinks(text) {
  var exp = /\[([^\]]*)\]\((https{0,1}:\/\/[^\ )]+)\)/ig;
  transformedText= text.replace(exp,`<a href='$2' target='_blank'>$1</a> `);
  var exp1 = /\[(.*)\]\(<a\s+href='(.*)'\s.*>.*\)/ig;
  const match = transformedText.matchAll(exp1);
  for (m of match){
      console.log(m[1])
      transformedText=transformedText.replace(m[0],"<a href='"+m[2]+"' target='_blank'>"+m[1]+"</a>")
  }
  return transformedText;
  //console.log(match[0])
  //transformedText = transformedText.replace(exp,`<a href='$2' target='_blank'>$1</a>$3`);
  //transformedText = transformedText.replace(exp,"<a href='$2' target='_blank'>$1</a>");

}

function replaceUsWithLinks(text){
  var exp = /(US[0-9]{6,8})/ig;
  let transformedText= text.replace(exp,`<a href='https://rally1.rallydev.com/#/search?keywords=$1' target='_blank'>$1</a>`);
  return transformedText;
}

function replaceDeWithLinks(text){
  var exp = /(DE[0-9]{5,8})/ig;
  let transformedText= text.replace(exp,`<a href='https://rally1.rallydev.com/#/search?keywords=$1' target='_blank'>$1</a>`);
  return transformedText;
}

function replaceTextWithLinks(text){
  return replaceURLWithHTMLLinks(replaceDeWithLinks(replaceUsWithLinks(text)));
}

function replaceDoubleAsterisksWithStrong(inputString) {
    // Replace "**" with <strong> tags
    return inputString.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
}
// ---------------- Massage Bot ----------------

// Function Send Massage bot(Gurdians) in content chat
async function SendMsgBot(msg) {
  msg = msg.toLowerCase();
  msg = msg.replace(/<\s*br[^>]?>/, "\n");
  msg = msg.replace(/(<([^>]+)>)/g, "");

  status_func_SendMsgBot = 1;
  //playSoundtype(1);

  let elementCPT = document.createElement("div");
  elementCPT.classList.add("captionBot", "msgCaption");
  // elementCPT.innerHTML =
  //   `<img src="${DEVELOPMENT ? '':'/lpm-gpd-chatbot'}/logo" alt="Gurdians"> <span>Guardians</span>`;
  // ContentChat.appendChild(elementCPT);

  let elementMSG = document.createElement("div");
  elementMSG.classList.add("massage");
  elementMSG.innerHTML = `<div class="bot-response text" text-first="true"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="30px" viewBox="0 0 24 30" style="enable-background:new 0 0 50 50;" xml:space="preserve"> <rect x="0" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="10" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.2s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="20" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.4s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> </svg></div>`;
  ContentChat.appendChild(elementMSG);

  let result="";
  // var settings = {
  //   "url": "http://127.0.0.1:8080/get?msg="+msg,
  //   "method": "GET"
  // };
    randid = randid+1;
await $.ajax({
    url:`${DEVELOPMENT ? '':'/lpm-gpd-chatbot'}/questions`, //"https://cloud-uhgdlm-dtlapi-stg.uhc.com/lpm-gpd-chatbot/questions", //url:"https://cloud-uhgdlm-dtlapi-stg.uhc.com/lpm-gpd-chatbot/get?msg="+msg,
    type:"GET",
    complete: function(response){
        console.log(response);
        if( response.status !=200){
            result = `<div class="bot-response text" text-last="true">😵‍💫 Oops! Sorry, I didn't understand your question</div>`;
        }
        else{
            result=`<pre class="bot-response text" id="`+ randid.toString()+`" text-last="true"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="30px" viewBox="0 0 24 30" style="enable-background:new 0 0 50 50;" xml:space="preserve"> <rect x="0" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="10" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.2s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="20" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.4s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> </svg></pre>`; //`+response.responseText+`
        }
        
        result = replaceTextWithLinks(result);
        console.log(result);


    elementMSG.innerHTML = result;
    
    send1.classList.remove("none");
    send2.classList.add("none");
    status_func_SendMsgBot = 0;


   ContentChat.appendChild(elementMSG);

    }
})

await format_message(msg,randid.toString())
  
result = "";
    
}

function overlay(){
  //document.querySelector('.overlay').style.display = 'none';
  let elementCPT = document.createElement("div");
  elementCPT.classList.add("captionBot", "msgCaption");
  const img23 = document.createElement('img');
  img23.src = `${DEVELOPMENT ? '':'/lpm-gpd-chatbot'}/logo`;
  img23.alt= "Guardians";
  const span23 = document.createElement('span');
  span23.textContent = 'Guardians';
  /*elementCPT.innerHTML =
    `<img src="{{ url_for('static', filename='chatbot.jpg') }}" alt="Gurdians"> <span>Guardians</span>`;
  ContentChat.appendChild(elementCPT);*/
  elementCPT.append(img23, span23);

  setTimeout(() => {
    elementMSG.innerHTML = `<div class="bot-response text" text-first="true">Hi 👋 ! It's good to see you!</div><div class="bot-response text" text-last="true">How can I help you with the Top Scrum 2.0 game?</div>`;
    send1.classList.remove("none");
    send2.classList.add("none");
    status_func_SendMsgBot = 0;
    //if(confirm("do you want to continue")){
        //var sound = document.getElementById("welcome1");
        //playSoundtype(0);
        //sound.play();
  //  }
   
   
  },2000)


  let elementMSG = document.createElement("div");
  elementMSG.classList.add("massage");
  elementMSG.innerHTML = `<div class="bot-response text" text-first="true"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="30px" viewBox="0 0 24 30" style="enable-background:new 0 0 50 50;" xml:space="preserve"> <rect x="0" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="10" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.2s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> <rect x="20" y="0" width="4" height="10" fill="rgb(155, 166, 178)"> <animateTransform attributeType="xml" attributeName="transform" type="translate" values="0 0; 0 20; 0 0" begin="0.4s" dur="0.6s" repeatCount="indefinite"> </animateTransform> </rect> </svg></div>`;
  ContentChat.appendChild(elementMSG);

  status_func_SendMsgBot = 1;
  send1.classList.add("none");
  send2.classList.remove("none");
}

overlay();
function format_message(text_input,idx){
// Fetch the event stream from the server
var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};
last_letter='a';
const completion_api = TOP_SCRUM ? 'api/scrum' : 'get'
var source = new EventSource(`${DEVELOPMENT ? '':'/lpm-gpd-chatbot'}/${completion_api}?msg=`+text_input) //'https://cloud-uhgdlm-dtlapi-stg.uhc.com/lpm-gpd-chatbot/get?msg='
      source.onopen = (e) => {console.log("Connection opened");document.getElementById(idx).innerHTML="";}
      source.onerror = (e) => console.log("Error:", event)
      source.onmessage = (e) => {
        if (event.data !== "[DONE]") {
        //console.log(event.data);
        //msg.replace(/<\s*br[^>]?>/, "\n");
        var ok = event.data
        // document.getElementById(idx).innerHTML += (isNaN(ok.substring(1))==false && (last_letter=='.' || last_letter=='*' || last_letter==")"))?'<br>' + ok.substring(1):ok.substring(1);
        document.getElementById(idx).innerHTML += ok.substring(1);
        last_letter=ok.substring(1).slice(-1);
        } else {
          console.log("Connection closed")
              var format_ok = document.getElementById(idx).innerText;
    format_ok= replaceDoubleAsterisksWithStrong(replaceTextWithLinks(format_ok));
    
    // var element = document.getElementById(idx);
    // element.innerHTML = '';
    // var textNode = document.createTextNode(format_ok);
    // element.appendChild(textNode);

    document.getElementById(idx).innerHTML = format_ok;
          source.close()
        }
      }

}
