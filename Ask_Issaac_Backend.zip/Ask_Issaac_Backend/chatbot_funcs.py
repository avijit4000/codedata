import datetime
import requests
import pytz
import json

#import tiktoken
def get_token_length(message: str, model_name="gpt-4o") -> int:
    encoding = tiktoken.encoding_for_model(model_name)
    tokens = encoding.encode(message)
    return len(tokens)


from azure_funcs import *
from tickets_funcs import *
from top_scrum_funcs import *
from system_messages import *
from environment import environment

from chatbot_logging import ChatbotLogger

from ops_chatbot.tool_calling import ops_tool_call, ops_rally_tool_call

vbf_list =[]
contact_list = []
pre_contact = "Scrum Team :	Primary Contact	Secondary Contact	Engineering Manager ( EM )	Tech Lead ( TL )	Scrum Master / Systems Analyst	Engineering - Delivery Director	Digital Test Lead / Digital Test Analyst 	Developers / Engineers	Product Owner	automation ( QE ) 	distribution list ( DL ) or team email; \n"
def load_teams_from_file():
    blob_client = AzureBlobConnect()
    teams = blob_client.get_blob('chatbot-store', 'teamcontact.txt')
    vbfs = blob_client.get_blob('chatbot-store', 'vbfkey.txt')
    #print(vbfs)
    for line in teams.split('\n'):
        contact_list.append(line.strip())
    for line in vbfs.split('\n'):
        vbf_list.append(line.strip().split(','))
  
def vbf_parse(search):
    if len(vbf_list) == 0 or len(contact_list) == 0:
        load_teams_from_file()
    vbf = None
    team_contact = ""
    for v in range(len(vbf_list)):
        #print(v)
        if not vbf:
            for vi in vbf_list[v]:   
                if vi in search.lower():
                    # print(f"VBF Found: {vbf_list[v][0]}")
                    vbf = vbf_list[v][0]
                    #team_contact += "You can reach out to : "+ pre_contact+ contact_list[v] +" \n"
                    team_contact += "\n For " + vbf + "/"+vi+" , you can reach out to team "+ contact_list[v].split(":")[0] +" \n" + pre_contact+ contact_list[v]
                    break
    print("contact info : ------------------------------- ",team_contact)
    return team_contact,vbf

print('Guardians Bot : Welcome to Internal Bot service made with innovation!!')
messages = [{"role": "system",
             "content": "You are an AI assistant [chatbot] to helps people find information. \
                you need to answer the question based on data provided by user. Just rephase \
                    and reformat the data user provided and avoid third person figure of speech.\
                        Include filepath in the end"}]


def get_chatbot_response(request):
    logger = ChatbotLogger('ops')
    logger.set_environment("Dev" if environment.DEVELOPMENT else "Prod")
    messages = [{"role": "system",
                 "content": ops_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}]

    user_input = request.args.get('msg')
    logger.set_question(user_input)
    user_input = get_ole_count_data(user_input)
    search = get_history_message(user_input,history)

    team_contact,vbf = vbf_parse(search)

    outdata,tools_data,long_res = ops_tool_call(user_input,search,logger=logger,team_contact=team_contact)
    outdata = outdata.replace('.0','.O').replace('<img','<p')
                # What are the key award points missed by Syed’s teams

    print(f"--Searching: {search} ------------")
    if "on call" in search.lower():
        search += ". Today is " + str(datetime.datetime.now().strftime('%A, %B %d, %Y'))

    vector_query = get_vectorized_query(search)
    fin_content= get_doc_content(search,[vector_query])
    print(tools_data)
    fin_content['content'] =  team_contact + fin_content['content']
    if tools_data :
        for tool_data in tools_data:
            fin_content['content'] += f"\n{tool_data}"
    messages.append(fin_content)
    # with open('messages.json', 'w') as f:
    #     json.dump(messages, f, indent=4)
    print(fin_content)
    return stream_chatbot_response(messages, openaii,outdata,long_res=long_res, logger=logger)

def get_scrum_response(request):
    logger = ChatbotLogger('topscrum')
    logger.set_environment("Dev" if environment.DEVELOPMENT else "Prod")
    messages = [{"role": "system",
                 "content": topscrum_chatbot_system_message}]

    user_input = request.args.get('msg')
    logger.set_question(user_input)
    with open('scrum_asks.txt', 'a') as f:
        f.write(user_input + '\n')
    # search = get_history_message(user_input,history)
    search = user_input

    top_scrum_scores,desc = search_top_scrum(user_input, logger=logger)
    outdata = ''
    if top_scrum_scores:
        # failed_items = []
        # vector_search_fails = False
        user_story_list = []
        user_story_outdata = ''
        search_extended = False
        for item in top_scrum_scores:
            # print(item)
            if 'Earned' in item and item['Earned'] == False:
                # vector_search_fails = True
                search += f"\nFailed call sign: {item['Call Sign']}: {item['Failed Reason']} ==> {item['Passing Formula']}"
                search_extended = True
            if 'User Stories' in item:
                if user_story_outdata == '':
                    user_story_outdata = f" <br><br><strong>User Stories By {item['Team'].split('#')[0] if '#' in item['Team'] else item['Team']} in Failed Call Signs</strong>:"
                for us in item['User Stories']:
                    if us not in user_story_list:
                        user_story_list.append(us)
        if len(user_story_list) < 12:
            for us in user_story_list:
                user_story_outdata += f"<br>{us}"
            if len(user_story_list) > 2:
                user_story_outdata += "<br>See more information with the <a target='_blank' href='https://uhgazure.sharepoint.com/sites/scrumtransformation/SitePages/Scoring-Assessment.aspx'>Q2E Tool</a>"
        else:
            user_story_outdata += f"<br>{user_story_list[0]}<br>{user_story_list[1]}<br>...{len(user_story_list)-2} more user stories<br>See more information with the <a target='_blank' href='https://uhgazure.sharepoint.com/sites/scrumtransformation/SitePages/Scoring-Assessment.aspx'>Q2E Tool</a>"
        
        messages += format_data_as_assistant(top_scrum_scores,desc)
        if search_extended:
            vector_query = get_vectorized_query(search,scrum=True)
            messages.append(get_doc_content(search,[vector_query],scrum=True))
        if len(top_scrum_scores) == 0:
            messages.append({'role':'assistant','content':f'Failed to find data for the following: {search}'})
        outdata += user_story_outdata
    else:
        vector_query = get_vectorized_query(search,scrum=True)
        messages.append(get_doc_content(search,[vector_query],scrum=True))
    # for top_scrum_score in top_scrum_scores:
    #     messages.append({'role':'assistant','content':f'Use this data to answer questions about Top Scrum scores: \n{top_scrum_score}'})
    

    print(f"--Searching: {search} ------------")

    print(messages)
    print(outdata)
    print(f"\nMessages Length - {len(messages)}")

    return stream_chatbot_response(messages, openaii, outdata=outdata, logger=logger)

def ole_count():
    central = pytz.timezone('US/Central')
    # current_time = datetime.datetime.now(central)
    url = 'https://cloud-uhgdlm-dtlapi-stg.uhc.com/gpd/data/ole/totalOleData?date=' + str(
        datetime.datetime.now(central) - datetime.timedelta(days=1))[:10]
    print(url)
    response = requests.get(url)
    # print(response.content)
    if (response.status_code != 200): return "Server is failed , contact Bijay for Lpm-admin server check."
    data = json.loads(response.content)
    value = data['totalOleDTOList'][-1]['totalole']
    return "Total Yesterday[" + str(datetime.datetime.now(central) - datetime.timedelta(days=1))[
                                :10] + "] OLE count :" + str(value)

def get_ole_count_data(user_input):
    if ("yesterday" in user_input and "count" in user_input):
        central = pytz.timezone('US/Central')
        # current_time = datetime.datetime.now(central)
        url = 'https://cloud-uhgdlm-dtlapi-stg.uhc.com/gpd/data/ole/totalOleData?date=' + str(
            datetime.datetime.now(central) - datetime.timedelta(days=1))[:10]
        print(url)
        response = requests.get(url)
        # print(response.content)
        if (response.status_code != 200): return "OLE Count request failed , contact the GPD-OPS team to check the server."
        data = json.loads(response.content)
        value = data['totalOleDTOList'][-1]['totalole']
        user_input += "data: aTotal Yesterday[" + str(datetime.datetime.now(central) - datetime.timedelta(days=1))[
                                    :10] + "] OLE count :" + str(value)
    return user_input

# Ops chatbot + rally merge
def get_chatbot_ops_rally_response(request,prt=False, prt_data=None,history=[]):
    logger = ChatbotLogger('opsrally')
    logger.set_environment("Dev" if environment.DEVELOPMENT else "Prod")
    messages = [{"role": "system",
                 "content": ops_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}]

    user_input = request.args.get('msg')
    logger.set_question(user_input)
    user_input = get_ole_count_data(user_input)

    search = get_history_message(user_input,history)

    team_contact,vbf = vbf_parse(search)

    outdata,tools_data,long_res = ops_rally_tool_call(user_input,search,logger=logger,history=history)

    outdata = outdata.replace('.0','.O').replace('<img','<p')

    print(f"--Searching: {search} ------------")
    if "on call" in search.lower():
        search += ". Today is " + str(datetime.datetime.now().strftime('%A, %B %d, %Y'))

    vector_query = get_vectorized_query(search)
    fin_content= get_doc_content(search,[vector_query], history=history)
    # print(fin_content)
    fin_content['content'] = fin_content['content'] + team_contact
    if tools_data:
        for tool_data in tools_data:
            fin_content['content'] += f"\n{tool_data}"
    messages.append(fin_content)
    # with open('messages.json', 'w') as f:
    #     json.dump(messages, f, indent=4)
    #print("TOKEN LENGTH: ", get_token_length(str(messages)))
    if prt:
        return single_chatbot_response(messages, openaii,outdata,long_res=long_res, logger=logger, prt_data=prt_data)
    return stream_chatbot_response(messages, openaii,outdata,long_res=long_res, logger=logger)
