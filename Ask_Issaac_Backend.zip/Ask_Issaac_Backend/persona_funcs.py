import datetime
import requests
import pytz
import json

#import tiktoken
def get_token_length(message: str, model_name="gpt-4o") -> int:
    encoding = tiktoken.encoding_for_model(model_name)
    tokens = encoding.encode(message)
    return len(tokens)


from azure_funcs import *
from tickets_funcs import *
from top_scrum_funcs import *
from system_messages import *
from environment import environment
from personas.personas import personas

from chatbot_logging import ChatbotLogger

from tools.tool_call import tool_call

vbf_list =[]
contact_list = []
lins = []
links_keys=[]
pre_contact = "Scrum Team :	Primary Contact	Secondary Contact	Engineering Manager ( EM )	Tech Lead ( TL )	Scrum Master / Systems Analyst	Engineering - Delivery Director	Digital Test Lead / Digital Test Analyst 	Developers / Engineers	Strategic Director	Product Manager	Product Analyst	Content Strategist	Content Producer	Project Manager	Product Owner	automation ( QE ) 	distribution list ( DL ) or team email; \n"
def load_teams_from_file():
    try:
        blob_client = AzureBlobConnect()
        teams = blob_client.get_blob('chatbot-store', 'teamcontact.txt')
        vbfs = blob_client.get_blob('chatbot-store', 'vbfkey.txt')
        store_link = blob_client.get_blob('chatbot-store', 'links.txt')
        #print(vbfs)
        for line in teams.split('\n'):
            contact_list.append(line.strip())
        for line in vbfs.split('\n'):
            vbf_list.append(line.strip().split(','))
        for lii in store_link.split('\n'):
            lida =lii.strip().split(':=')
            if len(lida)>1:
                lins.append(lida[1])
                links_keys.append(lida[0].split(','))
    except Exception as e:
        print("Failed to load teams from file ",e)

# history = []
# def append_history(text):
#     history.append(text)
#     if len(history) > 4:
#         history.pop(0)

def links_parser(search):
    links_data = ' LINKS you might be looking  : '
    urlinfo=[]
    if len(lins)==0:
        load_teams_from_file()
    for l in range(len(lins)):
        for li in links_keys[l]:
            #print("\n\nLink KEy checking : ",li)
            #all(key.lower() in search.lower() for key in li.split(' '))
            if all(key.lower() in search.lower() for key in li.split(' ')): #li in search.lower():
                links_data = links_data + f"<br> <a href='{lins[l]}' target='_blank'>{links_keys[l][0]}</a>"  #["+ links_keys[l][0] + "]("+lins[l]+") 
                urlinfo.append({"url":lins[l],"keyword":links_keys[l][0]})
                break
    print("found link for sure : =========================",links_data)
    return links_data,urlinfo
        

def vbf_parse(search):
    if len(vbf_list) == 0 or len(contact_list) == 0:
        load_teams_from_file()
    vbf = None
    team_contact = ""
    for v in range(len(vbf_list)):
        if not vbf or vbf:
            for vi in vbf_list[v]:   
                # if vi in search.lower():
                #     print(f"VBF Found: {vbf_list[v][0]}")
                #     vbf = vbf_list[v][0]
                #     #team_contact += "You can reach out to : "+ pre_contact+ contact_list[v] +" \n"
                #     team_contact += "\n For " + vbf + "/"+vi+" , you can reach out to team "+ contact_list[v].split(":")[0] +" \n" + pre_contact+ contact_list[v]
                #     break
                if all(key.lower() in search.lower() for key in vi.split(' ')):
                    print(f"VBF Found: {vbf_list[v][0]}")
                    vbf = vbf_list[v][0]
                #     #team_contact += "You can reach out to : "+ pre_contact+ contact_list[v] +" \n"
                #     team_contact += "\n For " + vbf + "/"+vi+" , you can reach out to team "+ contact_list[v].split(":")[0] +" \n" + pre_contact+ contact_list[v]
                #     break
                    try:
                        team_contact += "\n For " + vbf + "/"+vi+" contact "
                        roles = pre_contact.split("\t")
                        contact_details = contact_list[v].split("\t")
                        
                        if len(contact_details) < 2 or len(roles) < 2:  
                            raise IndexError("Not enough details to map roles")
                            
                        #team_contact = ""
                        for i, role in enumerate(roles):
                            if i < len(contact_details):
                                team_contact += f"{role.strip()} : {contact_details[i].strip()}\n"
                            else:

                                raise IndexError("More roles than contact details")
                    
                    except (IndexError, Exception) as e:
                       
                        print(f"Falling back to old behavior due to: {str(e)}")
                        team_contact = "\n For " + vbf + "/"+vi+" , you can reach out to team "+ contact_list[v].split(":")[0] +" \n" + pre_contact + contact_list[v]
                    
                    break
                    
                    
    print("contact infos : ------------------------------- ",team_contact.replace('\t', '|'))
    #return str(contact_list),str(vbf_list)
    return team_contact.replace('\t', '|'),vbf

def rally_iteration_release_parse(search):
    res = ""
    if "iteration" in search.lower():
        res += "\n" + str(get_latest_iterations())
    elif "sprint" in search.lower():
        res += "\n" + str(get_latest_iterations())
    if "release" in search.lower():
        res += "\n" + str(get_latest_releases())
    return res

def get_ole_count_data(user_input):
    if ("yesterday" in user_input and "count" in user_input):
        central = pytz.timezone('US/Central')
        # current_time = datetime.datetime.now(central)
        url = 'https://cloud-uhgdlm-dtlapi-stg.uhc.com/gpd/data/ole/totalOleData?date=' + str(
            datetime.datetime.now(central) - datetime.timedelta(days=1))[:10]
        print(url)
        response = requests.get(url)
        # print(response.content)
        if (response.status_code != 200): return "OLE Count request failed , contact the GPD-OPS team to check the server."
        data = json.loads(response.content)
        value = data['totalOleDTOList'][-1]['totalole']
        user_input += "data: aTotal Yesterday[" + str(datetime.datetime.now(central) - datetime.timedelta(days=1))[
                                    :10] + "] OLE count :" + str(value)
    return user_input

def get_chatbot_persona_response(request,persona="ops",prt=False,prt_data=None,history=[],username=None):
    if persona in personas:
        persona_obj = personas[persona]
        logger = ChatbotLogger('persona',persona=persona)
        logger.set_environment("Dev" if environment.DEVELOPMENT else "Prod")
        messages = [{"role": "system",
                    "content": (persona_obj['system_message'] if 'system_message' in persona_obj else ops_chatbot_system_message)+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}]
        past_ques_query=""
        if len(history)>0:
            messages.extend(history)
            past_ques_query= history[-2]
            
        
        if 'search_client' in persona_obj:
            search_client = persona_obj['search_client']

        user_input = request.args.get('msg')
        # append_history(user_input)
        logger.set_question(user_input)
        
        if past_ques_query != "":
            user_input = "previously i have asked : "+past_ques-query+" \n\n Now help me currently with :" +user_input 
        
        if username and username.strip():
            logger.set_username(username.strip())
        else:
            logger.set_username("anonymous")
        
        user_input = get_ole_count_data(user_input)
        user_input += rally_iteration_release_parse(user_input)
        search = get_history_message(user_input,history)

        team_contact,vbf = "",""
        if persona_obj['vbf_contacts']:
            #team_contact,vbf = vbf_parse(user_input)
            pass
        lp,urlInfo="",[]
        team_contact,vbf = vbf_parse(user_input)
        outdata,tools_data,props = tool_call(persona=persona_obj, user_input=user_input,search=search,logger=logger,history=history,team_contact=team_contact)
        long_res = props['long_res']
        print(f"Long Res: {long_res}")

        outdata = outdata.replace('.0','.O').replace('<img','<p')
        lp,urlInfo = links_parser(search)
        if len(urlInfo)<1:
            lp=""
        elif "link" in search or "url" in search :
            #outdata += lp  #For 100% surity of link
            pass
        else:
            print(lp)
            
        if "on call" in search.lower() or "count" in search.lower():
            search += ". Today is " + str(datetime.datetime.now().strftime('%A, %B %d, %Y'))

        vector_query = get_vectorized_query(search)
        doc_content_params = {"history":history, "search_client":search_client}
        if 'doc_count' in props:
            doc_content_params['doc_count'] = props['doc_count']
        fin_content= get_doc_content(search,[vector_query], **doc_content_params)
        # print(fin_content)
        fin_content['content'] = fin_content['content'] + team_contact
        if tools_data:
            for tool_data in tools_data:
                fin_content['content'] += f"\n{tool_data}"
        fin_content['content'] +=lp
        messages.append(fin_content)
        if prt_data is not None :
            if 'links' in prt_data:
                prt_data['links']=prt_data['links'].append(urlInfo)
            else:
                prt_data['links'] = urlInfo
        else:
            prt_data={}
            prt_data['links'] = urlInfo
        # with open('messages.json', 'w') as f:
        #     json.dump(messages, f, indent=4)
        #print("TOKEN LENGTH: ", get_token_length(str(messages)))
        if prt:
            return single_chatbot_response(messages, openaii,outdata,long_res=long_res, logger=logger, history_func=None, prt_data=prt_data)
        return stream_chatbot_response(messages, openaii,outdata,long_res=long_res, logger=logger, history_func=None)
    else:
        return stream_chatbot_response([{"role": "system","content": ops_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"},{"role": "user","content": "The persona is not available. Tell the user to check the URL they are using."}], openaii,"")