"""
related inc/prb
related US
OLE counts
arch information RAG
current (in progress) US
contact API
"""

from rally_chatbot.tool_list import get_rally_tool_list, rally_teams

vbf_list =["ole","dce","vpp","pre",]
architecture_pages = ['architecture_overview',
                    'microapps/pre',
                    'microapps/ole',
                    'microapps/dce',
                    'microapps/vpp',
                    'microapps/pse',
                    'microapps/pharmacy',
                    'microapps/sitesearch',
                    'microapps/landrover',
                    'microapps/global',
                    'microapps/external_apis/campaigncrosswalk',
                    'microapps/external_apis/email',
                    'microapps/external_apis/ocr_apis',
                    'microapps/external_apis/providersearch',
                    'microapps/ai-companion',
                    'common-tools',
                    'uhcm-proxy-solution',
                    'monitoring-tools',
                    'custom-monitoring'
                    ]

def get_ops_tool_list():
    return [
        {
            "type": "function",
            "function" : {
                "name": "get_related_tickets",
                "description": "Use this to pull related incidents and problems. Call this function without any parameters. Call this function any time a user is asking about any kind of problem or is looking for information from service now.",
                "parameters": {},
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_related_stories",
                "description": "Use this to pull related user stories. Call this function any time a user is asking about any kind of problem or is looking for information from rally.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "vbf": {
                            "type": "string",
                            "description": f"This is the vital business function that the user is asking about. This is a string that is used to filter the user stories. The only vbf values the user can ask for are {vbf_list}."
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_architecture_info",
                "description": "Use this to pull architecture document information. Call this function any time a user is asking about architecture, failover, webserver, micro apps, or system dependency information.",
                "parameters": {
                    "type": "object",
                    "properties": {}
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_manual_checkout_info",
                "description": "Use this to pull information on manual checkouts. Call this function only when a user is asking about manual checkouts or how to find problems with a zabbix probe.",
                "parameters": {
                    "type": "object",
                    "properties": {}
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_contact_info",
                "description": "Only use this when someone is asking for a person's contact information. That being the persons phone number, email id, or if they are onshore or offshore. This will return the contact information for the person that is asked about.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": f"The name of the person you are looking for."
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_quick_links",
                "description": "Use this to pull quick links. Call this function any time a user is asking about links or quick links.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "category": {
                            "type": "string",
                            "description": f"If the user is asking for a specific category of links, you can provide that here. The only categories that are currently supported are Splunk,Dynatrace,Azure,Zabbix,Other."
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_latest_inc",
                "description": "Use this to pull last week worth of incidents from Servicenow. Call this function without any parameters.",
                "parameters": {
                    "type": "object",
                    "properties": {}
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_hourglass_repo_riskiness",
                "description": "Use this to pull the riskiness of github repos using Hourglass metrics. This should be used when the user is asking about Hourglass or when asking about repo riskiness.",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_dynatrace_problems",
                "description": "Use this to pull the active or open Dynatrace ( dtsaas ) problems  .This should be used always when the user is asking about any open or active Dynatrace or Dtsaas problems , it will return list of problems detected by dynatrace .",
                
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_release_milestone_info",
                "description": "Use this to pull release milestone information. This should be used when the user is asking about release milestones. Release milestones include [Sprint 1, Soft Code Freeze (SCF), Push to Redwood Dev, Intergration Sanity in Dev, Push to Redwood QA, QA&E - Sprint Hardening/Regression in QA (Redwood), UAT (Content / Accessibility/ Analytics) Non QA&E in QA (Redwood), Push to Stage (Redwood) for Perf Testing Only, Performance Test Scripting & Execution Stage (Redwood), Hard Code Freeze (HCF), Green Deployment (Redwood), Green Deployment Validation (Redwood), Go/NoGo, Deployment (Redwood)]",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_hourglass_metrics",
                "description": "Use this to pull hourglass metrics. This should be used when the user is asking about hourglass metrics. This can also be used when asking about git velocity, branch score, or simplicity scores.",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
    ] + get_rally_tool_list()