import datetime
import json
import requests
import os

import psycopg2

from azure_funcs import TOOL_CALL_MODEL, openaii, get_vectorized_query, SearchClient, AZURE_SEARCH_SERVICE, azure_credential, AzureBlobConnect
from environment import environment
from tickets_funcs import get_incidents, get_problems, get_us, query_quick_links

from ops_chatbot.tool_list import get_ops_tool_list
from rally_chatbot.tool_list import rally_teams
from rally_chatbot.tool_calling import *

ARCH_SEARCH_SERVICE_INDEX = "gpd-ops-architecture-docs"
PROBES_SEARCH_SERVICE_INDEX = "gpd-ops-manual-checkout"

conn = psycopg2.connect(
        host="itsm_dm_prod.optum.com",
        database="itsm_dm",
        user=os.getenv('DATA_MART_DB_USER'),
        password=os.getenv('DATA_MART_DB_PASSWORD'),
        port="5432"
    )

cur = conn.cursor()

def get_ops_messages(user_input, search=""): 
    print(f"User Input: {user_input}")
    return [
        {"role": "system","content": f"You only respond if there is a tool call. If the user does not need to call any functions then exit quick with response 'N/A'. Today is {datetime.datetime.now()}."},
        {"role": "user", "content": user_input}
    ]

def ops_tool_call(user_input,search="",logger=None,team_contact=""):
    messages_input = get_ops_messages(user_input,search=search)
    outdata = ""
    return_data = []
    long_res = False
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_ops_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return outdata, None, long_res
    elif finish_reason =='tool_calls':
        print(compl.choices[0].message.tool_calls)
        for tool_call in compl.choices[0].message.tool_calls:
            if tool_call.function.name == 'get_related_tickets':
                args = json.loads(tool_call.function.arguments)
                tickets_res = get_related_tickets(user_input,search,logger=logger)
                return_data.append(tickets_res)
                outdata += tickets_res
            elif tool_call.function.name == 'get_related_stories':
                args = json.loads(tool_call.function.arguments)
                stories_res = get_related_stories(search,args)
                return_data.append(stories_res)
                outdata += stories_res
            elif tool_call.function.name == 'get_architecture_info':
                args = json.loads(tool_call.function.arguments)
                arch_info = get_architecture_info(search,args)
                return_data.append(arch_info)
                long_res = True
            elif tool_call.function.name == 'get_dynatrace_problems':
                #args = json.loads(tool_call.function.arguments)
                dyna = get_dyna_info(search,args)
                return_data.append(dyna)
                long_res = True
            elif tool_call.function.name == 'get_manual_checkout_info':
                args = json.loads(tool_call.function.arguments)
                manual_checkout_info = get_manual_checkout_info(search,args)
                return_data.append(manual_checkout_info)
                long_res = True
            elif tool_call.function.name == 'get_contact_info':
                if (len(team_contact)==0):   
                    args = json.loads(tool_call.function.arguments)
                    return_data.append(get_contact_info(search,args))
            elif tool_call.function.name == 'get_quick_links':
                args = json.loads(tool_call.function.arguments)
                quick_links_info = get_quick_links_info(search,args)
                return_data.append(quick_links_info)
                long_res = True
    return outdata, return_data, long_res

def ops_rally_tool_call(user_input,search="",logger=None,team_contact="", history=None):
    messages_input = get_ops_messages(user_input,search=search)
    outdata = ""
    return_data = []
    long_res = False
    if history:
        messages_input.append({"role": "assistant", "content": f"Here is the last few questions and responses in ask order: {history}"})
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_ops_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return outdata, None, long_res
    elif finish_reason =='tool_calls':
        print(compl.choices[0].message.tool_calls)
        for tool_call in compl.choices[0].message.tool_calls:
            print(tool_call.function.name)
            if tool_call.function.name == 'get_related_tickets':
                args = json.loads(tool_call.function.arguments)
                tickets_res = get_related_tickets(user_input,search,logger=logger)
                return_data.append(tickets_res)
                outdata += tickets_res
            elif tool_call.function.name == 'get_related_stories':
                args = json.loads(tool_call.function.arguments)
                stories_res = get_related_stories(search,args)
                return_data.append(stories_res)
                outdata += stories_res
            elif tool_call.function.name == 'get_architecture_info':
                args = json.loads(tool_call.function.arguments)
                arch_info = get_architecture_info(search,args)
                return_data.append(arch_info)
                long_res = True
            elif tool_call.function.name == 'get_manual_checkout_info':
                args = json.loads(tool_call.function.arguments)
                manual_checkout_info = get_manual_checkout_info(search,args)
                return_data.append(manual_checkout_info)
                long_res = True
            elif tool_call.function.name == 'get_quick_links':
                args = json.loads(tool_call.function.arguments)
                quick_links_info = get_quick_links_info(search,args)
                return_data.append(quick_links_info)
                long_res = True
            elif tool_call.function.name == 'get_contact_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_contact_info(search,args))
            elif tool_call.function.name == 'get_user_stories':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories(args))
            elif tool_call.function.name == 'get_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_estimates(args))
            elif tool_call.function.name == 'get_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features(args))
            elif tool_call.function.name == 'get_features_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_states(args))
            elif tool_call.function.name == 'get_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_plan_estimates(args))
            elif tool_call.function.name == 'get_accepted_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_features_plan_estimates(args))
            elif tool_call.function.name == 'get_user_story_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_acceptance_criteria(args))
            elif tool_call.function.name == 'get_user_story_descriptions':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_descriptions(args))
            elif tool_call.function.name == 'get_user_story_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_states(args))
            elif tool_call.function.name == 'get_accepted_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_user_story_estimates(args))
            elif tool_call.function.name == 'get_current_iterations':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_iterations(args))
            elif tool_call.function.name == 'get_current_releases':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_releases(args))
            elif tool_call.function.name == 'get_allowed_teams':
                return_data.append(f"Here are the teams thay are asking for: {rally_teams}")
            elif tool_call.function.name == 'get_rally_obj_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_rally_obj_info(args))
            elif tool_call.function.name == 'get_rally_obj_info_no_id':
                return_data.append(get_rally_obj_info_no_id(user_input))
            elif tool_call.function.name == 'get_completed_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_completed_user_story_estimates(args))
            elif tool_call.function.name == 'get_user_stories_no_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories_no_acceptance_criteria(args))
            elif tool_call.function.name == 'get_latest_inc':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_latest_inc(args))
            elif tool_call.function.name == 'get_hourglass_repo_riskiness':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_hourglass_repo_riskiness(args))
            elif tool_call.function.name == 'get_release_milestone_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_milestone_info(args))
            elif tool_call.function.name == 'get_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_defects(args))
            elif tool_call.function.name == 'get_release_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_defects(args))
            elif tool_call.function.name == 'get_release_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_features(args))
            elif tool_call.function.name == 'get_hourglass_metrics':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_hourglass_metrics(args))
    return outdata, return_data, long_res



def get_related_tickets(user_input,search,logger=None):
    inc_res, inc_search = get_incidents(user_input,search,logger=logger)
    prb_res, prb_search = get_problems(user_input,search,logger=logger)
    return inc_res + prb_res

def get_related_stories(search, args, logger=None):
    # return get_user_stories(search,args['vbf'],logger=logger)
    return get_us(search,None,logger=logger)

def get_architecture_info(search, args):
    arch_search_client = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=ARCH_SEARCH_SERVICE_INDEX,
        credential=azure_credential)
    results = arch_search_client.search(search, vector_queries=[get_vectorized_query(search)], top=4)
    return_data = ""
    for doc in results:
        return_data += f"Architecture chunk: {doc['chunk']}\n\n"
    return return_data

def get_manual_checkout_info(search, args):
    probes_search_client = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=PROBES_SEARCH_SERVICE_INDEX,
        credential=azure_credential)
    results = probes_search_client.search(search, vector_queries=[get_vectorized_query(search)], top=4)
    return_data = ""
    for doc in results:
        return_data += f"Manual Checkout chunk: {doc['chunk']}\n\n"
    return return_data

def get_contact_info(search, args):
    print("Contact Information: " + str(args))
    blob_client = AzureBlobConnect()
    res1 = blob_client.get_blob("chatbot-store", "contact_information.txt")
    res2 = blob_client.get_blob("chatbot-store", 'teamcontact.txt')
    res = []
    res.extend(res1.split("/n"))
    res.extend(res2.split(";"))
    founder =""
    for line in res :
        if args['name'].lower() in line.lower():
            founder = founder + line +"/n"
    if len(founder)==0 :
        return res1
    return founder

def get_quick_links_info(search, args):
    quick_links = query_quick_links(args['category'] if 'category' in args else None)
    print(quick_links)
    return quick_links

def  get_dyna_info(search,args):
    url = "https://dtsaas.uhc.com/e/4944fc42-016d-4462-8104-a110143a2322/api/v2/problems"

    querystring = {"from":"now-1d","pageSize":"500"}

    payload = ""
    headers = {
    'Authorization': Dynatrace_API,
    'Accept': "application/json"
    }

    response = requests.request("GET", url, data=payload, headers=headers, params=querystring,verify="../standard_trusts.pem")
    prblms =  response.json()
    active_prb = []
    for i in range(len(prblms['problems'])):
        if prblms['problems'][i]["status"]== "OPEN":
            active_prb.append(prblms['problems'][i])
    summary_out =""
    if len(active_prb) <1: 
        summary_out = "There are no Active problem in Dynatrace as of Now!"
        #return summary_out
    else :
        summary_out = "There are "+str(len(active_prb)) +" Active problems in Dynatrace. Few of them are : " 
        for p in active_prb:
            summary_out = summary_out + " <br>-  <a href='https://dtsaas.uhc.com/e/4944fc42-016d-4462-8104-a110143a2322/#problems/problemdetails;gtf=today;gf=all;pid="+ p["problemId"]+"' ><Strong>"+ p["displayId"]+"</Strong></a> : "+p["displayId"]+" in " + p["impactedEntities"][0]["name"]
    return summary_out

def get_latest_inc(args):
    def generate_sql(start_date, end_date,fields):
        # fields = '*'
        field_str = ', '.join(fields)
        sql = f"select {field_str} from SM_DM.SM_INCIDENTS where \"assignment\" = 'GOVERNMENT PROGRAMS DIGITAL (UNT) - APP' and open_time between \'" + start_date + "\' and \'" + end_date + "\'"
        return sql
    fields = ['uh_assignee_full_name', 'brief_description', 'in_id', 'update_action', 'resolution', 'open_time', 'priority_code', 'sm_incidents.status']
    sql = generate_sql((datetime.datetime.now() - datetime.timedelta(days=7)).strftime('%Y-%m-%d 00:00:00.000'),(datetime.datetime.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00.000'),fields)
    print(sql)
    cur.execute(sql)
    results = cur.fetchall()
    print(results)
    for i,r in enumerate(results):
        r = list(r)
        r[fields.index('priority_code')] = "Priority Code: " + r[fields.index('priority_code')]
        r[fields.index('sm_incidents.status')] = "INC State: " + r[fields.index('sm_incidents.status')]
        results[i] = r
    return ("Here are incidents from the last 7 days.",results)

def get_hourglass_repo_riskiness(args):
    # http://comprehensivedashboard-core-elr.optum.com/assets/hourglass-data/repoLateCommits.json
    repo_res = requests.get("http://comprehensivedashboard-core-elr.optum.com/assets/hourglass-data/repoLateCommits.json",verify='./optum.pem')
    if repo_res.status_code != 200:
        return "Failed to get Hourglass Repo Riskiness. Please check the availability in http://comprehensivedashboard-core-elr.optum.com/"
    repo_data = repo_res.json()
    return repo_data

def get_release_milestone_info(args):
    blob_client = AzureBlobConnect()
    release_milestone_data = blob_client.get_blob('chatbot-store', 'release_milestones.csv')
    return release_milestone_data

def get_hourglass_metrics(args):
    blob_client = AzureBlobConnect()
    hourglass_metrics = blob_client.get_blob('chatbot-store', 'hourglass_metrics.txt')
    temp_message = "The only available data is for the March 5th release. Reach out to Ted Youel and the Hourglass team for more information.\n\n"
    return f"{temp_message}{hourglass_metrics}"