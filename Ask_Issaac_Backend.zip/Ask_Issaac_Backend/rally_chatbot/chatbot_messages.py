from rally_chatbot.system_messages import rally_chatbot_system_message

import datetime

class RallyMessages:
    def __init__(self):
        self.sys_message = {"role": "system",
                 "content": rally_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}
        self.messages = [self.sys_message]
    
    def set_messages(self, message):
        if len(self.messages) > 6:
            self.messages = [self.sys_message]+self.messages[-4:]
        self.messages.append(message)
    
    def get_messages(self):
        return self.messages