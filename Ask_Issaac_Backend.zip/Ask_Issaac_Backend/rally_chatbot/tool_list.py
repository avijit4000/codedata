import requests

from environment import environment

rally_teams = []

def set_rally_teams():
    if len(rally_teams) == 0:
        print(f'{environment.get_tickets_endpoint()}/rally/teams')
        for team in requests.get(f'{environment.get_tickets_endpoint()}/rally/teams',verify='./optum.pem').json():
            rally_teams.append(team)
    print(rally_teams)

def get_rally_tool_list():
    return [
        {
            "type": "function",
            "function" : {
                "name": "get_user_stories",
                "description": "Call this when a user asks for user stories. This will return all data for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user stories for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_user_stories_no_acceptance_criteria",
                "description": "This will return all data for user stories that are missing the acceptance criteria. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user stories for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_user_story_estimates",
                "description": "This will return only the estimates for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user story estimates for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_completed_user_story_estimates",
                "description": "This will return only the estimates for user stories that are asked about and are complete or in a accepted state. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user story estimates for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_user_story_descriptions",
                "description": "This will return only the descriptions for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user story descriptions for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_user_story_states",
                "description": "This will return only the work progress states for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user story states for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_user_story_acceptance_criteria",
                "description": "This will return only the acceptance criteria for user stories that are asked about. The user stories can also be filtered by date, iteration, release, or feature.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user story acceptance criterias for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "feature": {
                            "type": "string",
                            "description": "The feature for a certain user story. Only use this field when the user states a feature ID. The feature is formatted as F123456. Do not make up feature IDs."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_features",
                "description": "This will return all data for features that are asked about. The features can also be filtered by date, or release.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants features for. The only teams that can be used are listed before."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_features_states",
                "description": "This will return the work progress state data for features that are asked about. The features can also be filtered by date, or release.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants the work progress state of features for. The only teams that can be used are listed before."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_features_plan_estimates",
                "description": "This will return the plan estimates for features that are asked about. The features can also be filtered by date, or release.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants the plan estimates of features for. The only teams that can be used are listed before."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        # {
        #     "type": "function",
        #     "function" : {
        #         "name": "get_accepted_features_plan_estimates",
        #         "description": "This will return the plan estimates for features that are complete or in an accepted state. The features can also be filtered by date, or release.",
        #         "parameters": {
        #             "type": "object",
        #             "properties": {
        #                 "team": {
        #                     "type": "string",
        #                     "description": f"The team the user wants the plan estimates of features for. The only teams that can be used are listed before."
        #                 },
        #                 "release": {
        #                     "type": "string",
        #                     "description": "The release for a certain feature. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
        #                 },
        #                 "from_date": {
        #                     "type": "string",
        #                     "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
        #                 },
        #                 "to_date": {
        #                     "type": "string",
        #                     "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
        #                 }
        #             }
        #         },
        #         "result": {
        #             "type": "array",
        #             "items": {
        #                 "type": "string"
        #             }
        #         }
        #     }
        # },
        # {
        #     "type": "function",
        #     "function" : {
        #         "name": "get_current_iterations",
        #         "description": "Use this when a user asks for current iteration or sprint. This will return the name and dates for a current iteration a team is working on.",
        #         "parameters": {
        #             "type": "object",
        #             "properties": {
        #                 "team": {
        #                     "type": "string",
        #                     "description": f"The team the user wants the current iteration for. The only teams that can be used are listed before."
        #                 }
        #             }
        #         },
        #         "result": {
        #             "type": "array",
        #             "items": {
        #                 "type": "string"
        #             }
        #         }
        #     }
        # },
        # {
        #     "type": "function",
        #     "function" : {
        #         "name": "get_current_releases",
        #         "description": "Use this when a user asks for what is the current release. This will return the name and dates for a current release a team is working on.",
        #         "parameters": {
        #             "type": "object",
        #             "properties": {
        #                 "team": {
        #                     "type": "string",
        #                     "description": f"The team the user wants the current release for. The only teams that can be used are listed before."
        #                 }
        #             }
        #         },
        #         "result": {
        #             "type": "array",
        #             "items": {
        #                 "type": "string"
        #             }
        #         }
        #     }
        # },

        {
            "type": "function",
            "function" : {
                "name": "get_rally_obj_info",
                "description": "Get information for a rally object. The user must give an object ID. Determine if the object is a user story, feature, defect or capability.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "FormattedID": {
                            "type": "string",
                            "description": f"The id given for the object. Examples: US123456, F123456, DE123456, C123456. Do not make up object IDs."
                        }
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },

        {
            "type": "function",
            "function" : {
                "name": "get_rally_obj_info_no_id",
                "description": "Get information for a rally object. The user must be looking for features or user stories without providing an ID. Only call this when the user is describing a task",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                },
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },

        {
            "type": "function",
            "function" : {
                "name": "get_allowed_teams",
                "description": "This will return the teams that are allowed to be queried with this chatbot.",
                "result": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                }
            }
        },
        
        {
            "type": "function",
            "function" : {
                "name": "get_defects",
                "description": "This will return all data for defects that are asked about. The defects can be filtered by date, iteration, or release.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "team": {
                            "type": "string",
                            "description": f"The team the user wants user stories for."
                        },
                        "iteration": {
                            "type": "string",
                            "description": "The iteration for a certain user story. Only use this field when the user states an iteration. Iterations look like this 2024_Jul_24_GPP-MRPR-Dev-Sprint_1. There are no spaces in iteration names. Do not make up iteration names. Keep the exact spelling used."
                        },
                        "release": {
                            "type": "string",
                            "description": "The release for a certain user story. Only use this field when the user states a release. Releases look like this 2024_Jul_24_GPP-MRPR-Dev. There are no spaces in release names. Do not make up release names."
                        },
                        "from_date": {
                            "type": "string",
                            "description": "The starting date for the query. Fill this field if the user specifies a start time range, and do one day before the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        },
                        "to_date": {
                            "type": "string",
                            "description": "The end date for the query. Fill this field if the user specifies an end time range, and do one day after the mentioned day. Use the same format as 2024-05-01T05:00:00.000"
                        }
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_release_defects",
                "description": "This will return all data for defects in the next release. Use this when the user is asking about defects without specifying a team.",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                }
            }
        },
        {
            "type": "function",
            "function" : {
                "name": "get_release_features",
                "description": "This will return all data for features in the next release. Use this when the user is asking about defects without specifying a team.",
                "parameters": {
                    "type": "object",
                    "properties": {
                    }
                }
            }
        }
    ]