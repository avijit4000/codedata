import datetime
import json
import requests

from azure_funcs import TOOL_CALL_MODEL, openaii
from environment import environment
from tickets_funcs import get_rally_obj

from rally_chatbot.tool_list import get_rally_tool_list, rally_teams

def get_rally_messages(user_input): 
    print(f"User Input: {user_input}")
    return [
        {"role": "system","content": f"You only respond if there is a tool call. A sprint is equal to the last two weeks. Never change the capitalization of sprints, iterations, or releases. If the user does not need to call any functions then exit quick with response 'N/A'. Today is {datetime.datetime.now()}. For data in a whole month, use the first of the current month to the first of the next month. Match a team name to one in the list if the user comes close to one. Do not pick a team if the user does not mention any. The only teams that can be used are  Teams: {rally_teams}"},
        {"role": "user", "content": user_input}
    ]

def search_rally(user_input,logger=None):
    messages_input = get_rally_messages(user_input)
    # if environment.get_team():
    #     messages_input.append({"role":"assistant","content":f"Here is the previous team the user was asking about: {environment.get_team()}. Do not use this data if an unlisted team is mentioned."})
    # with open('msg_input.json', 'w') as f:
    #     json.dump([messages_input,get_top_scrum_tool_list()],f)
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_rally_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return None
    elif finish_reason =='tool_calls':
        return_data = []
        print(compl.choices[0].message.tool_calls)
        for tool_call in compl.choices[0].message.tool_calls:
            if tool_call.function.name == 'get_user_stories':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories(args))
            elif tool_call.function.name == 'get_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_estimates(args))
            elif tool_call.function.name == 'get_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features(args))
            elif tool_call.function.name == 'get_features_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_states(args))
            elif tool_call.function.name == 'get_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_features_plan_estimates(args))
            elif tool_call.function.name == 'get_accepted_features_plan_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_features_plan_estimates(args))
            elif tool_call.function.name == 'get_user_story_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_acceptance_criteria(args))
            elif tool_call.function.name == 'get_user_story_descriptions':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_descriptions(args))
            elif tool_call.function.name == 'get_user_story_states':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_story_states(args))
            elif tool_call.function.name == 'get_accepted_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_accepted_user_story_estimates(args))
            elif tool_call.function.name == 'get_current_iterations':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_iterations(args))
            elif tool_call.function.name == 'get_current_releases':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_current_releases(args))
            elif tool_call.function.name == 'get_allowed_teams':
                args = json.loads(tool_call.function.arguments)
                return_data.append(f"Here are the teams thay are asking for: {rally_teams}")
            elif tool_call.function.name == 'get_rally_obj_info':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_rally_obj_info(args))
            elif tool_call.function.name == 'get_completed_user_story_estimates':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_completed_user_story_estimates(args))
            elif tool_call.function.name == 'get_user_stories_no_acceptance_criteria':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_user_stories_no_acceptance_criteria(args))
            elif tool_call.function.name == 'get_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_defects(args))
            elif tool_call.function.name == 'get_release_defects':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_defects(args))
            elif tool_call.function.name == 'get_release_features':
                args = json.loads(tool_call.function.arguments)
                return_data.append(get_release_features(args))
        return return_data
        # if compl.choices[0].message.tool_calls[0].function.name == 'get_user_stories':
        #     args = json.loads(compl.choices[0].message.tool_calls[0].function.arguments)
        #     return get_user_stories(args)
        # elif compl.choices[0].message.tool_calls[0].function.name == 'get_features':
        #     args = json.loads(compl.choices[0].message.tool_calls[0].function.arguments)
        #     return get_features(args)
    else:
        return None

def user_story_template(args, endpoint):
    team = args['team'] if 'team' in args else None
    if not team:
        return "No team specified. A team must be mentioned to get information on."
    # if 'team' not in args:
    #     return "Error: No team specified"
    # team = args['team']
    iteration = args.get('iteration',None)
    release = args.get('release',None)
    feature = args.get('feature',None)
    from_date = args.get('from_date',None)
    to_date = args.get('to_date',None)
    response_str = ''
    if not iteration and not release and not feature:
        try:
            iteration_url = f'{environment.get_tickets_endpoint()}/rally/{team}/iterations/current'
            response = requests.get(iteration_url,verify='./optum.pem')
            iteration = response.json()[0]['Name']
            response_str += f"Since none specified, using Current Iteration: {iteration}\n"
        except Exception as e:
            print(f"Error: {e}")
            return f"This team, {team}, is unavailable for metrics."
    try:
        url = f'{environment.get_tickets_endpoint()}/rally/{team}/user_stories/{endpoint}'
        if iteration:
            url += f'?iteration={iteration}'
        elif feature:
            url += f'?feature={feature}'
        elif release:
            url += f'?release={release}'
        if from_date:
            url += f'&from_date={from_date}' if '?' in url else f'?from_date={from_date}'
        if to_date:
            url += f'&to_date={to_date}' if '?' in url else f'?to_date={to_date}'
        response = requests.get(url,verify='./optum.pem')
        # for obj in response.json():
        #     if type(obj) == str:
        #         response_str += obj
        #         continue
        #     for key in obj:
        #         response_str += f"{key}: {obj[key]}, "
        #     response_str += '\n'
        return f"{response_str}\nUser Stories found: {response.json()}"
        # return f"User Stories found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."
    
def feature_template(args, endpoint):
    # team = args['team']
    team = args['team'] if 'team' in args else None
    if not team:
        return "No team specified. A team must be mentioned to get information on."
    print("IN func: "+ team)
    release = args.get('release',None)
    from_date = args.get('from_date',None)
    to_date = args.get('to_date',None)
    url = f'{environment.get_tickets_endpoint()}/rally/{team}/features/{endpoint}'
    print(url)
    response_str = ''
    if not release:
        try:
            release_url = f'{environment.get_tickets_endpoint()}/rally/{team}/releases/current'
            response = requests.get(release_url,verify='./optum.pem')
            release = response.json()[0]['Name']
            response_str += f"Since none specified, using Current release: {release}\n"
        except Exception as e:
            print(f"Error: {e}")
            return f"This team, {team}, is unavailable for metrics."
    try:
        if release:
            url += f'?release={release}'
        if from_date:
            url += f'&from_date={from_date}' if release else f'?from_date={from_date}'
        if to_date:
            url += f'&to_date={to_date}' if release or from_date else f'?to_date={to_date}'
        response = requests.get(url,verify='./optum.pem')
        print(response.json())
        # for obj in response.json():
            # if type(obj) == str:
            #     response_str += obj
            #     continue
            # if type(obj) == list:
            #     if len(obj) == 2:
            #         response_str += f"{obj[0]}: {obj[1]}, "
            #     else:
            #         response_str += f"{obj}"
            #     continue
            # for key in obj:
            #     response_str += f"{key}: {obj[key]}, "
            # response_str += '\n'
        # LAST_FEATURE[0] = response.json()
        return f"{response_str}\nFeatures found: {response.json()}"
        # return f"Features found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."

def defect_template(args, endpoint):
    team = args['team'] if 'team' in args else None
    if not team:
        return "No team specified. A team must be mentioned to get information on."
    # if 'team' not in args:
    #     return "Error: No team specified"
    # team = args['team']
    iteration = args.get('iteration',None)
    release = args.get('release',None)
    from_date = args.get('from_date',None)
    to_date = args.get('to_date',None)
    response_str = ''
    if not iteration and not release:
        try:
            iteration_url = f'{environment.get_tickets_endpoint()}/rally/{team}/iterations/current'
            response = requests.get(iteration_url,verify='./optum.pem')
            iteration = response.json()[0]['Name']
            response_str += f"Since none specified, using Current Iteration: {iteration}\n"
        except Exception as e:
            print(f"Error: {e}")
            return f"This team, {team}, is unavailable for metrics."
    try:
        url = f'{environment.get_tickets_endpoint()}/rally/{team}/defects{"/" if len(endpoint) > 0 else ""}{endpoint}'
        if iteration:
            url += f'?iteration={iteration}'
        elif release:
            url += f'?release={release}'
        if from_date:
            url += f'&from_date={from_date}' if '?' in url else f'?from_date={from_date}'
        if to_date:
            url += f'&to_date={to_date}' if '?' in url else f'?to_date={to_date}'
        response = requests.get(url,verify='./optum.pem')
        # for obj in response.json():
        #     if type(obj) == str:
        #         response_str += obj
        #         continue
        #     for key in obj:
        #         response_str += f"{key}: {obj[key]}, "
        #     response_str += '\n'
        return f"{response_str}\nDefects found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."

def iteration_template(args, endpoint):
    # team = args['team']
    team = args['team'] if 'team' in args else None
    if not team:
        return "No team specified. A team must be mentioned to get information on."
    try:
        url = f'{environment.get_tickets_endpoint()}/rally/{team}/iterations/{endpoint}'
        response = requests.get(url,verify='./optum.pem')
        LAST_ITERATION[0] = response.json()
        return f"Iterations found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."

def release_template(args, endpoint):
    team = args['team'] if 'team' in args else None
    try:
        url = f'{environment.get_tickets_endpoint()}/rally/{team}/releases/{endpoint}'
        response = requests.get(url,verify='./optum.pem')
        LAST_RELEASE[0] = response.json()
        return f"Releases found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."

def get_user_stories(args):
    return user_story_template(args, 'fid')

def get_user_story_estimates(args):
    return user_story_template(args, 'estimates')

def get_accepted_user_story_estimates(args):
    return user_story_template(args, 'accepted_estimates')
    
def get_user_story_descriptions(args):
    return user_story_template(args, 'descriptions')
    
def get_user_story_states(args):
    return user_story_template(args, 'states')

def get_user_story_acceptance_criteria(args):
    return user_story_template(args, 'acceptance_criteria')

def get_user_stories_no_acceptance_criteria(args):
    return user_story_template(args, 'no_acceptance_criteria')

def get_completed_user_story_estimates(args):
    return user_story_template(args, 'accepted_estimates')

def get_features(args):
    res = feature_template(args, 'fid')
    print(res)
    return res

def get_features_states(args):
    return feature_template(args, 'states')

def get_features_plan_estimates(args):
    return feature_template(args, 'plan_estimates')

def get_accepted_features_plan_estimates(args):
    return feature_template(args, 'accepted_estimates')

def get_current_iterations(args):
    return iteration_template(args, 'current')

def get_current_releases(args):
    print(args)
    return release_template(args, 'current')

def get_rally_obj_info(args):
    id = args['FormattedID'].upper()
    clean_id = "".join(list([character for character in id if character.isalpha() or character.isnumeric()]))
    if id != clean_id:
        return f"Error: FormattedID {id} is not in the correct format. Please provide a FormattedID that is alphanumeric."
    # typ = args['type']
    try:
        url = f'{environment.get_tickets_endpoint()}/rally/from_id/{clean_id}'
        response = requests.get(url,verify='./optum.pem')
        return f"Features found: {response.json()}"
    except Exception as e:
        print(f"Error: {e}")
        return f"I am unable to provide information on the ask since I could not find the right information."

def get_rally_obj_info_no_id(search,args=None):
    res = get_rally_obj(search)
    return res

def get_defects(args):
    return defect_template(args, '')

def get_release_defects(args):
    url = f'{environment.get_tickets_endpoint()}/rally/open_defects_next_release'
    res = requests.get(url,verify='./optum.pem')
    return f"Defects found: {res.json()}"

def get_release_features(args):
    url = f'{environment.get_tickets_endpoint()}/rally/features_next_release'
    print(url)
    res = requests.get(url,verify='./optum.pem')
    print(res)
    print(res.json())
    return f"Features found: {res.json()}"
