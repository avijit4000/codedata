import datetime

from chatbot_logging import ChatbotLogger
from environment import environment
from azure_funcs import get_vectorized_query, get_doc_content, stream_chatbot_response, openaii, get_history_message

from rally_chatbot.system_messages import rally_chatbot_system_message
from rally_chatbot.tool_calling import search_rally
from rally_chatbot.chatbot_messages import RallyMessages

history = []
# sys_message = {"role": "system",
#                  "content": rally_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}
# messages = [sys_message]

rMessages = RallyMessages()

def get_rally_response(request):
    logger = ChatbotLogger('rally')
    logger.set_environment("Dev" if environment.DEVELOPMENT else "Prod")
    # messages = [{"role": "system",
    #              "content": rally_chatbot_system_message+f" Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}"}]

    user_input = request.args.get('msg')
    logger.set_question(user_input)
    search = get_history_message(user_input,history)

    outdata = ""

    # outdata, search = get_incidents(user_input,search,logger=logger)
    # outdata_res, search = get_problems(user_input,search,logger=logger)
    # outdata += outdata_res
    # vbf = None
    rally_data = search_rally(user_input,logger=logger)
    usr_msg = user_input
    if rally_data:
        print(rally_data)
        usr_msg = usr_msg + "\n\n\nHere is data to support the question\n"
        for data in rally_data:
            print("DATA: ",data)
            usr_msg += data
            # messages.append({"role": "assistant", "content": str(data)})
        # print(data)
    # outdata += get_user_stories(search,vbf,logger=logger)
    # outdata = outdata.replace('.0','.O').replace('<img','<p')
                # What are the key award points missed by Syed’s teams

    print(f"--Searching: {search} ------------")

    # vector_query = get_vectorized_query(search, scrum=True)
    # messages.append(get_doc_content(search,[vector_query], scrum=True))
    # print(messages)
    # if len(messages) > 6:
    #     messages = [sys_message]+messages[-4:]
    rMessages.set_messages({"role": "user", "content": usr_msg})
    # messages.append({"role": "user", "content": usr_msg})
    return stream_chatbot_response(rMessages.get_messages(), openaii, outdata,rally=True,rally_messages=rMessages)
    # return stream_chatbot_response(messages, openaii, outdata, logger=logger)
