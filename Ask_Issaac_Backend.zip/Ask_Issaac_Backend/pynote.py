import os
import time
import json
import requests

# imports
from flask import Flask, render_template, request, send_from_directory, Response, send_file
from flask_cors import CORS, cross_origin

from azure_funcs import *
from environment import environment
from chatbot_funcs import *
from persona_funcs import get_chatbot_persona_response
from tickets_funcs import *
from bottle import *
from top_scrum_messages import populate_top_scrum_lists
# from azure_file_management.fileSysHandler import FileSysHandler

from rally_chatbot.tool_list import set_rally_teams
from rally_chatbot.route_handler import get_rally_response

app = Flask(__name__, template_folder='frontend', static_folder='frontend')
app.config['MAX_CONTENT_LENGTH'] = 16*1024*1024
cors = CORS(app)

# fsh = FileSysHandler()

# define app routes
@app.route('/')
def index():
    environment.set_env(dev=False)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript_opsrally.js")

@app.route('/ops')
def index_ops():
    environment.set_env(dev=False)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript.js")

@app.route('/ops_rally')
def index_or():
    environment.set_env(dev=False)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript_opsrally.js")

@app.route('/dashboard')
@cross_origin()
def dashboard():
    environment.set_env(dev=False)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript.js")

@app.route('/dev')
def dev_dashboard():
    environment.set_env(dev=True)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript_opsrally.js")

@app.route('/dev_ops')
def dev_dashboard_ops():
    environment.set_env(dev=True)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript.js")

@app.route('/dev_or')
def dev_dashboard_or():
    environment.set_env(dev=True)
    return render_template('index.html',
                           title="GPD-OPS CHATBOT DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript_opsrally.js")

@app.route('/dev_persona_ops')
def dev_dashboard_persona_ops():
    environment.set_env(dev=True)
    return render_template('index.html',
                           title="ASK ISAAC DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript_persona.js",
                           api="api/persona",
                           persona="ops")

@app.route('/dev_persona/<persona>')
def dev_dashboard_persona(persona):
    environment.set_env(dev=True)
    return render_template('index.html',
                           title="ASK ISAAC DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript_persona.js",
                           api="api/persona",
                           persona=persona)

@app.route('/persona/<persona>')
def hcc_dashboard_persona(persona):
    environment.set_env(dev=False)
    return render_template('index.html',
                           title="ASK ISAAC - PERSONA: "+persona.upper(), 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript_persona.js",
                           api="api/persona",
                           persona=persona)

@app.route('/scrum')
@cross_origin()
def scrum_dashboard():
    environment.set_env(dev=False,scrum=True)
    populate_top_scrum_lists()
    return render_template('index.html',
                           title="TOP SCRUM CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/dmyscript.js")

@app.route('/scrum-dev')
def scrum_dev_dashboard():
    environment.set_env(dev=True,scrum=True)
    populate_top_scrum_lists()
    return render_template('index.html',
                           title="TOP SCRUM CHATBOT DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/dmyscript.js")

@app.route('/rally')
@cross_origin()
def rally_dashboard():
    environment.set_env(dev=False,rally=True)
    set_rally_teams()
    return render_template('index_rally.html',
                           title="RALLY CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/rallyscript.js")

@app.route('/rally-dev')
def rally_dev_dashboard():
    environment.set_env(dev=True,rally=True)
    set_rally_teams()
    return render_template('index_rally.html',
                           title="RALLY DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/rallyscript.js")

@app.route('/topscrum')
@cross_origin()
def topscrum_dashboard():
    environment.set_env(dev=False,scrum=True)
    populate_top_scrum_lists()
    return render_template('index_scrum.html',
                           title="TOP SCRUM 2.0 CHATBOT", 
                           stylesheet="/lpm-gpd-chatbot/frontend/dstyle.css",
                           imgfile="/lpm-gpd-chatbot/frontend/chatbot.jpg",
                           srcfile="/lpm-gpd-chatbot/frontend/scrummyscript.js")

@app.route('/topscrum-dev')
def topscrum_dev_dashboard():
    environment.set_env(dev=True,scrum=True)
    populate_top_scrum_lists()
    return render_template('index_scrum.html',
                           title="TOP SCRUM 2.0 CHATBOT DEVELOPMENT", 
                           stylesheet="/frontend/dstyle.css",
                           imgfile="/frontend/chatbot.jpg",
                           srcfile="/frontend/scrummyscript.js")

@app.route('/logo')
def bot_logo():
    return send_from_directory('frontend', 'chatbot.jpg')


@app.route('/user')
def user_dashboard():
    username = os.getenv('USERNAME')  # Retrieve the username from the environment variable
    return f"Hello, {username}! Welcome to your dashboard."

@app.route('/updatecontact', methods=['POST'])
def update_vbfkey_contacts():
    if 'vbfkey' not in request.files:
        return 'No file part'
    file = request.files['vbfkey']
    if file.filename == '':
        return 'No selected file'
    if file:
        filepath = os.path.join('.', "vbfkey.txt")
        file.save(filepath)
    if 'teamcontact' not in request.files:
        return 'No file part'
    file = request.files['teamcontact']
    if file.filename == '':
        return 'No selected file'
    if file:
        filepath = os.path.join('.', 'teamcontact.txt')
        file.save(filepath)
    return "Contact Updated!"

@app.route("/test")
def idk():
    print("\n\n\n\n working and getting request .....................")
    return "GPD-OPS team see your flask is  working"


@app.route("/questions")
@cross_origin()
def get_bot_log():
    qa = ""
    with open("logs.txt", "r") as f:
        qa = f.read()
    return qa

def generate(tokens):
    #tokens = "Hello, this is a mocked chatbot. How can I help you?".split(" ")
    for token in tokens:
        time.sleep(1)
        yield f"data: a{token}\n\n" 
    yield "data: [DONE]\n\n"


@app.route("/get")
@cross_origin()
# function for the bot response
def get_bot_response():
    return Response(get_chatbot_response(request),mimetype='text/event-stream')

@app.route("/api/opsrally")
@cross_origin()
# function for the bot response
def get_bot_opsrally_response():
    return Response(get_chatbot_persona_response(request,persona="ops"),mimetype='text/event-stream')

@app.route("/api/scrum")
@cross_origin()
# function for the bot response
def scrum_api_response():
    return Response(get_scrum_response(request),mimetype='text/event-stream')

@app.route("/api/scrum_asks")
@cross_origin()
# function for the bot response
def give_asked_questions():
    return send_file("scrum_asks.txt")

@app.route("/api/rally")
@cross_origin()
# function for the bot response
def rally_api_response():
    return Response(get_rally_response(request),mimetype='text/event-stream')

@app.route('/stream')
def streamer():
    return Response(generate(), mimetype='text/event-stream')

@app.route("/api/persona/<persona>")
@cross_origin()
# function for the bot response
def get_bot_persona_response(persona):
    print(f"Persona: {persona}")
    return Response(get_chatbot_persona_response(request,persona=persona),mimetype='text/event-stream')

@app.route('/upload/bottle', methods=['POST'])
@cross_origin()
def upload_file():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        filepath = os.path.join('./images/', file.filename)
        #file.save(filepath)
        file.seek(0)
        fil = file.read()
        return get_bottle_response(fil)
        
@app.route("/api/prt_ui_test")
@cross_origin()
# function for the bot response
def get_bot_prt_test_response():
    def format_msg(response, questions=[]):
        obj = {"response": response, "questions": questions, "persona": "digital", "urlInfo": [{"url": "https://www.aarpmedicareplans.com", "section": "", "keyword": "premium"}, {"url": "https://www.aarpmedicareplans.com", "section": "Section 4", "keyword": "premium"}, {"url": "https://www.aarpmedicareplans.com", "section": "Section 4.1", "keyword": "premium"}]}
        print(obj)
        return json.dumps(obj).replace('\n','\n<br>')
    follow_up_qs = {}
    chatbotmsg = get_chatbot_ops_rally_response(request,prt=True, prt_data=follow_up_qs)
    print(chatbotmsg)
    return Response(format_msg(chatbotmsg,questions=follow_up_qs['questions']))

@app.route("/api/prt/persona/<persona>")
@cross_origin()
# function for the bot response
def get_bot_prt_persona_response(persona):
    environment.set_env(dev=False,rally=True)
    def format_msg(response, questions=[],links=[]):
        obj = {"response": response, "questions": questions, "persona": persona, "urlInfo": links}
        print(obj)
        return json.dumps(obj).replace('\n','\n<br>')
    print(f"Persona: {persona}")
    follow_up_qs = {}
    chatbotmsg = get_chatbot_persona_response(request,prt=True,persona=persona, prt_data=follow_up_qs)
    print(chatbotmsg)
    return Response(format_msg(chatbotmsg,questions=follow_up_qs['questions'] if 'questions' in follow_up_qs else [],links=follow_up_qs['links'] if 'links' in follow_up_qs else []))

@app.route("/api/prt/persona/<persona>", methods=['POST'])
@cross_origin()
# function for the bot response
def get_bot_prt_persona_response_post(persona):
    environment.set_env(dev=False,rally=True)
    post_body = request.get_json()
    history = post_body['history'] if 'history' in post_body else []
    username = post_body['username'] if 'username' in post_body else None
    # return {"content":post_body}
    def format_msg(response, questions=[],links=[]):
        obj = {"response": response, "questions": questions, "persona": persona, "urlInfo": links}
        print(obj)
        return json.dumps(obj).replace('\n','\n<br>')
    print(f"Persona: {persona}")
    follow_up_qs = {}
    chatbotmsg = get_chatbot_persona_response(request,prt=True,persona=persona, prt_data=follow_up_qs,history=history,username=username)
    print(chatbotmsg)
    return Response(format_msg(chatbotmsg,questions=follow_up_qs['questions'] if 'questions' in follow_up_qs else [],links=follow_up_qs['links'] if 'links' in follow_up_qs else []))


@app.route("/api/bulk_test")
@cross_origin()
# function for the bot response
def get_bulk_test_response():
    chatbotmsg = get_chatbot_ops_rally_response(request,prt=True)
    return Response(chatbotmsg,mimetype='text/event-stream')

@app.route('/api/ops/feedback', methods=['POST'])
def ops_chabot_feedback():
    try:
        content = [json.loads(request.get_json())]
        data_to_post = '\n'.join(json.dumps(d) for d in content)
        print(data_to_post)
        print("Sending feedback to Logstash...")
        res = requests.post("http://rn000124779:8080/generic_export", data=data_to_post, headers={'Content-type': 'application/json'})
        print(res)
        return {"content":"complete"}
    except Exception as e:
        print(e)
        return {"content":"error"}
    return {"content":"error"}

@app.route('/api/metrics/persona_usage', methods=['GET'])
def persona_usage_metrics():
    try:
        seven_days_ago = datetime.datetime.now() - datetime.timedelta(days=30)
        es_query = {"size": 0,"query": {"bool": {"must": [],"filter": [{"range": {"@timestamp": {"format": "strict_date_optional_time","gte": str(seven_days_ago).replace(' ','T')+"Z"}}},{"bool": {"must": [],"filter": [{"match_phrase": {"environment.keyword": "Prod"}},{"match_phrase": {"chatbot.keyword": "persona"}}],"should": [],"must_not": []}}],"should": [],"must_not": []}},"aggs": {"Question Count": {"cardinality": {"field": "@timestamp"}},"Dates": {"date_histogram": {"field": "@timestamp","calendar_interval": "1d","time_zone": "America/Chicago","extended_bounds": {"min": 1746648132380,"max": 1746820932380}},"aggs": {"Unique Question Count": {"cardinality": {"field": "question.keyword"}}}},"PieData": { "terms": {"field": "persona.keyword","order": { "_count": "desc"},"size": 20,"shard_size": 25}}}}
        feedback_query = {"size": 0,"aggs": {"0": {"terms": {"field": "name.keyword","order": {"_count": "desc"},"size": 3,"shard_size": 25},"aggs": {"Question Count": {"cardinality": {"field": "@timestamp"}}}}},"query": {"bool": {"must": [],"filter": [{"range": {"@timestamp": {"format": "strict_date_optional_time","gte": str(seven_days_ago).replace(' ','T')+"Z"}}}],"should": [],"must_not": []}}}
        ask_url = "http://mr-portals-monitoring.optum.com/elasticsearch/chatbot_usage*/_search"
        feedback_url = "http://mr-portals-monitoring.optum.com/elasticsearch/gpd_ops_chatbot_feedback*/_search"
        ask_res = requests.post(ask_url, data=json.dumps(es_query), headers={'Content-type': 'application/json'})
        feedback_res = requests.post(feedback_url, data=json.dumps(feedback_query), headers={'Content-type': 'application/json'})
        print(ask_url,ask_res)
        print(feedback_url,feedback_res)
        res_obj = {
            "count":ask_res.json()['aggregations']['Question Count']['value'],
            "daily_count":[{"date":day['key_as_string'].split('T')[0],"count":day['Unique Question Count']['value']} for day in ask_res.json()['aggregations']['Dates']['buckets']],
            "feedback_positive":feedback_res.json()['aggregations']['0']['buckets'][0]['Question Count']['value'] if len(feedback_res.json()['aggregations']['0']['buckets']) > 0 else 0,
            "feedback_negative":feedback_res.json()['aggregations']['0']['buckets'][1]['Question Count']['value'] if len(feedback_res.json()['aggregations']['0']['buckets']) > 1 else 0,
            "pie_data":[{"persona":day['key'],"count":day['doc_count']} for day in ask_res.json()['aggregations']['PieData']['buckets']],
            }
        return res_obj
    except Exception as e:
        print(e)
        return {"content":"error"}
    return {"content":"error"}

# @app.route('/api/fs/file_list')
# def fs_file_list_retrieve():
#     return fsh.get_file_list()

# @app.route('/api/fs/get_file')
# def fs_get_file():
#     file = request.args.get('file')
#     folder = request.args.get('folder')
#     return {"content":fsh.get_file(folder, file)}

# @app.route('/api/fs/save_file')
# def fs_save_file():
#     file = request.args.get('file')
#     folder = request.args.get('folder')
#     return {"content":fsh.save_file(folder, file)}
# make a post request save file that takes folder,file, and then content in the post body

# @app.route('/api/fs/save_file', methods=['POST'])
# def fs_save_file():
#     folder = request.args.get('folder')
#     file = request.args.get('file')
#     content = request.get_json()
#     return {"content":fsh.save_file(folder, file, content)}

# @app.route('/fs')
# def file_system_html():
#     return render_template('fileSys.html')


if __name__ == "__main__":
    print("Running .//////////////////////////////////////")
    app.run(host='0.0.0.0', port=7668)
    print("Stopping .//////////////////////////////////////")
