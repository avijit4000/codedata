import requests
import json

from azure_funcs import *
from top_scrum_messages import *
from environment import environment

def search_top_scrum(user_input,logger=None):
    messages_input = get_top_scrum_messages(user_input)
    # if environment.get_team():
    #     messages_input.append({"role":"assistant","content":f"Here is the previous team the user was asking about: {environment.get_team()}. Do not use this data if an unlisted team is mentioned."})
    # with open('msg_input.json', 'w') as f:
    #     json.dump([messages_input,get_top_scrum_tool_list()],f)
    compl = openaii.chat.completions.create(model=TOOL_CALL_MODEL, messages=messages_input, max_tokens=600,temperature=0.4,top_p=1,tools=get_top_scrum_tool_list())
    finish_reason = compl.choices[0].finish_reason
    print(f"Finish Reason: {finish_reason}")
    tool_data = []
    if finish_reason == 'stop':
        if logger:
            logger.set_ask_type('Doc Search')
        return (None,None)
    elif finish_reason =='tool_calls':
        print(compl.choices[0].message.tool_calls)
        if compl.choices[0].message.tool_calls[0].function.name == 'get_top_scrum_scores':
            if logger:
                logger.set_tense('Past')
                logger.set_ask_type('Scoring Reasons')
            return (get_top_scrum_scores(compl.choices[0].message.tool_calls[0].function.arguments,logger=logger),"Put the failed reason in the response and how it did match the formula. Include the date the award was given.")
        elif compl.choices[0].message.tool_calls[0].function.name == 'get_all_top_scrum_scores':
            # return format_data_as_assistant(get_all_top_scrum_scores(compl.choices[0].message.tool_calls[0].function.arguments),"This is a team, their points, and what place/ranking they are in: ")
            if logger:
                logger.set_tense('Past')
                logger.set_ask_type('Scoring Reasons')
            return ([str(get_all_top_scrum_scores(compl.choices[0].message.tool_calls[0].function.arguments,logger=logger))],"")
        elif compl.choices[0].message.tool_calls[0].function.name == 'get_future_top_scrum_score':
            print("Future top scrum score")
            args = json.loads(compl.choices[0].message.tool_calls[0].function.arguments)
            print(args)
            environment.set_team(args['team'].split('#')[0] if '#' in args['team'] else args['team'])
            if logger:
                logger.set_tense('Future')
                logger.set_ask_type('Proactive')
            return ([str(get_future_top_scrum_score(args['team'],args['call_sign'],logger=logger))],"This data contains why the call sign will pass or fail on the award date. Answer with this data being the reason for pass or fail, not as a guideline. State why the user will pass or fail the call sign. Give the date of when the award will be awarded next.")
        elif compl.choices[0].message.tool_calls[0].function.name == 'get_leader_specifics':
            print("Leader specifics")
            args = json.loads(compl.choices[0].message.tool_calls[0].function.arguments)
            print(args)
            if logger:
                logger.set_tense('Future')
                logger.set_ask_type('Proactive')
            return ([str(get_leader_specifics(args['leader'],args['op'],logger=None))],"Here is summary of the leader's teams performance")
    return (None,None)

# 'Title': 'Payback',
# 'IsPointAwarded': True,
# 'AllotedPoint': 800,
# 'Condition': 'All User Stories Meet Formula<br/>On Day 1 of the Iteration<br/> Iteration is EQUAL to 14 Days',
# 'ConditionResult': 'User Stories Meeting Conditions: 27<br/> Total User Stories: 27<br/> Iteration is 14 Days',
# 'Formula': 'All User Stories Meet Conditions <br/> All User Stories have: Schedule State EQUAL to "D" Defined OR "P" In Progress OR "C" Completed OR "A" Accepted, Plan Estimate Complete, Task Roll-up Estimate Complete, User Story Description is NOT BLANK, User Story Acceptance is NOT BLANK<br/>',
# 'FailedReason': '',
# 'ReferenceName': '2024_May_29_GPP-MRPR-DevCPP-Sprint_1',
# 'LoggedDate': '2024-05-08T13:48:27',


def get_top_scrum_scores(team_obj,logger=None):
    def get_user_stories(EventName,GamificationDetailLogId):
        if EventName is not None:
            endpoint = None
            if EventName == 'BATTELPLAN':
                endpoint = 'GetGamificationDetaillog_BattelPlan'
                res = requests.post(f'https://app.q2e.com/api/ExternalReportApi/{endpoint}',
                    headers={"Content-Type":"application/json"},
                    data=json.dumps({"GamificationDetailLogId": GamificationDetailLogId})
                ).json()
                print(res)
                user_stories = []
                for item in res:
                    if not item['HaveAcceptanceCriteria'] or not item['HaveDescription'] or item['TaskEstimateTotal'] == 0 or item['State'] == 'Refinement':
                        user_stories.append(item)
                return user_stories
            elif EventName == 'PHOENIX':
                endpoint = 'GetGamificationDetaillog_Phoenix'
                res = requests.post(f'https://app.q2e.com/api/ExternalReportApi/{endpoint}',
                    headers={"Content-Type":"application/json"},
                    data=json.dumps({"GamificationDetailLogId": GamificationDetailLogId})
                ).json()
                return_list = []
                for key in res:
                    return_list += res[key]
                return return_list
            elif EventName == 'HONDO':
                endpoint = 'GetGamificationDetaillog_Hondo'
            elif EventName == 'HALO':
                # endpoint = 'GetGamificationDetaillog_Halo'
                # res = requests.post(f'https://app.q2e.com/api/ExternalReportApi/{endpoint}',
                #     headers={"Content-Type":"application/json"},
                #     data=json.dumps({"GamificationDetailLogId": GamificationDetailLogId})
                # ).json()
                # # Points when top half of US are accepted at day 7
                # return res[:len(res)//2] if len(res) % 2 == 0 else res[:len(res)//2+1]
                return []
            if endpoint is not None:
                print(f"Endpoint: {endpoint}")
                return requests.post(f'https://app.q2e.com/api/ExternalReportApi/{endpoint}',
                    headers={"Content-Type":"application/json"},
                    data=json.dumps({"GamificationDetailLogId": GamificationDetailLogId})
                ).json()
        return []
    def reformat_list_str(q2e_list,team):
        new_list = []
        for item in q2e_list:
            new_item = f'Team: {team}\n'
            # for key in item:
            new_item += "Completed Call Sign: True\n" if int(item['AllotedPoint']) > 0 else 'Completed Call Sign: False\n'
            new_item += f"Call Sign: {item['Title']}\n"
            new_item += f"Reason for failure: {item['FailedReason']}\n" if int(item['AllotedPoint']) > 0 else ''
            new_item += f"Passing Condition: {item['Condition']}\n"
            new_item += f"Passing Formula: {item['Formula']}\n"
            new_item += f"Points Awarded: {str(item['AllotedPoint'])}\n"
            new_item += f"Condition Result: {item['ConditionResult']}\n"
            new_item += f"Award Date: {item['LoggedDate'].split('T')[0]}\n"
            # print(f"New Item: {new_item}")
            if int(item['AllotedPoint']) == 0:
                for user_story in get_user_stories(item['EventName'],item['GamificationDetailLogId']):
                    new_item += f"Share the User Stories that caused loss of points: {user_story['ID']} - {user_story['UserStoryName']}\n"
            new_list.append(new_item)
            # new_list += new_item + '\n\n'
        # print(f"New List: {new_list}")
        return new_list
    def reformat_list(q2e_list,team):
        new_list = []
        for item in q2e_list:
            new_item = {'Team': team.split('#')[0] if '#' in team else team, 'Call Sign': item['Title'], 'Earned': True if int(item['AllotedPoint']) > 0 else False, 'Condition Results': item['ConditionResult'], 'Passing Formula': item['Formula'], 'Points Awarded': item['AllotedPoint'],'Award Date': item['LoggedDate'].split('T')[0]}
            if not new_item['Earned']:
                # Fail case
                new_item['Failed Reason'] = item['FailedReason']
                found_user_stories = []
                for user_story in get_user_stories(item['EventName'],item['GamificationDetailLogId']):
                    print("User Story: ",user_story)
                    if 'User Stories' not in new_item:
                        new_item['User Stories'] = []
                    if user_story['ID'] not in found_user_stories:  
                        found_user_stories.append(user_story['ID'])
                        new_item['User Stories'].append((str(user_story['ID']) + ': ' + str(user_story['UserStoryName']).replace('\n',' ').replace('\t',' ')).replace(': ','- '))
                    print(str(user_story['ID']) + ' - ' + str(user_story['UserStoryName']).replace('\n',' ').replace('\t',' '))
            new_list.append(new_item)
        return new_list
    print(f"In get scores (Top Scrum): {team_obj}")
    team_obj = json.loads(team_obj)
    teams = team_obj['teams'] if 'teams' in team_obj else []
    call_signs = team_obj['call_sign'] if 'call_sign' in team_obj else []
    from_date = team_obj['from_date'] if 'from_date' in team_obj else None
    to_date = team_obj['to_date'] if 'to_date' in team_obj else None
    res_list = []
    for team in teams:
        query = get_q2e_query(teams=[team],call_signs=call_signs,from_time=from_date,to_time=to_date,logger=logger)
        res_list += reformat_list(requests.post("https://app.q2e.com/api/ExternalReportApi/GetCustomReportData",
            headers={"Content-Type":"application/json"},
            data=json.dumps(query)
        ).json(),team)
    clean_teams = []
    clean_call_signs = []
    for team in teams:
        clean_teams.append(team.split('#')[0] if '#' in team else team)
    for call_sign in call_signs:
        clean_call_signs.append(call_sign.split('#')[0] if '#' in call_sign else call_sign)
    if len(res_list) == 0:
        return [f"There is no data found for team{'s' if len(clean_teams)>1 else ''} {str(clean_teams).replace('[','').replace(']','')} {f'in the given time frame' if from_date or to_date else ''} for {str(clean_call_signs).replace('[','').replace(']','') if len(clean_call_signs)>0 else 'the given parameters'}."]
    return res_list

def get_q2e_query(teams=[],call_signs=[],from_time=None,to_time=None,logger=None):
    print(f"From time: {from_time}, To time: {to_time}")
    query = {
        "PassingObjects": {
            "Filters": [],
            "DrillToChildData": [],
            "ClientId": 98,
            "ReportId": 6567,
            "LevelNumber": 1,
            "LevelViewNumber": 1,
            "IsDrillToTask": False
        },
        "IsPrimary": True,
        "UserId": 1
    }
    if len(teams) > 0:
        team_filter =    {
            "ConditionalFieldFormula": "",
            "FilterDataType": "MENU",
            "FilterItems": [],
            "FilterKey": "ProjectName",
            "FilterType": "FILTER",
            "FilterValue": "",
            "FromValue": "",
            "ToValue": ""
        }
        for team in teams:
            if team != 'NONE':
                team_filter['FilterItems'].append({
                        "Id": int(team.split('#')[1]),
                        "Name": team.split('#')[0]
                    })
                if logger:
                    logger.set_team(team.split('#')[0])
        if len(team_filter['FilterItems']) > 0:
            query["PassingObjects"]['Filters'].append(team_filter)
            print('team appended')
    if len(call_signs) > 0:
        call_sign_filter = {
                    "ConditionalFieldFormula": "",
                    "FilterDataType": "MENU",
                    "FilterItems": [],
                    "FilterKey": "Title",
                    "FilterType": "FILTER",
                    "FilterValue": "",
                    "FromValue": "",
                    "ToValue": ""
                }
        for call_sign in call_signs:
            call_sign_filter['FilterItems'].append({
                            "Name": call_sign.split('#')[0],
                            "Id": int(call_sign.split('#')[1]),
                            "DB_name": "Title"
                        })
            if logger:
                logger.set_call_sign(call_sign.split('#')[0])
        query["PassingObjects"]['Filters'].append(call_sign_filter)
    if from_time or to_time:
        time_filter = {
            "ConditionalFieldFormula": "",
            "FilterDataType": "DATE",
            "FilterItems": [],
            "FilterKey": "LoggedDate",
            "FilterType": "FILTER",
            "FilterValue": "TM",
        }
        if from_time:
            time_filter["FromValue"] = from_time
        if to_time:
            time_filter["ToValue"] = to_time
        query["PassingObjects"]['Filters'].append(time_filter)
    return query

def get_all_top_scrum_scores(team_obj,logger=None):
    print(f"In get all scores (Top Scrum): {team_obj}")
    team_obj = json.loads(team_obj)
    res = requests.post("https://app.q2e.com/api/ExternalReportApi/GetExternalSummaryCustomReportDataQuery",
        headers={"Content-Type":"application/json"},
        data=json.dumps(get_team_totals_query())
    ).json()
    team_data = []
    search_teams = team_obj['teams'] if 'teams' in team_obj else []
    for i,team in enumerate(res):
        if len(search_teams) > 0:
            print(team['ProjectName_113'] + " " + str(search_teams))
        if len(search_teams) > 0 and team['ProjectName_113'] not in search_teams:
            continue
        print(f"Team: {team['ProjectName_113']}, Points: {team['AllotedPoint_105']}, Leader: {team['CONF_3012']}, Rank: {i+1}")
        team_data.append(f"Team: {team['ProjectName_113']}\nTotal Points: {int(team['AllotedPoint_105'])}\nLeader: {team['CONF_3012']}\nTeam Rank: {i+1}")
    return team_data

def get_team_totals_query():
    return {
        "PassingObjects": {
            "ClientId": 98,
            "ReportId": 5325,
            "LevelNumber": 1,
            "LevelViewNumber": 1,
            "IsDrillToTask": False,
            "Filters": [
                {
                    "FilterKey": "Title_204",
                    "FilterValue": "",
                    "FilterType": "FILTER",
                    "FilterDataType": "MENU",
                    "FromValue": "",
                    "ToValue": "",
                    "FilterItems": [
                        {
                            "Id": "495",
                            "Name": "Top Scrum - Mission 2.0"
                        }
                    ],
                    "ConditionalFieldFormula": ""
                }
            ],
            "DrillToChildData": {
                "ParentColumnName": "",
                "ChildColumnName": ""
            },
            "IsPaginatedTable": True,
            "OrderBy": "AllotedPoint_105",
            "Order": "DESC",
            "RECORDCOUNT": 77,
            "VIEWCOUNT": 1
        },
        "IsPrimary": True,
        "UserId": 1
    }

def get_future_top_scrum_score(team,call_sign,logger=None):
    print(f"Team: {team}, Call Sign: {call_sign}")
    if logger:
        logger.set_team(team.split('#')[0] if '#' in team else team)
        logger.set_call_sign(call_sign.split('#')[0] if '#' in call_sign else call_sign)
    if call_sign and call_sign != 'NONE':
        call_sign = call_sign.split('#')[0] if '#' in call_sign else call_sign
        call_sign = call_sign.lower().replace(' ','_')
        call_sign = call_sign.replace('payback','pay_back')
        call_sign = call_sign.replace('afterburn','after_burn')
        try:
            response = requests.get(f'{environment.get_tickets_endpoint()}/top-scrum/{call_sign}?team={team}',verify='./optum.pem')
            data = response.json()
            print(data)
            environment.set_asks(team,call_sign,data)
            return data
        except Exception as e:
            print("Failed to get future top scrum score ",e)
            return "Failed to get future top scrum score" + (' for team ' + team if team else '') + (' and call sign ' + call_sign if call_sign else '')
    return "No specific call sign provided. Please provide a single call sign to get the future score for."

def get_leader_specifics(leader,op,logger=None):
    def reformat_list(q2e_list,team):
        new_list = []
        for item in q2e_list:
            new_item = {'Team': team.split('#')[0] if '#' in team else team, 'Call Sign': item['Title'], 'Earned': True if int(item['AllotedPoint']) > 0 else False, 'Condition Results': item['ConditionResult'], 'Passing Formula': item['Formula'], 'Points Awarded': item['AllotedPoint'],'Award Date': item['LoggedDate'].split('T')[0]}
            if not new_item['Earned']:
                # Fail case
                new_item['Failed Reason'] = item['FailedReason']
                new_list.append(new_item)
        return new_list
    
    if leader:
        print(f"Leader: {leader}")
        print(f"Op: {op}")
    if op == 'total_points':
        res = requests.post("https://app.q2e.com/api/ExternalReportApi/GetExternalSummaryCustomReportDataQuery",
            headers={"Content-Type":"application/json"},
            data=json.dumps(get_team_totals_query())
        ).json()
        points = 0
        for team in res:
            if team['CONF_3012'] == leader:
                points += int(team['AllotedPoint_105']) if team['AllotedPoint_105'] else 0
        return f"{leader} has {points} across {len(res)} teams"
    elif op == 'failure_percents':
        print('Leader: ',leader)
        cs_stats = {}
        leaders_teams = top_scrum_team_with_id_list[leader] if leader in top_scrum_team_with_id_list else []
        for team in leaders_teams:
            print(f"Team: {team}")
            query = get_q2e_query(teams=[team],logger=logger)
            res = requests.post("https://app.q2e.com/api/ExternalReportApi/GetCustomReportData",
                headers={"Content-Type":"application/json"},
                data=json.dumps(query)
            ).json()
            for item in res:
                if item['EventName'] not in cs_stats:
                    cs_stats[item['EventName']] = {'Attempts':0,'Failed':0}
                cs_stats[item['EventName']]['Attempts'] += 1
                if int(item['AllotedPoint']) == 0:
                    cs_stats[item['EventName']]['Failed'] += 1
        for cs in cs_stats:
            cs_stats[cs]['Percent'] = round(cs_stats[cs]['Failed']/cs_stats[cs]['Attempts']*100,2)
        return cs_stats
    elif len(op) > 0:
        cs_stats = {}
        leaders_teams = top_scrum_team_with_id_list[leader] if leader in top_scrum_team_with_id_list else []
        for team in leaders_teams:
            print(f"Team: {team}")
            query = get_q2e_query(teams=[team], call_signs=[op],logger=logger)
            res = requests.post("https://app.q2e.com/api/ExternalReportApi/GetCustomReportData",
                headers={"Content-Type":"application/json"},
                data=json.dumps(query)
            ).json()
            for item in res:
                if item['EventName'] not in cs_stats:
                    cs_stats[item['EventName']] = {'Attempts':0,'Failed':0}
                cs_stats[item['EventName']]['Attempts'] += 1
                if int(item['AllotedPoint']) == 0:
                    cs_stats[item['EventName']]['Failed'] += 1
        for cs in cs_stats:
            cs_stats[cs]['Percent'] = round(cs_stats[cs]['Failed']/cs_stats[cs]['Attempts']*100,2)
        return cs_stats


    return "No operation matched for stats by leader"