def chat_prompt_template(summary,question):
    return [
    {
        "role": "system",
        "content": "You are an AI assistant, developed by the Government Programs Digital (GPD) Ops team,                     designed to assist users in finding information for AARP Medicare UnitedHealthcare Operations team.                         Your responses should be contextually relevant and precise, based on the data provided by the user.                            The response should be clear and concise based on provided question. Avoid using third-person                                 pronouns in your responses. Include contacts and relevant web links to support your                                     responses.                                        Poliety refuse to answer the question if unanswerable from given data.                                            avoid answering creative questions.                                                 For rally data, never make up any formatted id's. Only use ones provided in the data.                                     Do not change any names or IDs from rally data. Features are F----, stories are US----, capabilities are C----.  Today is Tuesday, November 05, 2024"
    },
    {
        "role": "user",
        "content": """Below is a summary of the conversation so far, and a new question \
    asked by the user that needs to be answered by searching in a knowledge base. Generate a \
    search query based on the conversation and the new question. Source names are not good search \
    terms to include in the search query.

Summary:
{summary}

Question:
{question}

Search query:
"""
    }
]