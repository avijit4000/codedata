import datetime
import requests
import pytz
import json
import re

from azure_funcs import *
from tickets_funcs import *
from top_scrum_funcs import *
from system_messages import *
from environment import *
from azure.ai.formrecognizer import DocumentAnalysisClient

from chatbot_logging import ChatbotLogger

from ops_chatbot.tool_calling import ops_tool_call


def format_bounding_box(bounding_box):
    if not bounding_box:
        return "N/A"
    return ", ".join(["[{}, {}]".format(p.x, p.y) for p in bounding_box])

def analyze_read(file):
    # sample document
    endpoint = "https://document-chunking.cognitiveservices.azure.com/"
    key = AZURE_DOC_KEY
    #formUrl = "https://raw.githubusercontent.com/Azure-Samples/cognitive-services-REST-api-samples/master/curl/form-recognizer/sample-layout.pdf"

    document_analysis_client = DocumentAnalysisClient(
        endpoint=endpoint, credential=AzureKeyCredential(key)
    )
    
    #poller = document_analysis_client.begin_analyze_document_from_url("prebuilt-read", formUrl)
    #with open(img_path, "rb") as f:
    poller = document_analysis_client.begin_analyze_document(
           "prebuilt-invoice", document=file, locale="en-US"
    )
    result = poller.result()

    print ("Document contains content: ", result.content)
    
    for idx, style in enumerate(result.styles):
        print(
            "Document contains {} content".format(
                "handwritten" if style.is_handwritten else "no handwritten"
            )
        )

    print("----------------------------------------")
    return result.content
def to_camel_case(snake_str):
    components = re.split(' |_|-', snake_str)
    return components[0].lower() + ''.join(x.title() for x in components[1:])
 
def convert_keys_to_camel_case(data):
    if isinstance(data, dict):
        return {to_camel_case(k): convert_keys_to_camel_case(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_keys_to_camel_case(i) for i in data]
    else:
        return data
 


def get_bottle_response(filepath):
    messagess = [{"role": "system",
                 #"content": "You are an AI assistant, developed by Krishna Gupta, designed to assist users in finding information for AARP Medicare UnitedHealthcare Telesales team. Your responses should be contextually relevant and precise, based on the data provided by the user.The response should be clear and concise based on provided question. Avoid using third-person pronouns in your responses. if there is no information provided in the data then return 'NO info'"
              "content" : f"""
     You have to categorize the medicine label information into following categories : Drug Name
Dosage
Quantity
Frequence
Pharmacy Name
Pharmacy Address
Doctor Name (If any)
Doctor address (if any)
Contact Number

if other information available then label it as misc data as single label string. Keep good json structure . unlabeled address assign it to pharmacy address. uncategorized label as empty string. fix druges name and usa pharmacy name if wrong.
    """
            }]
        
        
    content = "Medicine Label : "+ analyze_read(filepath)
    messagess.append({"role": "user", "content": content})
    completion = openaii.chat.completions.create(
        messages=messagess,
        model=  PILL_BOTTLE_MODEL, #'krishna-gpt4',
        temperature=0.1,
        max_tokens=200,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        #stream=True
    )
    chat_response = completion.choices[0].message.content
    parsed_data = json.loads(chat_response)
    converted_data = convert_keys_to_camel_case(parsed_data)
    cr = json.dumps(converted_data, indent=2)
    return cr