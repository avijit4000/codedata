from flask import Flask, request, jsonify
from utils.logging import logger 
# from LLM.llm_azure import FormAssistant
from LLM.llm_azure import FormChatBot
app = Flask(__name__)

# assistant = FormAssistant()

# @app.route('/ask_question', methods=['POST'])
# def ask_question():
#     data = request.json
#     user_input = data.get('field_name')
#     logger.info(f"Received field_name: {user_input}")
#     asking_question = assistant.generate_question(user_input)
#     logger.info(f"Generated question: {asking_question}")
#     return jsonify({"question": asking_question})
#
#
# @app.route('/extract_answer', methods=['POST'])
# def extract_answer():
#     data = request.json
#     asking_question = data.get('asking_question')
#     user_ans = data.get('user_answer')
#     logger.info(f"Received asking_question: {asking_question}")
#     logger.info(f"Received user_answer: {user_ans}")
#     ans_output = assistant.extract_answer(asking_question, user_ans)
#     logger.info(f"Extracted answer: {ans_output}")
#     return jsonify({"extracted_answer": ans_output})
#
#
# if __name__ == '__main__':
#     logger.info("Starting Flask API server on http://0.0.0.0:8080")
#     app.run(host='0.0.0.0', port=8080, debug=True, use_reloader=True)


# {
#     "field_name": "First Name"
# }



# {
#     "asking_question": "What is your first name?",
#     "user_answer": "My last name is Avijit Biswas. My date of birth 19 apr 1993"
# }


chatbot = FormChatBot()
@app.route("/chatbot", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "").strip()
    logger.info(f"User input: {user_input}")
    user_id = data.get("user_id", "").strip()

    if not user_input:
        if chatbot.index == 0:
            return jsonify({
                "message": "Hello! 👋",
                "next_question": chatbot.questions[chatbot.asked_keys[0]]
            })
        else:
            current_key = chatbot.asked_keys[chatbot.index]
            return jsonify({
                "message": "Please provide input to continue.",
                "next_question": chatbot.questions[current_key]
            })

    if user_input.lower() in ["exit", "quit"]:
        logger.info("Chatbot exited by user.")
        return jsonify({
            "message": "Chatbot: Exiting. Goodbye! 👋",
            "end": True
        })

    bot_response = chatbot.process_input(user_input,user_id)

    if bot_response == "invalid":
        current_key = chatbot.asked_keys[chatbot.index]
        return jsonify({
            "message": "Invalid input, please answer correctly.",
            "next_question": chatbot.questions[current_key]
        })

    next_question = chatbot.get_next_question()

    if not next_question:
        return jsonify({
            "message": "Completed ✅",
            "responses": chatbot.responses,
            "end": True
        })

    return jsonify({"message": bot_response, "question": next_question})

if __name__ == '__main__':
    logger.info("Starting Flask API server on http://0.0.0.0:8080")
    app.run(host='0.0.0.0', port=8080, debug=True, use_reloader=True)