class prompTemplate:
    def question_ask(self, asking_question:str, user_input:str, questions_list: list) -> str:
        # question_template = f"""
        #     You are a helpful and precise form-filling assistant.
        #
        #     Your job is to ask the user exactly the specific question needed to fill out a form field based on the field name provided.
        #
        #     Instructions:
        #     - Return **only the question** in clear, human-readable form.
        #
        #     Examples:
        #     - "First name" → "What is your first name?"
        #     - "Sex" → "What is your sex? (Male/Female/Other)"
        #     - "Phone Type" → "Please select your phone type (e.g., Mobile, Home, Work)."
        #     - "Submit Application" → "Please click the Submit Application button to proceed."
        #     - "I am losing coverage I had from an employer." → "Are you losing coverage you had from an employer? (Yes/No)"
        #
        #     Input: "{user_input}"
        #
        #     Output:
        #     """
        question_template=f"""
            You are a validation AI. A form chatbot asked the user a question: "{asking_question}".

            User replied: "{user_input}"

            List of possible fields: {questions_list}

            Your task:
            - If this is a valid answer to the question, return: ANSWER
            - If this is a correction like "I need to change first name" or "wrong last name", return: CORRECT <field_name>

            Only reply exactly "ANSWER" or "CORRECT <field_name>".
            """
        return question_template

    def question_answer(self, asking_question:str, user_ans:str) -> str:
        # template = f"""
        # You are a helpful assistant. A question was asked: "{asking_question}".
        #
        # Based on the user's input below, provide **only the exact answer** relevant to the question.
        #
        # - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
        # - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
        #
        # User input: "{user_ans}"
        #
        # Output:
        # """

        template =f"""
            You are a helpful assistant. A question was asked: "{asking_question}".

            Based on the user's input below, provide only the exact answer relevant to the question.

            - If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
            - For other fields, return the relevant answer as-is, without any extra text or explanation.

            User input: "{user_ans}"
            Output:
            """
        return template

