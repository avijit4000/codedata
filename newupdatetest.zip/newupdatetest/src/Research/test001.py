from ..globals import *
print(questions)
