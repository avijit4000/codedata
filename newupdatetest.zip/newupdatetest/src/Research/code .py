import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain


load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL")
print(azure_model, api_version, azure_endpoint, api_key)

llm = AzureChatOpenAI(
    openai_api_key=api_key,
    azure_endpoint=azure_endpoint,
    azure_deployment=azure_model,
    api_version=api_version,
    temperature=0.0
)
user_input = """ sex  """

question_template = f"""
            You are a helpful and precise form-filling assistant.

            Your job is to ask the user exactly the specific question needed to fill out a form field based on the field name provided.

            Instructions:
            - Return **only the question** in clear, human-readable form.

            Examples:
            - "First name" → "What is your first name?"
            - "Sex" → "What is your sex? (Male/Female/Other)"
            - "Phone Type" → "Please select your phone type (e.g., Mobile, Home, Work)."
            - "Submit Application" → "Please click the Submit Application button to proceed."
            - "I am losing coverage I had from an employer." → "Are you losing coverage you had from an employer? (Yes/No)"

            Input: "{user_input}"

            Output:
            """

Q_CHAIN_PROMPT = PromptTemplate(
    input_variables=["user_input"],
    template=question_template
)

asking_chain = LLMChain(
    llm=llm,
    prompt=Q_CHAIN_PROMPT,
    verbose=True
)

asking_result = asking_chain.run(user_input=user_input)
asking_question=asking_result.strip()

print(asking_question)

user_ans = """My name is Avijit Biswas. My date of birth is 19 Apr 1999. i am male."""
print(f"{user_ans}")

template = f"""
You are a helpful assistant. A question was asked: "{asking_question}".

Based on the user's input below, provide **only the exact answer** relevant to the question.

Instructions:
- If the question is about "date of birth" or any date field, detect the date in any format (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
- For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
- If the user's answer does not contain information for the field in the question, return:
  "User didn't provide the {asking_question.replace('What is your ', '').replace('?', '')}."

User input: "{user_ans}"

Output:
"""

A_CHAIN_PROMPT = PromptTemplate(
    input_variables=["user_input"],
    template=template
)

ans_chain = LLMChain(
    llm=llm,
    prompt=A_CHAIN_PROMPT,
    verbose=True
)

ans_result = ans_chain.run(user_input=user_ans)
ans_output=ans_result.strip()
print(ans_output)


#
# import os
# from dotenv import load_dotenv
# from langchain_openai import AzureChatOpenAI
# from langchain_core.prompts import PromptTemplate
# from langchain.chains import LLMChain
# from langchain.memory import ConversationBufferMemory
#
# # ------------------- Load ENV -------------------
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
# print(azure_model, api_version, azure_endpoint, api_key)
#
# # ------------------- LLM Setup -------------------
# llm = AzureChatOpenAI(
#     openai_api_key=api_key,
#     azure_endpoint=azure_endpoint,
#     azure_deployment=azure_model,
#     api_version=api_version,
#     temperature=0.0
# )
#
# # ------------------- Memory -------------------
# memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
#
# # ------------------- Question Chain -------------------
# Q_CHAIN_PROMPT = PromptTemplate(
#     input_variables=["user_input", "chat_history"],
#     template="""
#     You are a helpful and precise form-filling assistant.
#
#     Your job is to ask the user exactly the specific question needed
#     to fill out a form field based on the field name provided.
#
#     Conversation so far:
#     {chat_history}
#
#     Field name: "{user_input}"
#
#     Output: Return ONLY the question to ask.
#     """
# )
#
# asking_chain = LLMChain(
#     llm=llm,
#     prompt=Q_CHAIN_PROMPT,
#     memory=memory,
#     verbose=True
# )
#
# # ------------------- Answer Chain -------------------
# A_CHAIN_PROMPT = PromptTemplate(
#     input_variables=["user_input", "chat_history"],
#     template="""
#     A form-filling assistant asked: "{chat_history[-1]}".
#
#     Based on the user's input below, provide ONLY the exact answer relevant to the last question.
#
#     - If the question is about "date of birth" or any date field, detect the date in any format
#       (e.g., "April 19, 1999", "19/04/1999") and return it in DD-MM-YYYY format.
#     - For other fields, return the relevant answer as-is, without any extra text, punctuation, or explanation.
#
#     User input: "{user_input}"
#
#     Output:
#     """
# )
#
# ans_chain = LLMChain(
#     llm=llm,
#     prompt=A_CHAIN_PROMPT,
#     memory=memory,
#     verbose=True
# )
#
# # ------------------- Example Run -------------------
# if __name__ == "__main__":
#     user_input = "City"
#     asking_result = asking_chain.run(user_input=user_input).strip()
#     print(f"Bot asks: {asking_result}")
#
#     user_ans = "My name is Avijit Biswas. I am from kolkata. My date of birth is 19 Apr 1999."
#     print(f"You: {user_ans}")
#
#     ans_result = ans_chain.run(user_input=user_ans).strip()
#     print(f"Extracted Answer: {ans_result}")
#
#     # Show memory contents
#     print("\n--- Memory ---")
#     print(memory.buffer)
