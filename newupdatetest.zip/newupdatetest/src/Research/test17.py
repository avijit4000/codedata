# from flask import Flask, request, jsonify
# import openai
# import os
# from dotenv import load_dotenv
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# print(azure_endpoint, api_key)
#
# app = Flask(__name__)
#
# # Azure OpenAI Configuration
# openai.api_type = "azure"
# openai.api_version = "2023-05-15"
# openai.api_key = azure_endpoint
# openai.azure_endpoint = api_key
#
# # Form schema and session tracking
# REQUIRED_FIELDS = ["first_name", "last_name", "address", "gender", "terms_and_conditions"]
# SESSION_DATA = {}
#
# def get_next_field(session_id):
#     for field in REQUIRED_FIELDS:
#         if SESSION_DATA[session_id]["form"][field] is None:
#             return field
#     return None  # Means form is filled
#
# @app.route("/chatbot", methods=["POST"])
# def chatbot():
#     data = request.get_json()
#     session_id = data.get("session_id", "user1")
#     user_input = data.get("message", "").strip()
#
#     # Initialize session if new
#     if session_id not in SESSION_DATA:
#         SESSION_DATA[session_id] = {
#             "form": {field: None for field in REQUIRED_FIELDS},
#             "current_field": "first_name"
#         }
#         return jsonify({"message": "👋 Hello! Let's start. What is your first name?"})
#
#     current_field = SESSION_DATA[session_id]["current_field"]
#
#     # Handle corrections like: "XYZ is not my first name, change to MNOP"
#     if "change" in user_input.lower() or "not my" in user_input.lower():
#         for field in REQUIRED_FIELDS:
#             if field.replace("_", " ") in user_input.lower():
#                 new_value = user_input.split("to")[-1].strip().replace(".", "")
#                 SESSION_DATA[session_id]["form"][field] = new_value
#                 return jsonify({"message": f"✅ Updated {field.replace('_',' ').title()} to: {new_value}. Continue?"})
#
#     # If user says SUBMIT
#     if "submit" in user_input.lower():
#         return jsonify({
#             "message": "🎉 Form submitted successfully!",
#             "form_data": SESSION_DATA[session_id]["form"]
#         })
#
#     # Store response for current field
#     SESSION_DATA[session_id]["form"][current_field] = user_input
#
#     # Move to next field
#     next_field = get_next_field(session_id)
#
#     if next_field:
#         SESSION_DATA[session_id]["current_field"] = next_field
#         question_text = {
#             "first_name": "What is your first name?",
#             "last_name": "What is your last name?",
#             "address": "Please provide your address.",
#             "gender": "What is your gender? (Male/Female/Other)",
#             "terms_and_conditions": "Do you agree to the terms and conditions? (Yes/No)"
#         }
#         return jsonify({"message": f"✅ Saved! {question_text[next_field]}"})
#
#     return jsonify({
#         "message": "✅ All fields filled. Say 'Submit' to finish.",
#         "form_data": SESSION_DATA[session_id]["form"]
#     })
#
# if __name__ == "__main__":
#     app.run(debug=True)


#
# from flask import Flask, request, jsonify
# import openai
# import os
# from dotenv import load_dotenv
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
#
# app = Flask(__name__)
#
# openai.api_type = "azure"
# openai.api_version = "2023-05-15"
# openai.api_key = api_key
# openai.azure_endpoint = azure_endpoint
#
# REQUIRED_FIELDS = ["first_name", "last_name", "address", "gender", "terms_and_conditions"]
# SESSION_DATA = {}
#
# def get_next_field(session_id):
#     for field in REQUIRED_FIELDS:
#         if SESSION_DATA[session_id]["form"][field] is None:
#             return field
#     return None
#
# @app.route("/chatbot", methods=["POST"])
# def chatbot():
#     data = request.get_json()
#     session_id = data.get("session_id", "user1")
#     user_input = data.get("message", "").strip()
#
#     if session_id not in SESSION_DATA:
#         SESSION_DATA[session_id] = {
#             "form": {field: None for field in REQUIRED_FIELDS},
#             "current_field": "first_name"
#         }
#         return jsonify({
#             "message": "👋 Hello! Let's start. What is your first name?",
#             "update_field": None,
#             "update_value": None,
#             "form_data": SESSION_DATA[session_id]["form"]
#         })
#
#     current_field = SESSION_DATA[session_id]["current_field"]
#
#     # Handle corrections like: "XYZ is not my first name, change to MNOP"
#     if "change" in user_input.lower() or "not my" in user_input.lower():
#         for field in REQUIRED_FIELDS:
#             if field.replace("_", " ") in user_input.lower():
#                 new_value = user_input.split("to")[-1].strip().replace(".", "")
#                 SESSION_DATA[session_id]["form"][field] = new_value
#                 return jsonify({
#                     "message": f"✅ Updated {field.replace('_',' ').title()} to: {new_value}. Continue?",
#                     "update_field": field,
#                     "update_value": new_value,
#                     "form_data": SESSION_DATA[session_id]["form"]
#                 })
#
#     # If user says SUBMIT
#     if "submit" in user_input.lower():
#         return jsonify({
#             "message": "🎉 Form submitted successfully!",
#             "update_field": None,
#             "update_value": None,
#             "form_data": SESSION_DATA[session_id]["form"]
#         })
#
#     # Store response for current field
#     SESSION_DATA[session_id]["form"][current_field] = user_input
#     update_field = current_field
#     update_value = user_input
#
#     # Move to next field
#     next_field = get_next_field(session_id)
#
#     if next_field:
#         SESSION_DATA[session_id]["current_field"] = next_field
#         question_text = {
#             "first_name": "What is your first name?",
#             "last_name": "What is your last name?",
#             "address": "Please provide your address.",
#             "gender": "What is your gender? (Male/Female/Other)",
#             "terms_and_conditions": "Do you agree to the terms and conditions? (Yes/No)"
#         }
#         return jsonify({
#             "message": f"✅ Saved! {question_text[next_field]}",
#             "update_field": update_field,
#             "update_value": update_value,
#             "form_data": SESSION_DATA[session_id]["form"]
#         })
#
#     return jsonify({
#         "message": "✅ All fields filled. Say 'Submit' to finish.",
#         "update_field": update_field,
#         "update_value": update_value,
#         "form_data": SESSION_DATA[session_id]["form"]
#     })
#
# if __name__ == "__main__":
#     app.run(debug=True)



from flask import Flask, request, jsonify
import openai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")

# Initialize Flask app
app = Flask(__name__)

# Configure OpenAI for Azure
openai.api_type = "azure"
openai.api_version = "2023-05-15"
openai.api_key = api_key
openai.api_base = azure_endpoint  # Corrected line

# Form fields
REQUIRED_FIELDS = ["first_name", "last_name", "address", "gender", "terms_and_conditions"]
SESSION_DATA = {}

# Get next unfilled field
def get_next_field(session_id):
    for field in REQUIRED_FIELDS:
        if SESSION_DATA[session_id]["form"][field] is None:
            return field
    return None

@app.route("/chatbot", methods=["POST"])
def chatbot():
    data = request.get_json()
    session_id = data.get("session_id", "user1")
    user_input = data.get("message", "").strip()
    user_input_lower = user_input.lower()

    # Initialize session if not exists
    if session_id not in SESSION_DATA:
        SESSION_DATA[session_id] = {
            "form": {field: None for field in REQUIRED_FIELDS},
            "current_field": "first_name"
        }
        return jsonify({
            "message": "👋 Hello! Let's start. What is your first name?",
            "update_field": None,
            "update_value": None,
            "form_data": SESSION_DATA[session_id]["form"]
        })

    current_field = SESSION_DATA[session_id]["current_field"]

    # Handle corrections
    if "change" in user_input_lower or "not my" in user_input_lower:
        for field in REQUIRED_FIELDS:
            if field.replace("_", " ") in user_input_lower:
                # Extract new value after "to"
                if "to" in user_input_lower:
                    new_value = user_input.split("to")[-1].strip().replace(".", "")
                    SESSION_DATA[session_id]["form"][field] = new_value
                    SESSION_DATA[session_id]["current_field"] = get_next_field(session_id)
                    return jsonify({
                        "message": f"✅ Updated {field.replace('_',' ').title()} to: {new_value}. Continue?",
                        "update_field": field,
                        "update_value": new_value,
                        "form_data": SESSION_DATA[session_id]["form"]
                    })

    # Handle form submission
    if "submit" in user_input_lower:
        return jsonify({
            "message": "🎉 Form submitted successfully!",
            "update_field": None,
            "update_value": None,
            "form_data": SESSION_DATA[session_id]["form"]
        })

    # Store response for current field
    SESSION_DATA[session_id]["form"][current_field] = user_input
    update_field = current_field
    update_value = user_input

    # Move to next field
    next_field = get_next_field(session_id)

    question_text = {
        "first_name": "What is your first name?",
        "last_name": "What is your last name?",
        "address": "Please provide your address.",
        "gender": "What is your gender? (Male/Female/Other)",
        "terms_and_conditions": "Do you agree to the terms and conditions? (Yes/No)"
    }

    if next_field:
        SESSION_DATA[session_id]["current_field"] = next_field
        return jsonify({
            "message": f"✅ Saved! {question_text[next_field]}",
            "update_field": update_field,
            "update_value": update_value,
            "form_data": SESSION_DATA[session_id]["form"]
        })

    return jsonify({
        "message": "✅ All fields filled. Say 'Submit' to finish.",
        "update_field": update_field,
        "update_value": update_value,
        "form_data": SESSION_DATA[session_id]["form"]
    })

if __name__ == "__main__":
    app.run(debug=True)
