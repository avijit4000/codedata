# import os
# import sounddevice as sd
# import wave
# import uuid
# from openai import AzureOpenAI
# from dotenv import load_dotenv
#
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
#
# azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
# api_key = os.getenv("AZURE_OPENAI_API_KEY")
# api_version = os.getenv("AZURE_OPENAI_API_VERSION")
# azure_model = os.getenv("AZURE_OAI_MODEL")
#
# client = AzureOpenAI(
#     api_key=api_key,
#     api_version=api_version,
#     azure_endpoint=azure_endpoint,
# )
#
# # 🎤 Record audio from microphone
# def record_audio(filename="input.wav", duration=5, samplerate=16000):
#     print("🎙️ Recording... speak now")
#     audio = sd.rec(int(duration * samplerate), samplerate=samplerate, channels=1, dtype="int16")
#     sd.wait()
#     wavefile = wave.open(filename, "wb")
#     wavefile.setnchannels(1)
#     wavefile.setsampwidth(2)  # 16-bit
#     wavefile.setframerate(samplerate)
#     wavefile.writeframes(audio.tobytes())
#     wavefile.close()
#     print("✅ Recording saved:", filename)
#
# # 📝 Speech-to-Text
# def speech_to_text(filename="input.wav"):
#     with open(filename, "rb") as f:
#         transcript = client.audio.transcriptions.create(
#             model="whisper-1",
#             file=f
#         )
#     return transcript.text
#
# # 💬 GPT Conversation
# def chat_with_gpt(user_text):
#     response = client.chat.completions.create(
#         model="gpt-4o-mini",
#         messages=[
#             {"role": "system", "content": "You are a helpful voice assistant."},
#             {"role": "user", "content": user_text},
#         ],
#     )
#     return response.choices[0].message.content
#
# # 🔊 Text-to-Speech
# def text_to_speech(text, voice="alloy"):
#     out_file = f"reply_{uuid.uuid4()}.mp3"
#     with client.audio.speech.with_streaming_response.create(
#         model="gpt-4o-tts",
#         voice=voice,
#         input=text,
#     ) as response:
#         response.stream_to_file(out_file)
#     print("🔊 Reply saved as:", out_file)
#     return out_file
#
# # ▶️ Play audio
# def play_audio(filename):
#     import simpleaudio as sa
#     wave_obj = sa.WaveObject.from_wave_file(filename) if filename.endswith(".wav") else sa.WaveObject.from_wave_file(filename.replace(".mp3", ".wav"))
#     play_obj = wave_obj.play()
#     play_obj.wait_done()
#
# # 🔁 Conversation loop
# def main():
#     while True:
#         record_audio("input.wav", duration=5)
#         user_text = speech_to_text("input.wav")
#         print("👤 You:", user_text)
#
#         if user_text.lower() in ["quit", "exit", "stop"]:
#             print("👋 Ending conversation.")
#             break
#
#         reply = chat_with_gpt(user_text)
#         print("🤖 Assistant:", reply)
#
#         audio_file = text_to_speech(reply, voice="alloy")
#         # Convert MP3 → WAV for playback (simpleaudio needs WAV)
#         import pydub
#         sound = pydub.AudioSegment.from_mp3(audio_file)
#         wav_file = audio_file.replace(".mp3", ".wav")
#         sound.export(wav_file, format="wav")
#
#         play_audio(wav_file)
#
# if __name__ == "__main__":
#     main()


import os
import queue
import sounddevice as sd
import numpy as np
import tempfile
import uuid
from openai import AzureOpenAI
from dotenv import load_dotenv
from pydub import AudioSegment
import simpleaudio as sa

# 🔑 Load environment variables
load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")

azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")

client = AzureOpenAI(
    api_key=api_key,
    api_version=api_version,
    azure_endpoint=azure_endpoint,
)

# 🎤 Microphone streaming setup
samplerate = 16000
channels = 1
q = queue.Queue()

def audio_callback(indata, frames, time, status):
    """Callback from mic -> push chunks into queue."""
    if status:
        print(status)
    q.put(indata.copy())

# ▶️ Play audio (WAV)
def play_audio(filename):
    wave_obj = sa.WaveObject.from_wave_file(filename)
    play_obj = wave_obj.play()
    play_obj.wait_done()

# 📝 Speech-to-Text (one chunk at a time)
def transcribe_chunk(audio_file):
    with open(audio_file, "rb") as f:
        transcript = client.audio.transcriptions.create(
            model="whisper-1",
            file=f
        )
    return transcript.text.strip()

# 💬 GPT response
def chat_with_gpt(user_text):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": user_text}],
    )
    return response.choices[0].message.content

# 🔊 GPT Text-to-Speech
def text_to_speech_stream(text, voice="alloy"):
    out_file = f"reply_{uuid.uuid4()}.mp3"
    with client.audio.speech.with_streaming_response.create(
        model="gpt-4o-tts",
        voice=voice,
        input=text,
    ) as response:
        response.stream_to_file(out_file)

    # Convert MP3 → WAV for playback
    wav_file = out_file.replace(".mp3", ".wav")
    sound = AudioSegment.from_mp3(out_file)
    sound.export(wav_file, format="wav")
    return wav_file

# 🔁 Real-time loop
def main():
    print("🎙️ Real-time conversation started. Say 'stop' to quit.")
    buffer = np.array([], dtype=np.int16)

    with sd.InputStream(samplerate=samplerate, channels=channels, callback=audio_callback):
        while True:
            # Collect audio chunks
            chunk = q.get()
            buffer = np.append(buffer, chunk.flatten())

            # If buffer has ~3 seconds of audio → process
            if len(buffer) > samplerate * 3:
                # Save temp wav
                with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                    AudioSegment(
                        buffer.tobytes(),
                        frame_rate=samplerate,
                        sample_width=2,
                        channels=1
                    ).export(tmp.name, format="wav")
                    user_text = transcribe_chunk(tmp.name)

                if user_text:
                    print("👤 You:", user_text)

                    if user_text.lower() in ["stop", "quit", "exit"]:
                        print("👋 Conversation ended.")
                        break

                    reply = chat_with_gpt(user_text)
                    print("🤖 Assistant:", reply)

                    wav_reply = text_to_speech_stream(reply)
                    play_audio(wav_reply)

                # Reset buffer
                buffer = np.array([], dtype=np.int16)

if __name__ == "__main__":
    main()
