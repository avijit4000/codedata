import os
import sys
import asyncio
import logging
from dotenv import load_dotenv

from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent
from langchain_openai import AzureChatOpenAI

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.FileHandler("a2a_mcp.log"), logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("A2A-MCP")


class A2AMCPSystem:
    def __init__(self):
        load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")

        logger.info("Initializing MultiServerMCPClient...")
        self.client = MultiServerMCPClient(
            {
                "math": {
                    "command": sys.executable,
                    "args": ["test/mathserver.py"],
                    "transport": "stdio",
                },
                "latency": {
                    "command": sys.executable,
                    "args": ["latency_server.py"],   # <-- Only change here
                    "transport": "stdio",
                }
            }
        )

        logger.info("Initializing Azure OpenAI...")
        self.model = AzureChatOpenAI(
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            deployment_name=os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini"),
            temperature=0.3,
        )

        self.agent = None

    async def setup(self):
        logger.info("Loading MCP tools...")
        tools = await self.client.get_tools()

        logger.info("Creating ReAct agent...")
        self.agent = create_react_agent(self.model, tools)

    async def ask(self, prompt: str):
        logger.info(f"Prompt: {prompt}")

        response = await self.agent.ainvoke(
            {"messages": [{"role": "user", "content": prompt}]}
        )

        # Correct extraction
        final_answer = response["messages"][-1]["content"]

        logger.info(f"Response: {final_answer}")
        return final_answer

    async def run_tests(self):
        print("\nMath Test:")
        print(await self.ask("what is (3 + 5) * 12?"))

        print("\nLatency Test:")
        print(await self.ask("Give latency data for UMS for day 2025-01-01"))


async def main():
    system = A2AMCPSystem()
    await system.setup()
    await system.run_tests()


if __name__ == "__main__":
    asyncio.run(main())
