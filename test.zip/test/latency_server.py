from fastmcp import FastMCP, tool
from pull_metric_api import fetch_latency_report
from typing import Optional, List, Dict, Any
import json

# Initialize MCP server
mcp = FastMCP("latency_server")

@tool
def get_latency_data(
    day: Optional[str] = None,
    days: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    app: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch latency report from API with optional filters.
    """
    try:
        return fetch_latency_report(day, days, start_date, end_date, app)
    except Exception as e:
        return {"error": str(e)}

@tool
def get_latency_data_pretty(
    app: Optional[str] = None,
    day: Optional[str] = None
) -> str:
    """
    Return readable JSON text for latency report.
    """
    try:
        data = fetch_latency_report(day=day, app=app)
        return json.dumps(data, indent=2)
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    print("🚀 Starting Latency MCP Server...")
    mcp.run(transport="stdio")
