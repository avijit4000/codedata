import os
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
from LLM.prompts.llm_template import prompTemplate

from langchain.memory import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder


promptemplate=prompTemplate()
store = {}

class FormAssistant:
    def __init__(self):
        load_dotenv()
        self.azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.api_key        = os.getenv("AZURE_OPENAI_API_KEY")
        self.api_version    = os.getenv("AZURE_OPENAI_API_VERSION")
        self.azure_model    = os.getenv("AZURE_OAI_MODEL")
        self.llm = AzureChatOpenAI(
            openai_api_key=self.api_key,
            azure_endpoint=self.azure_endpoint,
            azure_deployment=self.azure_model,
            api_version=self.api_version,
            temperature=0.0
        )

    def generate_question(self, user_input):

        question_template = promptemplate.question_ask(user_input)

        prompt = PromptTemplate(
            input_variables=["user_input"],
            template=question_template
        )
        asking_chain = LLMChain(
            llm=self.llm,
            prompt=prompt,
            verbose=False
        )
        asking_result = asking_chain.run(user_input=user_input)
        return asking_result.strip()
    
    @staticmethod
    def get_session_history(session_id: str):
        if session_id not in store:
            store[session_id] = ChatMessageHistory()
        return store[session_id]

    def extract_answer(self, asking_question, user_ans):
        ans_template = promptemplate.question_answer(asking_question, user_ans)

        prompt = ChatPromptTemplate.from_messages([
            ("system", ans_template),
            MessagesPlaceholder(variable_name="history"),
            ("human", "{input}")
        ])

        chain = prompt | self.llm
        
        with_memory = RunnableWithMessageHistory(
            chain,
            FormAssistant.get_session_history,  # Correct static method reference
            input_messages_key="input",
            history_messages_key="history",
        )

        config = {"configurable": {"session_id": "user1"}}

        with_memory.invoke({"input": user_ans}, config=config)

        response = with_memory.invoke({"input": asking_question}, config=config)
        ans_result=response.content
        return ans_result.strip()
