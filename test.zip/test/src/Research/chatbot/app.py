# import os
# from flask import Flask, render_template, request, jsonify
# from langchain_openai import AzureChatOpenAI
# from langchain.memory import ConversationBufferMemory
# from langchain.chains import ConversationChain
# from dotenv import load_dotenv
#
# load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")
#
# app = Flask(__name__)
#
# def build_chatbot():
#     api_key = os.getenv("AZURE_OPENAI_API_KEY")
#     endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
#     deployment = os.getenv("AZURE_OAI_MODEL")  # matches your .env
#     api_version = os.getenv("AZURE_OPENAI_API_VERSION")
#
#     if not all([api_key, endpoint, deployment, api_version]):
#         raise RuntimeError("Missing Azure OpenAI environment variables!")
#
#     llm = AzureChatOpenAI(
#         openai_api_key=api_key,
#         azure_endpoint=endpoint,
#         deployment_name=deployment,
#         openai_api_version=api_version,
#         temperature=0.7,
#     )
#     memory = ConversationBufferMemory()
#     return ConversationChain(llm=llm, memory=memory, verbose=False)
#
# chatbot = build_chatbot()
#
# @app.route("/")
# def home():
#     return render_template("index.html")
#
# @app.route("/chat", methods=["POST"])
# def chat():
#     user_input = request.json.get("message", "")
#     if not user_input:
#         return jsonify({"reply": "Please say something!"})
#
#     reply = chatbot.run(user_input)
#     return jsonify({"reply": reply})
#
# if __name__ == "__main__":
#     app.run(debug=True)


import os
from flask import Flask, request, jsonify
from langchain_openai import AzureChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from dotenv import load_dotenv
load_dotenv(dotenv_path="D:/Pyn/Test_work/LLMs/.env")

app = Flask(__name__)

def build_chatbot():
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OAI_MODEL")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")

    if not all([api_key, endpoint, deployment, api_version]):
        raise RuntimeError("Missing Azure OpenAI environment variables!")

    llm = AzureChatOpenAI(
        openai_api_key=api_key,
        azure_endpoint=endpoint,
        deployment_name=deployment,
        openai_api_version=api_version,
        temperature=0.7,
    )
    memory = ConversationBufferMemory()
    return ConversationChain(llm=llm, memory=memory, verbose=False)

chatbot = build_chatbot()

@app.route("/")
def health_check():
    return jsonify({"status": "ok", "message": "Chatbot API is running!"})

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("message", "") if data else ""

    if not user_input:
        return jsonify({"error": "Please provide a 'message' field in JSON body"}), 400

    reply = chatbot.run(user_input)
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True, port=5000)

