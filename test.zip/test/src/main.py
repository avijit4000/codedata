from flask import Flask, request, jsonify
from utils.logging import logger 
from LLM.llm_azure import FormAssistant

app = Flask(__name__)

assistant = FormAssistant()

@app.route('/ask_question', methods=['POST'])
def ask_question():
    data = request.json
    user_input = data.get('field_name')
    logger.info(f"Received field_name: {user_input}")
    asking_question = assistant.generate_question(user_input)
    logger.info(f"Generated question: {asking_question}")
    return jsonify({"question": asking_question})


@app.route('/extract_answer', methods=['POST'])
def extract_answer():
    data = request.json
    asking_question = data.get('asking_question')
    user_ans = data.get('user_answer')
    logger.info(f"Received asking_question: {asking_question}")
    logger.info(f"Received user_answer: {user_ans}")
    ans_output = assistant.extract_answer(asking_question, user_ans)
    logger.info(f"Extracted answer: {ans_output}")
    return jsonify({"extracted_answer": ans_output})


if __name__ == '__main__':
    logger.info("Starting Flask API server on http://0.0.0.0:8080")
    app.run(host='0.0.0.0', port=8080, debug=True, use_reloader=True)


