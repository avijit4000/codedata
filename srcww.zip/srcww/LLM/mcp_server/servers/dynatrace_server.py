"""
Dynatrace MCP Server
Provides tools for fetching and analyzing Dynatrace problems and metrics
"""
import sys
import os
from pathlib import Path

# Get the project root directory and add to path
# PROJECT_ROOT = Path(__file__).parent.parent.parent.parent
# sys.path.insert(0, str(PROJECT_ROOT / "src"))

from mcp.server.fastmcp import FastMCP
from typing import Optional, List, Dict, Any
import json

# Import Dynatrace API wrapper from same directory
from dynatrace_api import dynatrace_api

# Initialize MCP server
mcp = FastMCP("dynatrace_server", stateless_http=True)


@mcp.tool()
def get_dynatrace_problems(
    from_time: str = "now-2h",
    to_time: Optional[str] = None,
    problem_selector: Optional[str] = None
) -> Dict[str, Any]:
    """Fetch problems from Dynatrace within a specified time range with optional filtering."""
    try:
        problems = dynatrace_api.fetch_problems(
            from_time=from_time,
            to_time=to_time,
            problem_selector=problem_selector
        )
        
        if isinstance(problems, dict) and "error" in problems:
            return problems
        
        summary = dynatrace_api.get_problem_summary(problems)
        
        return {
            "status": "success",
            "time_range": {"from": from_time, "to": to_time or "now"},
            "summary": summary
        }
    except Exception as e:
        return {"error": f"Failed to fetch problems: {str(e)}"}


@mcp.tool()
def get_dynatrace_problem_details(problem_id: str) -> Dict[str, Any]:
    """Fetch detailed information about a specific Dynatrace problem including affected entities and evidence."""
    try:
        details = dynatrace_api.fetch_problem_details(problem_id)
        return {
            "status": "success",
            "problem_details": details
        }
    except Exception as e:
        return {"error": f"Failed to fetch problem details: {str(e)}"}


@mcp.tool()
def analyze_dynatrace_problem(problem_id: str) -> Dict[str, Any]:
    """Perform comprehensive analysis of a Dynatrace problem including affected entities, root cause, and evidence."""
    try:
        analysis = dynatrace_api.analyze_problem(problem_id)
        return {
            "status": "success",
            "analysis": analysis
        }
    except Exception as e:
        return {"error": f"Failed to analyze problem: {str(e)}"}


@mcp.tool()
def get_dynatrace_metrics(
    metric_selector: str,
    from_time: str = "now-2h",
    to_time: Optional[str] = None,
    resolution: Optional[str] = None
) -> Dict[str, Any]:
    """Fetch metrics from Dynatrace using a metric selector query with optional time range and resolution."""
    try:
        metrics = dynatrace_api.fetch_metrics(
            metric_selector=metric_selector,
            from_time=from_time,
            to_time=to_time,
            resolution=resolution
        )
        return {
            "status": "success",
            "metric_selector": metric_selector,
            "time_range": {"from": from_time, "to": to_time or "now"},
            "metrics": metrics
        }
    except Exception as e:
        return {"error": f"Failed to fetch metrics: {str(e)}"}


@mcp.tool()
def get_dynatrace_problems_summary(from_time: str = "now-24h") -> str:
    """Get a human-readable summary of Dynatrace problems categorized by severity, status, and impact level."""
    try:
        problems = dynatrace_api.fetch_problems(from_time=from_time)
        
        if isinstance(problems, dict) and "error" in problems:
            return json.dumps(problems, indent=2)
        
        summary = dynatrace_api.get_problem_summary(problems)
        
        output = [
            f"=== Dynatrace Problems Summary (from {from_time}) ===\n",
            f"Total Problems: {summary['total_problems']}\n",
            "\nBy Severity:",
        ]
        
        for severity, count in summary['by_severity'].items():
            output.append(f"  - {severity}: {count}")
        
        output.append("\nBy Status:")
        for status, count in summary['by_status'].items():
            output.append(f"  - {status}: {count}")
        
        output.append("\nBy Impact Level:")
        for impact, count in summary['by_impact_level'].items():
            output.append(f"  - {impact}: {count}")
        
        output.append("\n\nRecent Problems:")
        for i, problem in enumerate(summary['problems'][:10], 1):
            output.append(
                f"\n{i}. [{problem['displayId']}] {problem['title']}\n"
                f"   Status: {problem['status']} | Severity: {problem['severity']}\n"
                f"   Affected Entities: {problem['affectedEntities']}"
            )
        
        if len(summary['problems']) > 10:
            output.append(f"\n... and {len(summary['problems']) - 10} more problems")
        
        return "\n".join(output)
    except Exception as e:
        return f"Error: Failed to generate summary - {str(e)}"


@mcp.tool()
def search_dynatrace_problems_by_entity(
    entity_type: str,
    from_time: str = "now-24h"
) -> Dict[str, Any]:
    """Search and filter Dynatrace problems by entity type (SERVICE, APPLICATION, HOST, PROCESS_GROUP)."""
    try:
        problems = dynatrace_api.fetch_problems(from_time=from_time)
        
        if isinstance(problems, dict) and "error" in problems:
            return problems
        
        filtered_problems = []
        for problem in problems:
            for entity in problem.get("affectedEntities", []):
                if entity.get("entityId", {}).get("type") == entity_type.upper():
                    filtered_problems.append({
                        "problemId": problem.get("problemId"),
                        "displayId": problem.get("displayId"),
                        "title": problem.get("title"),
                        "status": problem.get("status"),
                        "severity": problem.get("severityLevel"),
                        "entity": entity.get("name")
                    })
                    break
        
        return {
            "status": "success",
            "entity_type": entity_type,
            "total_problems": len(filtered_problems),
            "problems": filtered_problems
        }
    except Exception as e:
        return {"error": f"Failed to search problems: {str(e)}"}


# if __name__ == "__main__":
#     print("Starting Dynatrace MCP Server...")
#     mcp.run(transport="stdio")
