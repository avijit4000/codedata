"""
Dynatrace API wrapper for fetching problems and analyzing data
Simplified version for MCP integration
"""
import requests
from typing import Optional, List, Dict, Any
from datetime import datetime
import sys
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Dynatrace Configuration - Load directly from environment
DYNATRACE_API_TOKEN = os.getenv("DYNATRACE_API_TOKEN", "")
DYNATRACE_ENDPOINT = os.getenv("DYNATRACE_ENDPOINT", "")
# Dynatrace API settings
#DYNATRACE_API_TOKEN = os.getenv("AI_TRIAGE_DYNATRACE_API_TOKEN")

#CERT_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'standard_trusts.pem')

CERT_PATH = Path(__file__).parent / "standard_trusts.pem"
print("CERT_PATH",CERT_PATH)
API_PAGE_SIZE = 500
API_TIMEOUT = 30


class DynatraceAPI:
    """Wrapper class for Dynatrace API operations"""
    
    def __init__(self):
        self.api_token = DYNATRACE_API_TOKEN
        self.endpoint = DYNATRACE_ENDPOINT
        self.cert_path = str(CERT_PATH)
        self.headers = {
            'Authorization': f'Api-Token {self.api_token}',
            'Content-Type': 'application/json',
        }
    
    def fetch_problems(
        self, 
        from_time: str = "now-2h", 
        to_time: Optional[str] = None,
        problem_selector: Optional[str] = None,
        page_size: int = API_PAGE_SIZE
    ) -> List[Dict[str, Any]]:
        """Fetch problems from Dynatrace within a specified time range."""
        try:
            problems_url = f'{self.endpoint}/problems?pageSize={page_size}&from={from_time}&sort=-startTime'
            
            if to_time:
                problems_url += f'&to={to_time}'
            
            if problem_selector:
                problems_url += f'&problemSelector={problem_selector}'
            
            response = requests.get(
                problems_url, 
                headers=self.headers, 
                verify=self.cert_path,
                timeout=API_TIMEOUT
            )
            
            if response.status_code == 200:
                data = response.json()
                problems = data.get("problems", [])
                return problems
            else:
                return {
                    "error": f"Failed to fetch problems: {response.status_code}",
                    "details": response.text
                }
        except Exception as e:
            return {"error": f"Exception occurred: {str(e)}"}
    
    def fetch_problem_details(self, problem_id: str) -> Dict[str, Any]:
        """Fetch detailed information about a specific problem by problem ID."""
        try:
            problem_url = f'{self.endpoint}/problems/{problem_id}'
            response = requests.get(
                problem_url, 
                headers=self.headers, 
                verify=self.cert_path,
                timeout=API_TIMEOUT
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {
                    "error": f"Failed to fetch problem details: {response.status_code}",
                    "details": response.text
                }
        except Exception as e:
            return {"error": f"Exception occurred: {str(e)}"}
    
    def fetch_metrics(
        self,
        metric_selector: str,
        from_time: str = "now-2h",
        to_time: Optional[str] = None,
        resolution: Optional[str] = None
    ) -> Dict[str, Any]:
        """Fetch metrics from Dynatrace using metric selector query."""
        try:
            metrics_url = f'{self.endpoint}/metrics/query?metricSelector={metric_selector}&from={from_time}'
            
            if to_time:
                metrics_url += f'&to={to_time}'
            
            if resolution:
                metrics_url += f'&resolution={resolution}'
            
            response = requests.get(
                metrics_url, 
                headers=self.headers, 
                verify=self.cert_path,
                timeout=API_TIMEOUT
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {
                    "error": f"Failed to fetch metrics: {response.status_code}",
                    "details": response.text
                }
        except Exception as e:
            return {"error": f"Exception occurred: {str(e)}"}
    
    def get_problem_summary(self, problems: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary of problems with counts and categorization."""
        if isinstance(problems, dict) and "error" in problems:
            return problems
        
        summary = {
            "total_problems": len(problems),
            "by_severity": {},
            "by_status": {},
            "by_impact_level": {},
            "problems": []
        }
        
        for problem in problems:
            # Count by severity
            severity = problem.get("severityLevel", "UNKNOWN")
            summary["by_severity"][severity] = summary["by_severity"].get(severity, 0) + 1
            
            # Count by status
            status = problem.get("status", "UNKNOWN")
            summary["by_status"][status] = summary["by_status"].get(status, 0) + 1
            
            # Count by impact level
            impact = problem.get("impactLevel", "UNKNOWN")
            summary["by_impact_level"][impact] = summary["by_impact_level"].get(impact, 0) + 1
            
            # Add simplified problem info
            summary["problems"].append({
                "problemId": problem.get("problemId"),
                "displayId": problem.get("displayId"),
                "title": problem.get("title"),
                "status": status,
                "severity": severity,
                "impactLevel": impact,
                "startTime": problem.get("startTime"),
                "endTime": problem.get("endTime"),
                "affectedEntities": len(problem.get("affectedEntities", []))
            })
        
        return summary
    
    def analyze_problem(self, problem_id: str) -> Dict[str, Any]:
        """Perform detailed analysis of a specific problem including entities and evidence."""
        details = self.fetch_problem_details(problem_id)
        
        if isinstance(details, dict) and "error" in details:
            return details
        
        analysis = {
            "problemId": problem_id,
            "displayId": details.get("displayId"),
            "title": details.get("title"),
            "status": details.get("status"),
            "severityLevel": details.get("severityLevel"),
            "impactLevel": details.get("impactLevel"),
            "startTime": details.get("startTime"),
            "endTime": details.get("endTime"),
            "affected_entities": [],
            "root_cause": details.get("rootCauseEntity"),
            "evidence_summary": []
        }
        
        # Extract affected entities
        for entity in details.get("affectedEntities", []):
            analysis["affected_entities"].append({
                "name": entity.get("name"),
                "type": entity.get("entityId", {}).get("type"),
                "id": entity.get("entityId", {}).get("id")
            })
        
        # Extract evidence details
        evidence = details.get("evidenceDetails", {})
        if "details" in evidence:
            for detail in evidence["details"]:
                analysis["evidence_summary"].append({
                    "displayName": detail.get("displayName"),
                    "entity": detail.get("entity", {}).get("name"),
                    "rootCauseRelevant": detail.get("rootCauseRelevant", False)
                })
        
        return analysis


# Create global instance
dynatrace_api = DynatraceAPI()
