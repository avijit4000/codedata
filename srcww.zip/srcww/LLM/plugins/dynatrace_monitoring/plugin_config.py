"""
Dynatrace Monitoring Plugin Configuration
This file registers the Dynatrace functions with the MCPPlugin framework.
"""
from src.LLM.plugins.dynatrace_monitoring.dynatrace_functions import (
    get_problems,
    get_problem_details,
    get_problem_summary,
    analyze_problem,
    get_metrics,
    get_open_problems,
    get_problems_pretty,
    get_critical_problems
)
from src.LLM.plugins.MCPPlugin import MCPPlugin


# Create the Dynatrace monitoring plugin instance
dynatrace_plugin = MCPPlugin(
    name="dynatrace_monitoring_plugin",
    description="Plugin to monitor and analyze Dynatrace problems, metrics, and incidents",
    functions={
        "get_problems": get_problems,
        "get_problem_details": get_problem_details,
        "get_problem_summary": get_problem_summary,
        "analyze_problem": analyze_problem,
        "get_metrics": get_metrics,
        "get_open_problems": get_open_problems,
        "get_problems_pretty": get_problems_pretty,
        "get_critical_problems": get_critical_problems,
    }
)


if __name__ == "__main__":
    print("Starting Dynatrace Monitoring Plugin MCP Server...")
    print(f"Registered functions: {', '.join(dynatrace_plugin.list_registered())}")
    dynatrace_plugin.mcp.run(transport="stdio")
