"""
Dynatrace monitoring plugin functions.
These functions wrap the DynatraceAPI class to provide simple, 
callable interfaces for MCP integration.
"""
from typing import Optional, List, Dict, Any
import json
from src.LLM.mcp_server.servers.dynatrace_api import dynatrace_api


def get_problems(
    from_time: str = "now-2h",
    to_time: Optional[str] = None,
    problem_selector: Optional[str] = None,
    page_size: int = 500
) -> Dict[str, Any]:
    """
    Fetch problems from Dynatrace within a specified time range.
    
    Args:
        from_time: Start time for problem query (e.g., 'now-2h', 'now-24h', or timestamp)
        to_time: End time for problem query (optional)
        problem_selector: Dynatrace problem selector query for filtering (optional)
        page_size: Maximum number of problems to return (default: 500)
    
    Returns:
        Dictionary containing list of problems or error information
    
    Examples:
        - get_problems()  # Get problems from last 2 hours
        - get_problems(from_time="now-24h")  # Last 24 hours
        - get_problems(from_time="now-1w", problem_selector="status(OPEN)")
    """
    try:
        problems = dynatrace_api.fetch_problems(
            from_time=from_time,
            to_time=to_time,
            problem_selector=problem_selector,
            page_size=page_size
        )
        return {"success": True, "problems": problems, "count": len(problems) if isinstance(problems, list) else 0}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_problem_details(problem_id: str) -> Dict[str, Any]:
    """
    Fetch detailed information about a specific problem by problem ID.
    
    Args:
        problem_id: The unique problem ID from Dynatrace
    
    Returns:
        Dictionary containing detailed problem information including affected entities,
        evidence details, root cause, and timeline
    
    Example:
        - get_problem_details("P-12345")
    """
    try:
        details = dynatrace_api.fetch_problem_details(problem_id)
        return details
    except Exception as e:
        return {"error": str(e)}


def get_problem_summary(
    from_time: str = "now-2h",
    to_time: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get a summary of problems with counts categorized by severity, status, and impact.
    
    Args:
        from_time: Start time for problem query (e.g., 'now-2h', 'now-24h')
        to_time: End time for problem query (optional)
    
    Returns:
        Dictionary containing:
        - total_problems: Total count of problems
        - by_severity: Count grouped by severity level
        - by_status: Count grouped by status (OPEN, CLOSED, etc.)
        - by_impact_level: Count grouped by impact level
        - problems: List of simplified problem information
    
    Example:
        - get_problem_summary()  # Summary of last 2 hours
        - get_problem_summary(from_time="now-1d")  # Last day summary
    """
    try:
        problems = dynatrace_api.fetch_problems(from_time=from_time, to_time=to_time)
        summary = dynatrace_api.get_problem_summary(problems)
        return summary
    except Exception as e:
        return {"error": str(e)}


def analyze_problem(problem_id: str) -> Dict[str, Any]:
    """
    Perform comprehensive analysis of a specific problem including affected entities,
    evidence details, and root cause information.
    
    Args:
        problem_id: The unique problem ID from Dynatrace
    
    Returns:
        Dictionary containing:
        - Basic problem info (ID, title, status, severity, impact)
        - affected_entities: List of entities impacted by the problem
        - root_cause: Root cause entity information
        - evidence_summary: List of evidence items with relevance indicators
    
    Example:
        - analyze_problem("P-12345")
    """
    try:
        analysis = dynatrace_api.analyze_problem(problem_id)
        return analysis
    except Exception as e:
        return {"error": str(e)}


def get_metrics(
    metric_selector: str,
    from_time: str = "now-2h",
    to_time: Optional[str] = None,
    resolution: Optional[str] = None
) -> Dict[str, Any]:
    """
    Fetch metrics from Dynatrace using metric selector query.
    
    Args:
        metric_selector: Dynatrace metric selector query (e.g., 'builtin:host.cpu.usage')
        from_time: Start time for metrics (e.g., 'now-2h', 'now-24h')
        to_time: End time for metrics (optional)
        resolution: Data resolution (e.g., '1m', '5m', '1h') (optional)
    
    Returns:
        Dictionary containing metric data points and metadata
    
    Examples:
        - get_metrics("builtin:host.cpu.usage")
        - get_metrics("builtin:service.response.time", from_time="now-1h", resolution="1m")
    """
    try:
        metrics = dynatrace_api.fetch_metrics(
            metric_selector=metric_selector,
            from_time=from_time,
            to_time=to_time,
            resolution=resolution
        )
        return metrics
    except Exception as e:
        return {"error": str(e)}


def get_open_problems(from_time: str = "now-24h") -> Dict[str, Any]:
    """
    Get all currently open problems from Dynatrace.
    
    Args:
        from_time: Start time for problem query (default: last 24 hours)
    
    Returns:
        Dictionary containing list of open problems with summary
    
    Example:
        - get_open_problems()  # Open problems from last 24 hours
        - get_open_problems(from_time="now-7d")  # Open problems from last week
    """
    try:
        problems = dynatrace_api.fetch_problems(
            from_time=from_time,
            problem_selector="status(OPEN)"
        )
        summary = dynatrace_api.get_problem_summary(problems)
        return {
            "success": True,
            "open_problems": summary.get("total_problems", 0),
            "details": summary
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_problems_pretty(
    from_time: str = "now-2h",
    to_time: Optional[str] = None
) -> str:
    """
    Get problems in a pretty-printed JSON format for easy reading.
    
    Args:
        from_time: Start time for problem query
        to_time: End time for problem query (optional)
    
    Returns:
        Formatted JSON string containing problem summary
    
    Example:
        - get_problems_pretty()
        - get_problems_pretty(from_time="now-24h")
    """
    try:
        summary = get_problem_summary(from_time=from_time, to_time=to_time)
        return json.dumps(summary, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, indent=2)


def get_critical_problems(from_time: str = "now-24h") -> Dict[str, Any]:
    """
    Get all problems with CRITICAL severity level.
    
    Args:
        from_time: Start time for problem query (default: last 24 hours)
    
    Returns:
        Dictionary containing list of critical problems
    
    Example:
        - get_critical_problems()
        - get_critical_problems(from_time="now-7d")
    """
    try:
        problems = dynatrace_api.fetch_problems(
            from_time=from_time,
            problem_selector="severityLevel(CRITICAL)"
        )
        if isinstance(problems, list):
            return {
                "success": True,
                "critical_problems_count": len(problems),
                "problems": problems
            }
        else:
            return problems
    except Exception as e:
        return {"success": False, "error": str(e)}
