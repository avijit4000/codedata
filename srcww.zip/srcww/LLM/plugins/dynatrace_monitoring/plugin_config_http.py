"""
Dynatrace Monitoring Plugin Configuration - HTTP/SSE Mode
This file runs the Dynatrace plugin as an HTTP server using Server-Sent Events (SSE)
"""
import os
from src.LLM.plugins.dynatrace_monitoring.dynatrace_functions import (
    get_problems,
    get_problem_details,
    get_problem_summary,
    analyze_problem,
    get_metrics,
    get_open_problems,
    get_problems_pretty,
    get_critical_problems
)
from src.LLM.plugins.MCPPlugin import MCPPlugin


# Create the Dynatrace monitoring plugin instance
dynatrace_plugin = MCPPlugin(
    name="dynatrace_http",
    description="Plugin to monitor and analyze Dynatrace problems, metrics, and incidents via HTTP",
    functions={
        "get_problems": get_problems,
        "get_problem_details": get_problem_details,
        "get_problem_summary": get_problem_summary,
        "analyze_problem": analyze_problem,
        "get_metrics": get_metrics,
        "get_open_problems": get_open_problems,
        "get_problems_pretty": get_problems_pretty,
        "get_critical_problems": get_critical_problems,
    }
)


if __name__ == "__main__":
    print("=" * 70)
    print("Starting Dynatrace MCP Server on HTTP")
    print("=" * 70)
    print(f"Server Name: {dynatrace_plugin.name}")
    print(f"Transport: HTTP (SSE)")
    print(f"Port: 8003")
    print(f"URL: http://localhost:8003")
    print(f"Registered Functions: {len(dynatrace_plugin.list_registered())}")
    print("\nAvailable Tools:")
    for func_name in dynatrace_plugin.list_registered():
        print(f"  - {func_name}")
    print("\n" + "=" * 70)
    print("Server is running... Press Ctrl+C to stop")
    print("=" * 70)
    print()
    
    # Set the port using environment variable
    os.environ["FASTMCP_PORT"] = "8003"
    
    # Run FastMCP with streamable-http transport
    dynatrace_plugin.mcp.run(transport="streamable-http")
