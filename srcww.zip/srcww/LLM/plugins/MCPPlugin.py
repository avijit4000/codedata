from typing import Callable, Dict, Iterable, Optional
from importlib import import_module
from mcp.server.fastmcp import FastMCP


class MCPPlugin:
    """Plugin wrapper to expose Python callables to an MCP server.

    This class acts as a small registry for developer functions and
    registers them with a FastMCP instance. Developers can bring
    functions from their scripts and pass them in a dictionary, or
    use the helpers below to load modules dynamically.

    Example:
        from my_metrics import fetch_latency, compute_summary

        plugin = MCPPlugin(
            name="latency_plugin",
            description="Latency metrics for service X",
            functions={
                "fetch_latency": fetch_latency,
                "compute_summary": compute_summary,
            }
        )
        plugin.run()
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        functions: Optional[Dict[str, Callable]] = None,
    ) -> None:
        """Create a new MCPPlugin.

        Args:
            name: Short plugin name used to identify the MCP tool.
            description: Human-friendly description of the plugin.
            functions: Optional mapping of function name to callable.
        """
        if not isinstance(name, str) or not name:
            raise ValueError("`name` must be a non-empty string")

        self.name = name
        self.description = description or ""
        self.functions: Dict[str, Callable] = {}
        self.mcp = FastMCP(self.name)

        if functions:
            self.register_functions(functions)

    # -- Registration helpers -------------------------------------------------
    def register_function(self, func: Callable, alias: Optional[str] = None) -> None:
        """Register a single callable with the plugin and MCP server.

        Args:
            func: A Python callable to register.
            alias: Optional name to register the callable under; defaults to
                   the callable's __name__.
        """
        if not callable(func):
            raise TypeError("`func` must be callable")

        name = alias or getattr(func, "__name__", None)
        if not name:
            raise ValueError("Unable to determine a name for the function")

        # store locally and register with FastMCP
        self.functions[name] = func
        self.mcp.tool()(func)

    def register_functions(self, functions: Dict[str, Callable]) -> None:
        """Bulk register functions from a mapping.

        Accepts either name->callable maps or callable values where the key
        will be used as the registration name.
        """
        if not isinstance(functions, dict):
            raise TypeError("`functions` must be a dict of name->callable")

        for key, func in functions.items():
            # if the dict value is a callable and key is the name, prefer key
            if callable(func):
                self.register_function(func, alias=str(key))
            else:
                raise TypeError(f"Value for key '{key}' is not callable")

    def list_registered(self) -> Iterable[str]:
        """Return the names of registered functions."""
        return list(self.functions.keys())

    # -- Dynamic import helpers -----------------------------------------------
    @staticmethod
    def import_functions_from_module(module_path: str, names: Optional[Iterable[str]] = None) -> Dict[str, Callable]:
        """Import functions from a module path and return a name->callable dict.

        Args:
            module_path: Python import path (e.g. 'my_package.metrics').
            names: Optional list of attribute names to import. If omitted,
                   all callables that do not start with '_' are returned.
        """
        module = import_module(module_path)
        result: Dict[str, Callable] = {}
        if names:
            for n in names:
                attr = getattr(module, n)
                if callable(attr):
                    result[n] = attr
                else:
                    raise TypeError(f"Attribute '{n}' in {module_path} is not callable")
        else:
            for attr_name in dir(module):
                if attr_name.startswith("_"):
                    continue
                attr = getattr(module, attr_name)
                if callable(attr):
                    result[attr_name] = attr
        return result

    # -- Runtime ---------------------------------------------------------------
    def run(self, transport: str = "stdio") -> None:
        """Start the underlying FastMCP server.

        Args:
            transport: Transport to use when running FastMCP (default 'stdio').
        """
        self.mcp.run(transport=transport)

