from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import AzureOpenAI
import requests
import os
import logging
from logging.handlers import RotatingFileHandler
from dotenv import load_dotenv
import uvicorn
import traceback
# from datetime import datetime


load_dotenv()
azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_key = os.getenv("AZURE_OPENAI_API_KEY")
api_version = os.getenv("AZURE_OPENAI_API_VERSION")
azure_model = os.getenv("AZURE_OAI_MODEL", "gpt-4o-mini")

os.makedirs("logs", exist_ok=True)


log_file_path = "logs/app.log"
log_formatter = logging.Formatter(
    "%(asctime)s - %(levelname)s - User: system - Role: admin - Tenant: default : %(message)s"
)

file_handler = RotatingFileHandler(log_file_path, maxBytes=5_000_000, backupCount=3)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.INFO)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(file_handler)

app = FastAPI()

class SummaryRequest(BaseModel):
    api_url: str

class CallSummaryGenerator:
    def __init__(self):
        self.client = AzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version
        )
        logger.info("Application started")

    def fetch_call_summary(self, api_url: str) -> str:
        try:
            response = requests.get(api_url, timeout=10)
            response.raise_for_status()
            data = response.json()
            last_value = str(list(list(data[0].items())[-1])[-1])
            logger.info("Call summary fetched successfully.")
            return last_value
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(status_code=400, detail=f"Failed to fetch call summary: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(status_code=500, detail="Unexpected error while processing the call summary.")

    def generate_summary(self, conversation_summary: str) -> str:
        prompt = f"""
You are a summarization assistant. Your task is to turn the following medical service conversation summary into a short, clear, and user-focused explanation, addressing the reader directly ("you") and making the information easy to understand.

Guidelines:
- Carefully read the summary and infer the most likely context for the conversation, such as the user contacting us to inquire, confirm, or clarify something.
- Begin the summary with a phrase that gives context for the user's inquiry, such as "You contacted us to inquire about..." or "You reached out to confirm...", even if the input does not specify this directly.
- Rewrite all information in the second person, speaking to "you" (do not refer to the member, recipient, customer, or user in the third person).
- Use a respectful, supportive, and friendly tone.
- Clearly state what was confirmed, clarified, or explained, highlighting important benefits, eligibility details, and actions taken for you.
- Emphasize significant outcomes or protections using plain language and attention phrases such as:
  - "Please note..."
  - "You should know that..."
  - "It's important to understand..."
  - "You are eligible for..."
- If gratitude or appreciation is expressed in the conversation, reflect that in your summary.
- Avoid technical jargon, repetitive wording, or overly long explanations.
- Keep the summary concise (2 to 4 sentences), in a single continuous paragraph, and suitable for display to the user.

Conversation Summary:
{conversation_summary}

Rewrite the above as a user-focused summary. Begin by stating the user's inquiry, then summarize the key findings, clarifications, or benefits, highlighting critical points for the user's attention:
"""
        try:
            messages = [
                {"role": "system", "content": "You are a helpful summarization assistant."},
                {"role": "user", "content": prompt}
            ]
            response = self.client.chat.completions.create(
                model=azure_model,
                messages=messages,
                temperature=0.4
            )
            summary = response.choices[0].message.content.strip()
            logger.info("Summary generated successfully.")
            return summary
        except Exception as e:
            logger.error(f"OpenAI summarization error: {str(e)}\n{traceback.format_exc()}")
            raise HTTPException(status_code=500, detail="Error generating summary using AzureOpenAI.")

summary_generator = CallSummaryGenerator()

@app.post("/summary/", summary="Generate a user-friendly summary")
async def get_summary(request: SummaryRequest):
    logger.info(f"Received request for summary generation: {request.api_url}")
    try:
        conversation_data = summary_generator.fetch_call_summary(request.api_url)
        summary = summary_generator.generate_summary(conversation_data)
        return {"consumer_friendly_summary": summary}
    except HTTPException as http_ex:
        logger.warning(f"Handled HTTPException: {http_ex.detail}")
        raise http_ex
    except Exception as e:
        logger.error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)


