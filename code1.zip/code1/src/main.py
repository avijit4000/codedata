from fastapi import FastAPI, HTTPException
from src.components.logger import logger
from src.llm.llm_model import SummaryRequest
import uvicorn

app = FastAPI()

@app.post("/summary/", summary="Generate a user-friendly summary")
async def get_summary(request: SummaryRequest):
    logger.info(f"Received request for summary generation: {request.api_url}")
    try:
        conversation_data = summary_generator.fetch_call_summary(request.api_url)
        summary = summary_generator.generate_summary(conversation_data)
        return {"consumer_friendly_summary": summary}
    except HTTPException as http_ex:
        logger.warning(f"Handled HTTPException: {http_ex.detail}")
        raise http_ex
    except Exception as e:
        logger.error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)