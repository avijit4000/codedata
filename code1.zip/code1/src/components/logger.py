import os
import logging
from logging.handlers import RotatingFileHandler

current_dir = os.path.dirname(__file__)
logs_path = os.path.abspath(os.path.join(current_dir, "..", "..", "logs"))

os.makedirs(logs_path, exist_ok=True)

log_file_path = f"{logs_path}/app.log"
log_formatter = logging.Formatter(
    "%(asctime)s - %(levelname)s - User: system - Role: admin - Tenant: default : %(message)s"
)

file_handler = RotatingFileHandler(log_file_path, maxBytes=5_000_000, backupCount=3)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.INFO)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(file_handler)