def name():
    print("avijit biswas")
avi=name()

# print("avijit")

# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# app = FastAPI()
# class SummaryRequest(BaseModel):
#     api_url: str
# class CallSummaryGenerator:
#     def fetch_call_summary(self, api_url: str) -> str:
#         try:
#             response = requests.get(api_url, timeout=10)
#             response.raise_for_status()
#             data = response.json()
#             last_value = str(list(list(data[0].items())[-1])[-1])
#             logger.info("Call summary fetched successfully.")
#             return last_value


#
# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# import requests
# import logging
# import uvicorn
#
# # Initialize FastAPI app
# app = FastAPI()
#
# # Configure logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)
#
# # Request model
# class SummaryRequest(BaseModel):
#     api_url: str
#
# # Summary generator class
# class CallSummaryGenerator:
#     def fetch_call_summary(self, api_url: str) -> str:
#         try:
#             response = requests.get(api_url, timeout=10)
#             response.raise_for_status()
#             data = response.json()
#             last_value = str(list(list(data[0].items())[-1])[-1])
#             logger.info("Call summary fetched successfully.")
#             return last_value
#         except Exception as e:
#             logger.error(f"Error fetching call summary: {e}")
#             raise HTTPException(status_code=500, detail=str(e))
#
# # Endpoint
# @app.post("/get-summary/")
# def get_summary(request: SummaryRequest):
#     generator = CallSummaryGenerator()
#     summary = generator.fetch_call_summary(request.api_url)
#     return {"summary": summary}
#
# if __name__ == "__main__":
#     # Make sure the module name is correct (here it's app.py)
#     uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)



# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# import requests
# import uvicorn
#
# # Initialize FastAPI app
# app = FastAPI()
#
# # Request model
# class SummaryRequest(BaseModel):
#     api_url: str

# Summary generator class
# class CallSummaryGenerator:
#     def fetch_call_summary(self, api_url: str) -> str:
#         try:
#             response = requests.get(api_url, timeout=10)
#             response.raise_for_status()
#             data = response.json()
#             last_value = str(list(list(data[0].items())[-1])[-1])
#             return last_value
#         except Exception as e:
#             raise HTTPException(status_code=500, detail=str(e))
#
# class CallSummaryGenerator:
#     def fetch_call_summary(self, api_url: str) -> str:
#         try:
#             response = requests.get(api_url, timeout=10)
#             response.raise_for_status()
#             data = response.json()
#
#             # Extract agent summary
#             agent_summary = data[0].get("agent_summary", "")
#             if not agent_summary:
#                 raise ValueError("agent_summary not found in response")
#
#             # Convert to customer-friendly version
#             customer_summary = self.make_customer_friendly(agent_summary)
#             return customer_summary
#         except Exception as e:
#             raise HTTPException(status_code=500, detail=str(e))
#
#     def make_customer_friendly(self, summary: str) -> str:
#         # Simple transformation logic (you can replace with GPT/RAG model if needed)
#         return f"Here is a brief summary of your recent conversation:\n{summary}"
#
#
# # Endpoint
# @app.post("/get-summary/")
# def get_summary(request: SummaryRequest):
#     generator = CallSummaryGenerator()
#     summary = generator.fetch_call_summary(request.api_url)
#     return {"summary": summary}
#
# if __name__ == "__main__":
#     uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)
#
