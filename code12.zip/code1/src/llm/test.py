# import llm_model as lm
# print(lm.api_key)

from src.components import test2

print(test2.avi)
# name()


