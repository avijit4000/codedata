from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import AzureOpenAI
import requests
import os
import logging
from logging.handlers import RotatingFileHandler
from dotenv import load_dotenv
import uvicorn
import traceback
from src.components.logger import logger
from src.components import data_ingestion
from src.llm import llm_template
from src.llm import llm_model


promp=llm_template.promptem
thesummary= llm_model.summary
print(thesummary)


# app = FastAPI()

summary_data = data_ingestion.convert_data
print(summary_data)

# summary = summary_generator.generate_summary(promp)
# print({"the summary ": summary})
print("ok")
# convert_data=summary_data.fetch_call_summarytest(input_data)
print({"mydata":summary_data})
print("avijit ok")

@app.post("/summary/", summary="Generate a user-friendly summary")
async def get_summary(request: SummaryRequest):
    logger.info(f"Received request for summary generation: {request.api_url}")
    try:
        conversation_data = summary_generator.fetch_call_summary(request.api_url)
        summary = summary_generator.generate_summary(conversation_data)
        return {"consumer_friendly_summary": summary}
    except HTTPException as http_ex:
        logger.warning(f"Handled HTTPException: {http_ex.detail}")
        raise http_ex
    except Exception as e:
        logger.error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)


